package com.accumed.gtech.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.UserManager;
import com.accumed.gtech.thread.ThrChangestatus;
import com.accumed.gtech.thread.datamodel.ChangestatusThrDM;
import com.accumed.gtech.thread.datamodel.FriendListReturnDMSubDM;
import com.accumed.gtech.thread.datamodel.UserRequestReturnDM;
import com.accumed.gtech.util.LogCat;
import java.util.ArrayList;
import java.util.List;

public class FriendHoldListAp extends ArrayAdapter<UserRequestReturnDM> {
    static final String className = "FriendHoldListAp";
    ArrayList<Integer> clickList = new ArrayList();
    ArrayList<FriendListReturnDMSubDM> list;
    LogCat logCat = new LogCat();
    Context mContext;
    ArrayList<Integer> vList = new ArrayList();
    ViewHolder viewHolder;

    class ViewHolder {
        View parentView;

        public ViewHolder(View pv) {
            this.parentView = pv;
        }

        public TextView nameTv() {
            return (TextView) this.parentView.findViewById(C0213R.id.nameTv);
        }

        public TextView emailTv() {
            return (TextView) this.parentView.findViewById(C0213R.id.emailTv);
        }

        public Button allowBt() {
            return (Button) this.parentView.findViewById(C0213R.id.allowBt);
        }

        public Button denyBt() {
            return (Button) this.parentView.findViewById(C0213R.id.denyBt);
        }

        public LinearLayout detailLy0() {
            return (LinearLayout) this.parentView.findViewById(C0213R.id.detailLy0);
        }
    }

    public FriendHoldListAp(Context context, int textViewResourceId, List objects) {
        super(context, textViewResourceId, objects);
        this.mContext = context;
        this.list = new ArrayList();
        this.list = (ArrayList) objects;
    }

    public void setList(ArrayList<FriendListReturnDMSubDM> l) {
        this.list = l;
    }

    public int getCount() {
        return this.list.size();
    }

    public UserRequestReturnDM getItem(int position) {
        return (UserRequestReturnDM) super.getItem(position);
    }

    public long getItemId(int position) {
        return super.getItemId(position);
    }

    public View getView(int position, View convertview, ViewGroup parent) {
        final int posi = position;
        if (convertview == null) {
            convertview = ((Activity) this.mContext).getLayoutInflater().inflate(C0213R.layout.detail_user_hold, parent, false);
            this.viewHolder = new ViewHolder(convertview);
            convertview.setTag(this.viewHolder);
        } else {
            this.viewHolder = (ViewHolder) convertview.getTag();
        }
        this.viewHolder.nameTv().setText(((FriendListReturnDMSubDM) this.list.get(position)).name);
        this.viewHolder.emailTv().setText(((FriendListReturnDMSubDM) this.list.get(position)).friend);
        this.viewHolder.allowBt().setBackgroundDrawable(null);
        this.viewHolder.allowBt().setPaintFlags(this.viewHolder.allowBt().getPaintFlags() | 8);
        this.viewHolder.allowBt().setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                FriendHoldListAp.this.logCat.log(FriendHoldListAp.className, "onclick2", ((FriendListReturnDMSubDM) FriendHoldListAp.this.list.get(posi)).id);
                ChangestatusThrDM dm = new ChangestatusThrDM();
                dm.id = ((FriendListReturnDMSubDM) FriendHoldListAp.this.list.get(posi)).id;
                dm.command = ChangestatusThrDM.USER_ALLOW;
                new ThrChangestatus(FriendHoldListAp.this.mContext, dm, (UserManager) FriendHoldListAp.this.mContext, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
            }
        });
        this.viewHolder.denyBt().setBackgroundDrawable(null);
        this.viewHolder.denyBt().setPaintFlags(this.viewHolder.denyBt().getPaintFlags() | 8);
        this.viewHolder.denyBt().setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                FriendHoldListAp.this.logCat.log(FriendHoldListAp.className, "onclick2", ((FriendListReturnDMSubDM) FriendHoldListAp.this.list.get(posi)).id);
                ChangestatusThrDM dm = new ChangestatusThrDM();
                dm.id = ((FriendListReturnDMSubDM) FriendHoldListAp.this.list.get(posi)).id;
                dm.command = ChangestatusThrDM.USER_DEL;
                new ThrChangestatus(FriendHoldListAp.this.mContext, dm, (UserManager) FriendHoldListAp.this.mContext, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
            }
        });
        this.viewHolder.detailLy0().setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FriendHoldListAp.this.vList.clear();
                FriendHoldListAp.this.vList.add(Integer.valueOf(posi));
                FriendHoldListAp.this.notifyDataSetChanged();
            }
        });
        return convertview;
    }
}
