package com.accumed.gtech.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import java.util.ArrayList;

public class VoiceListAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList<String> arr;

    public VoiceListAdapter(Activity activity, ArrayList<String> arr) {
        this.activity = activity;
        this.arr = arr;
    }

    public int getCount() {
        return this.arr.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    public View getLayout() {
        return (LinearLayout) ((LayoutInflater) this.activity.getSystemService("layout_inflater")).inflate(C0213R.layout.item_voice, null);
    }

    public View getView(int position, View view, ViewGroup parent) {
        view = getLayout();
        ((TextView) view.findViewById(C0213R.id.tv_item_message)).setText((String) this.arr.get(position));
        return view;
    }
}
