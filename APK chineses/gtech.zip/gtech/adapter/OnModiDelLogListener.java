package com.accumed.gtech.adapter;

import com.accumed.gtech.datamodel.LogDM;

public interface OnModiDelLogListener {
    void onDelDeviceLog(LogDM logDM);

    void onDelSendServerLog(Object obj, String str);

    void onDeleteLog(LogDM logDM);

    void onModifyLog(LogDM logDM);

    void onModifySendServerLog(Object obj, String str);
}
