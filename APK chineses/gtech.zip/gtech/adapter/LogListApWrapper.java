package com.accumed.gtech.adapter;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;

public class LogListApWrapper {
    View base;

    public LogListApWrapper(View base) {
        this.base = base;
    }

    public RelativeLayout rl_item_line() {
        return (RelativeLayout) this.base.findViewById(C0213R.id.rl_item_line);
    }

    public TextView log_item_line_tv_date() {
        return (TextView) this.base.findViewById(C0213R.id.log_item_line_tv_date);
    }

    public LinearLayout log_litem_ll_layout() {
        return (LinearLayout) this.base.findViewById(C0213R.id.log_litem_ll_layout);
    }

    public TextView log_litem_tv_value() {
        return (TextView) this.base.findViewById(C0213R.id.log_litem_tv_value);
    }

    public TextView log_litem_tv_unit() {
        return (TextView) this.base.findViewById(C0213R.id.log_litem_tv_unit);
    }

    public TextView log_litem_tv_time() {
        return (TextView) this.base.findViewById(C0213R.id.log_litem_tv_time);
    }

    public ImageView log_litem_iv_eat() {
        return (ImageView) this.base.findViewById(C0213R.id.log_litem_iv_eat);
    }

    public ImageView log_litem_iv_modify() {
        return (ImageView) this.base.findViewById(C0213R.id.log_litem_iv_modify);
    }

    public ImageButton log_litem_ibtn_delete() {
        return (ImageButton) this.base.findViewById(C0213R.id.log_litem_ibtn_delete);
    }

    public ImageButton log_litem_ibtn_modify() {
        return (ImageButton) this.base.findViewById(C0213R.id.log_litem_ibtn_modify);
    }

    public LinearLayout log_ritem_ll_layout() {
        return (LinearLayout) this.base.findViewById(C0213R.id.log_ritem_ll_layout);
    }

    public ImageView log_ritem_iv_type() {
        return (ImageView) this.base.findViewById(C0213R.id.log_ritem_iv_type);
    }

    public TextView log_ritem_tv_time0() {
        return (TextView) this.base.findViewById(C0213R.id.log_ritem_tv_time0);
    }

    public TextView log_ritem_tv_message() {
        return (TextView) this.base.findViewById(C0213R.id.log_ritem_tv_message);
    }

    public TextView log_ritem_tv_message_detail() {
        return (TextView) this.base.findViewById(C0213R.id.log_ritem_tv_message_detail);
    }

    public TextView log_ritem_tv_value() {
        return (TextView) this.base.findViewById(C0213R.id.log_ritem_tv_value);
    }

    public ImageView log_ritem_iv_picture_s() {
        return (ImageView) this.base.findViewById(C0213R.id.log_ritem_iv_picture_s);
    }

    public LinearLayout log_ritem_ll_sub() {
        return (LinearLayout) this.base.findViewById(C0213R.id.log_ritem_ll_sub);
    }

    public ImageView log_ritem_iv_picture() {
        return (ImageView) this.base.findViewById(C0213R.id.log_ritem_iv_picture);
    }

    public ImageButton log_ritem_ibtn_delete() {
        return (ImageButton) this.base.findViewById(C0213R.id.log_ritem_ibtn_delete);
    }

    public ImageButton log_ritem_ibtn_modify() {
        return (ImageButton) this.base.findViewById(C0213R.id.log_ritem_ibtn_modify);
    }

    public TextView log_ritem_tv_time() {
        return (TextView) this.base.findViewById(C0213R.id.log_ritem_tv_time);
    }

    public LinearLayout log_litem_ll_sub() {
        return (LinearLayout) this.base.findViewById(C0213R.id.log_litem_ll_sub);
    }

    public ImageView log_item_line_iv_date() {
        return (ImageView) this.base.findViewById(C0213R.id.log_item_line_iv_date);
    }

    public RelativeLayout glucose_left_rly() {
        return (RelativeLayout) this.base.findViewById(C0213R.id.glucose_left_rly);
    }

    public RelativeLayout delModiRly() {
        return (RelativeLayout) this.base.findViewById(C0213R.id.delModiRly);
    }

    public FrameLayout all_fly() {
        return (FrameLayout) this.base.findViewById(C0213R.id.all_fly);
    }

    public LinearLayout align_ly0() {
        return (LinearLayout) this.base.findViewById(C0213R.id.align_ly0);
    }

    public ImageButton lineIb() {
        return (ImageButton) this.base.findViewById(C0213R.id.lineIb);
    }
}
