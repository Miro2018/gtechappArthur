package com.accumed.gtech.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.view.ViewCompat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.PinchZoomImageView;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.datamodel.DelDataThrDM;
import com.accumed.gtech.thread.datamodel.ModGlucoseDM;
import com.accumed.gtech.util.Anim;
import com.accumed.gtech.util.ImageDownloader;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.Util;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

@SuppressLint({"UseSparseArrays"})
public class LogListAp extends BaseAdapter {
    static int DEL_DATA_COMMENT = 3;
    static int DEL_DATA_GLUCOSE = 0;
    static int DEL_DATA_INSULIN = 1;
    static int DEL_DATA_NOTE = 2;
    static int DEL_DEVICE_DATA_GLUCOSE = 4;
    public static int Hi_str = ClassConstant.INPUT_GLUCOSE_MGDL_MAX;
    public static int Lo_str = 10;
    static final String className = "LogListAp";
    public static int max = 200;
    public static int min = 70;
    final int DEL = 1;
    final int MODI = 0;
    boolean SHOW_log_litem_ll_sub;
    Anim anim;
    public String bloodSugarUnit;
    HashMap<String, String> friendMap = new HashMap();
    String[] getBloodSugarUnitTypeArr;
    ImageDownloader imgDownloader;
    ArrayList<String> insulinNameList;
    ArrayList<String> insulinTypeList;
    boolean isMe;
    HashMap<Integer, Boolean> lSubViewMap;
    public String language;
    private LogCat logCat;
    private ArrayList<LogDM> logDMList;
    int mAppStatus;
    private Context mContext;
    String mg_dl;
    String mmol_l;
    private PreferenceAction prefServerCheck;
    HashMap<Integer, Boolean> rCommentSubViewMap;
    HashMap<Integer, Boolean> rInsulinSubViewMap;
    HashMap<Integer, Boolean> rNoteSubViewMap;
    UserProfileSettingData userProfileSettingData;
    private Util util;

    class C02502 implements OnClickListener {
        C02502() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
        }
    }

    class C02524 implements OnClickListener {
        C02524() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
        }
    }

    public LogListAp(Context c) {
        this.mContext = c;
        this.logCat = new LogCat();
        this.anim = new Anim(this.mContext);
        this.util = new Util(this.mContext);
        this.imgDownloader = new ImageDownloader();
        this.userProfileSettingData = new UserProfileSettingData(this.mContext);
        isMe();
        this.lSubViewMap = new HashMap();
        this.rInsulinSubViewMap = new HashMap();
        this.rNoteSubViewMap = new HashMap();
        this.rCommentSubViewMap = new HashMap();
        this.getBloodSugarUnitTypeArr = this.mContext.getResources().getStringArray(C0213R.array.array_bloodsugar_unit_data);
        this.mg_dl = this.getBloodSugarUnitTypeArr[0];
        this.mmol_l = this.getBloodSugarUnitTypeArr[1];
        setInsulinString();
    }

    public void setUserProfileSettingData(UserProfileSettingData d) {
        this.userProfileSettingData = d;
    }

    private void isMe() {
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        if (pref.getString(PreferenceAction.MY_EMAIL).equals(ContainerFragmentActivity.FRIEND_EMAIL) || ContainerFragmentActivity.FRIEND_EMAIL == null) {
            this.isMe = true;
            this.logCat.log(className, "mmmm isMe", "true");
        } else {
            this.isMe = false;
            this.logCat.log(className, "mmmm isMe", "false");
        }
        this.logCat.log(className, "mmmm my email", pref.getString(PreferenceAction.MY_EMAIL));
        this.logCat.log(className, "mmmm my femail", ContainerFragmentActivity.FRIEND_EMAIL);
    }

    public void clearSubView() {
        this.lSubViewMap.clear();
        this.rInsulinSubViewMap.clear();
        this.rNoteSubViewMap.clear();
        this.rCommentSubViewMap.clear();
    }

    public void setFriendMap(HashMap<String, String> friendMap) {
        this.friendMap = friendMap;
    }

    private void setInsulinString() {
        this.insulinTypeList = new ArrayList();
        this.insulinNameList = new ArrayList();
        this.insulinTypeList.add(this.mContext.getString(C0213R.string.insulin_type_rapid));
        this.insulinTypeList.add(this.mContext.getString(C0213R.string.insulin_type_short));
        this.insulinTypeList.add(this.mContext.getString(C0213R.string.insulin_type_nph));
        this.insulinTypeList.add(this.mContext.getString(C0213R.string.insulin_type_long));
        this.insulinTypeList.add(this.mContext.getString(C0213R.string.insulin_type_mix));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_novorapid));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_apidra));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_humalog));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_humulin_r));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_novorin_r));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_insulatard));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_lantus));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_levemir));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_novomix_30));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_novomix_50));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_novomix_70));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_mixtard));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_humulin_30));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_humulin_70));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_humalogmix_25));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_humalogmix_50));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_novorin_n));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_humulin_n));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_toujeo));
        this.insulinNameList.add(this.mContext.getString(C0213R.string.insulin_name_tresiba));
    }

    public ArrayList<LogDM> getLogDMList() {
        return this.logDMList;
    }

    public void setLogDMList(ArrayList<LogDM> list) {
        isMe();
        this.logDMList = list;
    }

    public int getCount() {
        try {
            return this.logDMList.size();
        } catch (Exception e) {
            return 0;
        }
    }

    public Object getItem(int arg0) {
        return null;
    }

    public long getItemId(int arg0) {
        return 0;
    }

    public void setLanguage(String lang) {
        this.language = lang;
    }

    void delDeviceAlert(final LogDM logDM) {
        new Builder(this.mContext).setTitle(this.mContext.getString(C0213R.string.alert_title)).setMessage(this.mContext.getString(C0213R.string.alert_type12)).setNegativeButton(this.mContext.getString(C0213R.string.btn_cancel), new C02502()).setPositiveButton(this.mContext.getString(C0213R.string.btn_ok), new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                AppStatusRouter appStatusRouter = new AppStatusRouter(LogListAp.this.mContext);
                LogListAp.this.mAppStatus = appStatusRouter.getAppStatus();
                ((OnModiDelLogListener) LogListAp.this.mContext).onDelDeviceLog(logDM);
            }
        }).show();
    }

    private void delAlert(final LogDM logDM) {
        new Builder(this.mContext).setTitle(this.mContext.getString(C0213R.string.alert_title)).setMessage(this.mContext.getString(C0213R.string.alert_type12)).setNegativeButton(this.mContext.getString(C0213R.string.btn_cancel), new C02524()).setPositiveButton(this.mContext.getString(C0213R.string.btn_ok), new OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                AppStatusRouter appStatusRouter = new AppStatusRouter(LogListAp.this.mContext);
                LogListAp.this.mAppStatus = appStatusRouter.getAppStatus();
                if (logDM.category.equals("0")) {
                    ((OnModiDelLogListener) LogListAp.this.mContext).onDeleteLog(logDM);
                } else {
                    ((OnModiDelLogListener) LogListAp.this.mContext).onDeleteLog(logDM);
                }
                DelDataThrDM delDataThrDM = new DelDataThrDM();
                delDataThrDM.id = logDM._id;
                delDataThrDM.email = logDM.user_id;
                delDataThrDM.ntype = new Util().getServerNoteType(logDM.note_type);
                LogListAp.this.logCat.log(LogListAp.className, "delDataThrDM.", delDataThrDM.email);
                LogListAp.this.logCat.log(LogListAp.className, "delDataThrDM.", delDataThrDM.id);
                if (logDM.category.equals("0")) {
                    if (logDM.blood_sugar_type.equals("0")) {
                        PreferenceAction pref = new PreferenceAction(LogListAp.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                        ModGlucoseDM modGlucoseDM = new ModGlucoseDM();
                        modGlucoseDM.id = logDM._id;
                        modGlucoseDM.email = pref.getString(PreferenceAction.MY_EMAIL);
                        modGlucoseDM.deviceid = logDM.device_id;
                        modGlucoseDM.gevent = logDM.blood_sugar_eat;
                        LogListAp.this.logCat.log(LogListAp.className, "gevent--", modGlucoseDM.gevent);
                        modGlucoseDM.gdate = new Util().getServerDateFormat(logDM.input_date);
                        modGlucoseDM.gvalue = logDM.blood_sugar_value;
                        modGlucoseDM.gtempeature = "0";
                        modGlucoseDM.manualinput = "NO";
                        LogListAp.this.logCat.log(LogListAp.className, "modGlucoseDM.id=>", modGlucoseDM.id);
                        LogListAp.this.logCat.log(LogListAp.className, "modGlucoseDM.email=>", modGlucoseDM.email);
                        LogListAp.this.logCat.log(LogListAp.className, "modGlucoseDM.deviceid=>", modGlucoseDM.deviceid);
                        LogListAp.this.logCat.log(LogListAp.className, "modGlucoseDM.gevent=>", modGlucoseDM.gevent);
                        LogListAp.this.logCat.log(LogListAp.className, "modGlucoseDM.gdate=>", modGlucoseDM.gdate);
                        LogListAp.this.logCat.log(LogListAp.className, "modGlucoseDM.gvalue=>", modGlucoseDM.gvalue);
                        LogListAp.this.logCat.log(LogListAp.className, "modGlucoseDM.gtempeature=>", modGlucoseDM.gtempeature);
                        LogListAp.this.logCat.log(LogListAp.className, "modGlucoseDM.manualinput=>", modGlucoseDM.manualinput);
                        LogListAp.this.actionDefine(LogListAp.DEL_DEVICE_DATA_GLUCOSE, modGlucoseDM);
                    } else if (logDM.blood_sugar_type.equals("1")) {
                        LogListAp.this.actionDefine(LogListAp.DEL_DATA_GLUCOSE, delDataThrDM);
                    }
                }
                if (logDM.category.equals("1")) {
                    LogListAp.this.actionDefine(LogListAp.DEL_DATA_INSULIN, delDataThrDM);
                }
                if (logDM.category.equals("2")) {
                    LogListAp.this.actionDefine(LogListAp.DEL_DATA_NOTE, delDataThrDM);
                }
                if (logDM.category.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                    LogListAp.this.actionDefine(LogListAp.DEL_DATA_COMMENT, delDataThrDM);
                }
            }
        }).show();
    }

    public String conversionStrDateTimeFormat(String date) {
        if (date == null) {
            return null;
        }
        return date.replaceAll("-", "").replaceAll(":", "").replaceAll("\\.", "").replaceAll("\\p{Space}", "");
    }

    public View getView(int position, View view, ViewGroup parent) {
        LogListApWrapper logListApWrapper;
        if (view == null) {
            view = ((Activity) this.mContext).getLayoutInflater().inflate(C0213R.layout.item_log, parent, false);
            logListApWrapper = new LogListApWrapper(view);
            view.setTag(logListApWrapper);
        } else {
            logListApWrapper = (LogListApWrapper) view.getTag();
        }
        if (!(this.logDMList == null || this.logDMList.size() == 0)) {
            final int i;
            this.logCat.log(className, "gvalue", ((LogDM) this.logDMList.get(position)).blood_sugar_value);
            this.logCat.log(className, "update_flag", ((LogDM) this.logDMList.get(position)).update_flag);
            this.logCat.log(className, "ap input_Date", ((LogDM) this.logDMList.get(position)).input_date);
            String lineDate = this.util.logApLineDateFormat(((LogDM) this.logDMList.get(position)).input_date);
            if (position == 0) {
                logListApWrapper.rl_item_line().setVisibility(0);
                logListApWrapper.log_item_line_iv_date().setVisibility(0);
                logListApWrapper.log_item_line_tv_date().setText(lineDate);
                logListApWrapper.log_item_line_tv_date().setVisibility(0);
                logListApWrapper.log_item_line_tv_date().bringToFront();
            } else {
                boolean prevDateCompare;
                try {
                    if (Integer.parseInt(((LogDM) this.logDMList.get(position)).input_date.substring(0, 8)) == Integer.parseInt(((LogDM) this.logDMList.get(position - 1)).input_date.substring(0, 8))) {
                        prevDateCompare = true;
                    } else {
                        prevDateCompare = false;
                    }
                } catch (Exception e) {
                    prevDateCompare = true;
                }
                if (prevDateCompare) {
                    logListApWrapper.rl_item_line().setVisibility(8);
                    logListApWrapper.log_item_line_iv_date().setVisibility(8);
                    logListApWrapper.log_item_line_tv_date().setVisibility(8);
                } else {
                    logListApWrapper.rl_item_line().setVisibility(0);
                    logListApWrapper.log_item_line_iv_date().setVisibility(0);
                    logListApWrapper.log_item_line_tv_date().setText(lineDate);
                    logListApWrapper.log_item_line_tv_date().setVisibility(0);
                    logListApWrapper.log_item_line_tv_date().bringToFront();
                }
            }
            if (((LogDM) this.logDMList.get(position)).category.equals("0")) {
                final LinearLayout log_litem_ll_sub = logListApWrapper.log_litem_ll_sub();
                logListApWrapper.log_ritem_ll_sub().setVisibility(8);
                this.logCat.log(className, "system_date", ((LogDM) this.logDMList.get(position)).system_date);
                this.logCat.log(className, "update_flag", ((LogDM) this.logDMList.get(position)).update_flag);
                if (((LogDM) this.logDMList.get(position)).blood_sugar_type.equals("0")) {
                    logListApWrapper.log_litem_ibtn_modify().setVisibility(4);
                } else {
                    logListApWrapper.log_litem_ibtn_modify().setVisibility(0);
                }
                i = position;
                logListApWrapper.log_litem_ibtn_modify().setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        LogListAp.this.logCat.log(LogListAp.className, "click", ((LogDM) LogListAp.this.logDMList.get(i)).seq);
                        if (((LogDM) LogListAp.this.logDMList.get(i)).category.equals("0")) {
                            ((OnModiDelLogListener) LogListAp.this.mContext).onModifyLog((LogDM) LogListAp.this.logDMList.get(i));
                        }
                    }
                });
                if (Integer.parseInt(((LogDM) this.logDMList.get(position)).blood_sugar_value) >= Integer.parseInt(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR) || Integer.parseInt(((LogDM) this.logDMList.get(position)).blood_sugar_value) <= Integer.parseInt(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR)) {
                    logListApWrapper.log_litem_tv_value().setTextColor(SupportMenu.CATEGORY_MASK);
                } else {
                    logListApWrapper.log_litem_tv_value().setTextColor(ViewCompat.MEASURED_STATE_MASK);
                }
                this.logCat.log(className, "bloodSugarUnit", this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT);
                if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mg_dl)) {
                    logListApWrapper.log_litem_tv_unit().setText(this.mContext.getString(C0213R.string.unit_blood_sugar_ko));
                    logListApWrapper.log_litem_tv_value().setText(((LogDM) this.logDMList.get(position)).blood_sugar_value);
                } else if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mmol_l)) {
                    logListApWrapper.log_litem_tv_unit().setText(this.mContext.getString(C0213R.string.unit_blood_sugar_en));
                    logListApWrapper.log_litem_tv_value().setText(this.util.mgdlToMmolL(((LogDM) this.logDMList.get(position)).blood_sugar_value));
                }
                if (Integer.parseInt(((LogDM) this.logDMList.get(position)).blood_sugar_value) < Lo_str) {
                    logListApWrapper.log_litem_tv_value().setText("Lo");
                } else {
                    if (Integer.parseInt(((LogDM) this.logDMList.get(position)).blood_sugar_value) > Hi_str) {
                        logListApWrapper.log_litem_tv_value().setText("Hi");
                    }
                }
                logListApWrapper.log_ritem_ll_layout().setVisibility(4);
                logListApWrapper.log_litem_ll_layout().setVisibility(0);
                logListApWrapper.log_litem_tv_time().setText(this.util.inputDateToGoodDate(((LogDM) this.logDMList.get(position)).input_date));
                logListApWrapper.log_litem_ll_sub().setVisibility(8);
                if (((LogDM) this.logDMList.get(position)).blood_sugar_type.equals("0")) {
                    logListApWrapper.log_litem_iv_modify().setImageDrawable(this.mContext.getResources().getDrawable(C0213R.drawable.ic_device_s));
                    logListApWrapper.log_litem_iv_modify().setVisibility(0);
                    i = position;
                    logListApWrapper.glucose_left_rly().setOnClickListener(new View.OnClickListener() {
                        public void onClick(View arg0) {
                            if (!LogListAp.this.isMe) {
                                return;
                            }
                            if (log_litem_ll_sub.getVisibility() == 0) {
                                log_litem_ll_sub.setVisibility(8);
                                LogListAp.this.lSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(false));
                                return;
                            }
                            log_litem_ll_sub.setVisibility(0);
                            LogListAp.this.anim.startAnim(log_litem_ll_sub, Anim.IN);
                            LogListAp.this.lSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(true));
                        }
                    });
                } else if (((LogDM) this.logDMList.get(position)).blood_sugar_type.equals("1")) {
                    logListApWrapper.log_litem_iv_modify().setImageDrawable(this.mContext.getResources().getDrawable(C0213R.drawable.ic_hand));
                    logListApWrapper.log_litem_iv_modify().setVisibility(0);
                    i = position;
                    logListApWrapper.glucose_left_rly().setOnClickListener(new View.OnClickListener() {
                        public void onClick(View arg0) {
                            if (!LogListAp.this.isMe) {
                                return;
                            }
                            if (log_litem_ll_sub.getVisibility() == 0) {
                                log_litem_ll_sub.setVisibility(8);
                                LogListAp.this.lSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(false));
                                return;
                            }
                            log_litem_ll_sub.setVisibility(0);
                            LogListAp.this.anim.startAnim(log_litem_ll_sub, Anim.IN);
                            LogListAp.this.lSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(true));
                        }
                    });
                    i = position;
                    logListApWrapper.log_litem_ibtn_delete().setOnClickListener(new View.OnClickListener() {
                        public void onClick(View arg0) {
                            if (!((LogDM) LogListAp.this.logDMList.get(i)).blood_sugar_type.equals("0") && ((LogDM) LogListAp.this.logDMList.get(i)).blood_sugar_type.equals("1")) {
                                LogListAp.this.delAlert((LogDM) LogListAp.this.logDMList.get(i));
                            }
                        }
                    });
                }
                i = position;
                logListApWrapper.glucose_left_rly().setOnClickListener(new View.OnClickListener() {
                    public void onClick(View arg0) {
                        if (!LogListAp.this.isMe) {
                            return;
                        }
                        if (log_litem_ll_sub.getVisibility() == 0) {
                            log_litem_ll_sub.setVisibility(8);
                            LogListAp.this.lSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(false));
                            return;
                        }
                        log_litem_ll_sub.setVisibility(0);
                        LogListAp.this.anim.startAnim(log_litem_ll_sub, Anim.IN);
                        LogListAp.this.lSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(true));
                    }
                });
                i = position;
                logListApWrapper.log_litem_ibtn_delete().setOnClickListener(new View.OnClickListener() {
                    public void onClick(View arg0) {
                        if (((LogDM) LogListAp.this.logDMList.get(i)).blood_sugar_type.equals("0")) {
                            LogListAp.this.delDeviceAlert((LogDM) LogListAp.this.logDMList.get(i));
                            LogListAp.this.logCat.log(LogListAp.className, "system_date", ((LogDM) LogListAp.this.logDMList.get(i)).system_date);
                        } else if (((LogDM) LogListAp.this.logDMList.get(i)).blood_sugar_type.equals("1")) {
                            LogListAp.this.delAlert((LogDM) LogListAp.this.logDMList.get(i));
                        }
                    }
                });
                if (this.lSubViewMap.get(Integer.valueOf(position)) != null) {
                    if (((Boolean) this.lSubViewMap.get(Integer.valueOf(position))).booleanValue()) {
                        log_litem_ll_sub.setVisibility(0);
                    } else {
                        log_litem_ll_sub.setVisibility(8);
                    }
                }
                if (((LogDM) this.logDMList.get(position)).blood_sugar_eat.equals("0") || ((LogDM) this.logDMList.get(position)).blood_sugar_eat.toLowerCase().equals("after")) {
                    logListApWrapper.log_litem_iv_eat().setImageResource(C0213R.drawable.ic_after);
                } else if (((LogDM) this.logDMList.get(position)).blood_sugar_eat.equals("1") || ((LogDM) this.logDMList.get(position)).blood_sugar_eat.toLowerCase().equals("before")) {
                    logListApWrapper.log_litem_iv_eat().setImageResource(C0213R.drawable.ic_before);
                } else if (((LogDM) this.logDMList.get(position)).blood_sugar_eat.equals("2") || ((LogDM) this.logDMList.get(position)).blood_sugar_eat.toLowerCase().equals("control solution")) {
                    logListApWrapper.log_litem_iv_eat().setImageResource(C0213R.drawable.ic_cs);
                } else if (((LogDM) this.logDMList.get(position)).blood_sugar_eat.equals(LogDM.GLUCOSE_EAT_FASTING) || ((LogDM) this.logDMList.get(position)).blood_sugar_eat.toLowerCase().equals("fasting")) {
                    logListApWrapper.log_litem_iv_eat().setImageResource(C0213R.drawable.ic_fasting);
                } else {
                    logListApWrapper.log_litem_iv_eat().setImageDrawable(null);
                }
                this.logCat.log(className, "blood_sugar_eat", ((LogDM) this.logDMList.get(position)).blood_sugar_eat);
            } else {
                final LinearLayout log_ritem_ll_sub = logListApWrapper.log_ritem_ll_sub();
                final ImageView log_ritem_iv_picture = logListApWrapper.log_ritem_iv_picture();
                ImageView log_ritem_iv_picture_s = logListApWrapper.log_ritem_iv_picture_s();
                TextView log_ritem_tv_message_detail = logListApWrapper.log_ritem_tv_message_detail();
                logListApWrapper.log_litem_ll_sub().setVisibility(8);
                logListApWrapper.log_ritem_ll_sub().setVisibility(8);
                logListApWrapper.log_ritem_ll_layout().setVisibility(0);
                logListApWrapper.log_litem_ll_layout().setVisibility(4);
                if (((LogDM) this.logDMList.get(position)).category.equals("1")) {
                    logListApWrapper.align_ly0().setGravity(5);
                    logListApWrapper.log_ritem_tv_time0().setText(this.util.inputDateToGoodDate(((LogDM) this.logDMList.get(position)).input_date));
                    log_ritem_tv_message_detail.setVisibility(8);
                    logListApWrapper.log_ritem_iv_type().setVisibility(0);
                    if (((LogDM) this.logDMList.get(position)).insulin_type.equals("0")) {
                        logListApWrapper.log_ritem_iv_type().setImageResource(C0213R.drawable.icon_item_insulin01);
                    } else if (((LogDM) this.logDMList.get(position)).insulin_type.equals("1")) {
                        logListApWrapper.log_ritem_iv_type().setImageResource(C0213R.drawable.icon_item_insulin02);
                    } else if (((LogDM) this.logDMList.get(position)).insulin_type.equals("2")) {
                        logListApWrapper.log_ritem_iv_type().setImageResource(C0213R.drawable.icon_item_insulin03);
                    } else if (((LogDM) this.logDMList.get(position)).insulin_type.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                        logListApWrapper.log_ritem_iv_type().setImageResource(C0213R.drawable.icon_item_insulin04);
                    } else {
                        logListApWrapper.log_ritem_iv_type().setImageResource(C0213R.drawable.icon_item_insulin05);
                    }
                    logListApWrapper.log_ritem_tv_value().setText(((LogDM) this.logDMList.get(position)).insulin_value);
                    try {
                        logListApWrapper.log_ritem_tv_message().setText((CharSequence) this.insulinNameList.get(Integer.parseInt(((LogDM) this.logDMList.get(position)).insulin_name)));
                    } catch (Exception e2) {
                    }
                    log_ritem_iv_picture_s.setImageResource(C0213R.drawable.ic_hand);
                    log_ritem_iv_picture_s.setScaleType(ScaleType.FIT_CENTER);
                    log_ritem_iv_picture_s.setVisibility(0);
                    if (this.isMe) {
                        logListApWrapper.delModiRly().setVisibility(0);
                    } else {
                        logListApWrapper.delModiRly().setVisibility(8);
                    }
                    log_ritem_iv_picture.setVisibility(8);
                    logListApWrapper.log_ritem_ll_layout().setBackgroundResource(C0213R.drawable.bg_box_right);
                    i = position;
                    logListApWrapper.log_ritem_ll_layout().setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            if (!LogListAp.this.isMe) {
                                return;
                            }
                            if (log_ritem_ll_sub.getVisibility() == 0) {
                                log_ritem_ll_sub.setVisibility(8);
                                LogListAp.this.rInsulinSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(false));
                                return;
                            }
                            log_ritem_ll_sub.setVisibility(0);
                            LogListAp.this.anim.startAnim(log_ritem_ll_sub, Anim.IN);
                            LogListAp.this.rInsulinSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(true));
                        }
                    });
                    if (this.rInsulinSubViewMap.get(Integer.valueOf(position)) != null) {
                        if (((Boolean) this.rInsulinSubViewMap.get(Integer.valueOf(position))).booleanValue()) {
                            log_ritem_ll_sub.setVisibility(0);
                        } else {
                            log_ritem_ll_sub.setVisibility(8);
                        }
                    }
                    i = position;
                    logListApWrapper.log_ritem_ibtn_delete().setOnClickListener(new View.OnClickListener() {
                        public void onClick(View arg0) {
                            LogListAp.this.delAlert((LogDM) LogListAp.this.logDMList.get(i));
                        }
                    });
                    i = position;
                    logListApWrapper.log_ritem_ibtn_modify().setOnClickListener(new View.OnClickListener() {
                        public void onClick(View arg0) {
                            ((OnModiDelLogListener) LogListAp.this.mContext).onModifyLog((LogDM) LogListAp.this.logDMList.get(i));
                        }
                    });
                } else if (((LogDM) this.logDMList.get(position)).category.equals("2")) {
                    logListApWrapper.align_ly0().setGravity(5);
                    logListApWrapper.log_ritem_tv_time0().setText(this.util.inputDateToGoodDate(((LogDM) this.logDMList.get(position)).input_date));
                    log_ritem_tv_message_detail.setVisibility(0);
                    logListApWrapper.log_ritem_tv_value().setText("");
                    logListApWrapper.delModiRly().setVisibility(0);
                    log_ritem_iv_picture_s.setVisibility(0);
                    if (this.isMe) {
                        logListApWrapper.delModiRly().setVisibility(0);
                    } else {
                        logListApWrapper.delModiRly().setVisibility(8);
                    }
                    logListApWrapper.log_ritem_iv_type().setVisibility(0);
                    if (((LogDM) this.logDMList.get(position)).note_type.equals("0")) {
                        logListApWrapper.log_ritem_iv_type().setImageResource(C0213R.drawable.ic_food);
                    } else if (((LogDM) this.logDMList.get(position)).note_type.equals("1")) {
                        logListApWrapper.log_ritem_iv_type().setImageResource(C0213R.drawable.ic_sports);
                    } else if (((LogDM) this.logDMList.get(position)).note_type.equals("2")) {
                        logListApWrapper.log_ritem_iv_type().setImageResource(C0213R.drawable.ic_note);
                    }
                    logListApWrapper.log_ritem_ll_layout().setBackgroundResource(C0213R.drawable.bg_box_right);
                    logListApWrapper.log_ritem_tv_message().setText(((LogDM) this.logDMList.get(position)).note_content);
                    log_ritem_tv_message_detail.setText(((LogDM) this.logDMList.get(position)).note_content);
                    this.logCat.log(className, "ntethum", ClassConstant.DIR_IMG_THUMB + ((LogDM) this.logDMList.get(position)).note_picture_thumb);
                    i = position;
                    logListApWrapper.log_ritem_ll_layout().setOnClickListener(new View.OnClickListener() {

                        class C02441 implements Runnable {
                            C02441() {
                            }

                            public void run() {
                                log_ritem_iv_picture.setImageURI(null);
                                log_ritem_iv_picture.setVisibility(8);
                            }
                        }

                        class C02452 implements Runnable {
                            C02452() {
                            }

                            public void run() {
                                if (LogListAp.this.isMe) {
                                    log_ritem_iv_picture.setImageURI(Uri.fromFile(new File(ClassConstant.DIR_IMG_THUMB + ((LogDM) LogListAp.this.logDMList.get(i)).note_picture_thumb)));
                                    log_ritem_iv_picture.setVisibility(0);
                                    return;
                                }
                                log_ritem_iv_picture.setVisibility(0);
                                String imgUrl = "";
                                LogListAp.this.prefServerCheck = new PreferenceAction(LogListAp.this.mContext, PreferenceAction.PREF_SELECT_SERVER);
                                if (((LogDM) LogListAp.this.logDMList.get(i)).note_picture_thumb.matches(".*svr_1_.*")) {
                                    imgUrl = "https://54.250.126.59/img/" + ((LogDM) LogListAp.this.logDMList.get(i)).note_picture_thumb;
                                } else {
                                    imgUrl = "https://service.sdbiosensor.com/img/" + ((LogDM) LogListAp.this.logDMList.get(i)).note_picture_thumb;
                                }
                                LogListAp.this.imgDownloader.download(imgUrl, log_ritem_iv_picture);
                            }
                        }

                        public void onClick(View v) {
                            if (log_ritem_ll_sub.getVisibility() == 0) {
                                log_ritem_ll_sub.setVisibility(8);
                                LogListAp.this.rNoteSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(false));
                                return;
                            }
                            log_ritem_ll_sub.setVisibility(0);
                            LogListAp.this.anim.startAnim(log_ritem_ll_sub, Anim.IN);
                            LogListAp.this.rNoteSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(true));
                            if (((LogDM) LogListAp.this.logDMList.get(i)).note_picture.equals("") || ((LogDM) LogListAp.this.logDMList.get(i)).note_picture.equals("temp.jpg") || ((LogDM) LogListAp.this.logDMList.get(i)).note_picture.equals("null") || ((LogDM) LogListAp.this.logDMList.get(i)).note_picture == null) {
                                ((Activity) LogListAp.this.mContext).runOnUiThread(new C02441());
                            } else {
                                ((Activity) LogListAp.this.mContext).runOnUiThread(new C02452());
                            }
                        }
                    });
                    if (this.rNoteSubViewMap.get(Integer.valueOf(position)) != null) {
                        if (((Boolean) this.rNoteSubViewMap.get(Integer.valueOf(position))).booleanValue()) {
                            log_ritem_ll_sub.setVisibility(0);
                            if (((LogDM) this.logDMList.get(position)).note_picture.equals("") || ((LogDM) this.logDMList.get(position)).note_picture.equals("temp.jpg") || ((LogDM) this.logDMList.get(position)).note_picture.equals("null") || ((LogDM) this.logDMList.get(position)).note_picture == null) {
                                log_ritem_iv_picture.setImageBitmap(null);
                                log_ritem_iv_picture.setVisibility(8);
                            } else if (this.isMe) {
                                log_ritem_iv_picture.setImageURI(Uri.fromFile(new File(ClassConstant.DIR_IMG_THUMB + ((LogDM) this.logDMList.get(position)).note_picture_thumb)));
                                log_ritem_iv_picture.setVisibility(0);
                            } else {
                                log_ritem_iv_picture.setVisibility(0);
                                imgUrl = "";
                                this.prefServerCheck = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_SERVER);
                                if (((LogDM) this.logDMList.get(position)).note_picture_thumb.matches(".*svr_1_.*")) {
                                    imgUrl = "https://54.250.126.59/img/" + ((LogDM) this.logDMList.get(position)).note_picture_thumb;
                                } else {
                                    imgUrl = "https://service.sdbiosensor.com/img/" + ((LogDM) this.logDMList.get(position)).note_picture_thumb;
                                }
                                this.imgDownloader.download(imgUrl, log_ritem_iv_picture);
                            }
                        } else {
                            log_ritem_ll_sub.setVisibility(8);
                        }
                    }
                    i = position;
                    log_ritem_iv_picture.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View arg0) {
                            LogListAp.this.logCat.log(LogListAp.className, "imgClick", "in0");
                            if (LogListAp.this.isMe) {
                                String fname = ((LogDM) LogListAp.this.logDMList.get(i)).note_picture;
                                Intent intent = new Intent(LogListAp.this.mContext, PinchZoomImageView.class);
                                intent.putExtra("fname", fname);
                                LogListAp.this.mContext.startActivity(intent);
                                LogListAp.this.logCat.log(LogListAp.className, "imgClick", "in1");
                                return;
                            }
                            fname = ((LogDM) LogListAp.this.logDMList.get(i)).note_picture;
                            intent = new Intent(LogListAp.this.mContext, PinchZoomImageView.class);
                            intent.putExtra("fname_friend", fname);
                            LogListAp.this.mContext.startActivity(intent);
                            LogListAp.this.logCat.log(LogListAp.className, "imgClick", "in2");
                        }
                    });
                    if (((LogDM) this.logDMList.get(position)).note_picture.equals("") || ((LogDM) this.logDMList.get(position)).note_picture.equals("null") || ((LogDM) this.logDMList.get(position)).note_picture == null || ((LogDM) this.logDMList.get(position)).note_picture.equals("temp.jpg")) {
                        log_ritem_iv_picture_s.setImageResource(C0213R.drawable.ic_write);
                        log_ritem_iv_picture_s.setScaleType(ScaleType.FIT_CENTER);
                    } else if (this.isMe) {
                        try {
                            log_ritem_iv_picture_s.setImageURI(Uri.fromFile(new File(ClassConstant.DIR_IMG_THUMB + ((LogDM) this.logDMList.get(position)).note_picture_thumb)));
                            log_ritem_iv_picture_s.setScaleType(ScaleType.FIT_XY);
                        } catch (Exception e3) {
                        }
                    } else {
                        imgUrl = "";
                        this.prefServerCheck = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_SERVER);
                        if (((LogDM) this.logDMList.get(position)).note_picture_thumb.matches(".*svr_1_.*")) {
                            imgUrl = "https://54.250.126.59/img/" + ((LogDM) this.logDMList.get(position)).note_picture_thumb;
                        } else {
                            imgUrl = "https://service.sdbiosensor.com/img/" + ((LogDM) this.logDMList.get(position)).note_picture_thumb;
                        }
                        this.imgDownloader.download(imgUrl, log_ritem_iv_picture_s);
                        log_ritem_iv_picture_s.setScaleType(ScaleType.FIT_XY);
                    }
                } else if (((LogDM) this.logDMList.get(position)).category.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                    if (!((LogDM) this.logDMList.get(position)).user_id.equals(((LogDM) this.logDMList.get(position)).targetemail) || ((LogDM) this.logDMList.get(position)).targetemail.equals("")) {
                        this.logCat.log(className, "isMe-", "yes");
                        logListApWrapper.log_ritem_ll_layout().setBackgroundResource(C0213R.drawable.back_log_item_friend);
                        logListApWrapper.align_ly0().setGravity(5);
                    } else {
                        this.logCat.log(className, "isMe-", "no");
                        logListApWrapper.log_ritem_ll_layout().setBackgroundResource(C0213R.drawable.back_log_item_me);
                        logListApWrapper.align_ly0().setGravity(5);
                    }
                    try {
                        if (!((String) this.friendMap.get(((LogDM) this.logDMList.get(position)).targetemail)).equals("")) {
                            if (!((String) this.friendMap.get(((LogDM) this.logDMList.get(position)).targetemail)).equals("null")) {
                                if (this.friendMap.get(((LogDM) this.logDMList.get(position)).targetemail) != null) {
                                    logListApWrapper.log_ritem_tv_time0().setText((CharSequence) this.friendMap.get(((LogDM) this.logDMList.get(position)).targetemail));
                                    logListApWrapper.log_ritem_iv_type().setVisibility(8);
                                    logListApWrapper.log_ritem_tv_message().setText(((LogDM) this.logDMList.get(position)).note_content);
                                    logListApWrapper.log_ritem_tv_value().setText("");
                                    log_ritem_tv_message_detail.setVisibility(0);
                                    log_ritem_tv_message_detail.setText(this.util.inputDateToGoodDate(((LogDM) this.logDMList.get(position)).input_date) + " \n " + ((LogDM) this.logDMList.get(position)).note_content);
                                    this.logCat.log(className, "checkEmail userid", ((LogDM) this.logDMList.get(position)).user_id);
                                    this.logCat.log(className, "checkEmail targetemail", ((LogDM) this.logDMList.get(position)).targetemail);
                                    i = position;
                                    log_ritem_iv_picture.setOnClickListener(new View.OnClickListener() {
                                        public void onClick(View arg0) {
                                            LogListAp.this.logCat.log(LogListAp.className, "imgClick", "in0");
                                            if (LogListAp.this.isMe) {
                                                String fname = ((LogDM) LogListAp.this.logDMList.get(i)).note_picture;
                                                Intent intent = new Intent(LogListAp.this.mContext, PinchZoomImageView.class);
                                                intent.putExtra("fname", fname);
                                                LogListAp.this.mContext.startActivity(intent);
                                                LogListAp.this.logCat.log(LogListAp.className, "imgClick", "in1");
                                                return;
                                            }
                                            fname = ((LogDM) LogListAp.this.logDMList.get(i)).note_picture;
                                            intent = new Intent(LogListAp.this.mContext, PinchZoomImageView.class);
                                            intent.putExtra("fname_friend", fname);
                                            LogListAp.this.mContext.startActivity(intent);
                                            LogListAp.this.logCat.log(LogListAp.className, "imgClick", "in2");
                                        }
                                    });
                                    i = position;
                                    logListApWrapper.log_ritem_ll_layout().setOnClickListener(new View.OnClickListener() {

                                        class C02461 implements Runnable {
                                            C02461() {
                                            }

                                            public void run() {
                                                log_ritem_ll_sub.setVisibility(0);
                                                LogListAp.this.anim.startAnim(log_ritem_ll_sub, Anim.IN);
                                                LogListAp.this.rCommentSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(true));
                                            }
                                        }

                                        class C02472 implements Runnable {
                                            C02472() {
                                            }

                                            public void run() {
                                                log_ritem_iv_picture.setImageURI(null);
                                                log_ritem_iv_picture.setVisibility(8);
                                            }
                                        }

                                        public void onClick(View v) {
                                            if (log_ritem_ll_sub.getVisibility() == 0) {
                                                log_ritem_ll_sub.setVisibility(8);
                                                LogListAp.this.rCommentSubViewMap.put(Integer.valueOf(i), Boolean.valueOf(false));
                                                return;
                                            }
                                            ((Activity) LogListAp.this.mContext).runOnUiThread(new C02461());
                                            if (((LogDM) LogListAp.this.logDMList.get(i)).note_picture.equals("") || ((LogDM) LogListAp.this.logDMList.get(i)).note_picture == null || ((LogDM) LogListAp.this.logDMList.get(i)).note_picture.equals("null") || ((LogDM) LogListAp.this.logDMList.get(i)).note_picture.equals("temp.jpg")) {
                                                LogListAp.this.logCat.log(LogListAp.className, "uuuuu", "in | " + ((LogDM) LogListAp.this.logDMList.get(i)).note_picture);
                                                ((Activity) LogListAp.this.mContext).runOnUiThread(new C02472());
                                                return;
                                            }
                                            LogListAp.this.logCat.log(LogListAp.className, "uuuuu", "in1" + ((LogDM) LogListAp.this.logDMList.get(i)).note_picture);
                                            final Uri uri = Uri.fromFile(new File(ClassConstant.DIR_IMG_THUMB + ((LogDM) LogListAp.this.logDMList.get(i)).note_picture_thumb));
                                            ((Activity) LogListAp.this.mContext).runOnUiThread(new Runnable() {
                                                public void run() {
                                                    if (LogListAp.this.isMe) {
                                                        log_ritem_iv_picture.setImageURI(uri);
                                                        log_ritem_iv_picture.setVisibility(0);
                                                        return;
                                                    }
                                                    log_ritem_iv_picture.setVisibility(0);
                                                    String imgUrl = "";
                                                    LogListAp.this.prefServerCheck = new PreferenceAction(LogListAp.this.mContext, PreferenceAction.PREF_SELECT_SERVER);
                                                    if (((LogDM) LogListAp.this.logDMList.get(i)).note_picture_thumb.matches(".*svr_1_.*")) {
                                                        imgUrl = "https://54.250.126.59/img/" + ((LogDM) LogListAp.this.logDMList.get(i)).note_picture_thumb;
                                                    } else {
                                                        imgUrl = "https://service.sdbiosensor.com/img/" + ((LogDM) LogListAp.this.logDMList.get(i)).note_picture_thumb;
                                                    }
                                                    LogListAp.this.imgDownloader.download(imgUrl, log_ritem_iv_picture);
                                                }
                                            });
                                        }
                                    });
                                    if (this.rCommentSubViewMap.get(Integer.valueOf(position)) != null) {
                                        if (((Boolean) this.rCommentSubViewMap.get(Integer.valueOf(position))).booleanValue()) {
                                            log_ritem_ll_sub.setVisibility(8);
                                        } else {
                                            log_ritem_ll_sub.setVisibility(0);
                                            if (!((LogDM) this.logDMList.get(position)).note_picture.equals("") || ((LogDM) this.logDMList.get(position)).note_picture == null || ((LogDM) this.logDMList.get(position)).note_picture.equals("null") || ((LogDM) this.logDMList.get(position)).note_picture.equals("temp.jpg")) {
                                                log_ritem_iv_picture.setImageBitmap(null);
                                                log_ritem_iv_picture.setVisibility(8);
                                            } else if (this.isMe) {
                                                log_ritem_iv_picture.setImageURI(Uri.fromFile(new File(ClassConstant.DIR_IMG_THUMB + ((LogDM) this.logDMList.get(position)).note_picture_thumb)));
                                                log_ritem_iv_picture.setVisibility(0);
                                            } else {
                                                log_ritem_iv_picture.setVisibility(0);
                                                imgUrl = "";
                                                this.prefServerCheck = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_SERVER);
                                                if (((LogDM) this.logDMList.get(position)).note_picture_thumb.matches(".*svr_1_.*")) {
                                                    imgUrl = "https://54.250.126.59/img/" + ((LogDM) this.logDMList.get(position)).note_picture_thumb;
                                                } else {
                                                    imgUrl = "https://service.sdbiosensor.com/img/" + ((LogDM) this.logDMList.get(position)).note_picture_thumb;
                                                }
                                                final String imgUrl1 = imgUrl;
                                                ((Activity) this.mContext).runOnUiThread(new Runnable() {
                                                    public void run() {
                                                        LogListAp.this.imgDownloader.download(imgUrl1, log_ritem_iv_picture);
                                                    }
                                                });
                                            }
                                        }
                                    }
                                    if (!((LogDM) this.logDMList.get(position)).note_picture.equals("") || ((LogDM) this.logDMList.get(position)).note_picture == null || ((LogDM) this.logDMList.get(position)).note_picture.equals("null") || ((LogDM) this.logDMList.get(position)).note_picture.equals("temp.jpg")) {
                                        log_ritem_iv_picture_s.setImageBitmap(null);
                                    } else if (this.isMe) {
                                        try {
                                            log_ritem_iv_picture_s.setImageURI(Uri.fromFile(new File(ClassConstant.DIR_IMG_THUMB + ((LogDM) this.logDMList.get(position)).note_picture_thumb)));
                                            log_ritem_iv_picture_s.setScaleType(ScaleType.FIT_XY);
                                        } catch (Exception e4) {
                                        }
                                    } else {
                                        imgUrl = "";
                                        this.prefServerCheck = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_SERVER);
                                        if (((LogDM) this.logDMList.get(position)).note_picture_thumb.matches(".*svr_1_.*")) {
                                            imgUrl = "https://54.250.126.59/img/" + ((LogDM) this.logDMList.get(position)).note_picture_thumb;
                                        } else {
                                            imgUrl = "https://service.sdbiosensor.com/img/" + ((LogDM) this.logDMList.get(position)).note_picture_thumb;
                                        }
                                        this.logCat.log(className, "commentThumbImgUrl", imgUrl);
                                        this.imgDownloader.download(imgUrl, log_ritem_iv_picture_s);
                                    }
                                }
                            }
                        }
                        logListApWrapper.log_ritem_tv_time0().setText(((LogDM) this.logDMList.get(position)).targetemail);
                    } catch (Exception e5) {
                        logListApWrapper.log_ritem_tv_time0().setText(((LogDM) this.logDMList.get(position)).targetemail);
                    }
                    logListApWrapper.log_ritem_iv_type().setVisibility(8);
                    logListApWrapper.log_ritem_tv_message().setText(((LogDM) this.logDMList.get(position)).note_content);
                    logListApWrapper.log_ritem_tv_value().setText("");
                    log_ritem_tv_message_detail.setVisibility(0);
                    log_ritem_tv_message_detail.setText(this.util.inputDateToGoodDate(((LogDM) this.logDMList.get(position)).input_date) + " \n " + ((LogDM) this.logDMList.get(position)).note_content);
                    this.logCat.log(className, "checkEmail userid", ((LogDM) this.logDMList.get(position)).user_id);
                    this.logCat.log(className, "checkEmail targetemail", ((LogDM) this.logDMList.get(position)).targetemail);
                    i = position;
                    log_ritem_iv_picture.setOnClickListener(/* anonymous class already generated */);
                    i = position;
                    logListApWrapper.log_ritem_ll_layout().setOnClickListener(/* anonymous class already generated */);
                    if (this.rCommentSubViewMap.get(Integer.valueOf(position)) != null) {
                        if (((Boolean) this.rCommentSubViewMap.get(Integer.valueOf(position))).booleanValue()) {
                            log_ritem_ll_sub.setVisibility(0);
                            if (((LogDM) this.logDMList.get(position)).note_picture.equals("")) {
                            }
                            log_ritem_iv_picture.setImageBitmap(null);
                            log_ritem_iv_picture.setVisibility(8);
                        } else {
                            log_ritem_ll_sub.setVisibility(8);
                        }
                    }
                    if (((LogDM) this.logDMList.get(position)).note_picture.equals("")) {
                    }
                    log_ritem_iv_picture_s.setImageBitmap(null);
                }
            }
            if (((LogDM) this.logDMList.get(position)).category.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                logListApWrapper.log_ritem_ibtn_modify().setVisibility(8);
            } else {
                logListApWrapper.log_ritem_ibtn_modify().setVisibility(0);
            }
            i = position;
            logListApWrapper.log_ritem_ibtn_delete().setOnClickListener(new View.OnClickListener() {
                public void onClick(View arg0) {
                    LogListAp.this.logCat.log(LogListAp.className, "note_type", ((LogDM) LogListAp.this.logDMList.get(i)).note_type);
                    LogListAp.this.logCat.log(LogListAp.className, "_id", ((LogDM) LogListAp.this.logDMList.get(i))._id);
                    LogListAp.this.delAlert((LogDM) LogListAp.this.logDMList.get(i));
                }
            });
            i = position;
            logListApWrapper.log_ritem_ibtn_modify().setOnClickListener(new View.OnClickListener() {
                public void onClick(View arg0) {
                    ((OnModiDelLogListener) LogListAp.this.mContext).onModifyLog((LogDM) LogListAp.this.logDMList.get(i));
                }
            });
            if (!this.isMe) {
                logListApWrapper.log_ritem_ibtn_delete().setVisibility(8);
                logListApWrapper.log_litem_iv_modify().setVisibility(8);
            }
        }
        return view;
    }

    private void actionDefine(int gubun, Object obj) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == DEL_DATA_COMMENT) {
                    ((OnModiDelLogListener) this.mContext).onDelSendServerLog((DelDataThrDM) obj, ClassConstant.SUBDIR_SUPORT_DELCOMMENT);
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == DEL_DATA_GLUCOSE) {
                    this.mContext.onDelSendServerLog((DelDataThrDM) obj, ClassConstant.SUBDIR_DEL_GLUCOSE);
                }
                if (gubun == DEL_DEVICE_DATA_GLUCOSE) {
                    ((OnModiDelLogListener) this.mContext).onModifySendServerLog((ModGlucoseDM) obj, ClassConstant.SUBDIR_MOD_GLUCOSE);
                }
                if (gubun == DEL_DATA_INSULIN) {
                    ((OnModiDelLogListener) this.mContext).onDelSendServerLog((DelDataThrDM) obj, ClassConstant.SUBDIR_DEL_INSULIN);
                }
                if (gubun == DEL_DATA_NOTE) {
                    ((OnModiDelLogListener) this.mContext).onDelSendServerLog((DelDataThrDM) obj, ClassConstant.SUBDIR_SUPORT_DELNOTE);
                }
                if (gubun == DEL_DATA_COMMENT) {
                    ((OnModiDelLogListener) this.mContext).onDelSendServerLog((DelDataThrDM) obj, ClassConstant.SUBDIR_SUPORT_DELCOMMENT);
                    return;
                }
                return;
            default:
                return;
        }
    }
}
