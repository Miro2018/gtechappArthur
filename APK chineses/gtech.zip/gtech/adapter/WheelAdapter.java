package com.accumed.gtech.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.wheel.adapters.AbstractWheelTextAdapter;

public class WheelAdapter extends AbstractWheelTextAdapter {
    private Context context;
    private int[] type;

    public WheelAdapter(Context context) {
        super(context, C0213R.layout.item_wheel_text, 0);
        this.context = context;
        setItemTextResource(C0213R.id.text);
    }

    public WheelAdapter(Context context, int[] type) {
        super(context, C0213R.layout.item_wheel_text, 0);
        this.context = context;
        this.type = type;
        setItemTextResource(C0213R.id.text);
    }

    public View getItem(int index, View cachedView, ViewGroup parent) {
        return super.getItem(index, cachedView, parent);
    }

    public int getItemsCount() {
        return this.type.length;
    }

    protected CharSequence getItemText(int index) {
        return this.context.getString(this.type[index]);
    }
}
