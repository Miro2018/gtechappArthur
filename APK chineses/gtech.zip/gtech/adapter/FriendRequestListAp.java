package com.accumed.gtech.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.UserManager;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.ThrAddFriend;
import com.accumed.gtech.thread.ThrChangestatus;
import com.accumed.gtech.thread.datamodel.AddFriendThrDM;
import com.accumed.gtech.thread.datamodel.ChangestatusThrDM;
import com.accumed.gtech.thread.datamodel.FriendListReturnDMSubDM;
import com.accumed.gtech.thread.datamodel.NotiFriensRequestThrDM;
import com.accumed.gtech.thread.datamodel.UserRequestReturnDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import java.util.ArrayList;
import java.util.List;

public class FriendRequestListAp extends ArrayAdapter<UserRequestReturnDM> {
    static final String className = "FriendRequestListAp";
    ArrayList<FriendListReturnDMSubDM> list;
    LogCat logCat = new LogCat();
    Context mContext;
    ViewHolder viewHolder;

    class RequestFriendThr extends Thread {
        NotiFriensRequestThrDM nDM;

        public RequestFriendThr(NotiFriensRequestThrDM d) {
            this.nDM = d;
        }

        public void run() {
            new SDConnection(this.nDM).notiFriendsRequestResult(FriendRequestListAp.this.mContext, ClassConstant.SUBDIR_SUPORT_NOTI_FRIENDS);
        }
    }

    class ViewHolder {
        public Button deniedBt = null;
        public TextView emailTv = null;
        public TextView nameEmailSpTv = null;
        public TextView nameTv = null;
        public Button requestBt = null;
        public ImageView userCircleIv = null;

        ViewHolder() {
        }
    }

    public FriendRequestListAp(Context context, int textViewResourceId, List objects) {
        super(context, textViewResourceId, objects);
        this.mContext = context;
        this.list = new ArrayList();
        this.list = (ArrayList) objects;
    }

    public void setList(ArrayList<FriendListReturnDMSubDM> l) {
        this.list = l;
    }

    public int getCount() {
        return this.list.size();
    }

    public UserRequestReturnDM getItem(int position) {
        return (UserRequestReturnDM) super.getItem(position);
    }

    public long getItemId(int position) {
        return super.getItemId(position);
    }

    public View getView(int position, View convertview, ViewGroup parent) {
        View v = convertview;
        final int posi = position;
        if (v == null) {
            this.viewHolder = new ViewHolder();
            v = ((Activity) this.mContext).getLayoutInflater().inflate(C0213R.layout.detail_user_request, parent, false);
            this.viewHolder.nameTv = (TextView) v.findViewById(C0213R.id.nameTv);
            this.viewHolder.emailTv = (TextView) v.findViewById(C0213R.id.emailTv);
            this.viewHolder.requestBt = (Button) v.findViewById(C0213R.id.requestBt);
            this.viewHolder.userCircleIv = (ImageView) v.findViewById(C0213R.id.userCircleIv);
            this.viewHolder.userCircleIv.setVisibility(8);
            this.viewHolder.nameEmailSpTv = (TextView) v.findViewById(C0213R.id.nameEmailSpTv);
            this.viewHolder.deniedBt = (Button) v.findViewById(C0213R.id.deniedBt);
            v.setTag(this.viewHolder);
        } else {
            this.viewHolder = (ViewHolder) v.getTag();
        }
        if (((FriendListReturnDMSubDM) this.list.get(position)).name.equals("null")) {
            this.viewHolder.nameTv.setVisibility(8);
            this.viewHolder.nameEmailSpTv.setVisibility(8);
        } else {
            this.viewHolder.nameTv.setVisibility(0);
            this.viewHolder.nameEmailSpTv.setVisibility(0);
        }
        if (((FriendListReturnDMSubDM) this.list.get(position)).status.equals("null") || ((FriendListReturnDMSubDM) this.list.get(position)).status.equals("")) {
            this.viewHolder.requestBt.setVisibility(0);
            this.viewHolder.deniedBt.setVisibility(8);
        } else if (((FriendListReturnDMSubDM) this.list.get(position)).status.equals("add")) {
            this.viewHolder.requestBt.setVisibility(8);
            this.viewHolder.deniedBt.setVisibility(0);
        }
        this.viewHolder.nameTv.setText(((FriendListReturnDMSubDM) this.list.get(position)).name);
        this.viewHolder.emailTv.setText(((FriendListReturnDMSubDM) this.list.get(position)).friend);
        this.viewHolder.requestBt.setBackgroundDrawable(null);
        this.viewHolder.requestBt.setPaintFlags(this.viewHolder.requestBt.getPaintFlags() | 8);
        this.viewHolder.requestBt.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                FriendRequestListAp.this.logCat.log(FriendRequestListAp.className, "onclick", ((FriendListReturnDMSubDM) FriendRequestListAp.this.list.get(posi)).id);
                PreferenceAction pref = new PreferenceAction(FriendRequestListAp.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                NotiFriensRequestThrDM nDM = new NotiFriensRequestThrDM();
                nDM.my_email = pref.getString(PreferenceAction.MY_EMAIL);
                nDM.message = FriendRequestListAp.this.mContext.getString(C0213R.string.noti_request_friend);
                nDM.friend_email = ((FriendListReturnDMSubDM) FriendRequestListAp.this.list.get(posi)).friend;
                FriendRequestListAp.this.logCat.log(FriendRequestListAp.className, "notiresult", new SDConnection(nDM).notiFriendsRequestResult(FriendRequestListAp.this.mContext, ClassConstant.SUBDIR_SUPORT_NOTI_FRIENDS));
                AddFriendThrDM addFriendThrDM = new AddFriendThrDM();
                addFriendThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
                addFriendThrDM.friendemail = ((FriendListReturnDMSubDM) FriendRequestListAp.this.list.get(posi)).friend;
                new ThrAddFriend(FriendRequestListAp.this.mContext, addFriendThrDM, (UserManager) FriendRequestListAp.this.mContext, ClassConstant.SUBDIR_USER_ADDFRIEND).start();
                FriendRequestListAp.this.logCat.log(FriendRequestListAp.className, "request", "click");
                PreferenceAction notiPref = new PreferenceAction(FriendRequestListAp.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                NotiFriensRequestThrDM dm = new NotiFriensRequestThrDM();
                dm.friend_email = ((FriendListReturnDMSubDM) FriendRequestListAp.this.list.get(posi)).friend;
                dm.message = FriendRequestListAp.this.mContext.getString(C0213R.string.noti_request_friend);
                dm.my_email = notiPref.getString(PreferenceAction.MY_EMAIL);
                dm.my_name = notiPref.getString(PreferenceAction.MY_NAME);
                new RequestFriendThr(dm).start();
            }
        });
        this.viewHolder.deniedBt.setBackgroundDrawable(null);
        this.viewHolder.deniedBt.setPaintFlags(this.viewHolder.deniedBt.getPaintFlags() | 8);
        this.viewHolder.deniedBt.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
                ChangestatusThrDM dm = new ChangestatusThrDM();
                dm.id = ((FriendListReturnDMSubDM) FriendRequestListAp.this.list.get(posi)).id;
                dm.command = ChangestatusThrDM.USER_DENY;
                new ThrChangestatus(FriendRequestListAp.this.mContext, dm, (UserManager) FriendRequestListAp.this.mContext, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
            }
        });
        return v;
    }
}
