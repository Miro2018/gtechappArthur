package com.accumed.gtech.adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.UserManager;
import com.accumed.gtech.thread.ThrChangestatus;
import com.accumed.gtech.thread.datamodel.ChangestatusThrDM;
import com.accumed.gtech.thread.datamodel.FriendListReturnDMSubDM;
import com.accumed.gtech.thread.datamodel.UserRequestReturnDM;
import com.accumed.gtech.util.LogCat;
import java.util.ArrayList;
import java.util.List;

public class FriendListAp extends ArrayAdapter<UserRequestReturnDM> {
    static final String className = "FriendListAp";
    ArrayList<Integer> clickList = new ArrayList();
    ArrayList<FriendListReturnDMSubDM> list;
    LogCat logCat = new LogCat();
    Context mContext;
    ArrayList<Integer> vList = new ArrayList();
    ViewHolder viewHolder;

    class ViewHolder {
        View parentView;

        public ViewHolder(View pv) {
            this.parentView = pv;
        }

        public TextView nameTv() {
            return (TextView) this.parentView.findViewById(C0213R.id.nameTv);
        }

        public TextView emailTv() {
            return (TextView) this.parentView.findViewById(C0213R.id.emailTv);
        }

        public Button requestBt() {
            return (Button) this.parentView.findViewById(C0213R.id.requestBt);
        }

        public LinearLayout detailLy0() {
            return (LinearLayout) this.parentView.findViewById(C0213R.id.detailLy0);
        }

        public ImageView userCircleIv() {
            return (ImageView) this.parentView.findViewById(C0213R.id.userCircleIv);
        }
    }

    public FriendListAp(Context context, int textViewResourceId, List objects) {
        super(context, textViewResourceId, objects);
        this.mContext = context;
        this.list = new ArrayList();
        this.list = (ArrayList) objects;
    }

    public void setList(ArrayList<FriendListReturnDMSubDM> l) {
        this.list = l;
    }

    public int getCount() {
        return this.list.size();
    }

    public UserRequestReturnDM getItem(int position) {
        return (UserRequestReturnDM) super.getItem(position);
    }

    public long getItemId(int position) {
        return super.getItemId(position);
    }

    public View getView(int position, View convertview, ViewGroup parent) {
        final int posi = position;
        if (convertview == null) {
            convertview = ((Activity) this.mContext).getLayoutInflater().inflate(C0213R.layout.detail_user_flist, parent, false);
            this.viewHolder = new ViewHolder(convertview);
            convertview.setTag(this.viewHolder);
        } else {
            this.viewHolder = (ViewHolder) convertview.getTag();
        }
        this.viewHolder.nameTv().setText(((FriendListReturnDMSubDM) this.list.get(position)).name);
        this.viewHolder.emailTv().setText(((FriendListReturnDMSubDM) this.list.get(position)).friend);
        if (position == 0) {
            this.viewHolder.requestBt().setVisibility(8);
        } else {
            this.viewHolder.requestBt().setVisibility(0);
        }
        this.viewHolder.requestBt().setText(C0213R.string.btn_del);
        this.viewHolder.requestBt().setBackgroundDrawable(null);
        this.viewHolder.requestBt().setPaintFlags(this.viewHolder.requestBt().getPaintFlags() | 8);
        this.viewHolder.requestBt().setOnClickListener(new OnClickListener() {

            class C02381 implements DialogInterface.OnClickListener {
                C02381() {
                }

                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                    ChangestatusThrDM dm = new ChangestatusThrDM();
                    dm.id = ((FriendListReturnDMSubDM) FriendListAp.this.list.get(posi)).id;
                    dm.command = ChangestatusThrDM.USER_DEL;
                    new ThrChangestatus(FriendListAp.this.mContext, dm, (UserManager) FriendListAp.this.mContext, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
                }
            }

            class C02392 implements DialogInterface.OnClickListener {
                C02392() {
                }

                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            }

            public void onClick(View arg0) {
                FriendListAp.this.logCat.log(FriendListAp.className, "onclick2", ((FriendListReturnDMSubDM) FriendListAp.this.list.get(posi)).id);
                String title = FriendListAp.this.mContext.getResources().getString(C0213R.string.alert_title);
                String btnOk = FriendListAp.this.mContext.getResources().getString(C0213R.string.btn_ok);
                String btnCancel = FriendListAp.this.mContext.getResources().getString(C0213R.string.btn_cancel);
                Builder alt_bld = new Builder((UserManager) FriendListAp.this.mContext);
                alt_bld.setMessage(FriendListAp.this.mContext.getResources().getString(C0213R.string.alert_type22));
                alt_bld.setCancelable(false);
                alt_bld.setPositiveButton(btnOk, new C02381());
                alt_bld.setNegativeButton(btnCancel, new C02392());
                AlertDialog alert = alt_bld.create();
                alert.setTitle(title);
                alert.show();
            }
        });
        this.viewHolder.detailLy0().setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FriendListAp.this.vList.clear();
                FriendListAp.this.vList.add(Integer.valueOf(posi));
                FriendListAp.this.notifyDataSetChanged();
                ((UserManager) FriendListAp.this.mContext).userClick(((FriendListReturnDMSubDM) FriendListAp.this.list.get(posi)).friend, ((FriendListReturnDMSubDM) FriendListAp.this.list.get(posi)).name);
            }
        });
        try {
            if (((Integer) this.vList.get(0)).intValue() == position) {
                this.viewHolder.userCircleIv().setImageResource(C0213R.drawable.btn_circle_selected);
            } else {
                this.viewHolder.userCircleIv().setImageResource(C0213R.drawable.btn_circle_normal);
            }
        } catch (Exception e) {
            this.viewHolder.userCircleIv().setImageResource(C0213R.drawable.btn_circle_normal);
        }
        return convertview;
    }
}
