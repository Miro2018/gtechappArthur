package com.accumed.gtech.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.datamodel.LogDM;
import java.util.ArrayList;

public class InsulinListAdapter extends BaseAdapter implements OnClickListener {
    private ArrayList<LogDM> mArr;
    Context mContext;
    private ArrayList<String> mRealNameArr;

    public InsulinListAdapter(Context c, ArrayList<LogDM> mArr, ArrayList<String> mRealNameArr) {
        this.mContext = c;
        this.mArr = mArr;
        this.mRealNameArr = mRealNameArr;
    }

    public int getCount() {
        return this.mArr.size();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    public View getLayout() {
        return (LinearLayout) ((LayoutInflater) this.mContext.getSystemService("layout_inflater")).inflate(C0213R.layout.item_insulin, null);
    }

    public View getView(int position, View view, ViewGroup parent) {
        view = getLayout();
        String realName = (String) this.mRealNameArr.get(position);
        String value = ((LogDM) this.mArr.get(position)).insulin_value;
        TextView tvValue = (TextView) view.findViewById(C0213R.id.tv_item_value);
        ((TextView) view.findViewById(C0213R.id.tv_item_name)).setText(realName);
        tvValue.setText(value);
        Button btnDelete = (Button) view.findViewById(C0213R.id.btn_delete);
        btnDelete.setTag(Integer.valueOf(position));
        btnDelete.setOnClickListener(this);
        return view;
    }

    public void onClick(View v) {
        if (v.getId() == C0213R.id.btn_delete) {
            delete(((Integer) v.getTag()).intValue());
        }
    }

    private void delete(int position) {
        this.mArr.remove(position);
        this.mRealNameArr.remove(position);
        notifyDataSetChanged();
    }
}
