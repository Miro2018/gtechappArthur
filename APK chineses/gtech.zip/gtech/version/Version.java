package com.accumed.gtech.version;

public class Version {
    public static final String APP_VERSION = "1.2.7.0";
    public static final int APP_VERSION_CODE = 55;
    public static final String DB_NEW_VERSION = "2";
    public static final String DB_VERSION = "1";
}
