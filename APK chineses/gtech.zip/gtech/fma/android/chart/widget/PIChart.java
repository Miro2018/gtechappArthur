package com.accumed.gtech.fma.android.chart.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Region;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Vector;
import lecho.lib.hellocharts.model.BubbleChartData;

public class PIChart extends View {
    private static final int PICHART_SEGMENT = 360;
    private static float SIZE_5_SP;
    private float PICHART_COLUMN_HEIGHT;
    private float PICHART_SELECTED_DELTA;
    private float PICHART_VH_RATIO = PullToRefreshBase.DEFAULT_FRICTION;
    private boolean doRegenerate = false;
    private boolean doSort;
    private Paint paint = new Paint();
    private Vector<PIChartItem> pathList = new Vector();
    private int selected = -1;
    private boolean showName = true;
    private boolean showPercent = true;
    private boolean showText = true;
    private float totalAmount = 0.0f;
    private String unit = "";

    class C02611 implements Comparator<PIChartItem> {
        C02611() {
        }

        public int compare(PIChartItem item1, PIChartItem item2) {
            if (item1.amount > item2.amount) {
                return -1;
            }
            if (item1.amount < item2.amount) {
                return 1;
            }
            return 0;
        }
    }

    public interface OnPIChartListener {
        void onSelected(PIChart pIChart, PIChartItem pIChartItem);

        void onUnselected(PIChart pIChart);
    }

    public class PIChartItem {
        private float amount;
        private int angle;
        private PointF center;
        private int color;
        private Path columnPath = new Path();
        private Vector<PointF> columnPointList = new Vector();
        private Path cutLeftPath = new Path();
        private Path cutRightPath = new Path();
        private String name;
        private Path path = new Path();
        private float percent;
        private Path selectedColumnPath = new Path();
        private Vector<PointF> selectedColumnPointList = new Vector();
        private Path selectedCutLeftPath = new Path();
        private Path selectedCutRightPath = new Path();
        private Path selectedPath = new Path();

        public String getName() {
            return this.name;
        }

        public int getColor() {
            return this.color;
        }

        public float getAmount() {
            return this.amount;
        }

        public float getPercent() {
            return this.percent;
        }

        public PIChartItem(String name, float amount, int color) {
            this.name = name;
            this.amount = amount;
            this.color = color;
        }

        public void addPoint(float x, float y, int angle) {
            if (this.path.isEmpty()) {
                this.path.moveTo(x, y);
                this.path.lineTo(x, y);
            } else {
                this.path.lineTo(x, y);
                if (angle >= 90 && angle <= 270) {
                    this.columnPointList.add(new PointF(x, y));
                }
            }
            if (this.selectedPath.isEmpty()) {
                this.selectedPath.moveTo(x, y - PIChart.this.PICHART_SELECTED_DELTA);
                this.selectedPath.lineTo(x, y - PIChart.this.PICHART_SELECTED_DELTA);
                return;
            }
            this.selectedPath.lineTo(x, y - PIChart.this.PICHART_SELECTED_DELTA);
            if (angle >= 90 && angle <= 270) {
                this.selectedColumnPointList.add(new PointF(x, y - PIChart.this.PICHART_SELECTED_DELTA));
            }
        }

        public void addLeftCut(float x, float y) {
            if (this.cutLeftPath.isEmpty()) {
                this.cutLeftPath.moveTo(x, y);
                this.cutLeftPath.lineTo(x, y);
                return;
            }
            this.cutLeftPath.lineTo(x, y);
        }

        public void addRightCut(float x, float y) {
            if (this.cutRightPath.isEmpty()) {
                this.cutRightPath.moveTo(x, y);
                this.cutRightPath.lineTo(x, y);
                return;
            }
            this.cutRightPath.lineTo(x, y);
        }

        public void addSelectedLeftCut(float x, float y) {
            if (this.selectedCutLeftPath.isEmpty()) {
                this.selectedCutLeftPath.moveTo(x, y);
                this.selectedCutLeftPath.lineTo(x, y);
                return;
            }
            this.selectedCutLeftPath.lineTo(x, y);
        }

        public void addSelectedRightCut(float x, float y) {
            if (this.selectedCutRightPath.isEmpty()) {
                this.selectedCutRightPath.moveTo(x, y);
                this.selectedCutRightPath.lineTo(x, y);
                return;
            }
            this.selectedCutRightPath.lineTo(x, y);
        }

        public void close() {
            Iterator it;
            PointF point;
            int i;
            this.path.close();
            if (!this.cutLeftPath.isEmpty()) {
                this.cutLeftPath.close();
            }
            if (!this.cutRightPath.isEmpty()) {
                this.cutRightPath.close();
            }
            this.selectedPath.close();
            if (!this.selectedCutLeftPath.isEmpty()) {
                this.selectedCutLeftPath.close();
            }
            if (!this.selectedCutRightPath.isEmpty()) {
                this.selectedCutRightPath.close();
            }
            if (this.columnPointList.size() > 0) {
                it = this.columnPointList.iterator();
                while (it.hasNext()) {
                    point = (PointF) it.next();
                    if (this.columnPath.isEmpty()) {
                        this.columnPath.moveTo(point.x, point.y);
                        this.columnPath.lineTo(point.x, point.y);
                    } else {
                        this.columnPath.lineTo(point.x, point.y);
                    }
                }
                for (i = this.columnPointList.size() - 1; i >= 0; i--) {
                    point = (PointF) this.columnPointList.elementAt(i);
                    this.columnPath.lineTo(point.x, point.y + PIChart.this.PICHART_COLUMN_HEIGHT);
                }
                this.columnPath.close();
            }
            this.columnPointList.removeAllElements();
            if (this.selectedColumnPointList.size() > 0) {
                it = this.selectedColumnPointList.iterator();
                while (it.hasNext()) {
                    point = (PointF) it.next();
                    if (this.selectedColumnPath.isEmpty()) {
                        this.selectedColumnPath.moveTo(point.x, point.y);
                        this.selectedColumnPath.lineTo(point.x, point.y);
                    } else {
                        this.selectedColumnPath.lineTo(point.x, point.y);
                    }
                }
                for (i = this.selectedColumnPointList.size() - 1; i >= 0; i--) {
                    point = (PointF) this.selectedColumnPointList.elementAt(i);
                    this.selectedColumnPath.lineTo(point.x, point.y + PIChart.this.PICHART_COLUMN_HEIGHT);
                }
                this.selectedColumnPath.close();
            }
            this.selectedColumnPointList.removeAllElements();
        }
    }

    public void setForm(float height, float selectedDelta, float vhratio) {
        this.PICHART_SELECTED_DELTA = selectedDelta;
        this.PICHART_COLUMN_HEIGHT = height;
        this.PICHART_VH_RATIO = vhratio;
    }

    public void setShowPercent(boolean showPercent) {
        this.showPercent = showPercent;
    }

    public void setShowName(boolean showName) {
        this.showName = showName;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public void setShowText(boolean showText) {
        this.showText = showText;
    }

    public void setTextSize(float sizeOfSP) {
        this.paint.setTextSize(TypedValue.applyDimension(2, sizeOfSP, getContext().getResources().getDisplayMetrics()));
    }

    public PIChart(Context context) {
        super(context);
        SIZE_5_SP = TypedValue.applyDimension(2, 5.0f, getContext().getResources().getDisplayMetrics());
        this.PICHART_SELECTED_DELTA = TypedValue.applyDimension(2, 7.0f, getContext().getResources().getDisplayMetrics());
        this.PICHART_COLUMN_HEIGHT = TypedValue.applyDimension(2, 15.0f, getContext().getResources().getDisplayMetrics());
        this.paint.setAntiAlias(true);
        this.paint.setStyle(Style.FILL);
        this.paint.setTextSize(TypedValue.applyDimension(2, 12.0f, getContext().getResources().getDisplayMetrics()));
    }

    public PIChart(Context context, AttributeSet attrs) {
        super(context, attrs);
        SIZE_5_SP = TypedValue.applyDimension(2, 5.0f, getContext().getResources().getDisplayMetrics());
        this.PICHART_SELECTED_DELTA = TypedValue.applyDimension(2, 7.0f, getContext().getResources().getDisplayMetrics());
        this.PICHART_COLUMN_HEIGHT = TypedValue.applyDimension(2, 15.0f, getContext().getResources().getDisplayMetrics());
        this.paint.setAntiAlias(true);
        this.paint.setStyle(Style.FILL);
        this.paint.setTextSize(TypedValue.applyDimension(2, 12.0f, getContext().getResources().getDisplayMetrics()));
    }

    public PIChart(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        SIZE_5_SP = TypedValue.applyDimension(2, 5.0f, getContext().getResources().getDisplayMetrics());
        this.PICHART_SELECTED_DELTA = TypedValue.applyDimension(2, 7.0f, getContext().getResources().getDisplayMetrics());
        this.PICHART_COLUMN_HEIGHT = TypedValue.applyDimension(2, 15.0f, getContext().getResources().getDisplayMetrics());
        this.paint.setAntiAlias(true);
        this.paint.setTextSize(TypedValue.applyDimension(2, 12.0f, getContext().getResources().getDisplayMetrics()));
    }

    protected void onDraw(Canvas canvas) {
        if (this.doRegenerate) {
            generate(this.doSort);
            this.doRegenerate = false;
        }
        super.onDraw(canvas);
        if (this.pathList.size() != 0) {
            int i;
            PIChartItem item;
            String text2;
            float maxSize2;
            String text1;
            float maxSize1;
            String amount;
            int line;
            float unitHeight;
            float height;
            float textPosLeftTop = SIZE_5_SP;
            float textPosRightTop = SIZE_5_SP;
            float textPosLeftBottom = ((float) getHeight()) - SIZE_5_SP;
            float textPosRightBottom = ((float) getHeight()) - SIZE_5_SP;
            for (i = this.pathList.size() - 1; i >= 0; i--) {
                if (i != this.selected) {
                    item = (PIChartItem) this.pathList.elementAt(i);
                    if (!item.cutLeftPath.isEmpty()) {
                        this.paint.setColor(item.color);
                        canvas.drawPath(item.cutLeftPath, this.paint);
                    }
                    if (!item.cutRightPath.isEmpty()) {
                        this.paint.setColor(item.color);
                        canvas.drawPath(item.cutRightPath, this.paint);
                    }
                }
            }
            for (i = this.pathList.size() - 1; i >= 0; i--) {
                if (i != this.selected) {
                    item = (PIChartItem) this.pathList.elementAt(i);
                    this.paint.setColor(item.color);
                    canvas.drawPath(item.path, this.paint);
                    if (!item.columnPath.isEmpty()) {
                        this.paint.setColor(Color.argb(Color.alpha(item.color), (int) (((float) Color.red(item.color)) * 0.7f), (int) (((float) Color.green(item.color)) * 0.7f), (int) (((float) Color.blue(item.color)) * 0.7f)));
                        canvas.drawPath(item.columnPath, this.paint);
                    }
                }
            }
            if (this.showText) {
                this.paint.setColor(-1);
                for (i = this.pathList.size() - 1; i >= 0; i--) {
                    if (i != this.selected) {
                        item = (PIChartItem) this.pathList.elementAt(i);
                        if (item.angle >= 18) {
                            text2 = null;
                            maxSize2 = 0.0f;
                            if (this.showName) {
                                if (this.showPercent) {
                                    text1 = item.name;
                                    maxSize1 = this.paint.measureText(text1);
                                    text2 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                    maxSize2 = this.paint.measureText(text2);
                                } else {
                                    amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                    text1 = item.name;
                                    maxSize1 = this.paint.measureText(text1);
                                    text2 = String.format("%s%s", new Object[]{amount, this.unit});
                                    maxSize2 = this.paint.measureText(text2);
                                }
                                line = 2;
                            } else {
                                if (this.showPercent) {
                                    text1 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                    maxSize1 = this.paint.measureText(text1);
                                } else {
                                    amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                    text1 = String.format("%s%s", new Object[]{amount, this.unit});
                                    maxSize1 = this.paint.measureText(text1);
                                }
                                line = 1;
                            }
                            unitHeight = this.paint.getTextSize();
                            height = unitHeight * ((float) line);
                            if (text1 != null) {
                                canvas.drawText(text1, item.center.x - (maxSize1 / PullToRefreshBase.DEFAULT_FRICTION), ((item.center.y - height) + (unitHeight / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                            }
                            if (text2 != null) {
                                canvas.drawText(text2, item.center.x - (maxSize2 / PullToRefreshBase.DEFAULT_FRICTION), (((item.center.y - height) + (unitHeight / PullToRefreshBase.DEFAULT_FRICTION)) + unitHeight) - this.paint.ascent(), this.paint);
                            }
                        }
                    }
                }
            }
            if (this.selected >= 0 && this.selected < this.pathList.size()) {
                item = (PIChartItem) this.pathList.elementAt(this.selected);
                int color = Color.argb(Color.alpha(item.color), (int) (((float) Color.red(item.color)) * 0.7f), (int) (((float) Color.green(item.color)) * 0.7f), (int) (((float) Color.blue(item.color)) * 0.7f));
                this.paint.setColor(item.color);
                canvas.drawPath(item.selectedPath, this.paint);
                if (!item.selectedColumnPath.isEmpty()) {
                    this.paint.setColor(color);
                    canvas.drawPath(item.selectedColumnPath, this.paint);
                }
                if (!item.selectedCutLeftPath.isEmpty()) {
                    this.paint.setColor(color);
                    canvas.drawPath(item.selectedCutLeftPath, this.paint);
                }
                if (!item.selectedCutRightPath.isEmpty()) {
                    this.paint.setColor(color);
                    canvas.drawPath(item.selectedCutRightPath, this.paint);
                }
                if (item.angle >= 18 && this.showText) {
                    text2 = null;
                    maxSize2 = 0.0f;
                    if (this.showName) {
                        if (this.showPercent) {
                            text1 = item.name;
                            maxSize1 = this.paint.measureText(text1);
                            text2 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                            maxSize2 = this.paint.measureText(text2);
                        } else {
                            amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                            text1 = item.name;
                            maxSize1 = this.paint.measureText(text1);
                            text2 = String.format("%s%s", new Object[]{amount, this.unit});
                            maxSize2 = this.paint.measureText(text2);
                        }
                        line = 2;
                    } else {
                        if (this.showPercent) {
                            text1 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                            maxSize1 = this.paint.measureText(text1);
                        } else {
                            amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                            text1 = String.format("%s%s", new Object[]{amount, this.unit});
                            maxSize1 = this.paint.measureText(text1);
                        }
                        line = 1;
                    }
                    this.paint.setColor(-1);
                    unitHeight = this.paint.getTextSize();
                    height = unitHeight * ((float) line);
                    if (text1 != null) {
                        canvas.drawText(text1, item.center.x - (maxSize1 / PullToRefreshBase.DEFAULT_FRICTION), (((item.center.y - height) + (unitHeight / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent()) - this.PICHART_SELECTED_DELTA, this.paint);
                    }
                    if (text2 != null) {
                        canvas.drawText(text2, item.center.x - (maxSize2 / PullToRefreshBase.DEFAULT_FRICTION), ((((item.center.y - height) + (unitHeight / PullToRefreshBase.DEFAULT_FRICTION)) + unitHeight) - this.paint.ascent()) - this.PICHART_SELECTED_DELTA, this.paint);
                    }
                }
            }
            if (this.showText) {
                float width;
                Canvas canvas2;
                this.paint.setColor(-10722445);
                this.paint.setStrokeWidth(BubbleChartData.DEFAULT_BUBBLE_SCALE);
                for (i = this.pathList.size() - 1; i >= 0; i--) {
                    item = (PIChartItem) this.pathList.elementAt(i);
                    if (item.angle < 18) {
                        if (item.center.x < ((float) getHeight()) / PullToRefreshBase.DEFAULT_FRICTION) {
                            if (item.center.y < ((float) getHeight()) / PullToRefreshBase.DEFAULT_FRICTION) {
                                text2 = null;
                                maxSize2 = 0.0f;
                                if (this.showName) {
                                    if (this.showPercent) {
                                        text1 = item.name;
                                        maxSize1 = this.paint.measureText(text1);
                                        text2 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                        maxSize2 = this.paint.measureText(text2);
                                    } else {
                                        amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                        text1 = item.name;
                                        maxSize1 = this.paint.measureText(text1);
                                        text2 = String.format("%s%s", new Object[]{amount, this.unit});
                                        maxSize2 = this.paint.measureText(text2);
                                    }
                                    line = 2;
                                } else {
                                    if (this.showPercent) {
                                        text1 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                        maxSize1 = this.paint.measureText(text1);
                                    } else {
                                        amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                        text1 = String.format("%s%s", new Object[]{amount, this.unit});
                                        maxSize1 = this.paint.measureText(text1);
                                    }
                                    line = 1;
                                }
                                this.paint.setColor(-10066330);
                                unitHeight = this.paint.getTextSize();
                                height = unitHeight * ((float) line);
                                if (maxSize1 > maxSize2) {
                                    width = maxSize1;
                                } else {
                                    width = maxSize2;
                                }
                                if (i == this.selected) {
                                    canvas2 = canvas;
                                    canvas2.drawLine(item.center.x, item.center.y - this.PICHART_SELECTED_DELTA, SIZE_5_SP + (SIZE_5_SP + width), textPosLeftTop + (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                                } else {
                                    canvas2 = canvas;
                                    canvas2.drawLine(item.center.x, item.center.y, SIZE_5_SP + (SIZE_5_SP + width), textPosLeftTop + (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                                }
                                canvas2 = canvas;
                                canvas2.drawLine(SIZE_5_SP + (SIZE_5_SP + width), textPosLeftTop + (height / PullToRefreshBase.DEFAULT_FRICTION), SIZE_5_SP + width, textPosLeftTop + (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                                if (text1 != null) {
                                    canvas.drawText(text1, SIZE_5_SP, textPosLeftTop - this.paint.ascent(), this.paint);
                                }
                                if (text2 != null) {
                                    canvas.drawText(text2, SIZE_5_SP, (textPosLeftTop + unitHeight) - this.paint.ascent(), this.paint);
                                }
                                textPosLeftTop += 5.0f + height;
                            }
                        } else if (item.center.y >= ((float) getHeight()) / PullToRefreshBase.DEFAULT_FRICTION) {
                            text2 = null;
                            maxSize2 = 0.0f;
                            if (this.showName) {
                                if (this.showPercent) {
                                    text1 = item.name;
                                    maxSize1 = this.paint.measureText(text1);
                                    text2 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                    maxSize2 = this.paint.measureText(text2);
                                } else {
                                    amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                    text1 = item.name;
                                    maxSize1 = this.paint.measureText(text1);
                                    text2 = String.format("%s%s", new Object[]{amount, this.unit});
                                    maxSize2 = this.paint.measureText(text2);
                                }
                                line = 2;
                            } else {
                                if (this.showPercent) {
                                    text1 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                    maxSize1 = this.paint.measureText(text1);
                                } else {
                                    amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                    text1 = String.format("%s%s", new Object[]{amount, this.unit});
                                    maxSize1 = this.paint.measureText(text1);
                                }
                                line = 1;
                            }
                            this.paint.setColor(-10066330);
                            unitHeight = this.paint.getTextSize();
                            height = unitHeight * ((float) line);
                            if (maxSize1 > maxSize2) {
                                width = maxSize1;
                            } else {
                                width = maxSize2;
                            }
                            if (i == this.selected) {
                                canvas.drawLine(item.center.x, item.center.y - this.PICHART_SELECTED_DELTA, (((float) getHeight()) - (SIZE_5_SP + width)) - SIZE_5_SP, textPosRightBottom - (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                            } else {
                                canvas.drawLine(item.center.x, item.center.y, (((float) getHeight()) - (SIZE_5_SP + width)) - SIZE_5_SP, textPosRightBottom - (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                            }
                            canvas.drawLine((((float) getHeight()) - (SIZE_5_SP + width)) - SIZE_5_SP, textPosRightBottom - (height / PullToRefreshBase.DEFAULT_FRICTION), ((float) getHeight()) - (SIZE_5_SP + width), textPosRightBottom - (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                            if (text1 != null) {
                                canvas.drawText(text1, ((float) getHeight()) - (SIZE_5_SP + width), (textPosRightBottom - height) - this.paint.ascent(), this.paint);
                            }
                            if (text2 != null) {
                                canvas.drawText(text2, ((float) getHeight()) - (SIZE_5_SP + width), ((textPosRightBottom - height) + unitHeight) - this.paint.ascent(), this.paint);
                            }
                            textPosRightBottom -= 5.0f + height;
                        }
                    }
                }
                for (i = this.pathList.size() - 1; i >= 0; i--) {
                    item = (PIChartItem) this.pathList.elementAt(i);
                    if (item.angle < 18) {
                        if (item.center.x < ((float) getHeight()) / PullToRefreshBase.DEFAULT_FRICTION) {
                            if (item.center.y >= ((float) getHeight()) / PullToRefreshBase.DEFAULT_FRICTION) {
                                text2 = null;
                                maxSize2 = 0.0f;
                                if (this.showName) {
                                    if (this.showPercent) {
                                        text1 = item.name;
                                        maxSize1 = this.paint.measureText(text1);
                                        text2 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                        maxSize2 = this.paint.measureText(text2);
                                    } else {
                                        amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                        text1 = item.name;
                                        maxSize1 = this.paint.measureText(text1);
                                        text2 = String.format("%s%s", new Object[]{amount, this.unit});
                                        maxSize2 = this.paint.measureText(text2);
                                    }
                                    line = 2;
                                } else {
                                    if (this.showPercent) {
                                        text1 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                        maxSize1 = this.paint.measureText(text1);
                                    } else {
                                        amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                        text1 = String.format("%s%s", new Object[]{amount, this.unit});
                                        maxSize1 = this.paint.measureText(text1);
                                    }
                                    line = 1;
                                }
                                this.paint.setColor(-10066330);
                                unitHeight = this.paint.getTextSize();
                                height = unitHeight * ((float) line);
                                if (maxSize1 > maxSize2) {
                                    width = maxSize1;
                                } else {
                                    width = maxSize2;
                                }
                                if (i == this.selected) {
                                    canvas2 = canvas;
                                    canvas2.drawLine(item.center.x, item.center.y - this.PICHART_SELECTED_DELTA, SIZE_5_SP + (SIZE_5_SP + width), textPosLeftBottom - (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                                } else {
                                    canvas2 = canvas;
                                    canvas2.drawLine(item.center.x, item.center.y, SIZE_5_SP + (SIZE_5_SP + width), textPosLeftBottom - (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                                }
                                canvas2 = canvas;
                                canvas2.drawLine(SIZE_5_SP + (SIZE_5_SP + width), textPosLeftBottom - (height / PullToRefreshBase.DEFAULT_FRICTION), SIZE_5_SP + width, textPosLeftBottom - (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                                if (text1 != null) {
                                    canvas.drawText(text1, SIZE_5_SP, (textPosLeftBottom - height) - this.paint.ascent(), this.paint);
                                }
                                if (text2 != null) {
                                    canvas.drawText(text2, SIZE_5_SP, ((textPosLeftBottom - height) + unitHeight) - this.paint.ascent(), this.paint);
                                }
                                textPosLeftBottom -= 5.0f + height;
                            }
                        } else if (item.center.y < ((float) getHeight()) / PullToRefreshBase.DEFAULT_FRICTION) {
                            text2 = null;
                            maxSize2 = 0.0f;
                            if (this.showName) {
                                if (this.showPercent) {
                                    text1 = item.name;
                                    maxSize1 = this.paint.measureText(text1);
                                    text2 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                    maxSize2 = this.paint.measureText(text2);
                                } else {
                                    amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                    text1 = item.name;
                                    maxSize1 = this.paint.measureText(text1);
                                    text2 = String.format("%s%s", new Object[]{amount, this.unit});
                                    maxSize2 = this.paint.measureText(text2);
                                }
                                line = 2;
                            } else {
                                if (this.showPercent) {
                                    text1 = String.format("%.2f%%", new Object[]{Float.valueOf(item.percent)});
                                    maxSize1 = this.paint.measureText(text1);
                                } else {
                                    amount = makeStringWithComma(String.format("%.0f", new Object[]{Float.valueOf(item.amount)}));
                                    text1 = String.format("%s%s", new Object[]{amount, this.unit});
                                    maxSize1 = this.paint.measureText(text1);
                                }
                                line = 1;
                            }
                            this.paint.setColor(-10066330);
                            unitHeight = this.paint.getTextSize();
                            height = unitHeight * ((float) line);
                            if (maxSize1 > maxSize2) {
                                width = maxSize1;
                            } else {
                                width = maxSize2;
                            }
                            if (i == this.selected) {
                                canvas.drawLine(item.center.x, item.center.y - this.PICHART_SELECTED_DELTA, (((float) getHeight()) - (SIZE_5_SP + width)) - SIZE_5_SP, textPosRightTop + (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                            } else {
                                canvas.drawLine(item.center.x, item.center.y, (((float) getHeight()) - (SIZE_5_SP + width)) - SIZE_5_SP, textPosRightTop + (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                            }
                            canvas.drawLine((((float) getHeight()) - (SIZE_5_SP + width)) - SIZE_5_SP, textPosRightTop + (height / PullToRefreshBase.DEFAULT_FRICTION), ((float) getHeight()) - (SIZE_5_SP + width), textPosRightTop + (height / PullToRefreshBase.DEFAULT_FRICTION), this.paint);
                            if (text1 != null) {
                                canvas.drawText(text1, ((float) getHeight()) - (SIZE_5_SP + width), textPosRightTop - this.paint.ascent(), this.paint);
                            }
                            if (text2 != null) {
                                canvas.drawText(text2, ((float) getHeight()) - (SIZE_5_SP + width), (textPosRightTop + unitHeight) - this.paint.ascent(), this.paint);
                            }
                            textPosRightTop += 5.0f + height;
                        }
                    }
                }
            }
        }
    }

    public void addItem(String name, float amount, int color) {
        this.totalAmount += amount;
        this.pathList.add(new PIChartItem(name, amount, color));
    }

    public void generate(boolean doSort) {
        if (getWidth() == 0 && getHeight() == 0) {
            this.doSort = doSort;
            this.doRegenerate = true;
            return;
        }
        this.doRegenerate = false;
        if (this.pathList.size() != 0) {
            PIChartItem item;
            int i;
            if (doSort) {
                Collections.sort(this.pathList, new C02611());
            }
            Iterator it = this.pathList.iterator();
            while (it.hasNext()) {
                item = (PIChartItem) it.next();
                if (this.totalAmount == 0.0f) {
                    this.totalAmount = BubbleChartData.DEFAULT_BUBBLE_SCALE;
                }
                item.percent = item.amount / this.totalAmount;
                item.angle = Math.round(item.percent * 360.0f);
                if (item.angle == 0) {
                    item.angle = 1;
                }
                item.percent = item.percent * 100.0f;
            }
            int restAngle = PICHART_SEGMENT;
            it = this.pathList.iterator();
            while (it.hasNext()) {
                restAngle -= ((PIChartItem) it.next()).angle;
            }
            if (restAngle < 0) {
                i = 0;
                while (restAngle < 0) {
                    item = (PIChartItem) this.pathList.elementAt(i % this.pathList.size());
                    if (item.angle > i) {
                        item.angle = item.angle - 1;
                        restAngle++;
                    }
                    i++;
                }
            } else {
                for (i = 0; i < restAngle; i++) {
                    ((PIChartItem) this.pathList.elementAt(i % this.pathList.size())).angle = ((PIChartItem) this.pathList.elementAt(i % this.pathList.size())).angle + 1;
                }
            }
            RectF rect = new RectF(0.0f, 0.0f, (float) getHeight(), (float) getHeight());
            PointF center = new PointF(rect.width() / PullToRefreshBase.DEFAULT_FRICTION, rect.height() / PullToRefreshBase.DEFAULT_FRICTION);
            int probe = 0;
            it = this.pathList.iterator();
            while (it.hasNext()) {
                item = (PIChartItem) it.next();
                item.addPoint(center.x, center.y, probe);
                PointF start = new PointF();
                PointF end = new PointF();
                for (i = probe; i <= item.angle + probe; i++) {
                    float radian = (float) ((((((double) i) * 3.141592653589793d) / 180.0d) * 360.0d) / 360.0d);
                    float costheta = (float) Math.sin((double) radian);
                    float sintheta = -((float) Math.cos((double) radian));
                    float r = rect.width() * 0.35f;
                    float x = (r * costheta) + center.x;
                    float y = ((r * sintheta) / this.PICHART_VH_RATIO) + center.y;
                    if (i == (item.angle / 2) + probe) {
                        item.center = new PointF(((r * costheta) / 1.5f) + center.x, ((r * sintheta) / 3.0f) + center.y);
                    }
                    if (i == probe) {
                        start.x = x;
                        start.y = y;
                    } else if (i == item.angle + probe) {
                        end.x = x;
                        end.y = y;
                    }
                    item.addPoint(x, y, i);
                }
                if (item.angle + probe > 0 && item.angle + probe < 180) {
                    item.addRightCut(center.x, center.y);
                    item.addRightCut(center.x, center.y + this.PICHART_COLUMN_HEIGHT);
                    item.addRightCut(end.x, end.y + this.PICHART_COLUMN_HEIGHT);
                    item.addRightCut(end.x, end.y);
                    item.addSelectedRightCut(center.x, center.y);
                    item.addSelectedRightCut(center.x, center.y - this.PICHART_SELECTED_DELTA);
                    item.addSelectedRightCut(end.x, end.y - this.PICHART_SELECTED_DELTA);
                    item.addSelectedRightCut(end.x, end.y);
                }
                if (probe > 180 && probe < PICHART_SEGMENT) {
                    item.addLeftCut(center.x, center.y);
                    item.addLeftCut(center.x, center.y + this.PICHART_COLUMN_HEIGHT);
                    item.addLeftCut(start.x, start.y + this.PICHART_COLUMN_HEIGHT);
                    item.addLeftCut(start.x, start.y);
                    item.addSelectedLeftCut(center.x, center.y);
                    item.addSelectedLeftCut(center.x, center.y - this.PICHART_SELECTED_DELTA);
                    item.addSelectedLeftCut(start.x, start.y - this.PICHART_SELECTED_DELTA);
                    item.addSelectedLeftCut(start.x, start.y);
                }
                item.close();
                probe += item.angle;
            }
            it = this.pathList.iterator();
            while (it.hasNext()) {
                item = (PIChartItem) it.next();
                Region region = new Region();
                RectF rectF = new RectF();
                item.path.computeBounds(rectF, true);
                region.setPath(item.path, new Region((int) rectF.left, (int) rectF.top, (int) rectF.right, (int) rectF.bottom));
            }
            invalidate();
        }
    }

    public void reset() {
        this.totalAmount = 0.0f;
        this.selected = -1;
        this.pathList.removeAllElements();
        invalidate();
    }

    private static String makeStringWithComma(String value) {
        return value;
    }
}
