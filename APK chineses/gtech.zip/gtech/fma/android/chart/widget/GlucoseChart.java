package com.accumed.gtech.fma.android.chart.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.fma.android.chart.type.GlucoseItem;
import com.accumed.gtech.fragments.GraphFragment;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Vector;
import lecho.lib.hellocharts.model.BubbleChartData;

public class GlucoseChart extends View {
    public static final int FLAG_AFTER_MEAL = 2;
    public static final int FLAG_ALL_MEAL = 4;
    public static final int FLAG_BEFORE_MEAL = 1;
    public static final int FLAG_EAT_MASK = 15;
    private static final float INSULIN_WIDTH = 5.0f;
    private static final int ONE_DAY = 86400000;
    private static final float TEXT_SIZE = 30.0f;
    static final String className = "GlucoseChart";
    private float accelLog = 10.0f;
    private float ascent;
    private Drawable btnViewline;
    private Drawable btnViewlinePressed;
    private boolean calc = false;
    private Context context;
    private int days = 0;
    private float detailPos = 0.0f;
    private long firstTimestamp = 0;
    private int flag = 3;
    private boolean flickingContinue = false;
    private final float glucoseDotMax = 650.0f;
    private boolean isDetail = false;
    private boolean isScale = false;
    private boolean isTouchDown = false;
    private Vector<GlucoseItem> items = new Vector();
    private Drawable layer;
    private Locale locale = Locale.KOREA;
    LogCat logCat = new LogCat();
    private float oldX = -1.0f;
    private Paint paint;
    private Drawable pointGray;
    private Drawable pointRed;
    private int safeZoneColor = -2760982;
    private float safeZoneMax = 200.0f;
    private float safeZoneMin = 70.0f;
    private float scale = BubbleChartData.DEFAULT_BUBBLE_SCALE;
    private int standardWidth = 0;
    private float start = -3.4028235E38f;
    private float touchDownDistance = 0.0f;
    private float touchDownPos;
    private float touchMoveRemain = 0.0f;
    private float touchScale = BubbleChartData.DEFAULT_BUBBLE_SCALE;
    private Locale unitLocale = Locale.KOREA;

    class C02601 implements Runnable {
        C02601() {
        }

        public void run() {
            try {
                GlucoseChart.this.flickingContinue = true;
                while (GlucoseChart.this.flickingContinue) {
                    GlucoseChart.this.start = GlucoseChart.this.start + GlucoseChart.this.touchMoveRemain;
                    GlucoseChart.this.touchMoveRemain = (float) (((double) GlucoseChart.this.touchMoveRemain) * Math.log10((double) GlucoseChart.this.accelLog));
                    GlucoseChart.this.accelLog = GlucoseChart.this.accelLog - ClassConstant.INPUT_GLUCOSE_MMOL_MIN;
                    if (GlucoseChart.this.touchMoveRemain == 0.0f) {
                        GlucoseChart.this.flickingContinue = false;
                    }
                    int width = GlucoseChart.this.getWidth();
                    float standardDayWidth = (float) (width / 3);
                    if (width > GlucoseChart.this.getHeight()) {
                        standardDayWidth = (float) (width / 7);
                    }
                    if (GlucoseChart.this.start < ((((float) (-GlucoseChart.this.days)) * standardDayWidth) * GlucoseChart.this.scale) + ((float) GlucoseChart.this.getWidth())) {
                        GlucoseChart.this.start = ((((float) (-GlucoseChart.this.days)) * standardDayWidth) * GlucoseChart.this.scale) + ((float) GlucoseChart.this.getWidth());
                        GlucoseChart.this.flickingContinue = false;
                    }
                    if (GlucoseChart.this.start > 0.0f) {
                        GlucoseChart.this.start = 0.0f;
                        GlucoseChart.this.flickingContinue = false;
                    }
                    GlucoseChart.this.postInvalidate();
                    Thread.sleep(100);
                }
            } catch (Exception e) {
            }
        }
    }

    class ItemComparator implements Comparator<GlucoseItem> {
        ItemComparator() {
        }

        public int compare(GlucoseItem arg0, GlucoseItem arg1) {
            return arg0.timestamp > arg1.timestamp ? 1 : -1;
        }
    }

    public GlucoseChart(Context context) {
        super(context);
        initialize(context);
    }

    public GlucoseChart(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(context);
    }

    public GlucoseChart(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initialize(context);
    }

    private void initialize(Context context) {
        this.safeZoneMin = 0.0f;
        this.safeZoneMax = 0.0f;
        this.paint = new Paint();
        this.paint.setAntiAlias(true);
        this.paint.setTextSize(TEXT_SIZE);
        this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
        this.ascent = this.paint.ascent();
        this.context = context;
    }

    public void setSafezone(int max, int min) {
        this.safeZoneMin = (float) min;
        this.safeZoneMax = (float) max;
    }

    public void setBtnViewlineResource(int resId, int resIdPressed) {
        this.btnViewline = this.context.getResources().getDrawable(resId);
        this.btnViewlinePressed = this.context.getResources().getDrawable(resIdPressed);
        invalidate();
    }

    public void setPointResource(int resIdGray, int resIdRed) {
        this.pointGray = this.context.getResources().getDrawable(resIdGray);
        this.pointRed = this.context.getResources().getDrawable(resIdRed);
        invalidate();
    }

    public void setLayerResource(int resId) {
        this.layer = this.context.getResources().getDrawable(resId);
        invalidate();
    }

    public void setItems(Vector<GlucoseItem> items) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
            Iterator it = items.iterator();
            while (it.hasNext()) {
                GlucoseItem item = (GlucoseItem) it.next();
                item.timestamp = sdf.parse(item.date + item.time).getTime();
            }
            Collections.sort(items, new ItemComparator());
            sdf = new SimpleDateFormat("yyyyMMdd");
            if (items.size() > 0) {
                GlucoseItem last = (GlucoseItem) items.lastElement();
                this.firstTimestamp = sdf.parse(((GlucoseItem) items.firstElement()).date).getTime();
                this.days = (int) (((sdf.parse(last.date).getTime() + GraphFragment.DATE_DAY) / GraphFragment.DATE_DAY) - (this.firstTimestamp / GraphFragment.DATE_DAY));
            }
            this.items.removeAllElements();
            this.items.addAll(items);
            this.calc = true;
            invalidate();
        } catch (Exception e) {
        }
    }

    private boolean dataHalfCheck(int[] arr, String v) {
        for (int num : arr) {
            if (Integer.toString(num).equals(v)) {
                return true;
            }
        }
        return false;
    }

    protected synchronized void onDraw(Canvas canvas) {
        int width = getWidth();
        int height = getHeight();
        if (!(width == 0 || height == 0)) {
            Iterator it;
            GlucoseItem item;
            if (this.standardWidth != width) {
                this.calc = true;
                this.standardWidth = width;
            }
            float standardDayWidth = (float) (width / 3);
            if (width > height) {
                standardDayWidth = (float) (width / 7);
            }
            if (this.start < ((((float) (-this.days)) * standardDayWidth) * this.scale) + ((float) width)) {
                this.start = ((((float) (-this.days)) * standardDayWidth) * this.scale) + ((float) width);
            }
            if (this.start > 0.0f) {
                this.start = 0.0f;
            }
            if (this.detailPos > ((float) width)) {
                this.detailPos = (float) width;
            }
            if (this.detailPos < 0.0f) {
                this.detailPos = 0.0f;
            }
            if (this.calc) {
                it = this.items.iterator();
                while (it.hasNext()) {
                    item = (GlucoseItem) it.next();
                    item.pos = (((float) (item.timestamp - this.firstTimestamp)) / 8.64E7f) * standardDayWidth;
                }
                this.calc = false;
            }
            int[] glocesHalfArr = new int[(((int) (700.0f / 100.0f)) - 1)];
            this.logCat.log(className, "glocesHalfArr length", Integer.toString(glocesHalfArr.length));
            for (int r = 1; r <= glocesHalfArr.length; r++) {
                glocesHalfArr[r - 1] = (((int) 700.0f) - (r * 100)) - 50;
                this.logCat.log(className, "glocesHalfArr" + Integer.toString(r - 1), Integer.toString(glocesHalfArr[r - 1]));
            }
            int[] iArr = new int[7];
            iArr = new int[]{2, 8, 12, 18, 22, 28, 32};
            GlucoseItem prev = null;
            GlucoseItem detailPrev = null;
            float textHeight = 4.0f + this.paint.getTextSize();
            float clientHeight = ((float) height) - (3.0f * textHeight);
            float clientOffset = textHeight * PullToRefreshBase.DEFAULT_FRICTION;
            float screenFactor = 700.0f == 0.0f ? clientHeight : clientHeight / 700.0f;
            float y70 = (clientOffset + clientHeight) - (this.safeZoneMin * screenFactor);
            float y200 = (clientOffset + clientHeight) - (this.safeZoneMax * screenFactor);
            this.paint.setColor(this.safeZoneColor);
            canvas.drawRect(0.0f, y200, (float) width, y70, this.paint);
            long probeStamp = this.firstTimestamp;
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd");
            int i = 0;
            while (i <= this.days) {
                if (((((float) i) * standardDayWidth) * this.scale) + this.start >= (-7.0f * standardDayWidth) * this.scale && ((((float) i) * standardDayWidth) * this.scale) + this.start <= ((float) width) + ((7.0f * standardDayWidth) * this.scale)) {
                    this.paint.setColor(-13484983);
                    this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                    String dateText = simpleDateFormat.format(new Date(probeStamp));
                    canvas.drawText(dateText, (((((float) i) * standardDayWidth) * this.scale) + (((this.scale * standardDayWidth) - this.paint.measureText(dateText)) / PullToRefreshBase.DEFAULT_FRICTION)) + this.start, ((clientOffset + clientHeight) + ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - this.ascent, this.paint);
                }
                probeStamp += GraphFragment.DATE_DAY;
                i++;
            }
            this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 0));
            for (float i2 = 0.0f; i2 <= 700.0f; i2 += 50.0f) {
                float y = (clientOffset + clientHeight) - (i2 * screenFactor);
                if (i2 == 0.0f) {
                    this.paint.setColor(-4079167);
                    this.paint.setStrokeWidth(PullToRefreshBase.DEFAULT_FRICTION);
                    canvas.drawLine(0.0f, y, (float) width, y, this.paint);
                    this.paint.setStrokeWidth(BubbleChartData.DEFAULT_BUBBLE_SCALE);
                } else {
                    this.paint.setColor(-2829100);
                    this.paint.setStrokeWidth(BubbleChartData.DEFAULT_BUBBLE_SCALE);
                    canvas.drawLine(0.0f, y, (float) width, y, this.paint);
                }
                this.paint.setColor(-13484983);
                String text = String.format(this.locale, "%.0f", new Object[]{Float.valueOf(i2)});
                float textWidth = this.paint.measureText(text);
                if (i2 == 0.0f) {
                    text = new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
                    textWidth = this.paint.measureText(text);
                } else {
                    if (new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT).toLowerCase().equals("mmol/l")) {
                        text = String.format(this.locale, "%.0f", new Object[]{Double.valueOf(((double) i2) / 18.01d)});
                    }
                }
                PreferenceAction preferenceAction = new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_SETTING);
                this.logCat.log(className, "setting", preferenceAction.getString(PreferenceAction.MY_LANGUAGE));
                if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ko")) {
                    if (text.equals("700")) {
                        this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                        canvas.drawText(this.context.getResources().getString(C0213R.string.log_smenu01), (((float) width) - textWidth) - 45.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                    } else {
                        if (text.equals("650")) {
                            canvas.drawText("Hi", (((float) width) - textWidth) - 4.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                        } else {
                            if (!dataHalfCheck(glocesHalfArr, text)) {
                                canvas.drawText(text, (((float) width) - textWidth) - 4.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                            }
                            this.logCat.log(className, "text", text);
                        }
                    }
                } else {
                    if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("en")) {
                        if (text.equals("35")) {
                            this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                            canvas.drawText(this.context.getResources().getString(C0213R.string.log_smenu01), (((float) width) - textWidth) - 65.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                        } else {
                            canvas.drawText(text, (((float) width) - textWidth) - 4.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                        }
                    } else {
                        if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ru")) {
                            if (text.equals("35")) {
                                this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                                canvas.drawText(this.context.getResources().getString(C0213R.string.log_smenu01), (((float) width) - textWidth) - 65.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                            } else {
                                canvas.drawText(text, (((float) width) - textWidth) - 4.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                            }
                        } else {
                            if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("zh")) {
                                if (text.equals("35")) {
                                    this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                                    canvas.drawText(this.context.getResources().getString(C0213R.string.log_smenu01), (((float) width) - textWidth) - 65.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                                } else {
                                    canvas.drawText(text, (((float) width) - textWidth) - 4.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                                }
                            }
                        }
                    }
                }
                text = String.format(this.locale, "%.0f", new Object[]{Float.valueOf(i2 / 20.0f)});
                textWidth = this.paint.measureText(text);
                if (i2 == 0.0f) {
                    text = this.context.getResources().getString(C0213R.string.profile_text09);
                    textWidth = this.paint.measureText(text);
                }
                if (text.equals("35")) {
                    text = this.context.getResources().getString(C0213R.string.log_smenu02);
                    this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                    canvas.drawText(text, 4.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                } else if (!dataHalfCheck(iArr, text)) {
                    canvas.drawText(text, 4.0f, ((y - ((textHeight - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - textHeight) - this.ascent, this.paint);
                }
            }
            if ((this.flag & 1) == 1) {
                it = this.items.iterator();
                while (it.hasNext()) {
                    item = (GlucoseItem) it.next();
                    if ((item.pos * this.scale) + this.start >= (-7.0f * standardDayWidth) * this.scale && (item.pos * this.scale) + this.start <= ((float) width) + ((7.0f * standardDayWidth) * this.scale) && item.glutype == 1 && drawLine(canvas, item, prev, clientOffset, clientHeight, screenFactor, -6504608)) {
                        prev = item;
                    }
                }
                it = this.items.iterator();
                while (it.hasNext()) {
                    item = (GlucoseItem) it.next();
                    if ((item.pos * this.scale) + this.start >= (-7.0f * standardDayWidth) * this.scale && (item.pos * this.scale) + this.start <= ((float) width) + ((7.0f * standardDayWidth) * this.scale) && item.glutype == 1) {
                        drawElement(canvas, item, clientOffset, clientHeight, 20.0f, screenFactor);
                    }
                }
            }
            prev = null;
            if ((this.flag & 2) == 2) {
                this.logCat.log(className, "after meal", "in");
                it = this.items.iterator();
                while (it.hasNext()) {
                    item = (GlucoseItem) it.next();
                    if ((item.pos * this.scale) + this.start >= (-7.0f * standardDayWidth) * this.scale && (item.pos * this.scale) + this.start <= ((float) width) + ((7.0f * standardDayWidth) * this.scale) && item.glutype == 2 && drawLine(canvas, item, prev, clientOffset, clientHeight, screenFactor, -1352105)) {
                        prev = item;
                    }
                }
                it = this.items.iterator();
                while (it.hasNext()) {
                    item = (GlucoseItem) it.next();
                    if ((item.pos * this.scale) + this.start >= (-7.0f * standardDayWidth) * this.scale && (item.pos * this.scale) + this.start <= ((float) width) + ((7.0f * standardDayWidth) * this.scale) && item.glutype == 2) {
                        this.logCat.logF(className, "item.glucose vlaue", item.glucose);
                        drawElement(canvas, item, clientOffset, clientHeight, 20.0f, screenFactor);
                    }
                }
            }
            prev = null;
            if ((this.flag & 4) == 4) {
                it = this.items.iterator();
                while (it.hasNext()) {
                    item = (GlucoseItem) it.next();
                    if ((item.pos * this.scale) + this.start >= (-7.0f * standardDayWidth) * this.scale && (item.pos * this.scale) + this.start <= ((float) width) + ((7.0f * standardDayWidth) * this.scale) && drawLine(canvas, item, prev, clientOffset, clientHeight, screenFactor, -10712890)) {
                        prev = item;
                    }
                }
                it = this.items.iterator();
                while (it.hasNext()) {
                    item = (GlucoseItem) it.next();
                    if ((item.pos * this.scale) + this.start >= (-7.0f * standardDayWidth) * this.scale && (item.pos * this.scale) + this.start <= ((float) width) + ((7.0f * standardDayWidth) * this.scale)) {
                        drawElement(canvas, item, clientOffset, clientHeight, 20.0f, screenFactor);
                    }
                }
            }
            if (this.isDetail) {
                float line;
                Drawable btnViewline;
                int drawableWidth;
                GlucoseItem detailItem = null;
                boolean detailLeftSide = false;
                Iterator it2 = this.items.iterator();
                while (it2.hasNext()) {
                    item = (GlucoseItem) it2.next();
                    if ((item.pos * this.scale) + this.start >= 0.0f && (item.pos * this.scale) + this.start <= ((float) width)) {
                        if ((this.flag != 1 || item.glutype == 1) && (this.flag != 2 || item.glutype == 2)) {
                            if (this.flag == 1 || this.flag == 2 || this.flag == 4 || item.insulin <= 0.0f) {
                                line = this.detailPos;
                                if (this.detailPos <= (item.pos * this.scale) + this.start) {
                                    if (detailPrev == null) {
                                        line = (item.pos * this.scale) + this.start;
                                        detailItem = item;
                                    } else if (((item.pos * this.scale) + this.start) - this.detailPos <= (this.detailPos - (detailPrev.pos * this.scale)) - this.start) {
                                        line = (item.pos * this.scale) + this.start;
                                        detailItem = item;
                                    } else {
                                        line = (detailPrev.pos * this.scale) + this.start;
                                        detailItem = detailPrev;
                                    }
                                    this.paint.setColor(-1048321);
                                    this.paint.setStrokeWidth(PullToRefreshBase.DEFAULT_FRICTION);
                                    canvas.drawLine(line, 0.0f, line, ((float) height) - textHeight, this.paint);
                                    this.paint.setStrokeWidth(BubbleChartData.DEFAULT_BUBBLE_SCALE);
                                    detailLeftSide = line > ((float) (width / 2));
                                    btnViewline = this.btnViewline;
                                    if (btnViewline != null) {
                                        if (this.isTouchDown && this.btnViewlinePressed != null) {
                                            btnViewline = this.btnViewlinePressed;
                                        }
                                        drawableWidth = btnViewline.getIntrinsicWidth();
                                        btnViewline.setBounds(new Rect(((int) (line - ((float) (drawableWidth / 2)))) + 3, 0, ((int) (((float) (drawableWidth / 2)) + line)) + 3, btnViewline.getIntrinsicHeight()));
                                        btnViewline.draw(canvas);
                                    }
                                    if (detailItem == null && detailPrev != null) {
                                        detailItem = detailPrev;
                                        line = (detailItem.pos * this.scale) + this.start;
                                        this.paint.setColor(-1048321);
                                        this.paint.setStrokeWidth(PullToRefreshBase.DEFAULT_FRICTION);
                                        canvas.drawLine(line, 0.0f, line, ((float) height) - textHeight, this.paint);
                                        this.paint.setStrokeWidth(BubbleChartData.DEFAULT_BUBBLE_SCALE);
                                        detailLeftSide = line <= ((float) (width / 2));
                                        btnViewline = this.btnViewline;
                                        if (btnViewline != null) {
                                            if (this.isTouchDown && this.btnViewlinePressed != null) {
                                                btnViewline = this.btnViewlinePressed;
                                            }
                                            drawableWidth = btnViewline.getIntrinsicWidth();
                                            btnViewline.setBounds(new Rect(((int) (line - ((float) (drawableWidth / 2)))) + 3, 0, ((int) (((float) (drawableWidth / 2)) + line)) + 3, btnViewline.getIntrinsicHeight()));
                                            btnViewline.draw(canvas);
                                        }
                                    }
                                    if (detailItem != null) {
                                        drawDetail(canvas, detailItem, detailLeftSide);
                                    }
                                } else {
                                    detailPrev = item;
                                }
                            } else {
                                for (i = 0; i < this.items.size(); i++) {
                                    if (((GlucoseItem) this.items.get(i)).glutype == 0) {
                                        this.items.remove(i);
                                    }
                                }
                            }
                        }
                    }
                }
                detailItem = detailPrev;
                line = (detailItem.pos * this.scale) + this.start;
                this.paint.setColor(-1048321);
                this.paint.setStrokeWidth(PullToRefreshBase.DEFAULT_FRICTION);
                canvas.drawLine(line, 0.0f, line, ((float) height) - textHeight, this.paint);
                this.paint.setStrokeWidth(BubbleChartData.DEFAULT_BUBBLE_SCALE);
                if (line <= ((float) (width / 2))) {
                }
                btnViewline = this.btnViewline;
                if (btnViewline != null) {
                    btnViewline = this.btnViewlinePressed;
                    drawableWidth = btnViewline.getIntrinsicWidth();
                    btnViewline.setBounds(new Rect(((int) (line - ((float) (drawableWidth / 2)))) + 3, 0, ((int) (((float) (drawableWidth / 2)) + line)) + 3, btnViewline.getIntrinsicHeight()));
                    btnViewline.draw(canvas);
                }
                if (detailItem != null) {
                    drawDetail(canvas, detailItem, detailLeftSide);
                }
            }
        }
    }

    private void drawElement(Canvas canvas, GlucoseItem item, float clientOffset, float clientHeight, float insulinFactor, float screenFactor) {
        if (item.insulin > 0.0f) {
            switch (item.instype) {
                case 1:
                    this.paint.setColor(-3595485);
                    break;
                case 2:
                    this.paint.setColor(-1202432);
                    break;
                case 3:
                    this.paint.setColor(-12672000);
                    break;
                case 4:
                    this.paint.setColor(-16748618);
                    break;
                default:
                    this.paint.setColor(ViewCompat.MEASURED_STATE_MASK);
                    break;
            }
            Canvas canvas2 = canvas;
            canvas2.drawRect(this.start + ((item.pos * this.scale) - 2.5f), (clientOffset + clientHeight) - ((item.insulin * insulinFactor) * screenFactor), this.start + ((item.pos * this.scale) + 2.5f), clientOffset + clientHeight, this.paint);
        }
        if (item.glucose > 0.0f) {
            if (item.glucose > 650.0f) {
                item.glucose = 650.0f;
            }
            int drawableWidth;
            int drawableHeight;
            if (item.glucose < this.safeZoneMin || item.glucose > this.safeZoneMax) {
                if (this.pointRed != null) {
                    drawableWidth = this.pointRed.getIntrinsicWidth();
                    drawableHeight = this.pointRed.getIntrinsicHeight();
                    this.pointRed.setBounds(new Rect((int) (((item.pos * this.scale) + this.start) - ((float) (drawableWidth / 2))), (int) (((clientOffset + clientHeight) - (item.glucose * screenFactor)) - ((float) (drawableHeight / 2))), (int) (((item.pos * this.scale) + this.start) + ((float) (drawableWidth / 2))), (int) (((clientOffset + clientHeight) - (item.glucose * screenFactor)) + ((float) (drawableHeight / 2)))));
                    this.pointRed.draw(canvas);
                    return;
                }
                this.paint.setColor(SupportMenu.CATEGORY_MASK);
                canvas.drawCircle((item.pos * this.scale) + this.start, (clientOffset + clientHeight) - (item.glucose * screenFactor), INSULIN_WIDTH, this.paint);
            } else if (this.pointGray != null) {
                drawableWidth = this.pointGray.getIntrinsicWidth();
                drawableHeight = this.pointGray.getIntrinsicHeight();
                this.pointGray.setBounds(new Rect((int) (((item.pos * this.scale) + this.start) - ((float) (drawableWidth / 2))), (int) (((clientOffset + clientHeight) - (item.glucose * screenFactor)) - ((float) (drawableHeight / 2))), (int) (((item.pos * this.scale) + this.start) + ((float) (drawableWidth / 2))), (int) (((clientOffset + clientHeight) - (item.glucose * screenFactor)) + ((float) (drawableHeight / 2)))));
                this.pointGray.draw(canvas);
            } else {
                this.paint.setColor(-12566464);
                canvas.drawCircle((item.pos * this.scale) + this.start, (clientOffset + clientHeight) - (item.glucose * screenFactor), INSULIN_WIDTH, this.paint);
            }
        }
    }

    private boolean drawLine(Canvas canvas, GlucoseItem item, GlucoseItem prev, float clientOffset, float clientHeight, float screenFactor, int color) {
        if (item.glucose <= 0.0f) {
            return false;
        }
        if (prev != null) {
            this.paint.setStrokeWidth(3.0f);
            this.paint.setColor(color);
            if (item.glucose > 650.0f) {
                item.glucose = 650.0f;
            }
            Canvas canvas2 = canvas;
            canvas2.drawLine(this.start + (prev.pos * this.scale), (clientOffset + clientHeight) - (prev.glucose * screenFactor), this.start + (item.pos * this.scale), (clientOffset + clientHeight) - (item.glucose * screenFactor), this.paint);
        }
        return true;
    }

    private void drawDetail(Canvas canvas, GlucoseItem item, boolean leftside) {
        PreferenceAction preferenceAction;
        String text_befroe;
        String text_after;
        if (this.layer != null) {
            int width = getWidth();
            int height = getHeight();
            int drawableWidth = this.layer.getIntrinsicWidth();
            int drawableHeight = this.layer.getIntrinsicHeight();
            int marginHeight = ((drawableHeight - 43) - 90) - 8;
            int x = (width - drawableWidth) / 2;
            int y = (((height - drawableHeight) / 2) * 26) / 32;
            this.layer.setBounds(new Rect(x, y, x + drawableWidth, y + drawableHeight));
            this.layer.draw(canvas);
            String high = "";
            if (item.glucose > 630.0f) {
                high = "Hi";
            }
            if (item.glucose < 10.0f) {
                high = "Lo";
            }
            this.paint.setColor(-13484983);
            SimpleDateFormat sdf = null;
            preferenceAction = new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_SETTING);
            this.logCat.log(className, "llfdldfl", preferenceAction.getString(PreferenceAction.MY_LANGUAGE));
            SimpleDateFormat simpleDateFormat;
            if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ko")) {
                simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd E HH:mm", Locale.KOREAN);
            } else {
                if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("en")) {
                    simpleDateFormat = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm  ", Locale.ENGLISH);
                } else {
                    if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ru")) {
                        simpleDateFormat = new SimpleDateFormat("EEE dd MM yyyy, HH:mm  ");
                    } else {
                        if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("zh")) {
                            simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd E HH:mm", Locale.CHINESE);
                        }
                    }
                }
            }
            String text = sdf.format(new Date(item.timestamp));
            float textWidth = this.paint.measureText(text);
            this.paint.setColor(-1);
            if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ko")) {
                this.paint.setTextSize(25.0f);
                canvas.drawText(text, ((float) (x + 8)) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION), ((float) ((y - 7) + 21)) - this.ascent, this.paint);
            } else {
                if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("en")) {
                    this.paint.setTextSize(25.0f);
                    canvas.drawText(text, ((float) (x + 24)) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION), ((float) ((y - 7) + 21)) - this.ascent, this.paint);
                } else {
                    if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ru")) {
                        this.paint.setTextSize(25.0f);
                        canvas.drawText(text, ((float) (x + 24)) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION), ((float) ((y - 7) + 21)) - this.ascent, this.paint);
                    } else {
                        if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("zh")) {
                            this.paint.setTextSize(25.0f);
                            canvas.drawText(text, ((float) (x + 24)) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION), ((float) ((y - 7) + 21)) - this.ascent, this.paint);
                        }
                    }
                }
            }
            Object[] objArr;
            if (item.glucose > 0.0f && item.insulin > 0.0f) {
                if (item.glucose <= this.safeZoneMin || item.glucose >= this.safeZoneMax) {
                    this.paint.setColor(-3595485);
                } else {
                    this.paint.setColor(ViewCompat.MEASURED_STATE_MASK);
                }
                this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                preferenceAction = new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_PROFILE);
                if (preferenceAction.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT).toLowerCase().equals("mg/dl")) {
                    text = String.format(this.locale, "%.0f", new Object[]{Float.valueOf(item.glucose)});
                } else {
                    if (preferenceAction.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT).toLowerCase().equals("mmol/l")) {
                        objArr = new Object[1];
                        objArr[0] = Float.valueOf(getBsValue(item.glucose));
                        text = String.format(this.locale, "%.1f", objArr);
                    } else {
                        text = String.format(this.locale, "%.0f", new Object[]{Float.valueOf(item.glucose)});
                    }
                }
                textWidth = this.paint.measureText(text);
                float pivot = ((float) ((y + 43) + marginHeight)) + (((((float) 45) - this.paint.getTextSize()) - 10.0f) / BubbleChartData.DEFAULT_BUBBLE_SCALE);
                canvas.drawText(text, (float) (x + 20), pivot - this.paint.ascent(), this.paint);
                pivot += this.paint.getTextSize();
                this.paint.setTextSize(35.0f);
                text_befroe = this.context.getResources().getString(C0213R.string.blood_sugar_eat_before);
                text_after = this.context.getResources().getString(C0213R.string.blood_sugar_eat_after);
                if (item.glutype == 1) {
                    text = text_befroe;
                } else if (item.glutype == 2) {
                    text = text_after;
                }
                this.paint.setColor(-10658467);
                this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 0));
                textWidth = this.paint.measureText(text);
                if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ko")) {
                    this.paint.setTextSize(25.0f);
                    canvas.drawText(text, (((float) (x + drawableWidth)) - textWidth) - 20.0f, (((pivot - this.paint.getTextSize()) - INSULIN_WIDTH) - this.paint.ascent()) - PullToRefreshBase.DEFAULT_FRICTION, this.paint);
                } else {
                    if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("en")) {
                        this.paint.setTextSize(25.0f);
                        canvas.drawText(text, (((float) (x + drawableWidth)) - textWidth) - 12.0f, (((pivot - this.paint.getTextSize()) - INSULIN_WIDTH) - this.paint.ascent()) - PullToRefreshBase.DEFAULT_FRICTION, this.paint);
                    } else {
                        if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ru")) {
                            this.paint.setTextSize(25.0f);
                            canvas.drawText(text, (((float) (x + drawableWidth)) - textWidth) - 12.0f, (((pivot - this.paint.getTextSize()) - INSULIN_WIDTH) - this.paint.ascent()) - PullToRefreshBase.DEFAULT_FRICTION, this.paint);
                        } else {
                            if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("zh")) {
                                this.paint.setTextSize(25.0f);
                                canvas.drawText(text, (((float) (x + drawableWidth)) - textWidth) - 12.0f, (((pivot - this.paint.getTextSize()) - INSULIN_WIDTH) - this.paint.ascent()) - PullToRefreshBase.DEFAULT_FRICTION, this.paint);
                            }
                        }
                    }
                }
                this.paint.setColor(-2829100);
                canvas.drawLine((float) (x + 10), (float) ((((y + 43) + marginHeight) + 45) + 4), (float) ((x + drawableWidth) - 10), (float) ((((y + 43) + marginHeight) + 45) + 4), this.paint);
                this.paint.setColor(-10658467);
                this.paint.setTextSize(10.0f);
                this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 0));
                text = item.insname;
                textWidth = this.paint.measureText(text);
                canvas.drawText(text, (float) (x + 20), (((float) (((y + 43) + marginHeight) + 45)) + ((((float) 45) - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                canvas.drawText(String.format(this.locale, "%.1f", new Object[]{Float.valueOf(item.insulin)}), (((float) (x + drawableWidth)) - textWidth) - 20.0f, (((float) (((y + 43) + marginHeight) + 45)) + ((((float) 45) - this.paint.getTextSize()) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                this.paint.setTextSize(TEXT_SIZE);
                return;
            } else if (item.glucose <= 0.0f || item.insulin != 0.0f) {
                this.paint.setColor(-15065566);
                this.paint.setTextSize(55.0f);
                this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                text = item.insname;
                textWidth = this.paint.measureText(text);
                preferenceAction = new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_SETTING);
                if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ko")) {
                    canvas.drawText(text, ((float) x) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION), (((float) ((y + 43) + marginHeight)) + (((((float) 45) - this.paint.getTextSize()) - 35.0f) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                } else {
                    if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("en")) {
                        canvas.drawText(text, ((float) x) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION), (((float) ((y + 43) + marginHeight)) + (((((float) 45) - this.paint.getTextSize()) - 50.0f) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                    } else {
                        if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("ru")) {
                            canvas.drawText(text, ((float) x) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION), (((float) ((y + 43) + marginHeight)) + (((((float) 45) - this.paint.getTextSize()) - 50.0f) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                        } else {
                            if (preferenceAction.getString(PreferenceAction.MY_LANGUAGE).equals("zh")) {
                                canvas.drawText(text, ((float) x) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION), (((float) ((y + 43) + marginHeight)) + (((((float) 45) - this.paint.getTextSize()) - 50.0f) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                            }
                        }
                    }
                }
                this.paint.setTextSize(TEXT_SIZE);
                this.paint.setColor(-10658467);
                this.paint.setTextSize(35.0f);
                this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 0));
                text = String.format(this.locale, "%.1f", new Object[]{Float.valueOf(item.insulin)});
                canvas.drawText(text, ((float) x) + ((((float) drawableWidth) - this.paint.measureText(text)) / PullToRefreshBase.DEFAULT_FRICTION), (((float) (((y + 43) + marginHeight) + 45)) + (((((float) 45) - this.paint.getTextSize()) - 25.0f) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                this.paint.setTextSize(TEXT_SIZE);
                return;
            } else {
                float _x;
                if (item.glucose <= this.safeZoneMin || item.glucose >= this.safeZoneMax) {
                    this.paint.setColor(-3595485);
                    this.logCat.log(className, "zone red item.glucose, min, max", item.glucose + "," + this.safeZoneMin + "," + this.safeZoneMax);
                } else {
                    this.paint.setColor(ViewCompat.MEASURED_STATE_MASK);
                    this.logCat.log(className, "zone black item.glucose, min, max", item.glucose + "," + this.safeZoneMin + "," + this.safeZoneMax);
                }
                this.paint.setTextSize(55.0f);
                this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 1));
                preferenceAction = new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_PROFILE);
                if (preferenceAction.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT).toLowerCase().equals("mg/dl")) {
                    text = String.format(this.locale, "%.0f", new Object[]{Float.valueOf(item.glucose)});
                }
                if (preferenceAction.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT).toLowerCase().equals("mmol/l")) {
                    objArr = new Object[1];
                    objArr[0] = Float.valueOf(getBsValue(item.glucose));
                    text = String.format(this.locale, "%.1f", objArr);
                } else {
                    text = String.format(this.locale, "%.0f", new Object[]{Float.valueOf(item.glucose)});
                }
                textWidth = this.paint.measureText(text);
                if (high.equals("High")) {
                    text = "Hi";
                    _x = (((float) x) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION)) + 6.0f;
                } else {
                    _x = ((float) x) + ((((float) drawableWidth) - textWidth) / PullToRefreshBase.DEFAULT_FRICTION);
                }
                canvas.drawText(text, _x, (((float) ((y + 43) + marginHeight)) + (((((float) 45) - this.paint.getTextSize()) - 50.0f) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                text_befroe = "";
                text_after = "";
                String text_etc = "";
                text_befroe = this.context.getResources().getString(C0213R.string.graph_text_before);
                text_after = this.context.getResources().getString(C0213R.string.graph_text_after);
                text_etc = "";
                if (item.glutype == 1) {
                    text = text_befroe;
                } else if (item.glutype == 2) {
                    text = text_after;
                } else {
                    text = text_etc;
                }
                this.paint.setColor(-10658467);
                this.paint.setTextSize(35.0f);
                this.paint.setTypeface(Typeface.create(Typeface.SANS_SERIF, 0));
                canvas.drawText(text, ((float) x) + ((((float) drawableWidth) - this.paint.measureText(text)) / PullToRefreshBase.DEFAULT_FRICTION), (((float) (((y + 43) + marginHeight) + 45)) + (((((float) 45) - this.paint.getTextSize()) - 20.0f) / PullToRefreshBase.DEFAULT_FRICTION)) - this.paint.ascent(), this.paint);
                this.paint.setTextSize(TEXT_SIZE);
                return;
            }
        }
        float center = (float) (getWidth() / 4);
        if (!leftside) {
            center = (float) ((getWidth() * 3) / 4);
        }
        float width2 = (float) (((getWidth() / 2) * 9) / 10);
        if (getWidth() > getHeight()) {
            width2 = (float) (getWidth() / 3);
        }
        float textHeight = 4.0f + this.paint.getTextSize();
        float height2 = textHeight * INSULIN_WIDTH;
        this.paint.setColor(-1);
        this.paint.setStyle(Style.FILL);
        canvas.drawRect(center - (width2 / PullToRefreshBase.DEFAULT_FRICTION), textHeight * PullToRefreshBase.DEFAULT_FRICTION, center + (width2 / PullToRefreshBase.DEFAULT_FRICTION), (PullToRefreshBase.DEFAULT_FRICTION * textHeight) + height2, this.paint);
        this.paint.setColor(ViewCompat.MEASURED_STATE_MASK);
        this.paint.setStyle(Style.STROKE);
        canvas.drawRect(center - (width2 / PullToRefreshBase.DEFAULT_FRICTION), textHeight * PullToRefreshBase.DEFAULT_FRICTION, center + (width2 / PullToRefreshBase.DEFAULT_FRICTION), (PullToRefreshBase.DEFAULT_FRICTION * textHeight) + height2, this.paint);
        float probe = ((PullToRefreshBase.DEFAULT_FRICTION * textHeight) + (textHeight / PullToRefreshBase.DEFAULT_FRICTION)) - this.ascent;
        this.paint.setStyle(Style.FILL);
        this.paint.setColor(-13484983);
        canvas.drawText(new SimpleDateFormat("yyyy.MM.dd E HH:mm", this.locale).format(new Date(item.timestamp)), (center - (width2 / PullToRefreshBase.DEFAULT_FRICTION)) + (textHeight / PullToRefreshBase.DEFAULT_FRICTION), probe, this.paint);
        probe += textHeight;
        if (item.glucose > 0.0f) {
            if (item.glucose < this.safeZoneMin || item.glucose > this.safeZoneMax) {
                this.paint.setColor(SupportMenu.CATEGORY_MASK);
            } else {
                this.paint.setColor(-13484983);
            }
            preferenceAction = new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_PROFILE);
            if (preferenceAction.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT).toLowerCase().equals("mg/dl")) {
                canvas.drawText(String.format("Glucose: %.1f mg/dl", new Object[]{Float.valueOf(item.glucose)}), (center - (width2 / PullToRefreshBase.DEFAULT_FRICTION)) + (textHeight / PullToRefreshBase.DEFAULT_FRICTION), probe, this.paint);
            } else {
                if (preferenceAction.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT).toLowerCase().equals("mmol/L")) {
                    Object[] objArr2 = new Object[1];
                    objArr2[0] = Float.valueOf(getBsValue(item.glucose));
                    canvas.drawText(String.format("Glucose: %.1f mg/dl", objArr2), (center - (width2 / PullToRefreshBase.DEFAULT_FRICTION)) + (textHeight / PullToRefreshBase.DEFAULT_FRICTION), probe, this.paint);
                } else {
                    canvas.drawText(String.format("Glucose: %.1f mg/dl", new Object[]{Float.valueOf(item.glucose)}), (center - (width2 / PullToRefreshBase.DEFAULT_FRICTION)) + (textHeight / PullToRefreshBase.DEFAULT_FRICTION), probe, this.paint);
                }
            }
            probe += textHeight;
        }
        if (item.insulin > 0.0f) {
            switch (item.instype) {
                case 1:
                    this.paint.setColor(-3595485);
                    break;
                case 2:
                    this.paint.setColor(-1220864);
                    break;
                case 3:
                    this.paint.setColor(-12672000);
                    break;
                case 4:
                    this.paint.setColor(-16748618);
                    break;
                default:
                    this.paint.setColor(ViewCompat.MEASURED_STATE_MASK);
                    break;
            }
            canvas.drawText(String.format("Insulin: %.1f cc", new Object[]{Float.valueOf(item.insulin)}), (center - (width2 / PullToRefreshBase.DEFAULT_FRICTION)) + (textHeight / PullToRefreshBase.DEFAULT_FRICTION), probe, this.paint);
            probe += textHeight;
        }
        text_befroe = this.context.getResources().getString(C0213R.string.blood_sugar_eat_before);
        text_after = this.context.getResources().getString(C0213R.string.blood_sugar_eat_after);
        if (item.glutype == 1) {
            this.paint.setColor(-13484983);
            canvas.drawText(text_befroe, (center - (width2 / PullToRefreshBase.DEFAULT_FRICTION)) + (textHeight / PullToRefreshBase.DEFAULT_FRICTION), probe, this.paint);
            probe += textHeight;
        } else if (item.glutype == 2) {
            this.paint.setColor(-13484983);
            canvas.drawText(text_after, (center - (width2 / PullToRefreshBase.DEFAULT_FRICTION)) + (textHeight / PullToRefreshBase.DEFAULT_FRICTION), probe, this.paint);
            probe += textHeight;
        }
    }

    public synchronized boolean onTouchEvent(MotionEvent event) {
        boolean onTouchDownEvent;
        switch (event.getAction()) {
            case 0:
                onTouchDownEvent = onTouchDownEvent(event);
                break;
            case 1:
            case 3:
                onTouchDownEvent = onTouchUpEvent(event);
                break;
            case 2:
                onTouchDownEvent = onTouchMoveEvent(event);
                break;
            default:
                onTouchDownEvent = false;
                break;
        }
        return onTouchDownEvent;
    }

    private boolean onTouchDownEvent(MotionEvent event) {
        if (this.isDetail) {
            this.isTouchDown = true;
            this.detailPos = event.getX();
            invalidate();
        } else {
            this.isTouchDown = true;
            this.isScale = false;
            this.touchDownPos = event.getX();
            this.touchMoveRemain = 0.0f;
            this.flickingContinue = false;
            this.oldX = -1.0f;
            if (event.getPointerCount() > 1) {
                float distX = event.getX(1) - event.getX(0);
                float distY = event.getY(1) - event.getY(0);
                this.touchDownDistance = (float) Math.sqrt((double) ((distX * distX) + (distY * distY)));
                this.touchScale = this.scale;
                this.isScale = true;
            }
        }
        return true;
    }

    private boolean onTouchMoveEvent(MotionEvent event) {
        if (this.isDetail) {
            this.isTouchDown = true;
            this.detailPos = event.getX();
            invalidate();
        } else if (this.isTouchDown) {
            if (event.getPointerCount() == 1) {
                if (!this.isScale) {
                    this.start += event.getX() - this.touchDownPos;
                    this.touchDownPos = event.getX();
                    if (this.oldX >= 0.0f) {
                        this.touchMoveRemain = event.getX() - this.oldX;
                    } else {
                        this.touchMoveRemain = 0.0f;
                    }
                    this.oldX = event.getX();
                }
            } else if (event.getPointerCount() > 1) {
                float distX = event.getX(1) - event.getX(0);
                float distY = event.getY(1) - event.getY(0);
                float distance = (float) Math.sqrt((double) ((distX * distX) + (distY * distY)));
                if (distance > 10.0f) {
                    if (this.touchDownDistance == 0.0f) {
                        this.touchDownDistance = distance;
                        this.touchScale = this.scale;
                        this.isScale = true;
                    }
                    this.touchScale = (this.touchScale * distance) / this.touchDownDistance;
                    this.touchDownDistance = distance;
                    if (this.touchScale < ClassConstant.INPUT_GLUCOSE_MMOL_MIN) {
                        this.touchScale = ClassConstant.INPUT_GLUCOSE_MMOL_MIN;
                    }
                    if (this.touchScale > 10.0f) {
                        this.touchScale = 10.0f;
                    }
                    this.start = ((-(Math.abs(this.start) + ((float) (getWidth() / 2)))) * (this.touchScale / this.scale)) + ((float) (getWidth() / 2));
                    this.scale = this.touchScale;
                }
            }
            int width = getWidth();
            float standardDayWidth = (float) (width / 3);
            if (width > getHeight()) {
                standardDayWidth = (float) (width / 7);
            }
            if (this.start < ((((float) (-this.days)) * standardDayWidth) * this.scale) + ((float) getWidth())) {
                this.start = ((((float) (-this.days)) * standardDayWidth) * this.scale) + ((float) getWidth());
            }
            if (this.start > 0.0f) {
                this.start = 0.0f;
            }
            invalidate();
        }
        return true;
    }

    private boolean onTouchUpEvent(MotionEvent event) {
        if (this.isDetail) {
            this.isTouchDown = false;
            this.detailPos = event.getX();
            invalidate();
        } else {
            if (this.isTouchDown && !this.isScale) {
                this.accelLog = 10.0f;
                new Thread(new C02601()).start();
            }
            this.isTouchDown = false;
            this.touchDownDistance = 0.0f;
            this.isScale = false;
        }
        return true;
    }

    public int getFlag() {
        return this.flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
        this.calc = true;
        invalidate();
    }

    public boolean getIsDetail() {
        return this.isDetail;
    }

    public void setIsDetail(boolean isDetail) {
        this.isDetail = isDetail;
        this.calc = true;
        invalidate();
    }

    public void setSafeZoneColor(int color) {
        this.safeZoneColor = color;
        invalidate();
    }

    public void setInsulinLocale(Locale unitLocale) {
        this.unitLocale = unitLocale;
        invalidate();
    }

    public void setLocale(Locale locale) {
        this.locale = locale;
        PreferenceAction pref = new PreferenceAction(this.context, PreferenceAction.PREF_NAME_MY_SETTING);
        if (pref.getString(PreferenceAction.MY_LANGUAGE).equals("ko")) {
            this.logCat.log(className, "logcale", "0");
        } else if (pref.getString(PreferenceAction.MY_LANGUAGE).equals("en")) {
            this.logCat.log(className, "logcale", "1");
        } else {
            this.logCat.log(className, "logcale", "2");
        }
        invalidate();
    }

    private float getBsValue(float value) {
        String strValue = String.valueOf(((double) value) / 18.01d);
        String[] strArray = strValue.split("\\.");
        if (strArray.length == 2 && strArray[1].length() > 1) {
            strValue = strArray[0] + "." + strArray[1].substring(0, 1);
        }
        return Float.parseFloat(strValue);
    }
}
