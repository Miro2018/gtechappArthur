package com.accumed.gtech.fma.android.chart.type;

public class GlucoseItem {
    public static final int GLU_TYPE_AFTER_MEAL = 2;
    public static final int GLU_TYPE_BEFORE_MEAL = 1;
    public static final int GLU_TYPE_FASTING = 3;
    public static final int GLU_TYPE_UNKNOWN = 0;
    public static final int INS_TYPE_BLACK = 5;
    public static final int INS_TYPE_BLUE = 4;
    public static final int INS_TYPE_GREEN = 3;
    public static final int INS_TYPE_ORANGE = 2;
    public static final int INS_TYPE_RED = 1;
    public static final int INS_TYPE_UNKNOWN = 0;
    public String date;
    public float glucose;
    public int glutype;
    public String insname;
    public int instype;
    public float insulin;
    public float pos;
    public String time;
    public long timestamp;

    public GlucoseItem(String date, String time, int glutype, float glucose, int instype, float insulin, String insname) {
        this.date = date;
        this.time = time;
        this.glutype = glutype;
        this.glucose = glucose;
        this.instype = instype;
        this.insulin = insulin;
        this.insname = insname;
    }
}
