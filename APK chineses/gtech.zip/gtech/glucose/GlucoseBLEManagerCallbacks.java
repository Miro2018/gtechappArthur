package com.accumed.gtech.glucose;

import com.accumed.gtech.datamodel.LogDM;
import java.util.ArrayList;

public interface GlucoseBLEManagerCallbacks extends BleManagerCallbacks {
    void onDataGetCount(int i);

    void onDatasetChanged();

    void onNumberOfRecordsRequested(int i);

    void onOperationAborted();

    void onOperationCompleted();

    void onOperationCompleted(ArrayList<LogDM> arrayList);

    void onOperationFailed();

    void onOperationNotSupported();

    void onOperationStarted();
}
