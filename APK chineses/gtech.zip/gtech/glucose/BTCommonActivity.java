package com.accumed.gtech.glucose;

import android.annotation.TargetApi;
import android.app.AlertDialog.Builder;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.os.Build.VERSION;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.glucose.ScannerFragment.OnDeviceSelectedListener;
import com.accumed.gtech.util.PreferenceUtil;
import com.accumed.gtech.util.PreferenceUtil.PREF_NAME_MY_DEVICE_TABLE;
import java.util.ArrayList;
import java.util.UUID;

public class BTCommonActivity extends FragmentActivity implements BleManagerCallbacks, OnDeviceSelectedListener, GlucoseBLEManagerCallbacks {
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    protected static final int REQUEST_ENABLE_BT = 2;
    protected BleManager<? extends BleManagerCallbacks> mBleManager;
    protected boolean mDeviceConnected = false;
    protected GlucoseBLEManager mGlucoseManager;

    class C02941 implements OnDismissListener {
        C02941() {
        }

        @TargetApi(23)
        public void onDismiss(DialogInterface dialog) {
            BTCommonActivity.this.requestPermissions(new String[]{"android.permission.ACCESS_COARSE_LOCATION"}, 1);
        }
    }

    class C02952 implements OnDismissListener {
        C02952() {
        }

        public void onDismiss(DialogInterface dialog) {
        }
    }

    protected void showDeviceScanningDialog(UUID filter, boolean discoverableRequired) {
    }

    protected BleManager<GlucoseBLEManagerCallbacks> initializeManager() {
        GlucoseBLEManager manager = GlucoseBLEManager.getGlucoseManager(this);
        this.mGlucoseManager = manager;
        manager.setGattCallbacks(this);
        return manager;
    }

    protected void ensureBLESupported() {
        if (!getPackageManager().hasSystemFeature("android.hardware.bluetooth_le")) {
            Toast.makeText(this, C0213R.string.no_ble, 1).show();
            finish();
        } else if (VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != 0) {
            Builder builder = new Builder(this);
            builder.setTitle(getResources().getString(C0213R.string.location_access_title));
            builder.setMessage(getResources().getString(C0213R.string.location_access_message));
            builder.setPositiveButton(C0213R.string.btn_ok, null);
            builder.setOnDismissListener(new C02941());
            builder.show();
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults[0] != 0) {
                    Builder builder = new Builder(this);
                    builder.setTitle(getResources().getString(C0213R.string.location_access_cancel_title));
                    builder.setMessage(getResources().getString(C0213R.string.location_access_cancel_message));
                    builder.setPositiveButton(17039370, null);
                    builder.setOnDismissListener(new C02952());
                    builder.show();
                    return;
                }
                return;
            default:
                return;
        }
    }

    protected boolean isBLEEnabled() {
        BluetoothAdapter adapter = ((BluetoothManager) getSystemService("bluetooth")).getAdapter();
        return adapter != null && adapter.isEnabled();
    }

    protected void showBLEDialog() {
        startActivityForResult(new Intent("android.bluetooth.adapter.action.REQUEST_ENABLE"), 2);
    }

    public void onOperationStarted() {
    }

    public void onOperationCompleted() {
    }

    public void onOperationCompleted(ArrayList<LogDM> arrayList) {
    }

    public void onOperationFailed() {
    }

    public void onOperationAborted() {
    }

    public void onOperationNotSupported() {
    }

    public void onDatasetChanged() {
    }

    public void onNumberOfRecordsRequested(int value) {
    }

    public void onDataGetCount(int value) {
    }

    public void onDeviceConnected() {
    }

    public void onDeviceDisconnecting() {
    }

    public void onDeviceDisconnected() {
    }

    public void onLinklossOccur() {
    }

    public void onServicesDiscovered(boolean optionalServicesFound) {
    }

    public void onDeviceReady() {
    }

    public void onBatteryValueReceived(int value) {
    }

    public void onBondingRequired() {
    }

    public void onBonded() {
    }

    public void onError(String message, int errorCode) {
    }

    public void onDeviceNotSupported() {
    }

    public void onTimeSetSuccess() {
    }

    public void onGetServiceNumber() {
    }

    public void onBluetoothClose() {
    }

    public void onDeviceSelected(BluetoothDevice device, String name) {
        this.mBleManager.connect(device);
        PreferenceUtil devicePref = new PreferenceUtil(getApplicationContext(), PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
        devicePref.initDevicePref(getApplicationContext());
        devicePref.putString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS, device.getAddress());
        devicePref.putString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_NAME, device.getName());
    }

    public void onDialogCanceled() {
        setResult(0);
        finish();
    }

    protected void onPause() {
        super.onPause();
        if (this.mGlucoseManager != null) {
            this.mGlucoseManager.close();
        }
    }
}
