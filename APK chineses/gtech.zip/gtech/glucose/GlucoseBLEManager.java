package com.accumed.gtech.glucose;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.os.Handler;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.PreferenceUtil;
import com.accumed.gtech.util.PreferenceUtil.PREF_NAME_MY_DEVICE_TABLE;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Queue;
import java.util.UUID;

public class GlucoseBLEManager extends BleManager<GlucoseBLEManagerCallbacks> {
    public static final UUID CURRENT_TIME_CHARACTERISTIC = UUID.fromString("00002a2b-0000-1000-8000-00805f9b34fb");
    private static final UUID CURRENT_TIME_SERVICE_UUID = UUID.fromString("00001805-0000-1000-8000-00805f9b34fb");
    private static final UUID DEVICE_SERVICE_UUID = UUID.fromString("0000180A-0000-1000-8000-00805f9b34fb");
    private static final int FILTER_TYPE_SEQUENCE_NUMBER = 1;
    private static final int FILTER_TYPE_USER_FACING_TIME = 2;
    private static final UUID GF_CHARACTERISTIC = UUID.fromString("00002A51-0000-1000-8000-00805f9b34fb");
    public static final UUID GLS_SERVICE_UUID = UUID.fromString("00001808-0000-1000-8000-00805f9b34fb");
    private static final UUID GM_CHARACTERISTIC = UUID.fromString("00002A18-0000-1000-8000-00805f9b34fb");
    private static final UUID GM_CONTEXT_CHARACTERISTIC = UUID.fromString("00002A34-0000-1000-8000-00805f9b34fb");
    private static final UUID MANUFACTURER_CHARACTERISTIC = UUID.fromString("00002a29-0000-1000-8000-00805f9b34fb");
    private static final int OPERATOR_ALL_RECORDS = 1;
    private static final int OPERATOR_FIRST_RECORD = 5;
    private static final int OPERATOR_GREATER_THEN_OR_EQUAL = 3;
    private static final int OPERATOR_LAST_RECORD = 6;
    private static final int OPERATOR_LESS_THEN_OR_EQUAL = 2;
    private static final int OPERATOR_NULL = 0;
    private static final int OPERATOR_WITHING_RANGE = 4;
    private static final int OP_CODE_ABORT_OPERATION = 3;
    private static final int OP_CODE_DELETE_STORED_RECORDS = 2;
    private static final int OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE = 5;
    private static final int OP_CODE_REPORT_NUMBER_OF_RECORDS = 4;
    private static final int OP_CODE_REPORT_STORED_RECORDS = 1;
    private static final int OP_CODE_RESPONSE_CODE = 6;
    private static final UUID RACP_CHARACTERISTIC = UUID.fromString("00002A52-0000-1000-8000-00805f9b34fb");
    private static final int RESPONSE_ABORT_UNSUCCESSFUL = 7;
    private static final int RESPONSE_INVALID_OPERAND = 5;
    private static final int RESPONSE_INVALID_OPERATOR = 3;
    private static final int RESPONSE_NO_RECORDS_FOUND = 6;
    private static final int RESPONSE_OPERAND_NOT_SUPPORTED = 9;
    private static final int RESPONSE_OPERATOR_NOT_SUPPORTED = 4;
    private static final int RESPONSE_OP_CODE_NOT_SUPPORTED = 2;
    private static final int RESPONSE_PROCEDURE_NOT_COMPLETED = 8;
    private static final int RESPONSE_SUCCESS = 1;
    private static final UUID SERIAL_NUMBER_CHARACTERISTIC = UUID.fromString("00002a25-0000-1000-8000-00805f9b34fb");
    private static final String TAG = "GlucoseManager";
    private static GlucoseBLEManager mInstance;
    private byte dataCount = (byte) 0;
    private ArrayList<LogDM> inputListLogDM;
    private LogDM logDM;
    private boolean mAbort;
    private Context mContext;
    private BluetoothGattCharacteristic mCurrentTimeCharacteristic;
    private BluetoothGattCharacteristic mDeviceSerialNumberCharacteristic;
    private final BleManagerGattCallback mGattCallback = new C03151();
    private BluetoothGattCharacteristic mGlucoseMeasurementCharacteristic;
    private BluetoothGattCharacteristic mGlucoseMeasurementContextCharacteristic;
    private Handler mHandler = new Handler();
    private BluetoothGattCharacteristic mManufacturerCharacteristic;
    private BluetoothGattCharacteristic mRecordAccessControlPointCharacteristic;

    class C03151 extends BleManagerGattCallback {

        class C03142 implements Runnable {
            C03142() {
            }

            public void run() {
                ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onOperationCompleted();
            }
        }

        C03151() {
            super();
        }

        protected Queue<Request> initGatt(BluetoothGatt gatt) {
            LinkedList<Request> requests = new LinkedList();
            requests.push(Request.newReadRequest(GlucoseBLEManager.this.mDeviceSerialNumberCharacteristic));
            requests.push(Request.newEnableNotificationsRequest(GlucoseBLEManager.this.mGlucoseMeasurementCharacteristic));
            if (GlucoseBLEManager.this.mGlucoseMeasurementContextCharacteristic != null) {
                requests.push(Request.newEnableNotificationsRequest(GlucoseBLEManager.this.mGlucoseMeasurementContextCharacteristic));
            }
            requests.push(Request.newEnableIndicationsRequest(GlucoseBLEManager.this.mRecordAccessControlPointCharacteristic));
            return requests;
        }

        public boolean isRequiredServiceSupported(BluetoothGatt gatt) {
            BluetoothGattService currentTime = gatt.getService(GlucoseBLEManager.CURRENT_TIME_SERVICE_UUID);
            BluetoothGattService service = gatt.getService(GlucoseBLEManager.GLS_SERVICE_UUID);
            BluetoothGattService device = gatt.getService(GlucoseBLEManager.DEVICE_SERVICE_UUID);
            if (currentTime != null) {
                GlucoseBLEManager.this.mCurrentTimeCharacteristic = currentTime.getCharacteristic(GlucoseBLEManager.CURRENT_TIME_CHARACTERISTIC);
            }
            if (device != null) {
                GlucoseBLEManager.this.mDeviceSerialNumberCharacteristic = device.getCharacteristic(GlucoseBLEManager.SERIAL_NUMBER_CHARACTERISTIC);
            }
            if (service != null) {
                GlucoseBLEManager.this.mGlucoseMeasurementCharacteristic = service.getCharacteristic(GlucoseBLEManager.GM_CHARACTERISTIC);
                GlucoseBLEManager.this.mGlucoseMeasurementContextCharacteristic = service.getCharacteristic(GlucoseBLEManager.GM_CONTEXT_CHARACTERISTIC);
                GlucoseBLEManager.this.mRecordAccessControlPointCharacteristic = service.getCharacteristic(GlucoseBLEManager.RACP_CHARACTERISTIC);
            }
            return (GlucoseBLEManager.this.mGlucoseMeasurementCharacteristic == null || GlucoseBLEManager.this.mRecordAccessControlPointCharacteristic == null) ? false : true;
        }

        protected boolean isOptionalServiceSupported(BluetoothGatt gatt) {
            return GlucoseBLEManager.this.mGlucoseMeasurementContextCharacteristic != null;
        }

        protected void onDeviceDisconnected() {
            GlucoseBLEManager.this.mDeviceSerialNumberCharacteristic = null;
            GlucoseBLEManager.this.mManufacturerCharacteristic = null;
            GlucoseBLEManager.this.mGlucoseMeasurementCharacteristic = null;
            GlucoseBLEManager.this.mGlucoseMeasurementContextCharacteristic = null;
            GlucoseBLEManager.this.mRecordAccessControlPointCharacteristic = null;
            GlucoseBLEManager.this.mCurrentTimeCharacteristic = null;
        }

        public void onCharacteristicNotified(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            int flags;
            int offset;
            UUID uuid = characteristic.getUuid();
            float mGlucoseValue = 0.0f;
            if (GlucoseBLEManager.GM_CHARACTERISTIC.equals(uuid)) {
                PreferenceUtil devicePref = new PreferenceUtil(GlucoseBLEManager.this.mContext, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
                PreferenceAction preferenceAction = new PreferenceAction(GlucoseBLEManager.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                flags = characteristic.getIntValue(17, 0).intValue();
                offset = 0 + 1;
                boolean timeOffsetPresent = (flags & 1) > 0;
                boolean typeAndLocationPresent = (flags & 2) > 0;
                if ((flags & 8) > 0) {
                }
                final boolean contextInfoFollows = (flags & 16) > 0;
                int sequenceNumber = characteristic.getIntValue(18, offset).intValue();
                new PreferenceUtil(GlucoseBLEManager.this.mContext, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME).putInt(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_SEQUENCE_NUMBER, characteristic.getIntValue(18, offset).intValue());
                offset += 2;
                offset += 7;
                Calendar.getInstance().set(characteristic.getIntValue(18, offset).intValue(), characteristic.getIntValue(17, 5).intValue(), characteristic.getIntValue(17, 6).intValue(), characteristic.getIntValue(17, 7).intValue(), characteristic.getIntValue(17, 8).intValue(), characteristic.getIntValue(17, 9).intValue());
                if (timeOffsetPresent) {
                    offset += 2;
                }
                GlucoseBLEManager.this.logDM = new LogDM();
                if (typeAndLocationPresent) {
                    mGlucoseValue = characteristic.getFloatValue(50, offset).floatValue();
                    int typeAndLocation = characteristic.getIntValue(17, offset + 2).intValue();
                    if ((((typeAndLocation & 240) >> 4) == 10 || ((typeAndLocation & 240) >> 4) == 4) && ((typeAndLocation & 15) == 10 || (typeAndLocation & 15) == 4)) {
                        GlucoseBLEManager.this.logDM.blood_sugar_eat = "2";
                    }
                    offset += 3;
                }
                GlucoseBLEManager.this.logDM.device_id = devicePref.getString(PREF_NAME_MY_DEVICE_TABLE.IS_DEVICE_SERIAL_NUMBER);
                GlucoseBLEManager.this.logDM.input_date = String.format("%04d%02d%02d%02d%02d00000", new Object[]{Integer.valueOf(year), Integer.valueOf(month), Integer.valueOf(day), Integer.valueOf(hours), Integer.valueOf(minutes)});
                GlucoseBLEManager.this.logDM.blood_sugar_value = String.valueOf(Math.round(100000.0f * mGlucoseValue));
                GlucoseBLEManager.this.logDM.blood_sugar_type = "0";
                GlucoseBLEManager.this.logDM.category = Integer.toString(0);
                GlucoseBLEManager.this.logDM.update_flag = "insert";
                GlucoseBLEManager.this.logDM._id = "";
                GlucoseBLEManager.this.logDM.user_id = preferenceAction.getString(PreferenceAction.MY_EMAIL);
                GlucoseBLEManager.this.logDM.system_date = Long.toString(System.nanoTime());
                GlucoseBLEManager.this.dataCount = (byte) (GlucoseBLEManager.this.dataCount + 1);
                GlucoseBLEManager.this.mHandler.post(new Runnable() {
                    public void run() {
                        if (!contextInfoFollows) {
                            ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onDatasetChanged();
                        }
                    }
                });
                ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onDataGetCount(GlucoseBLEManager.this.dataCount);
            }
            if (GlucoseBLEManager.GM_CONTEXT_CHARACTERISTIC.equals(uuid)) {
                flags = characteristic.getIntValue(17, 0).intValue();
                offset = 0 + 1;
                boolean carbohydratePresent = (flags & 1) > 0;
                boolean mealPresent = (flags & 2) > 0;
                if ((flags & 4) > 0) {
                }
                if ((flags & 8) > 0) {
                }
                if ((flags & 16) > 0) {
                }
                if ((flags & 64) > 0) {
                }
                boolean moreFlagsPresent = (flags & 128) > 0;
                sequenceNumber = characteristic.getIntValue(18, offset).intValue();
                offset += 2;
                if (moreFlagsPresent) {
                    offset++;
                }
                if (carbohydratePresent) {
                    offset += 3;
                }
                if (mealPresent) {
                    int meal = characteristic.getIntValue(17, offset).intValue();
                    if (meal == 1) {
                        GlucoseBLEManager.this.logDM.blood_sugar_eat = "1";
                    }
                    if (meal == 2) {
                        GlucoseBLEManager.this.logDM.blood_sugar_eat = "0";
                    }
                    if (meal == 3) {
                        GlucoseBLEManager.this.logDM.blood_sugar_eat = LogDM.GLUCOSE_EAT_FASTING;
                    }
                    offset++;
                    GlucoseBLEManager.this.inputListLogDM.remove(GlucoseBLEManager.this.inputListLogDM.size() - 1);
                }
                ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onDatasetChanged();
            }
            if (GlucoseBLEManager.this.logDM.blood_sugar_eat.equals("")) {
                GlucoseBLEManager.this.logDM.blood_sugar_eat = LogDM.GLUCOSE_EAT_NONE;
            }
            GlucoseBLEManager.this.inputListLogDM.add(GlucoseBLEManager.this.logDM);
        }

        protected void onCharacteristicIndicated(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            int opCode = characteristic.getIntValue(17, 0).intValue();
            int offset = 0 + 2;
            PreferenceUtil mPreference = new PreferenceUtil(GlucoseBLEManager.this.mContext, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
            if (opCode == 5) {
                int number = characteristic.getIntValue(18, offset).intValue();
                GlucoseBLEManager.this.inputListLogDM = new ArrayList();
                if (number > 0) {
                    ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onNumberOfRecordsRequested(number);
                } else {
                    ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onOperationCompleted();
                }
            } else if (opCode == 6) {
                int requestedOpCode = characteristic.getIntValue(17, offset).intValue();
                switch (characteristic.getIntValue(17, 3).intValue()) {
                    case 1:
                        if (!GlucoseBLEManager.this.mAbort) {
                            GlucoseBLEManager.this.setLogList(GlucoseBLEManager.this.inputListLogDM);
                            GlucoseBLEManager.this.mHandler.postDelayed(new C03142(), 100);
                            GlucoseBLEManager.this.dataCount = (byte) 0;
                            break;
                        }
                        ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onOperationAborted();
                        break;
                    case 2:
                        ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onOperationNotSupported();
                        break;
                    case 6:
                        ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onOperationCompleted();
                        break;
                    default:
                        ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onOperationFailed();
                        break;
                }
                GlucoseBLEManager.this.mAbort = false;
            }
        }
    }

    public GlucoseBLEManager(Context context) {
        super(context);
        this.mContext = context;
        this.inputListLogDM = new ArrayList();
        this.logDM = new LogDM();
    }

    public static GlucoseBLEManager getGlucoseManager(Context context) {
        if (mInstance == null) {
            mInstance = new GlucoseBLEManager(context);
        }
        return mInstance;
    }

    protected BleManagerGattCallback getGattCallback() {
        return this.mGattCallback;
    }

    private void setOpCode(BluetoothGattCharacteristic characteristic, int opCode, int operator, Integer... params) {
        int i;
        int i2 = 0;
        if (params.length > 0) {
            i = 1;
        } else {
            i = 0;
        }
        characteristic.setValue(new byte[((i + 2) + (params.length * 2))]);
        characteristic.setValue(opCode, 17, 0);
        int offset = 0 + 1;
        characteristic.setValue(operator, 17, offset);
        offset++;
        if (params.length > 0) {
            characteristic.setValue(1, 17, offset);
            offset++;
            i = params.length;
            while (i2 < i) {
                characteristic.setValue(params[i2].intValue(), 18, offset);
                offset += 2;
                i2++;
            }
        }
    }

    public void getLastRecord() {
        if (this.mRecordAccessControlPointCharacteristic != null) {
            ((GlucoseBLEManagerCallbacks) this.mCallbacks).onOperationStarted();
            BluetoothGattCharacteristic characteristic = this.mRecordAccessControlPointCharacteristic;
            setOpCode(characteristic, 1, 6, new Integer[0]);
            writeCharacteristic(characteristic);
        }
    }

    public void getFirstRecord() {
        if (this.mRecordAccessControlPointCharacteristic != null) {
            ((GlucoseBLEManagerCallbacks) this.mCallbacks).onOperationStarted();
            BluetoothGattCharacteristic characteristic = this.mRecordAccessControlPointCharacteristic;
            setOpCode(characteristic, 1, 5, new Integer[0]);
            writeCharacteristic(characteristic);
        }
    }

    public void getDeviceCount() {
        if (this.mRecordAccessControlPointCharacteristic != null) {
            ((GlucoseBLEManagerCallbacks) this.mCallbacks).onOperationStarted();
            BluetoothGattCharacteristic characteristic = this.mRecordAccessControlPointCharacteristic;
            setOpCode(characteristic, 4, 1, new Integer[0]);
            writeCharacteristic(characteristic);
        }
    }

    public void getAllRecords() {
        if (this.mRecordAccessControlPointCharacteristic != null) {
            ((GlucoseBLEManagerCallbacks) this.mCallbacks).onOperationStarted();
            BluetoothGattCharacteristic characteristic = this.mRecordAccessControlPointCharacteristic;
            setOpCode(characteristic, 1, 1, new Integer[0]);
            writeCharacteristic(characteristic);
        }
    }

    public void refreshRecords() {
        if (this.mRecordAccessControlPointCharacteristic != null) {
        }
    }

    public void abort() {
        if (this.mRecordAccessControlPointCharacteristic != null) {
            this.mAbort = true;
            BluetoothGattCharacteristic characteristic = this.mRecordAccessControlPointCharacteristic;
            setOpCode(characteristic, 3, 0, new Integer[0]);
            writeCharacteristic(characteristic);
        }
    }

    public void getTimeSync() {
        if (this.mCurrentTimeCharacteristic != null) {
            ((GlucoseBLEManagerCallbacks) this.mCallbacks).onOperationStarted();
            BluetoothGattCharacteristic characteristic = this.mCurrentTimeCharacteristic;
            characteristic.setValue(getTimeInCurrentTimeByteFormat());
            writeCharacteristic(characteristic);
        }
    }

    private byte[] getTimeInCurrentTimeByteFormat() {
        Calendar calendarLocal = Calendar.getInstance();
        calendarLocal.setTimeInMillis(System.currentTimeMillis());
        int year = calendarLocal.get(1);
        int mon = calendarLocal.get(2) + 1;
        int mday = calendarLocal.get(5);
        int wday = calendarLocal.get(7);
        int hour = calendarLocal.get(11);
        int min = calendarLocal.get(12);
        int sec = calendarLocal.get(13);
        return new byte[]{(byte) (year & 255), (byte) ((year >> 8) & 255), (byte) mon, (byte) mday, (byte) hour, (byte) min, (byte) sec, (byte) wday, (byte) 0, (byte) 0};
    }

    public void deleteAllRecords() {
        if (this.mRecordAccessControlPointCharacteristic != null) {
            ((GlucoseBLEManagerCallbacks) this.mCallbacks).onOperationStarted();
            BluetoothGattCharacteristic characteristic = this.mRecordAccessControlPointCharacteristic;
            setOpCode(characteristic, 2, 1, new Integer[0]);
            writeCharacteristic(characteristic);
        }
    }

    public void getNotSyncCount(int lastseq) {
        if (this.mRecordAccessControlPointCharacteristic != null) {
            ((GlucoseBLEManagerCallbacks) this.mCallbacks).onOperationStarted();
            BluetoothGattCharacteristic characteristic = this.mRecordAccessControlPointCharacteristic;
            if (lastseq < 1) {
                setOpCode(characteristic, 1, 1, new Integer[0]);
            } else {
                setOpCode(characteristic, 1, 3, Integer.valueOf(lastseq + 1));
            }
            writeCharacteristic(characteristic);
        }
    }

    public void setLogList(final ArrayList<LogDM> getDeviceLogList) {
        this.mHandler.postDelayed(new Runnable() {
            public void run() {
                ((GlucoseBLEManagerCallbacks) GlucoseBLEManager.this.mCallbacks).onOperationCompleted(getDeviceLogList);
            }
        }, 100);
    }
}
