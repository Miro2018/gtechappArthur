package com.accumed.gtech.glucose;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.util.PreferenceUtil;
import com.accumed.gtech.util.PreferenceUtil.ModelName;
import com.accumed.gtech.util.PreferenceUtil.PREF_NAME_MY_DEVICE_TABLE;
import java.util.List;
import java.util.UUID;

public class ScannerFragment extends DialogFragment {
    private static final boolean DEVICE_IS_BONDED = true;
    private static final boolean DEVICE_NOT_BONDED = false;
    private static final String DISCOVERABLE_REQUIRED = "discoverable_required";
    static final int NO_RSSI = -1000;
    private static final String PARAM_UUID = "param_uuid";
    private static final long SCAN_DURATION = 5000;
    private static final String TAG = "ScannerFragment";
    private DeviceListAdapter mAdapter;
    private BluetoothAdapter mBluetoothAdapter;
    private boolean mDiscoverableRequired;
    private final Handler mHandler = new Handler();
    private boolean mIsScanning = false;
    private LeScanCallback mLEScanCallback = new C03171();
    private BluetoothLeScanner mLEScanner;
    private OnDeviceSelectedListener mListener;
    private Button mScanButton;
    private ScanCallback mScanCallback;
    private UUID mUuid;

    public interface OnDeviceSelectedListener {
        void onDeviceSelected(BluetoothDevice bluetoothDevice, String str);

        void onDialogCanceled();
    }

    class C03171 implements LeScanCallback {
        C03171() {
        }

        public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
            if (device != null) {
                ScannerFragment.this.updateScannedDevice(device, rssi);
                try {
                    if (ScannerServiceParser.decodeDeviceAdvData(scanRecord, ScannerFragment.this.mUuid, ScannerFragment.this.mDiscoverableRequired)) {
                        ScannerFragment.this.addScannedDevice(device, ScannerServiceParser.decodeDeviceName(scanRecord), rssi, false);
                    }
                } catch (Exception e) {
                    Log.e(ScannerFragment.TAG, "Invalid data in Advertisement packet " + e.toString());
                }
            }
        }
    }

    class C03204 implements Runnable {
        C03204() {
        }

        public void run() {
            if (ScannerFragment.this.mIsScanning) {
                ScannerFragment.this.stopScan();
            }
        }
    }

    class C03237 extends ScanCallback {
        C03237() {
        }

        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            BluetoothDevice device = result.getDevice();
            if (device != null) {
                ScannerFragment.this.updateScannedDevice(device, result.getRssi());
                try {
                    ScannerFragment.this.addScannedDevice(device, device.getName(), result.getRssi(), false);
                } catch (Exception e) {
                    Log.e(ScannerFragment.TAG, "Invalid data in Advertisement packet " + e.toString());
                }
            }
        }

        public void onBatchScanResults(List<ScanResult> results) {
            super.onBatchScanResults(results);
        }

        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
        }
    }

    public static ScannerFragment getInstance(Context context, UUID uuid, boolean discoverableRequired) {
        ScannerFragment fragment = new ScannerFragment();
        Bundle args = new Bundle();
        args.putParcelable(PARAM_UUID, new ParcelUuid(uuid));
        args.putBoolean(DISCOVERABLE_REQUIRED, discoverableRequired);
        fragment.setArguments(args);
        return fragment;
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.mListener = (OnDeviceSelectedListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement OnDeviceSelectedListener");
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args.containsKey(PARAM_UUID)) {
            this.mUuid = ((ParcelUuid) args.getParcelable(PARAM_UUID)).getUuid();
        }
        this.mDiscoverableRequired = args.getBoolean(DISCOVERABLE_REQUIRED);
        this.mBluetoothAdapter = ((BluetoothManager) getActivity().getSystemService("bluetooth")).getAdapter();
        initScanCallback();
    }

    private void initScanCallback() {
        if (VERSION.SDK_INT >= 21) {
            initCallbackLollipop();
        }
    }

    public void onDestroyView() {
        stopScan();
        super.onDestroyView();
    }

    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Builder builder = new Builder(getActivity());
        View dialogView = LayoutInflater.from(getActivity()).inflate(C0213R.layout.fragment_device_selection, null);
        ListView listview = (ListView) dialogView.findViewById(16908298);
        listview.setEmptyView(dialogView.findViewById(16908292));
        ListAdapter deviceListAdapter = new DeviceListAdapter(getActivity());
        this.mAdapter = deviceListAdapter;
        listview.setAdapter(deviceListAdapter);
        builder.setTitle(C0213R.string.scanner_title);
        final AlertDialog dialog = builder.setView(dialogView).create();
        listview.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ScannerFragment.this.stopScan();
                dialog.dismiss();
                ExtendedBluetoothDevice d = (ExtendedBluetoothDevice) ScannerFragment.this.mAdapter.getItem(position);
                ScannerFragment.this.mListener.onDeviceSelected(d.device, d.name);
                PreferenceUtil devicePref = new PreferenceUtil(ScannerFragment.this.getActivity(), PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
                devicePref.putString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS, d.device.getAddress());
                devicePref.putString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_NAME, d.name);
            }
        });
        this.mScanButton = (Button) dialogView.findViewById(C0213R.id.action_cancel);
        this.mScanButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (v.getId() != C0213R.id.action_cancel) {
                    return;
                }
                if (ScannerFragment.this.mIsScanning) {
                    dialog.cancel();
                } else {
                    ScannerFragment.this.startScan();
                }
            }
        });
        if (savedInstanceState == null) {
            startScan();
        }
        return dialog;
    }

    public void onCancel(DialogInterface dialog) {
        super.onCancel(dialog);
        this.mListener.onDialogCanceled();
    }

    private void startScan() {
        this.mAdapter.clearDevices();
        this.mScanButton.setText(C0213R.string.scanner_action_cancel);
        if (VERSION.SDK_INT < 21) {
            this.mBluetoothAdapter.startLeScan(this.mLEScanCallback);
        } else {
            this.mLEScanner = this.mBluetoothAdapter.getBluetoothLeScanner();
            this.mLEScanner.startScan(this.mScanCallback);
        }
        this.mIsScanning = DEVICE_IS_BONDED;
        this.mHandler.postDelayed(new C03204(), SCAN_DURATION);
    }

    private void stopScan() {
        if (this.mIsScanning) {
            this.mScanButton.setText(C0213R.string.scanner_action_scan);
            if (VERSION.SDK_INT < 21) {
                this.mBluetoothAdapter.stopLeScan(this.mLEScanCallback);
            } else {
                this.mLEScanner.stopScan(this.mScanCallback);
            }
            this.mIsScanning = false;
        }
    }

    private void addBondedDevices() {
        for (BluetoothDevice device : this.mBluetoothAdapter.getBondedDevices()) {
            this.mAdapter.addBondedDevice(new ExtendedBluetoothDevice(device, device.getName(), -1000, DEVICE_IS_BONDED));
        }
    }

    private void addScannedDevice(BluetoothDevice device, String name, int rssi, boolean isBonded) {
        if (getActivity() != null) {
            final String str = name;
            final BluetoothDevice bluetoothDevice = device;
            final int i = rssi;
            final boolean z = isBonded;
            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    if (str.contains(ModelName.BGMS_MODEL_GLUCOSE_MENTOR_BT_NAME) || str.contains(ModelName.BGMS_MODEL_GLUCOSE_CODEFREE_BT_NAME)) {
                        ScannerFragment.this.mAdapter.addOrUpdateDevice(new ExtendedBluetoothDevice(bluetoothDevice, str, i, z));
                    }
                }
            });
        }
    }

    private void updateScannedDevice(final BluetoothDevice device, final int rssi) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    ScannerFragment.this.mAdapter.updateRssiOfBondedDevice(device.getAddress(), rssi);
                }
            });
        }
    }

    @TargetApi(21)
    private void initCallbackLollipop() {
        if (this.mScanCallback == null) {
            this.mScanCallback = new C03237();
        }
    }
}
