package com.accumed.gtech.glucose;

public interface BleManagerCallbacks {
    void onBatteryValueReceived(int i);

    void onBluetoothClose();

    void onBonded();

    void onBondingRequired();

    void onDeviceConnected();

    void onDeviceDisconnected();

    void onDeviceDisconnecting();

    void onDeviceNotSupported();

    void onDeviceReady();

    void onError(String str, int i);

    void onGetServiceNumber();

    void onLinklossOccur();

    void onServicesDiscovered(boolean z);

    void onTimeSetSuccess();
}
