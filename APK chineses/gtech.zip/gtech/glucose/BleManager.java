package com.accumed.gtech.glucose;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import com.accumed.gtech.util.PreferenceUtil;
import com.accumed.gtech.util.PreferenceUtil.PREF_NAME_MY_DEVICE_TABLE;
import com.accumed.gtech.util.Util;
import java.util.Queue;
import java.util.UUID;

public abstract class BleManager<E extends BleManagerCallbacks> {
    private static final UUID BATTERY_LEVEL_CHARACTERISTIC = UUID.fromString("00002A19-0000-1000-8000-00805f9b34fb");
    private static final UUID BATTERY_SERVICE = UUID.fromString("0000180F-0000-1000-8000-00805f9b34fb");
    private static final UUID CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    public static final UUID CURRENT_TIME_CHARACTERISTIC = UUID.fromString("00002a2b-0000-1000-8000-00805f9b34fb");
    private static final UUID DEVICE_SERVICE_UUID = UUID.fromString("0000180A-0000-1000-8000-00805f9b34fb");
    private static final String ERROR_AUTH_ERROR_WHILE_BONDED = "Phone has lost bonding information";
    private static final String ERROR_CONNECTION_STATE_CHANGE = "Error on connection state change";
    private static final String ERROR_DISCOVERY_SERVICE = "Error on discovering services";
    private static final String ERROR_READ_CHARACTERISTIC = "Error on reading characteristic";
    private static final String ERROR_WRITE_DESCRIPTOR = "Error on writing descriptor";
    private static final UUID GENERIC_ATTRIBUTE_SERVICE = UUID.fromString("00001801-0000-1000-8000-00805f9b34fb");
    private static final UUID MANUFACTURER_CHARACTERISTIC = UUID.fromString("00002a29-0000-1000-8000-00805f9b34fb");
    private static final UUID SERIAL_NUMBER_CHARACTERISTIC = UUID.fromString("00002a25-0000-1000-8000-00805f9b34fb");
    private static final UUID SERVICE_CHANGED_CHARACTERISTIC = UUID.fromString("00002A05-0000-1000-8000-00805f9b34fb");
    private static final String TAG = "BleManager";
    private BluetoothGatt mBluetoothGatt;
    private final BroadcastReceiver mBluetoothStateBroadcastReceiver = new C02983();
    private BroadcastReceiver mBondingBroadcastReceiver = new C02972();
    protected E mCallbacks;
    private boolean mConnected = false;
    private Context mContext;
    private Handler mHandler;
    private final Object mLock = new Object();
    private final BroadcastReceiver mPairingRequestBroadcastReceiver = new C02961();
    private boolean mUserDisconnected;

    class C02961 extends BroadcastReceiver {
        C02961() {
        }

        public void onReceive(Context context, Intent intent) {
            BluetoothDevice device = (BluetoothDevice) intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE");
            if (BleManager.this.mBluetoothGatt != null && device.getAddress().equals(BleManager.this.mBluetoothGatt.getDevice().getAddress())) {
                int variant = intent.getIntExtra("android.bluetooth.device.extra.PAIRING_VARIANT", 0);
            }
        }
    }

    class C02972 extends BroadcastReceiver {
        C02972() {
        }

        public void onReceive(Context context, Intent intent) {
            BluetoothDevice device = (BluetoothDevice) intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE");
            int bondState = intent.getIntExtra("android.bluetooth.device.extra.BOND_STATE", -1);
            int previousBondState = intent.getIntExtra("android.bluetooth.device.extra.PREVIOUS_BOND_STATE", -1);
            if (BleManager.this.mBluetoothGatt != null && device.getAddress().equals(BleManager.this.mBluetoothGatt.getDevice().getAddress())) {
                switch (bondState) {
                    case 11:
                        BleManager.this.mCallbacks.onBondingRequired();
                        return;
                    case 12:
                        BleManager.this.mCallbacks.onBonded();
                        BleManager.this.mBluetoothGatt.discoverServices();
                        return;
                    default:
                        return;
                }
            }
        }
    }

    class C02983 extends BroadcastReceiver {
        C02983() {
        }

        public void onReceive(Context context, Intent intent) {
            int state = intent.getIntExtra("android.bluetooth.adapter.extra.STATE", 10);
            int previousState = intent.getIntExtra("android.bluetooth.adapter.extra.PREVIOUS_STATE", 10);
            String stateString = "[Broadcast] Action received: android.bluetooth.adapter.action.STATE_CHANGED, state changed to " + state2String(state);
            switch (state) {
                case 10:
                case 13:
                    if (BleManager.this.mConnected && previousState != 13 && previousState != 10) {
                        BleManager.this.getGattCallback().notifyDeviceDisconnected();
                        BleManager.this.close();
                        return;
                    }
                    return;
                default:
                    return;
            }
        }

        private String state2String(int state) {
            switch (state) {
                case 10:
                    return "OFF";
                case 11:
                    return "TURNING ON";
                case 12:
                    return "ON";
                case 13:
                    return "TURNING OFF";
                default:
                    return "UNKNOWN (" + state + ")";
            }
        }
    }

    protected abstract class BleManagerGattCallback extends BluetoothGattCallback {
        private boolean mInitInProgress;
        private Queue<Request> mInitQueue;

        protected abstract Queue<Request> initGatt(BluetoothGatt bluetoothGatt);

        protected abstract boolean isRequiredServiceSupported(BluetoothGatt bluetoothGatt);

        protected abstract void onDeviceDisconnected();

        protected BleManagerGattCallback() {
        }

        protected boolean isOptionalServiceSupported(BluetoothGatt gatt) {
            return false;
        }

        protected void onDeviceReady() {
            BleManager.this.mCallbacks.onDeviceReady();
        }

        private void notifyDeviceDisconnected() {
            BleManager.this.mConnected = false;
            if (BleManager.this.mUserDisconnected) {
                BleManager.this.mCallbacks.onDeviceDisconnected();
                BleManager.this.close();
            } else {
                BleManager.this.mCallbacks.onLinklossOccur();
            }
            onDeviceDisconnected();
        }

        protected void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        }

        protected void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        }

        protected void onCharacteristicNotified(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        }

        protected void onCharacteristicIndicated(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        }

        private void onError(String message, int errorCode) {
            BleManager.this.mCallbacks.onError(message, errorCode);
        }

        public final void onConnectionStateChange(final BluetoothGatt gatt, int status, int newState) {
            if (status == 0 && newState == 2) {
                BleManager.this.mConnected = true;
                BleManager.this.mCallbacks.onDeviceConnected();
                BleManager.this.mHandler.postDelayed(new Runnable() {
                    public void run() {
                        if (gatt.getDevice().getBondState() != 11) {
                            gatt.discoverServices();
                        }
                    }
                }, 600);
            } else if (newState == 0) {
                notifyDeviceDisconnected();
            } else {
                BleManager.this.mCallbacks.onError(BleManager.ERROR_CONNECTION_STATE_CHANGE, status);
            }
        }

        public final void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status != 0) {
                onError(BleManager.ERROR_DISCOVERY_SERVICE, status);
            } else if (isRequiredServiceSupported(gatt)) {
                BleManager.this.mCallbacks.onServicesDiscovered(isOptionalServiceSupported(gatt));
                this.mInitInProgress = true;
                this.mInitQueue = initGatt(gatt);
                if (!BleManager.this.ensureServiceChangedEnabled(gatt) && !BleManager.this.readBatteryLevel()) {
                    nextRequest();
                }
            } else {
                BleManager.this.mCallbacks.onDeviceNotSupported();
                BleManager.this.disconnect();
            }
        }

        public String checkInputOnlyNumberAndAlphabet(String textInput) {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < textInput.length(); i++) {
                char chrInput = textInput.charAt(i);
                if (chrInput >= 'a' && chrInput <= 'z') {
                    result.append(chrInput);
                } else if (chrInput >= 'A' && chrInput <= 'Z') {
                    result.append(chrInput);
                } else if (chrInput < '0' || chrInput > '9') {
                    result.append("AA");
                } else {
                    result.append(chrInput);
                }
            }
            return result.toString();
        }

        public final void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            PreferenceUtil devicePref = new PreferenceUtil(BleManager.this.mContext, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
            if (status == 0) {
                if (BleManager.this.isManufacturerCharacteristic(characteristic)) {
                }
                if (BleManager.this.isServiceNumberCharacteristic(characteristic)) {
                    devicePref.putString(PREF_NAME_MY_DEVICE_TABLE.IS_DEVICE_SERIAL_NUMBER, checkInputOnlyNumberAndAlphabet(characteristic.getStringValue(0)));
                }
                if (BleManager.this.isBatteryLevelCharacteristic(characteristic)) {
                    BleManager.this.mCallbacks.onBatteryValueReceived(characteristic.getIntValue(17, 0).intValue());
                    if (!BleManager.this.setBatteryNotifications(true)) {
                        nextRequest();
                        return;
                    }
                    return;
                }
                onCharacteristicRead(gatt, characteristic);
                nextRequest();
            } else if (status != 5) {
                onError(BleManager.ERROR_READ_CHARACTERISTIC, status);
            } else if (gatt.getDevice().getBondState() != 10) {
                BleManager.this.mCallbacks.onError(BleManager.ERROR_AUTH_ERROR_WHILE_BONDED, status);
            }
        }

        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == 0) {
                onCharacteristicWrite(gatt, characteristic);
                nextRequest();
                if (BleManager.this.isCurrentTimeServiceCharacteristic(characteristic)) {
                    BleManager.this.mCallbacks.onTimeSetSuccess();
                }
            } else if (status != 5) {
                onError(BleManager.ERROR_READ_CHARACTERISTIC, status);
            } else if (gatt.getDevice().getBondState() != 10) {
                BleManager.this.mCallbacks.onError(BleManager.ERROR_AUTH_ERROR_WHILE_BONDED, status);
            }
        }

        public final void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            if (status == 0) {
                if (BleManager.this.isServiceChangedCCCD(descriptor)) {
                    if (!BleManager.this.readBatteryLevel()) {
                        nextRequest();
                    }
                } else if (BleManager.this.isBatteryLevelCCCD(descriptor)) {
                    byte[] value = descriptor.getValue();
                    if (value != null && value.length > 0 && value[0] == (byte) 1) {
                        nextRequest();
                    }
                } else {
                    nextRequest();
                }
            } else if (status != 5) {
                onError(BleManager.ERROR_WRITE_DESCRIPTOR, status);
            } else if (gatt.getDevice().getBondState() != 10) {
                BleManager.this.mCallbacks.onError(BleManager.ERROR_AUTH_ERROR_WHILE_BONDED, status);
            }
        }

        public final void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            boolean notifications = false;
            String data = Util.parse(characteristic);
            if (BleManager.this.isBatteryLevelCharacteristic(characteristic)) {
                BleManager.this.mCallbacks.onBatteryValueReceived(characteristic.getIntValue(17, 0).intValue());
                return;
            }
            BluetoothGattDescriptor cccd = characteristic.getDescriptor(BleManager.CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID);
            if (cccd == null || cccd.getValue() == null || cccd.getValue().length != 2 || cccd.getValue()[0] == (byte) 1) {
                notifications = true;
            }
            if (notifications) {
                onCharacteristicNotified(gatt, characteristic);
            } else {
                onCharacteristicIndicated(gatt, characteristic);
            }
        }

        private void nextRequest() {
            Request request = (Request) this.mInitQueue.poll();
            if (request != null) {
                switch (request.type) {
                    case READ:
                        BleManager.this.readCharacteristic(request.characteristic);
                        return;
                    case WRITE:
                        BluetoothGattCharacteristic characteristic = request.characteristic;
                        characteristic.setValue(request.value);
                        BleManager.this.writeCharacteristic(characteristic);
                        return;
                    case ENABLE_NOTIFICATIONS:
                        BleManager.this.enableNotifications(request.characteristic);
                        return;
                    case ENABLE_INDICATIONS:
                        BleManager.this.enableIndications(request.characteristic);
                        return;
                    default:
                        return;
                }
            } else if (this.mInitInProgress) {
                this.mInitInProgress = false;
                onDeviceReady();
            }
        }
    }

    protected static final class Request {
        private final BluetoothGattCharacteristic characteristic;
        private final Type type;
        private final byte[] value;

        private enum Type {
            WRITE,
            READ,
            ENABLE_NOTIFICATIONS,
            ENABLE_INDICATIONS
        }

        private Request(Type type, BluetoothGattCharacteristic characteristic) {
            this.type = type;
            this.characteristic = characteristic;
            this.value = null;
        }

        private Request(Type type, BluetoothGattCharacteristic characteristic, byte[] value) {
            this.type = type;
            this.characteristic = characteristic;
            this.value = value;
        }

        public static Request newReadRequest(BluetoothGattCharacteristic characteristic) {
            return new Request(Type.READ, characteristic);
        }

        public static Request newWriteRequest(BluetoothGattCharacteristic characteristic, byte[] value) {
            return new Request(Type.WRITE, characteristic, value);
        }

        public static Request newEnableNotificationsRequest(BluetoothGattCharacteristic characteristic) {
            return new Request(Type.ENABLE_NOTIFICATIONS, characteristic);
        }

        public static Request newEnableIndicationsRequest(BluetoothGattCharacteristic characteristic) {
            return new Request(Type.ENABLE_INDICATIONS, characteristic);
        }
    }

    protected abstract BleManagerGattCallback getGattCallback();

    public BleManager(Context context) {
        this.mContext = context;
        this.mHandler = new Handler();
    }

    protected Context getContext() {
        return this.mContext;
    }

    protected boolean shouldAutoConnect() {
        return false;
    }

    public void connect(BluetoothDevice device) {
        if (!this.mConnected) {
            synchronized (this.mLock) {
                if (this.mBluetoothGatt != null) {
                    this.mBluetoothGatt.close();
                    this.mBluetoothGatt = null;
                } else {
                    this.mContext.registerReceiver(this.mBluetoothStateBroadcastReceiver, new IntentFilter("android.bluetooth.adapter.action.STATE_CHANGED"));
                    this.mContext.registerReceiver(this.mBondingBroadcastReceiver, new IntentFilter("android.bluetooth.device.action.BOND_STATE_CHANGED"));
                    this.mContext.registerReceiver(this.mPairingRequestBroadcastReceiver, new IntentFilter("android.bluetooth.device.action.PAIRING_REQUEST"));
                }
            }
            boolean autoConnect = shouldAutoConnect();
            this.mUserDisconnected = !autoConnect;
            this.mBluetoothGatt = device.connectGatt(this.mContext, autoConnect, getGattCallback());
        }
    }

    public boolean disconnect() {
        this.mUserDisconnected = true;
        if (!this.mConnected || this.mBluetoothGatt == null) {
            return false;
        }
        this.mCallbacks.onDeviceDisconnecting();
        this.mBluetoothGatt.disconnect();
        this.mConnected = false;
        return true;
    }

    public void close() {
        try {
            this.mContext.unregisterReceiver(this.mBluetoothStateBroadcastReceiver);
            this.mContext.unregisterReceiver(this.mBondingBroadcastReceiver);
            this.mContext.unregisterReceiver(this.mPairingRequestBroadcastReceiver);
        } catch (Exception e) {
        }
        synchronized (this.mLock) {
            if (this.mBluetoothGatt != null) {
                this.mBluetoothGatt.close();
                this.mBluetoothGatt = null;
            }
            this.mConnected = false;
        }
    }

    public void setGattCallbacks(E callbacks) {
        this.mCallbacks = callbacks;
    }

    private boolean isServiceChangedCCCD(BluetoothGattDescriptor descriptor) {
        if (descriptor == null) {
            return false;
        }
        return SERVICE_CHANGED_CHARACTERISTIC.equals(descriptor.getCharacteristic().getUuid());
    }

    private boolean isServiceNumberCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (characteristic == null) {
            return false;
        }
        return SERIAL_NUMBER_CHARACTERISTIC.equals(characteristic.getUuid());
    }

    private boolean isManufacturerCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (characteristic == null) {
            return false;
        }
        return MANUFACTURER_CHARACTERISTIC.equals(characteristic.getUuid());
    }

    private boolean isCurrentTimeServiceCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (characteristic == null) {
            return false;
        }
        return CURRENT_TIME_CHARACTERISTIC.equals(characteristic.getUuid());
    }

    private boolean isBatteryLevelCCCD(BluetoothGattDescriptor descriptor) {
        if (descriptor == null) {
            return false;
        }
        return BATTERY_LEVEL_CHARACTERISTIC.equals(descriptor.getCharacteristic().getUuid());
    }

    private boolean isBatteryLevelCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (characteristic == null) {
            return false;
        }
        return BATTERY_LEVEL_CHARACTERISTIC.equals(characteristic.getUuid());
    }

    private boolean ensureServiceChangedEnabled(BluetoothGatt gatt) {
        if (gatt == null || gatt.getDevice().getBondState() != 12) {
            return false;
        }
        BluetoothGattService gaService = gatt.getService(GENERIC_ATTRIBUTE_SERVICE);
        if (gaService == null) {
            return false;
        }
        BluetoothGattCharacteristic scCharacteristic = gaService.getCharacteristic(SERVICE_CHANGED_CHARACTERISTIC);
        if (scCharacteristic != null) {
            return enableIndications(scCharacteristic);
        }
        return false;
    }

    protected final boolean enableNotifications(BluetoothGattCharacteristic characteristic) {
        BluetoothGatt gatt = this.mBluetoothGatt;
        if (gatt == null || characteristic == null || (characteristic.getProperties() & 16) == 0) {
            return false;
        }
        gatt.setCharacteristicNotification(characteristic, true);
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID);
        if (descriptor == null) {
            return false;
        }
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        return gatt.writeDescriptor(descriptor);
    }

    protected final boolean enableIndications(BluetoothGattCharacteristic characteristic) {
        BluetoothGatt gatt = this.mBluetoothGatt;
        if (gatt == null || characteristic == null || (characteristic.getProperties() & 32) == 0) {
            return false;
        }
        gatt.setCharacteristicNotification(characteristic, true);
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID);
        if (descriptor == null) {
            return false;
        }
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
        return gatt.writeDescriptor(descriptor);
    }

    protected final boolean readCharacteristic(BluetoothGattCharacteristic characteristic) {
        BluetoothGatt gatt = this.mBluetoothGatt;
        if (gatt == null || characteristic == null || (characteristic.getProperties() & 2) == 0) {
            return false;
        }
        return gatt.readCharacteristic(characteristic);
    }

    protected final boolean writeCharacteristic(BluetoothGattCharacteristic characteristic) {
        BluetoothGatt gatt = this.mBluetoothGatt;
        if (gatt == null || characteristic == null || (characteristic.getProperties() & 12) == 0) {
            return false;
        }
        return gatt.writeCharacteristic(characteristic);
    }

    public final boolean readBatteryLevel() {
        BluetoothGatt gatt = this.mBluetoothGatt;
        if (gatt == null) {
            return false;
        }
        BluetoothGattService batteryService = gatt.getService(BATTERY_SERVICE);
        if (batteryService == null) {
            return false;
        }
        BluetoothGattCharacteristic batteryLevelCharacteristic = batteryService.getCharacteristic(BATTERY_LEVEL_CHARACTERISTIC);
        if (batteryLevelCharacteristic == null) {
            return false;
        }
        if ((batteryLevelCharacteristic.getProperties() & 2) == 0) {
            return setBatteryNotifications(true);
        }
        return readCharacteristic(batteryLevelCharacteristic);
    }

    public boolean setBatteryNotifications(boolean enable) {
        BluetoothGatt gatt = this.mBluetoothGatt;
        if (gatt == null) {
            return false;
        }
        BluetoothGattService batteryService = gatt.getService(BATTERY_SERVICE);
        if (batteryService == null) {
            return false;
        }
        BluetoothGattCharacteristic batteryLevelCharacteristic = batteryService.getCharacteristic(BATTERY_LEVEL_CHARACTERISTIC);
        if (batteryLevelCharacteristic == null || (batteryLevelCharacteristic.getProperties() & 16) == 0) {
            return false;
        }
        gatt.setCharacteristicNotification(batteryLevelCharacteristic, enable);
        BluetoothGattDescriptor descriptor = batteryLevelCharacteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID);
        if (descriptor == null) {
            return false;
        }
        if (enable) {
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        } else {
            descriptor.setValue(BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
        }
        return gatt.writeDescriptor(descriptor);
    }
}
