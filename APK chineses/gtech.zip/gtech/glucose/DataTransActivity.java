package com.accumed.gtech.glucose;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.util.PreferenceUtil;
import com.accumed.gtech.util.PreferenceUtil.PREF_NAME_MY_DEVICE_TABLE;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DataTransActivity extends BTCommonActivity {
    public static final String ACTION_DATA_CATEGORY = "action_data_category";
    public static final int ACTION_PROGRESS_VALUE = 1;
    public static final int ACTION_SEARCH_VALUE = 0;
    public static final String HIDE_PROGRESS_RECEIVER = "hide_progress_receiver";
    public static final String REFRESH_COUNT_RECEIVER = "refresh_count_receiver";
    public static final String SHOW_PROGRESS_RECEIVER = "show_progress_receiver";
    private boolean FLAG_FOLLOW_CONTROL_MEASURE_DATA;
    private boolean FLAG_MEASURE;
    boolean blockNFC = false;
    private boolean firstGetDate = true;
    final Handler hideH = new C03011();
    private ImageView ivDevice;
    private ImageView ivMobile;
    private ImageView ivSignal;
    private BleManager<? extends BleManagerCallbacks> mBleManager;
    private BluetoothAdapter mBluetoothAdapter;
    private Context mContext;
    private Intent mIntent;
    private LeScanCallback mLEScanCallback;
    private BluetoothLeScanner mLEScanner;
    private ArrayList<LogDM> mLogList;
    private int mNowDataCategory;
    private ProgressBar mProgressStick;
    private final BroadcastReceiver mReceiver = new C03022();
    private ScanCallback mScanCallback;
    private Handler progressBarHandler = new Handler();
    private int progressBarStatus = 0;
    private int progressBarSum = 0;
    private int resumeCount = 0;
    private RelativeLayout rlProgressCount;
    private boolean startThread = false;
    private TextView tvCount;
    private TextView tvLoading;
    private TextView tvSumCount;

    class C03011 extends Handler {
        C03011() {
        }

        public void handleMessage(Message msg) {
            try {
                DataTransActivity.this.finish();
            } catch (Exception e) {
            }
            DataTransActivity.this.FLAG_MEASURE = false;
        }
    }

    class C03022 extends BroadcastReceiver {
        C03022() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            int count = 0;
            if (action.equals(DataTransActivity.SHOW_PROGRESS_RECEIVER)) {
                count = intent.getIntExtra("progress_max", 0);
            } else if (action.equals(DataTransActivity.REFRESH_COUNT_RECEIVER)) {
                count = intent.getIntExtra("progress_count", 0);
            }
            String device_info = intent.getStringExtra("device_info");
            DataTransActivity.this.initProgressState(action, count);
        }
    }

    class C03043 implements LeScanCallback {
        C03043() {
        }

        public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
            if (device != null) {
                if (device.getAddress().equals(new PreferenceUtil(DataTransActivity.this.getApplicationContext(), PREF_NAME_MY_DEVICE_TABLE.PREF_NAME).getString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS))) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        public void run() {
                            DataTransActivity.this.AutoConnectDevice(device);
                            DataTransActivity.this.firstGetDate = false;
                        }
                    });
                }
            }
        }
    }

    class C03054 extends ScanCallback {
        C03054() {
        }

        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            BluetoothDevice device = result.getDevice();
            if (device != null) {
                if (device.getAddress().equals(new PreferenceUtil(DataTransActivity.this.getApplicationContext(), PREF_NAME_MY_DEVICE_TABLE.PREF_NAME).getString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS)) && DataTransActivity.this.firstGetDate) {
                    DataTransActivity.this.AutoConnectDevice(device);
                    DataTransActivity.this.firstGetDate = false;
                }
            }
        }

        public void onBatchScanResults(List<ScanResult> results) {
            super.onBatchScanResults(results);
        }

        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
        }
    }

    class C03085 implements Runnable {

        class C03071 implements Runnable {

            class C03061 implements Runnable {
                C03061() {
                }

                public void run() {
                    DataTransActivity.this.mProgressStick.setProgress(DataTransActivity.this.progressBarStatus);
                }
            }

            C03071() {
            }

            public void run() {
                while (DataTransActivity.this.progressBarStatus < DataTransActivity.this.progressBarSum) {
                    DataTransActivity.this.progressBarStatus = DataTransActivity.this.DoWork();
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    DataTransActivity.this.progressBarHandler.post(new C03061());
                }
            }
        }

        C03085() {
        }

        public void run() {
            new Thread(new C03071()).start();
        }
    }

    private void initCallbackLEScan() {
        if (this.mLEScanCallback == null) {
            this.mLEScanCallback = new C03043();
        }
    }

    @TargetApi(21)
    private void initCallbackLollipop() {
        this.mScanCallback = new C03054();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.activity_data_trans);
        this.mNowDataCategory = getIntent().getIntExtra(ACTION_DATA_CATEGORY, 1);
        this.mContext = this;
        this.rlProgressCount = (RelativeLayout) findViewById(C0213R.id.progress_count_group);
        this.ivDevice = (ImageView) findViewById(C0213R.id.iv_bgms);
        this.ivMobile = (ImageView) findViewById(C0213R.id.iv_mobile);
        this.mProgressStick = (ProgressBar) findViewById(C0213R.id.progressBar);
        this.mProgressStick.setVisibility(0);
        this.mProgressStick.setProgress(0);
        this.mProgressStick.setMax(100);
        this.mProgressStick.setProgressDrawable(getResources().getDrawable(C0213R.drawable.custom_progressbar));
        this.tvLoading = (TextView) findViewById(C0213R.id.tv_loading);
        this.tvLoading.startAnimation(AnimationUtils.loadAnimation(this, C0213R.anim.text_flow_effect));
        this.ivSignal = (ImageView) findViewById(C0213R.id.iv_signal);
        this.ivSignal.setBackgroundResource(C0213R.drawable.signal);
        ((AnimationDrawable) this.ivSignal.getBackground()).start();
        this.tvCount = (TextView) findViewById(C0213R.id.tv_count);
        this.tvSumCount = (TextView) findViewById(C0213R.id.tv_sumcount);
        this.progressBarStatus = 0;
        IntentFilter filter = new IntentFilter();
        filter.addAction(SHOW_PROGRESS_RECEIVER);
        filter.addAction(HIDE_PROGRESS_RECEIVER);
        filter.addAction(REFRESH_COUNT_RECEIVER);
        registerReceiver(this.mReceiver, filter);
        ensureBLESupported();
        initScanCallback();
        PreferenceUtil profilePref = new PreferenceUtil(getApplicationContext(), PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
        if (!isBLEEnabled()) {
            showBLEDialog();
        }
        if (this.mNowDataCategory == 0) {
            this.tvLoading.setText(getResources().getString(C0213R.string.device_search));
            this.rlProgressCount.setVisibility(8);
            this.ivDevice.setVisibility(4);
            this.ivMobile.setVisibility(4);
            return;
        }
        this.tvLoading.setText(getResources().getString(C0213R.string.data_sending));
        this.rlProgressCount.setVisibility(0);
        this.ivDevice.setVisibility(0);
        this.ivMobile.setVisibility(0);
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.mReceiver != null) {
            unregisterReceiver(this.mReceiver);
        }
    }

    protected void onResume() {
        super.onResume();
        this.resumeCount++;
        if (this.resumeCount == 1) {
            onNewIntent(getIntent());
        }
        this.mBleManager = initializeManager();
        if (isBLEEnabled() && this.mNowDataCategory == 0) {
            PreferenceUtil mPreference = new PreferenceUtil(this.mContext, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
            if (this.mDeviceConnected) {
                this.mBleManager.disconnect();
            } else if (mPreference.getString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS).length() > 0) {
                getAutoData();
                findViewById(C0213R.id.loading_layout).setVisibility(0);
            } else {
                showDeviceScanningDialog(GlucoseBLEManager.GLS_SERVICE_UUID, true);
                findViewById(C0213R.id.loading_layout).setVisibility(4);
            }
        }
    }

    public int DoWork() {
        if (this.progressBarStatus < this.progressBarSum) {
            return this.progressBarStatus;
        }
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return 1;
    }

    public void showProgressBar() {
        runOnUiThread(new C03085());
    }

    private void initProgressState(String action, final int count) {
        if (action.equals(SHOW_PROGRESS_RECEIVER)) {
            runOnUiThread(new Runnable() {
                public void run() {
                    DataTransActivity.this.tvLoading.setText(DataTransActivity.this.getResources().getString(C0213R.string.data_sending));
                    DataTransActivity.this.rlProgressCount.setVisibility(0);
                    DataTransActivity.this.ivDevice.setVisibility(0);
                    DataTransActivity.this.ivMobile.setVisibility(0);
                    DataTransActivity.this.findViewById(C0213R.id.loading_layout).setVisibility(0);
                    DataTransActivity.this.mProgressStick.setVisibility(0);
                    DataTransActivity.this.findViewById(C0213R.id.count_group).setVisibility(0);
                    DataTransActivity.this.mProgressStick.setProgress(0);
                    DataTransActivity.this.mProgressStick.setMax(count);
                    DataTransActivity.this.tvSumCount.setText(String.valueOf(count));
                    DataTransActivity.this.progressBarSum = count;
                    DataTransActivity.this.showProgressBar();
                }
            });
        } else if (action.equals(HIDE_PROGRESS_RECEIVER)) {
            Message msg = Message.obtain();
            msg.what = 0;
            this.hideH.sendMessage(msg);
        } else if (action.equals(REFRESH_COUNT_RECEIVER)) {
            runOnUiThread(new Runnable() {
                public void run() {
                    DataTransActivity.this.progressBarStatus = count;
                    DataTransActivity.this.tvCount.setText(String.valueOf(count));
                }
            });
        }
    }

    private void initScanCallback() {
        if (VERSION.SDK_INT >= 21) {
            initCallbackLollipop();
        } else {
            initCallbackLEScan();
        }
    }

    private void AutoConnectDevice(BluetoothDevice device) {
        if (this.startThread) {
            if (VERSION.SDK_INT < 21) {
                this.mBluetoothAdapter.stopLeScan(this.mLEScanCallback);
            } else {
                this.mLEScanner.stopScan(this.mScanCallback);
            }
            this.startThread = false;
        }
        this.mBleManager.connect(device);
    }

    private void getAutoData() {
        this.firstGetDate = true;
        this.mBleManager = initializeManager();
        this.mBluetoothAdapter = ((BluetoothManager) getSystemService("bluetooth")).getAdapter();
        if (VERSION.SDK_INT >= 21) {
            this.mLEScanner = this.mBluetoothAdapter.getBluetoothLeScanner();
        }
        if (new PreferenceUtil(getApplicationContext(), PREF_NAME_MY_DEVICE_TABLE.PREF_NAME).getString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS).trim().length() > 0) {
            this.startThread = true;
            if (VERSION.SDK_INT < 21) {
                this.mBluetoothAdapter.startLeScan(this.mLEScanCallback);
                return;
            } else {
                this.mLEScanner.startScan(this.mScanCallback);
                return;
            }
        }
        if (VERSION.SDK_INT < 21) {
            this.mBluetoothAdapter.stopLeScan(this.mLEScanCallback);
        } else {
            this.mLEScanner.stopScan(this.mScanCallback);
        }
        this.startThread = false;
    }

    protected void showDeviceScanningDialog(final UUID filter, final boolean discoverableRequired) {
        runOnUiThread(new Runnable() {
            public void run() {
                ScannerFragment.getInstance(DataTransActivity.this, filter, discoverableRequired).show(DataTransActivity.this.getSupportFragmentManager(), "scan_fragment");
            }
        });
    }

    protected void onStop() {
        super.onStop();
        if (this.mNowDataCategory == 0 && this.startThread) {
            if (VERSION.SDK_INT < 21) {
                this.mBluetoothAdapter.stopLeScan(this.mLEScanCallback);
            } else {
                this.mLEScanner.stopScan(this.mScanCallback);
            }
            this.startThread = false;
        }
    }

    public void onDeviceReady() {
        this.mGlucoseManager.getDeviceCount();
    }

    public void onOperationStarted() {
    }

    public void onOperationCompleted() {
    }

    public void onNumberOfRecordsRequested(int value) {
        if (value == 0) {
            initProgressState(HIDE_PROGRESS_RECEIVER, 0);
            return;
        }
        PreferenceUtil devicePref = new PreferenceUtil(this.mContext, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
        initProgressState(SHOW_PROGRESS_RECEIVER, value);
        this.mGlucoseManager.getNotSyncCount(devicePref.getInt(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_SEQUENCE_NUMBER));
    }

    public void onDeviceConnected() {
        this.mDeviceConnected = true;
    }

    public void onDeviceDisconnected() {
        this.mDeviceConnected = false;
        if (this.mLogList == null || this.mLogList.size() <= 0) {
            setResult(0);
        } else {
            setResult(-1, this.mIntent);
        }
        finish();
        this.mBleManager.close();
    }

    public void onLinklossOccur() {
        this.mDeviceConnected = false;
    }

    public void onDeviceSelected(BluetoothDevice device, String name) {
        this.mBleManager.connect(device);
    }

    public void onDataGetCount(int value) {
        initProgressState(REFRESH_COUNT_RECEIVER, value);
    }

    public void onTimeSetSuccess() {
        if (this.mDeviceConnected) {
            this.mBleManager.disconnect();
        }
    }

    public void onError(String message, int errorCode) {
        if (errorCode == 22) {
            this.mBleManager = initializeManager();
            if (isBLEEnabled() && this.mNowDataCategory == 0) {
                PreferenceUtil mPreference = new PreferenceUtil(this.mContext, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
                if (this.mDeviceConnected) {
                    this.mBleManager.disconnect();
                } else if (mPreference.getString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS).length() > 0) {
                    getAutoData();
                } else {
                    showDeviceScanningDialog(GlucoseBLEManager.GLS_SERVICE_UUID, true);
                }
            }
        }
    }

    public void onGetServiceNumber() {
    }

    public void onBluetoothClose() {
    }

    public void onOperationCompleted(ArrayList<LogDM> logDMArrayList) {
        this.mLogList = logDMArrayList;
        this.mIntent = new Intent();
        this.mIntent.putExtra("bt_log", this.mLogList);
        this.mGlucoseManager.getTimeSync();
    }
}
