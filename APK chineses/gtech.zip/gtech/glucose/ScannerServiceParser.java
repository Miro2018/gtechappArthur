package com.accumed.gtech.glucose;

import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.util.UUID;

public class ScannerServiceParser {
    private static final int COMPLETE_LOCAL_NAME = 9;
    private static final int FLAGS_BIT = 1;
    private static final byte LE_GENERAL_DISCOVERABLE_MODE = (byte) 2;
    private static final byte LE_LIMITED_DISCOVERABLE_MODE = (byte) 1;
    private static final int SERVICES_COMPLETE_LIST_128_BIT = 7;
    private static final int SERVICES_COMPLETE_LIST_16_BIT = 3;
    private static final int SERVICES_COMPLETE_LIST_32_BIT = 5;
    private static final int SERVICES_MORE_AVAILABLE_128_BIT = 6;
    private static final int SERVICES_MORE_AVAILABLE_16_BIT = 2;
    private static final int SERVICES_MORE_AVAILABLE_32_BIT = 4;
    private static final int SHORTENED_LOCAL_NAME = 8;
    private static final String TAG = "ScannerServiceParser";

    public static boolean decodeDeviceAdvData(byte[] data, UUID requiredUUID, boolean discoverableRequired) {
        String uuid = requiredUUID != null ? requiredUUID.toString() : null;
        if (data == null) {
            return false;
        }
        boolean connectible = !discoverableRequired;
        boolean valid = uuid == null;
        if (connectible && valid) {
            return true;
        }
        int packetLength = data.length;
        int index = 0;
        while (index < packetLength) {
            int fieldLength = data[index];
            if (fieldLength == 0) {
                return connectible && valid;
            } else {
                index++;
                int fieldName = data[index];
                if (uuid != null) {
                    int i;
                    if (fieldName == 2 || fieldName == 3) {
                        for (i = index + 1; i < (index + fieldLength) - 1; i += 2) {
                            valid = valid || decodeService16BitUUID(uuid, data, i, 2);
                        }
                    } else if (fieldName == 4 || fieldName == 5) {
                        for (i = index + 1; i < (index + fieldLength) - 1; i += 4) {
                            valid = valid || decodeService32BitUUID(uuid, data, i, 4);
                        }
                    } else if (fieldName == 6 || fieldName == 7) {
                        for (i = index + 1; i < (index + fieldLength) - 1; i += 16) {
                            valid = valid || decodeService128BitUUID(uuid, data, i, 16);
                        }
                    }
                }
                if (!connectible && fieldName == 1) {
                    connectible = (data[index + 1] & 3) > 0;
                }
                index = (index + (fieldLength - 1)) + 1;
            }
        }
        return connectible && valid;
    }

    public static String decodeDeviceName(byte[] data) {
        int packetLength = data.length;
        int index = 0;
        while (index < packetLength) {
            int fieldLength = data[index];
            if (fieldLength == 0) {
                return null;
            }
            index++;
            int fieldName = data[index];
            if (fieldName == 9 || fieldName == 8) {
                return decodeLocalName(data, index + 1, fieldLength - 1);
            }
            index = (index + (fieldLength - 1)) + 1;
        }
        return null;
    }

    public static String decodeLocalName(byte[] data, int start, int length) {
        try {
            return new String(data, start, length, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            Log.e(TAG, "Unable to convert the complete local name to UTF-8", e);
            return null;
        } catch (IndexOutOfBoundsException e2) {
            Log.e(TAG, "Error when reading complete local name", e2);
            return null;
        }
    }

    private static boolean decodeService16BitUUID(String uuid, byte[] data, int startPosition, int serviceDataLength) {
        return Integer.toHexString(decodeUuid16(data, startPosition)).equals(uuid.substring(4, 8));
    }

    private static boolean decodeService32BitUUID(String uuid, byte[] data, int startPosition, int serviceDataLength) {
        return Integer.toHexString(decodeUuid16(data, (startPosition + serviceDataLength) - 4)).equals(uuid.substring(4, 8));
    }

    private static boolean decodeService128BitUUID(String uuid, byte[] data, int startPosition, int serviceDataLength) {
        return Integer.toHexString(decodeUuid16(data, (startPosition + serviceDataLength) - 4)).equals(uuid.substring(4, 8));
    }

    private static int decodeUuid16(byte[] data, int start) {
        return ((data[start + 1] & 255) << 8) | (data[start] & 255);
    }
}
