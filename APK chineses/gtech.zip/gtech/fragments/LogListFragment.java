package com.accumed.gtech.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ListView;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.adapter.LogListAp;
import com.accumed.gtech.customview.MoreFooter;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.lib.pulltorefresh.PullToRefreshBase.OnRefreshListener;
import com.accumed.gtech.lib.pulltorefresh.PullToRefreshListView;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import java.util.HashMap;

public class LogListFragment extends Fragment {
    public static final String FINISH_REFRESH = "0";
    static final String className = "LogListFragment";
    final int GET_FRIEND_TIMELINE_LIMIT = 0;
    final int SHOW_MORE_FOOTER = 1;
    ListView actualListView;
    public boolean loadingFlag;
    LogCat logCat = new LogCat();
    LogListAp logListAp;
    public LogListFragmentListener logListFragmentListener;
    int mAppStatus;
    Context mContext;
    MoreFooter moreFooter;
    boolean nowSync;
    PullToRefreshListView pullToRefreshView;
    long refreshWait = 10000;
    long startTime = System.currentTimeMillis();
    UserProfileSettingData userProfileSettingData;

    public interface LogListFragmentListener {
        void change_friend_timeline_startnum_from_logList();

        void checkout_LogList_from_logList();

        void checkout_UserProfileSettingData_from_logList();

        void checkout_dataMining_LogList_from_logList();

        void checkout_noDataMining_LogList_from_logList();

        void execute_timeLineLimitThr_from_logList();

        void roadingProgessBar(int i);
    }

    class C02641 implements OnRefreshListener {
        C02641() {
        }

        public void onRefresh() {
            if (LogListFragment.this.nowSync) {
                Toast.makeText(LogListFragment.this.mContext, C0213R.string.already_running, 0).show();
                LogListFragment.this.pullToRefreshView.onRefreshComplete();
                return;
            }
            LogListFragment.this.startTime = System.currentTimeMillis();
            LogListFragment.this.nowSync = true;
            LogListFragment.this.logListFragmentListener.roadingProgessBar(0);
            LogListFragment.this.logListFragmentListener.change_friend_timeline_startnum_from_logList();
            LogListFragment.this.logListFragmentListener.checkout_LogList_from_logList();
        }
    }

    class C02652 implements OnScrollListener {
        C02652() {
        }

        public void onScroll(AbsListView arg0, int arg1, int arg2, int arg3) {
            LogListFragment.this.logCat.log(LogListFragment.className, "onScroll arg1", arg1 + "");
            LogListFragment.this.logCat.log(LogListFragment.className, "onScroll arg2", arg2 + "");
            LogListFragment.this.logCat.log(LogListFragment.className, "onScroll arg3", arg3 + "");
            if (arg3 != 0 && arg2 - arg3 != 0 && arg3 > 0 && arg1 + arg2 == arg3 && !LogListFragment.this.loadingFlag) {
                LogListFragment.this.logCat.log(LogListFragment.className, "user_email", LogListFragment.this.userProfileSettingData.USER_EMAIL);
                PreferenceAction pref = new PreferenceAction(LogListFragment.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                if (!(LogListFragment.this.userProfileSettingData.USER_EMAIL == null || LogListFragment.this.userProfileSettingData.USER_EMAIL.equals("") || LogListFragment.this.userProfileSettingData.USER_EMAIL.equals(pref.getString(PreferenceAction.MY_EMAIL)))) {
                    LogListFragment.this.actionDefine(1);
                }
                LogListFragment.this.logCat.log(LogListFragment.className, "floading", "in");
                LogListFragment.this.actionDefine(0);
            }
        }

        public void onScrollStateChanged(AbsListView arg0, int arg1) {
        }
    }

    class C02663 implements Runnable {
        C02663() {
        }

        public void run() {
            LogListFragment.this.pullToRefreshView.onRefreshComplete();
        }
    }

    class C02674 implements Runnable {
        C02674() {
        }

        public void run() {
            LogListFragment.this.pullToRefreshView.onRefreshComplete();
        }
    }

    class C02685 implements Runnable {
        C02685() {
        }

        public void run() {
            LogListFragment.this.actualListView.setAdapter(LogListFragment.this.logListAp);
        }
    }

    class C02696 implements Runnable {
        C02696() {
        }

        public void run() {
            LogListFragment.this.actualListView.removeFooterView(LogListFragment.this.moreFooter);
        }
    }

    class C02707 implements Runnable {
        C02707() {
        }

        public void run() {
            LogListFragment.this.actualListView.addFooterView(LogListFragment.this.moreFooter);
        }
    }

    class C02718 implements Runnable {
        C02718() {
        }

        public void run() {
            LogListFragment.this.actualListView.removeFooterView(LogListFragment.this.moreFooter);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.nowSync = true;
        View v = inflater.inflate(C0213R.layout.loglist_fragment, null);
        this.mContext = getActivity();
        this.logCat.log(className, "onCreateView", "in");
        this.moreFooter = new MoreFooter(this.mContext);
        this.logListAp = new LogListAp(this.mContext);
        this.userProfileSettingData = new UserProfileSettingData(this.mContext);
        this.logListAp.setUserProfileSettingData(this.userProfileSettingData);
        this.logCat.log(className, "userProfileSettingData-USER_EMAIL", this.userProfileSettingData.USER_EMAIL);
        this.logCat.log(className, "userProfileSettingData-USER_HIGH_BLOOD_SUGAR", this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR);
        this.logCat.log(className, "userProfileSettingData-USER_BLOOD_SUGAR_UNIT", this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT);
        this.pullToRefreshView = (PullToRefreshListView) v.findViewById(C0213R.id.pull_refresh_list);
        this.pullToRefreshView.setOnRefreshListener(new C02641());
        this.actualListView = (ListView) this.pullToRefreshView.getRefreshableView();
        this.actualListView.setDivider(null);
        this.actualListView.setFastScrollEnabled(true);
        this.actualListView.setOnScrollListener(new C02652());
        this.logListFragmentListener.checkout_UserProfileSettingData_from_logList();
        this.logListFragmentListener.checkout_noDataMining_LogList_from_logList();
        return v;
    }

    public void onRefreshComplete() {
        this.logCat.log(className, "onRefreshComplete", "in");
        try {
            ((ContainerFragmentActivity) this.mContext).runOnUiThread(new C02663());
            this.logListFragmentListener.roadingProgessBar(8);
        } catch (Exception e) {
        }
    }

    public void onRefreshCompleteOnly() {
        this.logCat.log(className, "onRefreshComplete", "in");
        try {
            ((ContainerFragmentActivity) this.mContext).runOnUiThread(new C02674());
        } catch (Exception e) {
        }
    }

    public void setUserProfileSettingData(UserProfileSettingData d) {
        this.userProfileSettingData = d;
        if (this.userProfileSettingData != null) {
            this.logListAp.setUserProfileSettingData(this.userProfileSettingData);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setLogListApFromContainer(boolean r8, java.util.ArrayList<com.accumed.gtech.datamodel.LogDM> r9) {
        /*
        r7 = this;
        r6 = 0;
        r1 = r7.logCat;
        r2 = "LogListFragment";
        r3 = "setLogListApFromContainer() ";
        r4 = new java.lang.StringBuilder;
        r4.<init>();
        r5 = "in size ";
        r4 = r4.append(r5);
        r5 = r9.size();
        r4 = r4.append(r5);
        r4 = r4.toString();
        r1.log(r2, r3, r4);
        r1 = r7.logListAp;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = r1.getCount();	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        if (r1 != 0) goto L_0x0035;
    L_0x0029:
        r1 = r7.mContext;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = (com.accumed.gtech.ContainerFragmentActivity) r1;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r2 = new com.accumed.gtech.fragments.LogListFragment$5;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r2.<init>();	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1.runOnUiThread(r2);	 Catch:{ Exception -> 0x0075, all -> 0x008a }
    L_0x0035:
        r1 = r7.logListAp;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1.clearSubView();	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = r7.logListAp;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1.setLogDMList(r9);	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = r7.logListAp;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r2 = r7.userProfileSettingData;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1.setUserProfileSettingData(r2);	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = r7.logListAp;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1.notifyDataSetChanged();	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        if (r8 == 0) goto L_0x0061;
    L_0x004d:
        r0 = new com.accumed.gtech.util.Anim;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = r7.mContext;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r0.<init>(r1);	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = r7.actualListView;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r0.listAnim(r1);	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = r7.logListAp;	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        r1 = r1.getCount();	 Catch:{ Exception -> 0x0075, all -> 0x008a }
        if (r1 != 0) goto L_0x0061;
    L_0x0061:
        r1 = r7.mContext;	 Catch:{ Exception -> 0x00a4 }
        r1 = (com.accumed.gtech.ContainerFragmentActivity) r1;	 Catch:{ Exception -> 0x00a4 }
        r2 = new com.accumed.gtech.fragments.LogListFragment$6;	 Catch:{ Exception -> 0x00a4 }
        r2.<init>();	 Catch:{ Exception -> 0x00a4 }
        r1.runOnUiThread(r2);	 Catch:{ Exception -> 0x00a4 }
        r7.onRefreshComplete();	 Catch:{ Exception -> 0x00a4 }
    L_0x0070:
        r7.loadingFlag = r6;
        r7.nowSync = r6;
    L_0x0074:
        return;
    L_0x0075:
        r1 = move-exception;
        r1 = r7.mContext;	 Catch:{ Exception -> 0x00a2 }
        r1 = (com.accumed.gtech.ContainerFragmentActivity) r1;	 Catch:{ Exception -> 0x00a2 }
        r2 = new com.accumed.gtech.fragments.LogListFragment$6;	 Catch:{ Exception -> 0x00a2 }
        r2.<init>();	 Catch:{ Exception -> 0x00a2 }
        r1.runOnUiThread(r2);	 Catch:{ Exception -> 0x00a2 }
        r7.onRefreshComplete();	 Catch:{ Exception -> 0x00a2 }
    L_0x0085:
        r7.loadingFlag = r6;
        r7.nowSync = r6;
        goto L_0x0074;
    L_0x008a:
        r1 = move-exception;
        r2 = r1;
        r1 = r7.mContext;	 Catch:{ Exception -> 0x00a0 }
        r1 = (com.accumed.gtech.ContainerFragmentActivity) r1;	 Catch:{ Exception -> 0x00a0 }
        r3 = new com.accumed.gtech.fragments.LogListFragment$6;	 Catch:{ Exception -> 0x00a0 }
        r3.<init>();	 Catch:{ Exception -> 0x00a0 }
        r1.runOnUiThread(r3);	 Catch:{ Exception -> 0x00a0 }
        r7.onRefreshComplete();	 Catch:{ Exception -> 0x00a0 }
    L_0x009b:
        r7.loadingFlag = r6;
        r7.nowSync = r6;
        throw r2;
    L_0x00a0:
        r1 = move-exception;
        goto L_0x009b;
    L_0x00a2:
        r1 = move-exception;
        goto L_0x0085;
    L_0x00a4:
        r1 = move-exception;
        goto L_0x0070;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.accumed.gtech.fragments.LogListFragment.setLogListApFromContainer(boolean, java.util.ArrayList):void");
    }

    public void notifyDataSetChanged() {
        try {
            this.logListAp.notifyDataSetChanged();
        } catch (Exception e) {
        }
        this.logListAp.clearSubView();
    }

    public void addFooterView() {
        ((ContainerFragmentActivity) this.mContext).runOnUiThread(new C02707());
    }

    public void removeFooterView() {
        ((ContainerFragmentActivity) this.mContext).runOnUiThread(new C02718());
    }

    public void listViewSetSelection(int rowNum) {
        try {
            this.actualListView.setSelection(rowNum);
        } catch (Exception e) {
        }
    }

    public void setFriendMap(HashMap<String, String> friendMap) {
        if (friendMap != null && this.logListAp != null) {
            this.logListAp.setFriendMap(friendMap);
        }
    }

    private void appStatus() {
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
    }

    private void actionDefine(int gubun) {
        appStatus();
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                actionAlert();
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                actionAlert();
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                actionAlert();
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                actionAlert();
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                actionAlert();
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                actionAlert();
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                actionAlert();
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                actionAlert();
                if (gubun == 1) {
                    addFooterView();
                }
                if (gubun == 0) {
                    this.loadingFlag = true;
                    this.logListFragmentListener.execute_timeLineLimitThr_from_logList();
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                actionAlert();
                if (gubun == 1) {
                    addFooterView();
                }
                if (gubun == 0) {
                    this.logListFragmentListener.execute_timeLineLimitThr_from_logList();
                    this.loadingFlag = true;
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void actionAlert() {
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.logListFragmentListener = (LogListFragmentListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + "let's implement LogListFragmentListener");
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        this.logCat.log(className, "onSaveInstanceState", "in");
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        this.logCat.log(className, "onConfigurationChanged in", "logListFragment");
    }
}
