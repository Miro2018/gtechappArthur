package com.accumed.gtech.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.IndiaPurchase;
import com.accumed.gtech.OtherrecordFragmentActivity;
import com.accumed.gtech.UsefulInformation;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.settings.AboutGluconavii;
import com.accumed.gtech.settings.ProfileModify;
import com.accumed.gtech.settings.SettingModify;
import com.accumed.gtech.settings.SettingNotiActivity;
import com.accumed.gtech.thread.OnVersionCheckListener;
import com.accumed.gtech.thread.ThrVersionCheck;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.version.Version;
import java.util.Locale;

public class MoreFragment extends Fragment implements OnVersionCheckListener {
    private static final int READ_PHONE_STATE_PERMISSION = 0;
    static final String className = "MoreFragment";
    final int SETTING = 78;
    final int VERSION_CHECK = 0;
    LinearLayout limitLy;
    View limitVew;
    LogCat logCat;
    int mAppStatus;
    Context mContext;
    LinearLayout menuAboutLy;
    LinearLayout menuAramSettingLy;
    LinearLayout menuNfcSettingLy;
    LinearLayout menuProfileLy;
    LinearLayout menuPurchaseLy;
    LinearLayout menuRecordLy;
    LinearLayout menuSettingLy;
    LinearLayout menuSyncSettingLy;
    LinearLayout menuUseInfoLy;
    LinearLayout menuVersionLy;
    MoreFragmentListener moreFragmentListener;
    TextView more_version_tv;
    ProgressBar versionProgressBar;
    View view_menu04;
    View view_menu07;
    View view_menu071;
    View view_menu08;
    View view_menu09;

    public interface MoreFragmentListener {
        void onFinish_from_moreFragment();

        void onMoreFragment_request_isMe();
    }

    class C02721 implements OnClickListener {
        C02721() {
        }

        public void onClick(View arg0) {
            MoreFragment.this.startActivity(new Intent(MoreFragment.this.mContext, ProfileModify.class));
        }
    }

    class C02732 implements OnClickListener {
        C02732() {
        }

        public void onClick(View arg0) {
            MoreFragment.this.startActivity(new Intent(MoreFragment.this.mContext, SettingModify.class));
        }
    }

    class C02743 implements OnClickListener {
        C02743() {
        }

        public void onClick(View arg0) {
            MoreFragment.this.startActivity(new Intent(MoreFragment.this.mContext, OtherrecordFragmentActivity.class));
        }
    }

    class C02754 implements OnClickListener {
        C02754() {
        }

        public void onClick(View arg0) {
            MoreFragment.this.startActivity(new Intent(MoreFragment.this.mContext, AboutGluconavii.class));
        }
    }

    class C02765 implements OnClickListener {
        C02765() {
        }

        public void onClick(View arg0) {
            MoreFragment.this.startActivity(new Intent(MoreFragment.this.mContext, UsefulInformation.class));
        }
    }

    class C02776 implements OnClickListener {
        C02776() {
        }

        public void onClick(View arg0) {
            if (VERSION.SDK_INT >= 14) {
                Intent nfcIntent = new Intent("android.settings.NFC_SETTINGS");
                nfcIntent.addCategory("android.intent.category.DEFAULT");
                MoreFragment.this.startActivity(nfcIntent);
                return;
            }
            nfcIntent = new Intent("android.settings.WIRELESS_SETTINGS");
            nfcIntent.addCategory("android.intent.category.DEFAULT");
            MoreFragment.this.startActivity(nfcIntent);
        }
    }

    class C02787 implements OnClickListener {
        C02787() {
        }

        public void onClick(View arg0) {
            MoreFragment.this.startActivity(new Intent(MoreFragment.this.mContext, SettingNotiActivity.class));
        }
    }

    class C02798 implements OnClickListener {
        C02798() {
        }

        public void onClick(View arg0) {
        }
    }

    class C02809 implements OnClickListener {
        C02809() {
        }

        public void onClick(View arg0) {
            int permissionCheck = ContextCompat.checkSelfPermission(MoreFragment.this.mContext, "android.permission.READ_PHONE_STATE");
            if (ContextCompat.checkSelfPermission(MoreFragment.this.getActivity(), "android.permission.READ_PHONE_STATE") != 0) {
                MoreFragment.this.requestPermissions(new String[]{"android.permission.READ_PHONE_STATE"}, 0);
                return;
            }
            TelephonyManager manager = (TelephonyManager) MoreFragment.this.mContext.getSystemService("phone");
            if (manager.getSimSerialNumber().equals("") || !manager.getSimSerialNumber().substring(2, 4).equals("91")) {
                MoreFragment.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://m.sd-market.com?from_android=yes")));
                return;
            }
            MoreFragment.this.startActivity(new Intent(MoreFragment.this.mContext, IndiaPurchase.class));
        }
    }

    public void onResume() {
        super.onResume();
        localeEvent();
        this.moreFragmentListener.onMoreFragment_request_isMe();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0213R.layout.more_fragment, null);
        this.mContext = getActivity();
        this.logCat = new LogCat();
        this.menuProfileLy = (LinearLayout) v.findViewById(C0213R.id.menuProfileLy);
        this.menuSettingLy = (LinearLayout) v.findViewById(C0213R.id.menuSettingLy);
        this.menuRecordLy = (LinearLayout) v.findViewById(C0213R.id.menuRecordLy);
        this.menuAboutLy = (LinearLayout) v.findViewById(C0213R.id.menuAboutLy);
        this.menuUseInfoLy = (LinearLayout) v.findViewById(C0213R.id.menuUseInfoLy);
        this.view_menu07 = v.findViewById(C0213R.id.view_menu07);
        this.menuNfcSettingLy = (LinearLayout) v.findViewById(C0213R.id.menuNfcSettingLy);
        this.menuAramSettingLy = (LinearLayout) v.findViewById(C0213R.id.menuAramSettingLy);
        this.menuVersionLy = (LinearLayout) v.findViewById(C0213R.id.menuVersionLy);
        this.menuSyncSettingLy = (LinearLayout) v.findViewById(C0213R.id.menuSyncSettingLy);
        this.menuPurchaseLy = (LinearLayout) v.findViewById(C0213R.id.menuPurchaseLy);
        this.versionProgressBar = (ProgressBar) v.findViewById(C0213R.id.versionProgressBar);
        this.versionProgressBar.setVisibility(8);
        this.limitVew = v.findViewById(C0213R.id.limitVew);
        this.limitVew.setVisibility(8);
        this.limitLy = (LinearLayout) v.findViewById(C0213R.id.limitLy);
        this.limitLy.setVisibility(8);
        this.view_menu04 = v.findViewById(C0213R.id.view_menu04);
        this.view_menu08 = v.findViewById(C0213R.id.view_menu08);
        this.view_menu09 = v.findViewById(C0213R.id.view_menu09);
        this.view_menu071 = v.findViewById(C0213R.id.view_menu071);
        this.more_version_tv = (TextView) v.findViewById(C0213R.id.more_version_tv);
        this.more_version_tv.setText(this.more_version_tv.getText().toString() + Version.APP_VERSION);
        this.menuProfileLy.setOnClickListener(new C02721());
        this.menuSettingLy.setOnClickListener(new C02732());
        this.menuRecordLy.setOnClickListener(new C02743());
        this.menuAboutLy.setOnClickListener(new C02754());
        this.menuUseInfoLy.setOnClickListener(new C02765());
        this.menuNfcSettingLy.setOnClickListener(new C02776());
        this.menuAramSettingLy.setOnClickListener(new C02787());
        this.menuVersionLy.setOnClickListener(new C02798());
        this.menuPurchaseLy.setOnClickListener(new C02809());
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_SYNC_SWITCH);
        final EditText limitEt = (EditText) v.findViewById(C0213R.id.limitEt);
        ((Button) v.findViewById(C0213R.id.limitBt)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                new PreferenceAction(MoreFragment.this.getActivity(), PreferenceAction.PREF_NAME_TEST_LIMIT).putString(PreferenceAction.TEST_LIMIT, limitEt.getText().toString());
                new ShowAlert(MoreFragment.this.getActivity()).alert0("ok", "ok", "ok");
            }
        });
        return v;
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 0:
                if (grantResults[0] == 0) {
                    TelephonyManager manager = (TelephonyManager) this.mContext.getSystemService("phone");
                    if (manager.getSimSerialNumber().equals("") || !manager.getSimSerialNumber().substring(2, 4).equals("91")) {
                        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://m.sd-market.com?from_android=yes")));
                        return;
                    } else {
                        startActivity(new Intent(this.mContext, IndiaPurchase.class));
                        return;
                    }
                }
                Toast.makeText(this.mContext, C0213R.string.read_phone_state_cancel_title, 0).show();
                return;
            default:
                return;
        }
    }

    void appStatus() {
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
    }

    public void setIsMe(boolean isMe) {
        if (isMe) {
            this.logCat.log(className, "setIsMe()", "me");
            this.menuProfileLy.setVisibility(0);
            this.menuSettingLy.setVisibility(0);
            this.menuRecordLy.setVisibility(0);
            this.menuSyncSettingLy.setVisibility(8);
            this.menuPurchaseLy.setVisibility(0);
            this.view_menu04.setVisibility(0);
            this.view_menu08.setVisibility(8);
            this.view_menu09.setVisibility(0);
        } else {
            this.logCat.log(className, "setIsMe()", "friend");
            this.menuProfileLy.setVisibility(8);
            this.menuSettingLy.setVisibility(8);
            this.menuRecordLy.setVisibility(8);
            this.menuSyncSettingLy.setVisibility(8);
            this.menuPurchaseLy.setVisibility(8);
            this.view_menu04.setVisibility(8);
            this.view_menu08.setVisibility(8);
            this.view_menu09.setVisibility(8);
        }
        localeEvent();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.moreFragmentListener = (MoreFragmentListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + "let's implement MoreFragmentListener");
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            this.mContext.getResources().updateConfiguration(config, this.mContext.getResources().getDisplayMetrics());
            if (prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("ko")) {
                this.view_menu071.setVisibility(0);
                this.menuUseInfoLy.setVisibility(0);
                this.menuAboutLy.setVisibility(0);
                this.view_menu07.setVisibility(0);
                this.menuPurchaseLy.setVisibility(0);
                this.view_menu09.setVisibility(0);
                return;
            }
            if (prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("en")) {
                this.menuPurchaseLy.setVisibility(0);
                this.view_menu09.setVisibility(0);
            }
            this.menuPurchaseLy.setVisibility(8);
            this.view_menu09.setVisibility(8);
            this.view_menu071.setVisibility(8);
            this.menuUseInfoLy.setVisibility(8);
            this.menuAboutLy.setVisibility(8);
            this.view_menu07.setVisibility(8);
        }
    }

    public void onVersionCheck(Object obj) {
        this.logCat.log(className, "onVersionCheck", "in");
        if (obj != null) {
            if (Version.APP_VERSION.equals((String) obj)) {
                alertVersionCheck(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_no_update_msg), getString(C0213R.string.alert_text_confirm));
            } else {
                alertVersionCheck(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_update_msg), getString(C0213R.string.alert_text_confirm));
            }
        }
        hideVersionProgressBar();
    }

    void alertVersionCheck(final String title, final String message, final String btText) {
        ((ContainerFragmentActivity) this.mContext).runOnUiThread(new Runnable() {
            public void run() {
                new ShowAlert(MoreFragment.this.mContext).alert0(title, message, btText);
            }
        });
    }

    void hideVersionProgressBar() {
        ((ContainerFragmentActivity) this.mContext).runOnUiThread(new Runnable() {
            public void run() {
                MoreFragment.this.versionProgressBar.setVisibility(8);
            }
        });
    }

    void showVersionProgressBar() {
        ((ContainerFragmentActivity) this.mContext).runOnUiThread(new Runnable() {
            public void run() {
                MoreFragment.this.versionProgressBar.setVisibility(0);
            }
        });
    }

    private void actionDefine(int gubun) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == 0) {
                    alertVersionCheck(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_text_message), getString(C0213R.string.alert_text_confirm));
                    return;
                }
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == 0) {
                    alertVersionCheck(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_text_message), getString(C0213R.string.alert_text_confirm));
                    return;
                }
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == 0) {
                    alertVersionCheck(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_text_message), getString(C0213R.string.alert_text_confirm));
                    return;
                }
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == 0) {
                    alertVersionCheck(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_text_message), getString(C0213R.string.alert_text_confirm));
                    return;
                }
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == 0) {
                    showVersionProgressBar();
                    new ThrVersionCheck(this.mContext, this).start();
                    return;
                }
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == 0) {
                    showVersionProgressBar();
                    new ThrVersionCheck(this.mContext, this).start();
                    return;
                }
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    showVersionProgressBar();
                    new ThrVersionCheck(this.mContext, this).start();
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    showVersionProgressBar();
                    new ThrVersionCheck(this.mContext, this).start();
                    return;
                }
                return;
            default:
                return;
        }
    }
}
