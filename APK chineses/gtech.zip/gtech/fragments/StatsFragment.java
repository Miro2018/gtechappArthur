package com.accumed.gtech.fragments;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.chart.StatsBloodSugar;
import com.accumed.gtech.chart.StatsChart;
import com.accumed.gtech.chart.StatsCsv;
import com.accumed.gtech.chart.StatsInsulin;
import com.accumed.gtech.datamining.DataMiningSelectLog;
import com.accumed.gtech.datamodel.ChartData;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.fma.android.chart.widget.PIChart;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.TimeLineReturnDM;
import com.accumed.gtech.thread.datamodel.TimeLineThrDM;
import com.accumed.gtech.util.GlucoseEvent;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.Util;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import lecho.lib.hellocharts.model.BubbleChartData;

@SuppressLint({"SimpleDateFormat"})
public class StatsFragment extends Fragment {
    @SuppressLint({"SdCardPath"})
    public static String AnalysisFileDir = "/sdcard/data/com.gluconavii/file/";
    static final String className = "StatsFragment";
    private OnClickListener btnClickListener = new C02896();
    private OnCheckedChangeListener chboxCheckedChangeListener = new C02863();
    public OnDateSetListener dateListener01 = new C02874();
    public OnDateSetListener dateListener02 = new C02885();
    private boolean isCsv;
    private boolean isLogbook;
    boolean isMe;
    private boolean isStats;
    LogCat logCat = new LogCat();
    private LogDM logDM;
    private ArrayList<LogDM> logList = new ArrayList();
    private View mBottomDivider;
    private Button mBtnPeriod01;
    private Button mBtnPeriod02;
    private Button mBtnPeriod03;
    public ChartData mChartData;
    private CheckBox mChboxCsv;
    private CheckBox mChboxLogbook;
    private CheckBox mChboxStats;
    private Context mContext;
    private String mDate01;
    private String mDate02;
    private int mDay01;
    private int mDay02;
    private ImageButton mIbtnAttach;
    private ImageButton mIbtnEmail;
    private LinearLayout mLLAttach;
    private LinearLayout mLLAttachLayout;
    private LinearLayout mLLBottomLayout;
    private LinearLayout mLLEmail;
    private int mMonth01;
    private int mMonth02;
    private int mPeriod;
    private TextView mTvAttach;
    private TextView mTvDate01;
    private TextView mTvDate02;
    private TextView mTvEmail;
    private int mYear01;
    private int mYear02;
    String myHyper;
    String myHypo;
    String myLanguage;
    String mybloodUnit;
    private ProgressDialog pd;
    private PreferenceAction prefMyProfile;
    private PreferenceAction prefMySetting;
    public StatsFragmentListener statsFragmentListener;
    @SuppressLint({"HandlerLeak"})
    private Handler statsHandler = new C02852();
    Handler timeLineH = new C02841();
    UserProfileSettingData userProfileSettingData;
    private Util util;
    View f15v;

    public interface StatsFragmentListener {
        void checkout_UserProfileSettingData_from_stats();

        void request_hideDialog_from_stats();

        void request_showDialog_from_stats();
    }

    class C02841 extends Handler {
        C02841() {
        }

        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                StatsFragment.this.logList = (ArrayList) msg.obj;
                StatsFragment.this.setChart(StatsFragment.this.mDate01, StatsFragment.this.mDate02);
                StatsFragment.this.statsFragmentListener.request_hideDialog_from_stats();
            }
        }
    }

    class C02852 extends Handler {
        C02852() {
        }

        public void handleMessage(Message msg) {
            if (StatsFragment.this.pd != null && StatsFragment.this.pd.isShowing()) {
                StatsFragment.this.pd.cancel();
            }
            String title = "None_title";
            if (StatsFragment.this.isStats) {
                if (StatsFragment.this.userProfileSettingData == null || !StatsFragment.this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
                    title = "GlucoNavii - Stats";
                } else {
                    title = "글루코나비 리포트";
                }
            } else if (StatsFragment.this.userProfileSettingData == null || !StatsFragment.this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
                title = "GlucoNavii Report";
            } else {
                title = "글루코나비 리포트";
            }
            String name = "User";
            if (!(StatsFragment.this.userProfileSettingData == null || StatsFragment.this.userProfileSettingData.USER_NAME == null)) {
                name = StatsFragment.this.userProfileSettingData.USER_NAME;
            }
            String subject = title + " : " + name + "[" + new SimpleDateFormat("yyyy-MM-dd").format(Long.valueOf(System.currentTimeMillis())) + "]";
            String[] tos = new String[]{""};
            Intent intent = new Intent("android.intent.action.SEND_MULTIPLE");
            intent.setType("plain/text");
            intent.putExtra("android.intent.extra.EMAIL", tos);
            intent.putExtra("android.intent.extra.SUBJECT", subject);
            intent.putExtra("android.intent.extra.TEXT", "FileAttach");
            ArrayList<Uri> uriArr = new ArrayList();
            File[] fileArr = new File(StatsFragment.AnalysisFileDir).listFiles();
            if (fileArr == null) {
                StatsFragment.this.getString(C0213R.string.alert_type16);
                return;
            }
            for (File fromFile : fileArr) {
                uriArr.add(Uri.fromFile(fromFile));
            }
            intent.putParcelableArrayListExtra("android.intent.extra.STREAM", uriArr);
            StatsFragment.this.startActivity(intent);
        }
    }

    class C02863 implements OnCheckedChangeListener {
        C02863() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            switch (buttonView.getId()) {
                case C0213R.id.stats_chbox_logbook:
                    StatsFragment.this.isLogbook = isChecked;
                    StatsFragment.this.mChboxLogbook.setButtonDrawable(C0213R.drawable.btn_chbox_on);
                    return;
                case C0213R.id.stats_chbox_stats:
                    StatsFragment.this.isStats = isChecked;
                    if (isChecked) {
                        StatsFragment.this.mChboxStats.setButtonDrawable(C0213R.drawable.btn_chbox_on);
                        return;
                    } else {
                        StatsFragment.this.mChboxStats.setButtonDrawable(C0213R.drawable.btn_chbox_off);
                        return;
                    }
                case C0213R.id.stats_chbox_csv:
                    StatsFragment.this.isCsv = isChecked;
                    if (isChecked) {
                        StatsFragment.this.mChboxCsv.setButtonDrawable(C0213R.drawable.btn_chbox_on);
                        return;
                    } else {
                        StatsFragment.this.mChboxCsv.setButtonDrawable(C0213R.drawable.btn_chbox_off);
                        return;
                    }
                default:
                    return;
            }
        }
    }

    class C02874 implements OnDateSetListener {
        C02874() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            StatsFragment.this.setDate01(year, monthOfYear + 1, dayOfMonth);
        }
    }

    class C02885 implements OnDateSetListener {
        C02885() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            StatsFragment.this.setDate02(year, monthOfYear + 1, dayOfMonth);
        }
    }

    class C02896 implements OnClickListener {
        C02896() {
        }

        public void onClick(View v) {
            switch (v.getId()) {
                case C0213R.id.stats_btn_period01:
                    StatsFragment.this.mPeriod = 0;
                    StatsFragment.this.mBtnPeriod01.setBackgroundResource(C0213R.drawable.bg_smenu_on);
                    StatsFragment.this.mBtnPeriod02.setBackgroundResource(C0213R.drawable.bg_smenu_off);
                    StatsFragment.this.mBtnPeriod03.setBackgroundResource(C0213R.drawable.bg_smenu_off);
                    StatsFragment.this.setDateType();
                    return;
                case C0213R.id.stats_btn_period02:
                    StatsFragment.this.mPeriod = 1;
                    StatsFragment.this.mBtnPeriod01.setBackgroundResource(C0213R.drawable.bg_smenu_off);
                    StatsFragment.this.mBtnPeriod02.setBackgroundResource(C0213R.drawable.bg_smenu_on);
                    StatsFragment.this.mBtnPeriod03.setBackgroundResource(C0213R.drawable.bg_smenu_off);
                    StatsFragment.this.setDateType();
                    return;
                case C0213R.id.stats_btn_period03:
                    StatsFragment.this.mPeriod = 2;
                    StatsFragment.this.mBtnPeriod01.setBackgroundResource(C0213R.drawable.bg_smenu_off);
                    StatsFragment.this.mBtnPeriod02.setBackgroundResource(C0213R.drawable.bg_smenu_off);
                    StatsFragment.this.mBtnPeriod03.setBackgroundResource(C0213R.drawable.bg_smenu_on);
                    StatsFragment.this.setDateType();
                    return;
                case C0213R.id.stats_tv_date01:
                    StatsFragment.this.showDatePicker01();
                    return;
                case C0213R.id.stats_tv_date02:
                    StatsFragment.this.showDatePicker02();
                    return;
                case C0213R.id.stats_ll_email:
                    StatsFragment.this.sendEmail();
                    return;
                case C0213R.id.stats_ll_attach:
                    StatsFragment.this.setAttacMenu();
                    return;
                default:
                    return;
            }
        }
    }

    class C02907 implements Runnable {
        C02907() {
        }

        public void run() {
            int type = Integer.parseInt(StatsFragment.this.util.blankToZero(StatsFragment.this.logDM.blood_sugar_type));
            if (StatsFragment.this.isLogbook && type == 0) {
                StatsFragment.this.logCat.log(StatsFragment.className, "email attach isLogbook", "in0");
                new StatsInsulin(StatsFragment.this.mContext, StatsFragment.this.userProfileSettingData).saveInsulin(StatsFragment.this.mDate01, StatsFragment.this.mDate02);
            } else if (StatsFragment.this.isLogbook && type != 0) {
                StatsFragment.this.logCat.log(StatsFragment.className, "email attach isLogbook", "in1");
                new StatsBloodSugar(StatsFragment.this.mContext, StatsFragment.this.userProfileSettingData).saveBloodSugar(StatsFragment.this.mDate01, StatsFragment.this.mDate02);
            }
            if (StatsFragment.this.isStats) {
                StatsFragment.this.logCat.log(StatsFragment.className, "email attach isStats", "in");
                new StatsChart(StatsFragment.this.mContext, StatsFragment.this.mChartData, StatsFragment.this.userProfileSettingData).saveStats();
            }
            if (StatsFragment.this.isCsv) {
                StatsFragment.this.logCat.log(StatsFragment.className, "email attach isCsv", "in");
                new StatsCsv(StatsFragment.this.mContext, StatsFragment.this.userProfileSettingData).saveCsv();
            }
            StatsFragment.this.statsHandler.sendEmptyMessage(0);
        }
    }

    class TimeLineThr extends Thread {
        final String className = "TimeLineThr";
        Context mContext;
        Handler mHandler;
        String mSubDir;
        ArrayList<LogDM> tLogList;
        TimeLineThrDM timeLineThrDM;
        String userEmail;

        TimeLineThr(Context c, TimeLineThrDM dm, String subDir, Handler h) {
            this.mContext = c;
            StatsFragment.this.logCat.log("TimeLineThr", "TimeLineThr", "in");
            this.timeLineThrDM = dm;
            this.userEmail = this.timeLineThrDM.email;
            this.mSubDir = subDir;
            this.tLogList = new ArrayList();
            this.mHandler = h;
        }

        public void run() {
            this.tLogList = new ArrayList();
            StatsFragment.this.logCat.log("TimeLineThr", "0 / start_num / return_num", Integer.toString(0) + "/" + this.timeLineThrDM.start_num + " / " + this.timeLineThrDM.return_num);
            SDConnection conn = new SDConnection(this.timeLineThrDM);
            String result = conn.suport_getTimeLineResult(this.mContext, this.mSubDir);
            StatsFragment.this.logCat.log("TimeLineThr", "result", result);
            TimeLineReturnDM tiemLineReturnDM = new MagicReturnDM(this.mContext).suport_timeLineReturnDM(result);
            StatsFragment.this.logCat.log("TimeLineThr", "tiemLineReturnDM", tiemLineReturnDM.code);
            StatsFragment.this.logCat.log("TimeLineThr", "tiemLineReturnDM", tiemLineReturnDM.statusResult);
            int start_num = Integer.parseInt(this.timeLineThrDM.start_num);
            int i = 0;
            while (tiemLineReturnDM.code.equals("200") && tiemLineReturnDM.statusResult.equals("ok")) {
                StatsFragment.this.logCat.log("TimeLineThr", "while", "in");
                if (i > 0) {
                    start_num = Integer.parseInt(this.timeLineThrDM.start_num) + Integer.parseInt(this.timeLineThrDM.return_num);
                } else if (i == 0) {
                    start_num = Integer.parseInt(this.timeLineThrDM.start_num);
                }
                this.timeLineThrDM.start_num = Integer.toString(start_num);
                conn.setDataModel(this.timeLineThrDM);
                result = conn.suport_getTimeLineResult(this.mContext, this.mSubDir);
                tiemLineReturnDM = new MagicReturnDM(this.mContext).suport_timeLineReturnDM(result);
                this.tLogList.addAll(tiemLineReturnDM.subLogDMList);
                i++;
                StatsFragment.this.logCat.log("TimeLineThr", "i / start_num / return_num", Integer.toString(i) + "/" + Integer.toString(start_num) + " / " + Integer.parseInt(this.timeLineThrDM.return_num));
                StatsFragment.this.logCat.log("TimeLineThr", "result", result);
            }
            Message msg = Message.obtain();
            msg.what = 0;
            msg.obj = this.tLogList;
            this.mHandler.sendMessage(msg);
        }
    }

    public static int average(ArrayList<Float> array) {
        float sum = 0.0f;
        for (int i = 0; i < array.size(); i++) {
            sum += ((Float) array.get(i)).floatValue();
        }
        return (int) (sum / ((float) array.size()));
    }

    public static int standardDeviation(ArrayList<Float> array, int option) {
        if (array.size() < 2) {
            return 0;
        }
        float sum = 0.0f;
        float meanValue = (float) average(array);
        for (int i = 0; i < array.size(); i++) {
            float diff = ((Float) array.get(i)).floatValue() - meanValue;
            sum += diff * diff;
        }
        return (int) ((float) Math.sqrt((double) (sum / ((float) (array.size() - option)))));
    }

    public static int max(ArrayList<Float> array) {
        float m = 0.0f;
        for (int i = 0; i < array.size(); i++) {
            if (m < ((Float) array.get(i)).floatValue()) {
                m = ((Float) array.get(i)).floatValue();
            }
        }
        return (int) m;
    }

    public static int min(ArrayList<Float> array) {
        float m = 0.0f;
        for (int i = 0; i < array.size(); i++) {
            if (i == 0) {
                m = ((Float) array.get(i)).floatValue();
            } else if (m > ((Float) array.get(i)).floatValue()) {
                m = ((Float) array.get(i)).floatValue();
            }
        }
        return (int) m;
    }

    public static int getDayDifference(String startDate, String endDate) {
        try {
            Date endDay = new SimpleDateFormat("yyyyMMddHHmmss").parse(endDate);
            Calendar endDayCal = new GregorianCalendar();
            endDayCal.setTime(endDay);
            Date startDay = new SimpleDateFormat("yyyyMMddHHmmss").parse(startDate);
            Calendar startDayCal = new GregorianCalendar();
            startDayCal.setTime(startDay);
            return (int) ((endDayCal.getTimeInMillis() - startDayCal.getTimeInMillis()) / GraphFragment.DATE_DAY);
        } catch (ParseException e) {
            e.printStackTrace(System.out);
            return 0;
        }
    }

    public static Integer[] getCalendar_today() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat f1 = new SimpleDateFormat("yyyy");
        SimpleDateFormat f2 = new SimpleDateFormat("MM");
        SimpleDateFormat f3 = new SimpleDateFormat("dd");
        int year = Integer.parseInt(f1.format(cal.getTime()));
        int month = Integer.parseInt(f2.format(cal.getTime()));
        int day = Integer.parseInt(f3.format(cal.getTime()));
        return new Integer[]{Integer.valueOf(year), Integer.valueOf(month), Integer.valueOf(day)};
    }

    public void onResume() {
        super.onResume();
        this.statsFragmentListener.checkout_UserProfileSettingData_from_stats();
        init();
    }

    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.f15v = inflater.inflate(C0213R.layout.stats_fragment, null);
        this.mContext = getActivity();
        this.logDM = new LogDM();
        this.util = new Util();
        this.logCat.log(className, "onCreateView()", "in");
        this.userProfileSettingData = new UserProfileSettingData(this.mContext);
        this.prefMyProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        this.prefMySetting = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        this.mybloodUnit = this.prefMyProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
        this.myLanguage = this.prefMySetting.getString(PreferenceAction.MY_LANGUAGE);
        this.myHypo = this.prefMyProfile.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR);
        this.myHyper = this.prefMyProfile.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR);
        return this.f15v;
    }

    private void init() {
        this.logCat.log(className, "init()", "in");
        contentsLayout();
        if (getResources().getConfiguration().orientation == 1) {
            this.mBottomDivider.setVisibility(0);
            this.mLLBottomLayout.setVisibility(0);
        } else if (getResources().getConfiguration().orientation == 2) {
            this.mBottomDivider.setVisibility(8);
            this.mLLBottomLayout.setVisibility(8);
        }
    }

    private void contentsLayout() {
        this.logCat.log(className, "contentsLayout()", "in");
        this.mBtnPeriod01 = (Button) this.f15v.findViewById(C0213R.id.stats_btn_period01);
        this.mBtnPeriod02 = (Button) this.f15v.findViewById(C0213R.id.stats_btn_period02);
        this.mBtnPeriod03 = (Button) this.f15v.findViewById(C0213R.id.stats_btn_period03);
        this.mBottomDivider = this.f15v.findViewById(C0213R.id.stats_line);
        this.mLLBottomLayout = (LinearLayout) this.f15v.findViewById(C0213R.id.stats_bottom);
        this.mLLEmail = (LinearLayout) this.f15v.findViewById(C0213R.id.stats_ll_email);
        this.mLLAttach = (LinearLayout) this.f15v.findViewById(C0213R.id.stats_ll_attach);
        this.mIbtnEmail = (ImageButton) this.f15v.findViewById(C0213R.id.stats_ibtn_email);
        this.mIbtnAttach = (ImageButton) this.f15v.findViewById(C0213R.id.stats_ibtn_attach);
        this.mIbtnEmail.setClickable(false);
        this.mIbtnAttach.setClickable(false);
        this.mTvEmail = (TextView) this.f15v.findViewById(C0213R.id.stats_tv_email);
        this.mTvAttach = (TextView) this.f15v.findViewById(C0213R.id.stats_tv_attach);
        this.mTvEmail.setClickable(false);
        this.mTvAttach.setClickable(false);
        this.mTvDate01 = (TextView) this.f15v.findViewById(C0213R.id.stats_tv_date01);
        this.mTvDate02 = (TextView) this.f15v.findViewById(C0213R.id.stats_tv_date02);
        this.mChboxLogbook = (CheckBox) this.f15v.findViewById(C0213R.id.stats_chbox_logbook);
        this.mChboxStats = (CheckBox) this.f15v.findViewById(C0213R.id.stats_chbox_stats);
        this.mChboxCsv = (CheckBox) this.f15v.findViewById(C0213R.id.stats_chbox_csv);
        this.mLLAttachLayout = (LinearLayout) this.f15v.findViewById(C0213R.id.stats_ll_attachlayout);
        this.mBtnPeriod01.setOnClickListener(this.btnClickListener);
        this.mBtnPeriod02.setOnClickListener(this.btnClickListener);
        this.mBtnPeriod03.setOnClickListener(this.btnClickListener);
        this.mLLEmail.setOnClickListener(this.btnClickListener);
        this.mLLAttach.setOnClickListener(this.btnClickListener);
        this.mTvDate01.setOnClickListener(this.btnClickListener);
        this.mTvDate02.setOnClickListener(this.btnClickListener);
        this.mChboxLogbook.setOnCheckedChangeListener(this.chboxCheckedChangeListener);
        this.mChboxStats.setOnCheckedChangeListener(this.chboxCheckedChangeListener);
        this.mChboxCsv.setOnCheckedChangeListener(this.chboxCheckedChangeListener);
        this.mChboxLogbook.setChecked(true);
        this.mChboxLogbook.setEnabled(false);
        this.mChboxLogbook.setButtonDrawable(C0213R.drawable.btn_chbox_on);
        this.isLogbook = true;
        if (this.userProfileSettingData.USER_EMAIL.equals(new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL))) {
            if (this.mLLBottomLayout != null) {
                this.mLLBottomLayout.setVisibility(0);
                this.logCat.log(className, "setUserProfileSettingData()", "1");
            }
        } else if (this.mLLBottomLayout != null) {
            this.mLLBottomLayout.setVisibility(8);
            this.logCat.log(className, "setUserProfileSettingData()", "2");
        }
        setDefaultData();
    }

    private void setDefaultData() {
        this.logCat.log(className, "setDefaultData()", "in");
        this.mPeriod = 0;
        this.mBtnPeriod01.setBackgroundResource(C0213R.drawable.bg_smenu_on);
        this.mBtnPeriod02.setBackgroundResource(C0213R.drawable.bg_smenu_off);
        this.mBtnPeriod03.setBackgroundResource(C0213R.drawable.bg_smenu_off);
        Calendar c = Calendar.getInstance();
        setDate02(c.get(1), c.get(2) + 1, c.get(5));
    }

    private void setDate01(int year, int month, int date) {
        this.logCat.log(className, "setDate01()", "in");
        this.mYear01 = year;
        this.mMonth01 = month;
        this.mDay01 = date;
        Integer[] date_array = null;
        this.mDate01 = convertDateValue(this.mYear01) + convertDateValue(this.mMonth01) + convertDateValue(this.mDay01);
        this.mTvDate01.setText(convertDateValue(this.mYear01) + "." + convertDateValue(this.mMonth01) + "." + convertDateValue(this.mDay01));
        if (this.mPeriod == 0) {
            date_array = getCalendar(0, year, month, date, 14);
        } else if (this.mPeriod == 1) {
            date_array = getCalendar(1, year, month, date, 1);
        } else if (this.mPeriod == 2) {
            date_array = getCalendar(1, year, month, date, 3);
        }
        this.mYear02 = date_array[0].intValue();
        this.mMonth02 = date_array[1].intValue();
        this.mDay02 = date_array[2].intValue();
        this.mDate02 = convertDateValue(this.mYear02) + convertDateValue(this.mMonth02) + convertDateValue(this.mDay02);
        this.mTvDate02.setText(convertDateValue(this.mYear02) + "." + convertDateValue(this.mMonth02) + "." + convertDateValue(this.mDay02));
        if (this.isMe) {
            setChart(this.mDate01, this.mDate02);
        } else {
            timeLineThr();
        }
    }

    private void setDate02(int year, int month, int date) {
        this.logCat.log(className, "setDate02()", "in");
        Integer[] date_array = null;
        if (this.mPeriod == 0) {
            date_array = getCalendar(0, year, month, date, -14);
        } else if (this.mPeriod == 1) {
            date_array = getCalendar(1, year, month, date, -1);
        } else if (this.mPeriod == 2) {
            date_array = getCalendar(1, year, month, date, -3);
        }
        this.mYear01 = date_array[0].intValue();
        this.mMonth01 = date_array[1].intValue();
        this.mDay01 = date_array[2].intValue();
        this.mDate01 = convertDateValue(this.mYear01) + convertDateValue(this.mMonth01) + convertDateValue(this.mDay01);
        this.mTvDate01.setText(convertDateValue(this.mYear01) + "." + convertDateValue(this.mMonth01) + "." + convertDateValue(this.mDay01));
        this.mYear02 = year;
        this.mMonth02 = month;
        this.mDay02 = date;
        this.mDate02 = convertDateValue(this.mYear02) + convertDateValue(this.mMonth02) + convertDateValue(this.mDay02);
        this.mTvDate02.setText(convertDateValue(this.mYear02) + "." + convertDateValue(this.mMonth02) + "." + convertDateValue(this.mDay02));
        if (this.isMe) {
            setChart(this.mDate01, this.mDate02);
        } else {
            timeLineThr();
        }
    }

    private void setDateType() {
        Integer[] date_array = null;
        int year = Integer.parseInt(this.mDate02.substring(0, 4));
        int month = Integer.parseInt(this.mDate02.substring(4, 6));
        int date = Integer.parseInt(this.mDate02.substring(6));
        if (this.mPeriod == 0) {
            date_array = getCalendar(0, year, month, date, -14);
        } else if (this.mPeriod == 1) {
            date_array = getCalendar(1, year, month, date, -1);
        } else if (this.mPeriod == 2) {
            date_array = getCalendar(1, year, month, date, -3);
        }
        this.mYear01 = date_array[0].intValue();
        this.mMonth01 = date_array[1].intValue();
        this.mDay01 = date_array[2].intValue();
        this.mDate01 = convertDateValue(this.mYear01) + convertDateValue(this.mMonth01) + convertDateValue(this.mDay01);
        this.mTvDate01.setText(convertDateValue(this.mYear01) + "." + convertDateValue(this.mMonth01) + "." + convertDateValue(this.mDay01));
        this.logCat.log(className, "mDate01", this.mDate01);
        this.logCat.log(className, "mDate02", this.mDate02);
        if (this.isMe) {
            setChart(this.mDate01, this.mDate02);
        } else {
            timeLineThr();
        }
    }

    private void timeLineThr() {
        this.statsFragmentListener.request_showDialog_from_stats();
        TimeLineThrDM dm = new TimeLineThrDM();
        dm.email = this.userProfileSettingData.USER_EMAIL;
        dm.enddate = this.util.getTomorrowBartype(this.mDate02) + " 23:59:59.000";
        dm.startdate = this.util.getTomorrowBartype(this.mDate01);
        dm.start_num = "0";
        dm.return_num = ClassConstant.TIMELINE_LIMIT;
        new TimeLineThr(this.mContext, dm, ClassConstant.SUBDIR_SUPORT_TIMELINE, this.timeLineH).start();
    }

    private void statsThreadAndDialog() {
        this.pd = new ProgressDialog(this.mContext);
        this.pd.setProgressStyle(0);
        this.pd.setCancelable(false);
        this.pd.setMessage("Loading...");
        this.pd.show();
        File[] fileArr = new File(AnalysisFileDir).listFiles();
        if (fileArr != null && fileArr.length > 0) {
            for (File delete : fileArr) {
                delete.delete();
            }
        }
        new Thread(new C02907()).start();
    }

    private void sendEmail() {
        if (this.mLLAttachLayout.getVisibility() == 0) {
            closeAttacMenu();
        }
        statsThreadAndDialog();
    }

    public void showDatePicker01() {
        new DatePickerDialog(this.mContext, this.dateListener01, this.mYear01, this.mMonth01 - 1, this.mDay01).show();
    }

    public void showDatePicker02() {
        new DatePickerDialog(this.mContext, this.dateListener02, this.mYear02, this.mMonth02 - 1, this.mDay02).show();
    }

    private void setAttacMenu() {
        if (this.mLLAttachLayout != null && this.mLLAttachLayout.getVisibility() == 0) {
            closeAttacMenu();
        } else if (this.mLLAttachLayout != null && this.mLLAttachLayout.getVisibility() == 8) {
            Toast.makeText(this.mContext, getString(C0213R.string.message_text33), 0).show();
            openAttachMenu();
        }
    }

    private void openAttachMenu() {
        this.mLLAttachLayout.setVisibility(0);
    }

    private void closeAttacMenu() {
        this.mLLAttachLayout.setVisibility(8);
    }

    public void setChartCount(ArrayList<LogDM> arr, String date01, String date02) {
        int diffDay = getDayDifference(date01, date02);
        int total_count = arr.size();
        this.logCat.log(className, "total_count", total_count + "");
        float average_count = (float) (total_count / diffDay);
        String stitle01 = getString(C0213R.string.stats_text_chart_btitle01) + total_count;
        String stitle02 = getString(C0213R.string.stats_text_chart_btitle02) + average_count;
        ((TextView) this.f15v.findViewById(C0213R.id.stats_tv_subtitle01)).setText(stitle01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_tv_subtitle02)).setText(stitle02);
        this.mChartData.setChart_total_count(String.valueOf(total_count));
        this.mChartData.setChart_average_count(String.valueOf(average_count));
    }

    public void setUserProfileSettingData(UserProfileSettingData d) {
        this.userProfileSettingData = d;
    }

    public void setLogList(ArrayList<LogDM> l) {
        this.logCat.log(className, "setLogList() list size", this.logList.size() + "");
        this.logList = l;
    }

    public void setChart(String date1, String date2) {
        int i;
        this.mChartData = new ChartData();
        date1 = date1 + "000000";
        date2 = date2 + "235959";
        int diffDay = getDayDifference(date1, date2);
        String name = this.prefMyProfile.getString(PreferenceAction.MY_NAME);
        String birth = this.prefMyProfile.getString(PreferenceAction.MY_BIRTH);
        String since = this.prefMyProfile.getString(PreferenceAction.MY_OCCOURDAY);
        String preiod = String.valueOf(diffDay);
        this.mChartData.setInfo_name(name);
        this.mChartData.setInfo_birth(birth);
        this.mChartData.setInfo_since(since);
        this.mChartData.setInfo_preriod(preiod);
        this.mChartData.setInfo_date01(date1);
        this.mChartData.setInfo_date02(date2);
        this.mChartData.setInfo_language(this.prefMySetting.getString(PreferenceAction.MY_LANGUAGE));
        ArrayList<LogDM> t_array01 = new ArrayList();
        DataMiningSelectLog dataMiningSelectLog = new DataMiningSelectLog(this.mContext);
        if (this.userProfileSettingData.isMe(this.userProfileSettingData.USER_EMAIL)) {
            this.isMe = true;
            this.logCat.log(className, "sIsMe", "yes");
            String MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
            String DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
            String q = "select * from log where (user_id='' or user_id='" + this.prefMyProfile.getString(PreferenceAction.MY_EMAIL) + "') and  input_date between '" + date1 + "' and '" + date2 + "' and  blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE;
            this.logCat.log(className, "qStr", q);
            t_array01 = dataMiningSelectLog.getLogList(q);
        } else {
            this.isMe = false;
            this.logCat.log(className, "sIsMe", "no");
            t_array01 = this.logList;
        }
        ArrayList<Float> sd01_array01 = new ArrayList();
        ArrayList<Float> sd01_array02 = new ArrayList();
        ArrayList<Float> sd01_array03 = new ArrayList();
        ArrayList<Float> sd01_array04 = new ArrayList();
        ArrayList<Float> sd02_array01 = new ArrayList();
        ArrayList<Float> sd02_array02 = new ArrayList();
        ArrayList<Float> sd02_array03 = new ArrayList();
        ArrayList<Float> sd02_array04 = new ArrayList();
        ArrayList<Float> sd02_array05 = new ArrayList();
        ArrayList<Float> sd02_array06 = new ArrayList();
        ArrayList<Float> sd02_array07 = new ArrayList();
        ArrayList<LogDM> t_array02 = new ArrayList();
        for (i = 0; i < t_array01.size(); i++) {
            LogDM data = (LogDM) t_array01.get(i);
            String category = data.category;
            if (category != null) {
                if (category.equals("0")) {
                    t_array02.add(data);
                }
            }
        }
        ArrayList<LogDM> arr = new ArrayList();
        for (i = 0; i < t_array02.size(); i++) {
            data = (LogDM) t_array02.get(i);
            String blood_sugar_eat = data.blood_sugar_eat;
            if (blood_sugar_eat != null) {
                if (blood_sugar_eat.equals("0")) {
                    arr.add(data);
                }
            }
            if (blood_sugar_eat != null) {
                if (blood_sugar_eat.equals("1")) {
                    arr.add(data);
                }
            }
            if (blood_sugar_eat != null) {
                if (blood_sugar_eat.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                    arr.add(data);
                }
            }
            if (blood_sugar_eat != null) {
                if (blood_sugar_eat.equals(LogDM.GLUCOSE_EAT_NONE)) {
                    arr.add(data);
                }
            }
        }
        for (i = 0; i < arr.size(); i++) {
            String input_date = ((LogDM) arr.get(i)).input_date;
            int eat = Integer.parseInt(((LogDM) arr.get(i)).blood_sugar_eat);
            float value = Float.parseFloat(((LogDM) arr.get(i)).blood_sugar_value);
            sd01_array01.add(Float.valueOf(value));
            if (eat == 1) {
                sd01_array02.add(Float.valueOf(value));
            }
            if (eat == 0) {
                sd01_array03.add(Float.valueOf(value));
            }
            if (eat == 3) {
                sd01_array04.add(Float.valueOf(value));
            }
            int day = getDay(input_date);
            if (day == 1) {
                sd02_array01.add(Float.valueOf(value));
            } else if (day == 2) {
                sd02_array02.add(Float.valueOf(value));
            } else if (day == 3) {
                sd02_array03.add(Float.valueOf(value));
            } else if (day == 4) {
                sd02_array04.add(Float.valueOf(value));
            } else if (day == 5) {
                sd02_array05.add(Float.valueOf(value));
            } else if (day == 6) {
                sd02_array06.add(Float.valueOf(value));
            } else if (day == 7) {
                sd02_array07.add(Float.valueOf(value));
            }
        }
        try {
            setChartCount(arr, date1, date2);
        } catch (Exception e) {
        }
        try {
            setChart01(arr);
            setChart02(arr);
            setChart03(arr);
            setChart04(arr);
            setTable01(sd01_array01, sd01_array02, sd01_array03, sd01_array04);
            setTable02(sd02_array01, sd02_array02, sd02_array03, sd02_array04, sd02_array05, sd02_array06, sd02_array07);
        } catch (Exception e2) {
        }
    }

    public void setTable01(ArrayList<Float> sd01_array01, ArrayList<Float> sd01_array02, ArrayList<Float> sd01_array03, ArrayList<Float> sd01_array04) {
        String title;
        String avg01;
        String avg02;
        String avg03;
        String avg04;
        String sd01;
        String sd02;
        String sd03;
        String sd04;
        String max01;
        String max02;
        String max03;
        String max04;
        String min01;
        String min02;
        String min03;
        String min04;
        if (this.mybloodUnit.equals("mg/dL")) {
            title = getString(C0213R.string.stats_text_chart_atitle04_01);
            ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_title01)).setText(title);
        } else {
            title = getString(C0213R.string.stats_text_chart_atitle04_02);
            ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_title01)).setText(title);
        }
        if (this.myLanguage.equals("ko")) {
            ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_title02)).setVisibility(8);
        } else {
            ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_title02)).setVisibility(0);
        }
        if (this.mybloodUnit.equals("mg/dL")) {
            avg01 = String.valueOf(average(sd01_array01));
            avg02 = String.valueOf(average(sd01_array02));
            avg03 = String.valueOf(average(sd01_array03));
            avg04 = String.valueOf(average(sd01_array04));
        } else {
            avg01 = getBsValue(average(sd01_array01));
            avg02 = getBsValue(average(sd01_array02));
            avg03 = getBsValue(average(sd01_array03));
            avg04 = getBsValue(average(sd01_array04));
        }
        if (this.mybloodUnit.equals("mg/dL")) {
            sd01 = String.valueOf(standardDeviation(sd01_array01, 1));
            sd02 = String.valueOf(standardDeviation(sd01_array02, 1));
            sd03 = String.valueOf(standardDeviation(sd01_array03, 1));
            sd04 = String.valueOf(standardDeviation(sd01_array04, 1));
        } else {
            sd01 = getBsValue(standardDeviation(sd01_array01, 1));
            sd02 = getBsValue(standardDeviation(sd01_array02, 1));
            sd03 = getBsValue(standardDeviation(sd01_array03, 1));
            sd04 = getBsValue(standardDeviation(sd01_array04, 1));
        }
        if (this.mybloodUnit.equals("mg/dL")) {
            max01 = String.valueOf(max(sd01_array01));
            max02 = String.valueOf(max(sd01_array02));
            max03 = String.valueOf(max(sd01_array03));
            max04 = String.valueOf(max(sd01_array04));
        } else {
            max01 = getBsValue(max(sd01_array01));
            max02 = getBsValue(max(sd01_array02));
            max03 = getBsValue(max(sd01_array03));
            max04 = getBsValue(max(sd01_array04));
        }
        if (this.mybloodUnit.equals("mg/dL")) {
            min01 = String.valueOf(min(sd01_array01));
            min02 = String.valueOf(min(sd01_array02));
            min03 = String.valueOf(min(sd01_array03));
            min04 = String.valueOf(min(sd01_array04));
        } else {
            min01 = getBsValue(min(sd01_array01));
            min02 = getBsValue(min(sd01_array02));
            min03 = getBsValue(min(sd01_array03));
            min04 = getBsValue(min(sd01_array04));
        }
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value01_01)).setText(avg01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value01_02)).setText(avg02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value01_03)).setText(avg03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value01_04)).setText(avg04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value02_01)).setText(sd01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value02_02)).setText(sd02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value02_03)).setText(sd03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value02_04)).setText(sd04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value03_01)).setText(max01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value03_02)).setText(max02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value03_03)).setText(max03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value03_04)).setText(max04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value04_01)).setText(min01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value04_02)).setText(min02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value04_03)).setText(min03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table01_tv_value04_04)).setText(min04);
        this.mChartData.setTable01_title(title);
        this.mChartData.setTable01_avg01(avg01);
        this.mChartData.setTable01_avg02(avg02);
        this.mChartData.setTable01_avg03(avg03);
        this.mChartData.setTable01_avg04(avg04);
        this.mChartData.setTable01_sd01(sd01);
        this.mChartData.setTable01_sd02(sd02);
        this.mChartData.setTable01_sd03(sd03);
        this.mChartData.setTable01_sd04(sd04);
        this.mChartData.setTable01_max01(max01);
        this.mChartData.setTable01_max02(max02);
        this.mChartData.setTable01_max03(max03);
        this.mChartData.setTable01_max04(max04);
        this.mChartData.setTable01_min01(min01);
        this.mChartData.setTable01_min02(min02);
        this.mChartData.setTable01_min03(min03);
        this.mChartData.setTable01_min04(min04);
    }

    public void setTable02(ArrayList<Float> sd02_array01, ArrayList<Float> sd02_array02, ArrayList<Float> sd02_array03, ArrayList<Float> sd02_array04, ArrayList<Float> sd02_array05, ArrayList<Float> sd02_array06, ArrayList<Float> sd02_array07) {
        String title;
        String avg01;
        String avg02;
        String avg03;
        String avg04;
        String avg05;
        String avg06;
        String avg07;
        String sd01;
        String sd02;
        String sd03;
        String sd04;
        String sd05;
        String sd06;
        String sd07;
        String max01;
        String max02;
        String max03;
        String max04;
        String max05;
        String max06;
        String max07;
        String min01;
        String min02;
        String min03;
        String min04;
        String min05;
        String min06;
        String min07;
        if (this.mybloodUnit.equals("mg/dL")) {
            title = getString(C0213R.string.stats_text_chart_atitle05_01);
            ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_title)).setText(title);
        } else {
            title = getString(C0213R.string.stats_text_chart_atitle05_02);
            ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_title)).setText(title);
        }
        if (this.mybloodUnit.equals("mg/dL")) {
            avg01 = String.valueOf(average(sd02_array02));
            avg02 = String.valueOf(average(sd02_array03));
            avg03 = String.valueOf(average(sd02_array04));
            avg04 = String.valueOf(average(sd02_array05));
            avg05 = String.valueOf(average(sd02_array06));
            avg06 = String.valueOf(average(sd02_array07));
            avg07 = String.valueOf(average(sd02_array01));
        } else {
            avg01 = getBsValue(average(sd02_array02));
            avg02 = getBsValue(average(sd02_array03));
            avg03 = getBsValue(average(sd02_array04));
            avg04 = getBsValue(average(sd02_array05));
            avg05 = getBsValue(average(sd02_array06));
            avg06 = getBsValue(average(sd02_array07));
            avg07 = getBsValue(average(sd02_array01));
        }
        if (this.mybloodUnit.equals("mg/dL")) {
            sd01 = String.valueOf(standardDeviation(sd02_array02, 1));
            sd02 = String.valueOf(standardDeviation(sd02_array03, 1));
            sd03 = String.valueOf(standardDeviation(sd02_array04, 1));
            sd04 = String.valueOf(standardDeviation(sd02_array05, 1));
            sd05 = String.valueOf(standardDeviation(sd02_array06, 1));
            sd06 = String.valueOf(standardDeviation(sd02_array07, 1));
            sd07 = String.valueOf(standardDeviation(sd02_array01, 1));
        } else {
            sd01 = getBsValue(standardDeviation(sd02_array02, 1));
            sd02 = getBsValue(standardDeviation(sd02_array03, 1));
            sd03 = getBsValue(standardDeviation(sd02_array04, 1));
            sd04 = getBsValue(standardDeviation(sd02_array05, 1));
            sd05 = getBsValue(standardDeviation(sd02_array06, 1));
            sd06 = getBsValue(standardDeviation(sd02_array07, 1));
            sd07 = getBsValue(standardDeviation(sd02_array01, 1));
        }
        if (this.mybloodUnit.equals("mg/dL")) {
            max01 = String.valueOf(max(sd02_array02));
            max02 = String.valueOf(max(sd02_array03));
            max03 = String.valueOf(max(sd02_array04));
            max04 = String.valueOf(max(sd02_array05));
            max05 = String.valueOf(max(sd02_array06));
            max06 = String.valueOf(max(sd02_array07));
            max07 = String.valueOf(max(sd02_array01));
        } else {
            max01 = getBsValue(max(sd02_array02));
            max02 = getBsValue(max(sd02_array03));
            max03 = getBsValue(max(sd02_array04));
            max04 = getBsValue(max(sd02_array05));
            max05 = getBsValue(max(sd02_array06));
            max06 = getBsValue(max(sd02_array07));
            max07 = getBsValue(max(sd02_array01));
        }
        if (this.mybloodUnit.equals("mg/dL")) {
            min01 = String.valueOf(min(sd02_array02));
            min02 = String.valueOf(min(sd02_array03));
            min03 = String.valueOf(min(sd02_array04));
            min04 = String.valueOf(min(sd02_array05));
            min05 = String.valueOf(min(sd02_array06));
            min06 = String.valueOf(min(sd02_array07));
            min07 = String.valueOf(min(sd02_array01));
        } else {
            min01 = getBsValue(min(sd02_array02));
            min02 = getBsValue(min(sd02_array03));
            min03 = getBsValue(min(sd02_array04));
            min04 = getBsValue(min(sd02_array05));
            min05 = getBsValue(min(sd02_array06));
            min06 = getBsValue(min(sd02_array07));
            min07 = getBsValue(min(sd02_array01));
        }
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value01_01)).setText(avg01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value01_02)).setText(avg02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value01_03)).setText(avg03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value01_04)).setText(avg04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value01_05)).setText(avg05);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value01_06)).setText(avg06);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value01_07)).setText(avg07);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value02_01)).setText(sd01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value02_02)).setText(sd02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value02_03)).setText(sd03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value02_04)).setText(sd04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value02_05)).setText(sd05);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value02_06)).setText(sd06);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value02_07)).setText(sd07);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value03_01)).setText(max01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value03_02)).setText(max02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value03_03)).setText(max03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value03_04)).setText(max04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value03_05)).setText(max05);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value03_06)).setText(max06);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value03_07)).setText(max07);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value04_01)).setText(min01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value04_02)).setText(min02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value04_03)).setText(min03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value04_04)).setText(min04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value04_05)).setText(min05);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value04_06)).setText(min06);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_table02_tv_value04_07)).setText(min07);
        this.mChartData.setTable02_title(title);
        this.mChartData.setTable02_avg01(avg01);
        this.mChartData.setTable02_avg02(avg02);
        this.mChartData.setTable02_avg03(avg03);
        this.mChartData.setTable02_avg04(avg04);
        this.mChartData.setTable02_avg05(avg05);
        this.mChartData.setTable02_avg06(avg06);
        this.mChartData.setTable02_avg07(avg07);
        this.mChartData.setTable02_sd01(sd01);
        this.mChartData.setTable02_sd02(sd02);
        this.mChartData.setTable02_sd03(sd03);
        this.mChartData.setTable02_sd04(sd04);
        this.mChartData.setTable02_sd05(sd05);
        this.mChartData.setTable02_sd06(sd06);
        this.mChartData.setTable02_sd07(sd07);
        this.mChartData.setTable02_max01(max01);
        this.mChartData.setTable02_max02(max02);
        this.mChartData.setTable02_max03(max03);
        this.mChartData.setTable02_max04(max04);
        this.mChartData.setTable02_max05(max05);
        this.mChartData.setTable02_max06(max06);
        this.mChartData.setTable02_max07(max07);
        this.mChartData.setTable02_min01(min01);
        this.mChartData.setTable02_min02(min02);
        this.mChartData.setTable02_min03(min03);
        this.mChartData.setTable02_min04(min04);
        this.mChartData.setTable02_min05(min05);
        this.mChartData.setTable02_min06(min06);
        this.mChartData.setTable02_min07(min07);
    }

    public void setChart01(ArrayList<LogDM> arr) {
        float percent1;
        float percent2;
        float percent5;
        float percent3;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        float percent4 = 0.0f;
        for (int i = 0; i < arr.size(); i++) {
            int eat = Integer.parseInt(((LogDM) arr.get(i)).blood_sugar_eat);
            if (eat == 1) {
                count1++;
            } else if (eat == 0) {
                count2++;
            } else if (eat == 3) {
                count4++;
            } else {
                count3++;
            }
        }
        int total_count = ((count1 + count2) + count3) + count4;
        if (total_count != 0) {
            percent1 = (float) Math.round((float) ((count1 * 100) / total_count));
            percent2 = (float) Math.round((float) ((count2 * 100) / total_count));
            percent5 = (float) Math.round((float) ((count4 * 100) / total_count));
            percent3 = 100.0f - ((percent1 + percent2) + percent5);
        } else {
            percent1 = 0.0f;
            percent2 = 0.0f;
            percent3 = 0.0f;
            percent5 = 0.0f;
        }
        if (percent1 == 0.0f && percent2 == 0.0f && percent3 == 0.0f && percent5 == 0.0f) {
            percent4 = 100.0f;
        }
        String legend01 = count1 + " (" + percent1 + "%)";
        String legend02 = count2 + " (" + percent2 + "%)";
        String legend04 = count4 + " (" + percent5 + "%)";
        String legend03 = count3 + " (" + percent3 + "%)";
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart01_tv_value01)).setText(legend01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart01_tv_value02)).setText(legend02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart01_tv_value03)).setText(legend03);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart01_tv_value04)).setText(legend04);
        PIChart piChart = (PIChart) this.f15v.findViewById(C0213R.id.stats_chart_01);
        piChart.reset();
        piChart.setShowText(false);
        piChart.setForm(TypedValue.applyDimension(2, 3.0f, getResources().getDisplayMetrics()), 0.0f, BubbleChartData.DEFAULT_BUBBLE_SCALE);
        if (percent1 > 0.0f) {
            piChart.addItem("item01", percent1, -6504352);
            this.mChartData.setChart01_color01("#9cc060");
        } else {
            this.mChartData.setChart01_color01("#9cc060");
        }
        if (percent2 > 0.0f) {
            piChart.addItem("item02", percent2, -1352105);
            this.mChartData.setChart01_color02("#eb5e57");
        } else {
            this.mChartData.setChart01_color02("#eb5e57");
        }
        if (percent3 > 0.0f) {
            piChart.addItem("item03", percent3, -526345);
            this.mChartData.setChart01_color03("#f7f7f7");
        } else {
            this.mChartData.setChart01_color03("#cbcbcb");
        }
        if (percent5 > 0.0f) {
            piChart.addItem("item05", percent5, -1334185);
            this.mChartData.setChart01_color04("#eba457");
        } else {
            this.mChartData.setChart01_color04("#eba457");
        }
        if (percent4 == 100.0f) {
            piChart.addItem("item04", percent4, -3421237);
            this.mChartData.setChart01_color03("#cbcbcb");
        }
        piChart.generate(false);
        int web_count01 = count1;
        int web_count02 = count2;
        int web_count03 = count3;
        float web_percent01 = percent1;
        float web_percent02 = percent2;
        float web_percent03 = percent3;
        if (web_count01 != 0 && web_count02 == 0 && web_count03 == 0) {
            web_percent01 = 99.8f;
            web_percent02 = 0.1f;
            web_percent03 = 0.1f;
        } else if (web_count01 == 0 && web_count02 != 0 && web_count03 == 0) {
            web_percent01 = 0.1f;
            web_percent02 = 99.8f;
            web_percent03 = 0.1f;
        } else if (web_count01 == 0 && web_count02 == 0 && web_count03 != 0) {
            web_percent01 = 0.1f;
            web_percent02 = 0.1f;
            web_percent03 = 99.8f;
        } else if (web_count01 == 0 && web_count02 == 0 && web_count03 == 0) {
            web_percent01 = 0.1f;
            web_percent02 = 0.1f;
            web_percent03 = 99.8f;
        }
        this.mChartData.setChart01_count01(String.valueOf(web_count01));
        this.mChartData.setChart01_count02(String.valueOf(web_count02));
        this.mChartData.setChart01_count03(String.valueOf(web_count03));
        this.mChartData.setChart01_percent01(String.valueOf(web_percent01));
        this.mChartData.setChart01_percent02(String.valueOf(web_percent02));
        this.mChartData.setChart01_percent03(String.valueOf(web_percent03));
    }

    public void setChart02(ArrayList<LogDM> arr) {
        float percent1;
        float percent2;
        float percent3;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        float percent4 = 0.0f;
        for (int i = 0; i < arr.size(); i++) {
            if (Integer.parseInt(((LogDM) arr.get(i)).category) == 0) {
                float value = Float.parseFloat(((LogDM) arr.get(i)).blood_sugar_value);
                if (value <= Float.parseFloat(this.myHypo)) {
                    count1++;
                } else if (value >= Float.parseFloat(this.myHyper)) {
                    count2++;
                } else {
                    count3++;
                }
            }
        }
        int total_count = (count1 + count2) + count3;
        if (total_count != 0) {
            percent1 = (float) Math.round((float) ((count1 * 100) / total_count));
            percent2 = (float) Math.round((float) ((count2 * 100) / total_count));
            percent3 = 100.0f - (percent1 + percent2);
        } else {
            percent1 = 0.0f;
            percent2 = 0.0f;
            percent3 = 0.0f;
        }
        if (percent1 == 0.0f && percent2 == 0.0f && percent3 == 0.0f) {
            percent4 = 100.0f;
        }
        String legend01 = count1 + " (" + percent1 + "%)";
        String legend02 = count2 + " (" + percent2 + "%)";
        String legend03 = count3 + " (" + percent3 + "%)";
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart02_tv_value01)).setText(legend01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart02_tv_value02)).setText(legend02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart02_tv_value03)).setText(legend03);
        PIChart piChart = (PIChart) this.f15v.findViewById(C0213R.id.stats_chart_02);
        piChart.reset();
        piChart.setShowText(false);
        piChart.setForm(TypedValue.applyDimension(2, 3.0f, getResources().getDisplayMetrics()), 0.0f, BubbleChartData.DEFAULT_BUBBLE_SCALE);
        if (percent1 > 0.0f) {
            piChart.addItem("item01", percent1, -6504352);
            this.mChartData.setChart02_color01("#9cc060");
        } else {
            this.mChartData.setChart02_color01("#9cc060");
        }
        if (percent2 > 0.0f) {
            piChart.addItem("item02", percent2, -1352105);
            this.mChartData.setChart02_color02("#eb5e57");
        } else {
            this.mChartData.setChart02_color02("#eb5e57");
        }
        if (percent3 > 0.0f) {
            piChart.addItem("item03", percent3, -526345);
            this.mChartData.setChart02_color03("#f7f7f7");
        } else {
            this.mChartData.setChart02_color03("#cbcbcb");
        }
        if (percent4 == 100.0f) {
            piChart.addItem("item04", percent4, -3421237);
            this.mChartData.setChart02_color03("#cbcbcb");
        }
        piChart.generate(false);
        int web_count01 = count1;
        int web_count02 = count2;
        int web_count03 = count3;
        float web_percent01 = percent1;
        float web_percent02 = percent2;
        float web_percent03 = percent3;
        if (web_count01 != 0 && web_count02 == 0 && web_count03 == 0) {
            web_percent01 = 99.8f;
            web_percent02 = 0.1f;
            web_percent03 = 0.1f;
        } else if (web_count01 == 0 && web_count02 != 0 && web_count03 == 0) {
            web_percent01 = 0.1f;
            web_percent02 = 99.8f;
            web_percent03 = 0.1f;
        } else if (web_count01 == 0 && web_count02 == 0 && web_count03 != 0) {
            web_percent01 = 0.1f;
            web_percent02 = 0.1f;
            web_percent03 = 99.8f;
        } else if (web_count01 == 0 && web_count02 == 0 && web_count03 == 0) {
            web_percent01 = 0.1f;
            web_percent02 = 0.1f;
            web_percent03 = 99.8f;
        }
        this.mChartData.setChart02_count01(String.valueOf(web_count01));
        this.mChartData.setChart02_count02(String.valueOf(web_count02));
        this.mChartData.setChart02_count03(String.valueOf(web_count03));
        this.mChartData.setChart02_percent01(String.valueOf(web_percent01));
        this.mChartData.setChart02_percent02(String.valueOf(web_percent02));
        this.mChartData.setChart02_percent03(String.valueOf(web_percent03));
    }

    public void setChart03(ArrayList<LogDM> arr) {
        float percent1;
        float percent2;
        float percent5;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        float percent3 = 0.0f;
        float percent4 = 0.0f;
        for (int i = 0; i < arr.size(); i++) {
            if (Integer.parseInt(((LogDM) arr.get(i)).category) == 0) {
                int eat = Integer.parseInt(((LogDM) arr.get(i)).blood_sugar_eat);
                if (Float.parseFloat(((LogDM) arr.get(i)).blood_sugar_value) >= Float.parseFloat(this.myHyper)) {
                    if (eat == 1) {
                        count1++;
                    } else if (eat == 0) {
                        count2++;
                    } else if (eat == 3) {
                        count4++;
                    } else {
                        count3++;
                    }
                }
            }
        }
        int total_count = ((count1 + count2) + count3) + count4;
        if (total_count != 0) {
            percent1 = (float) Math.round((float) ((count1 * 100) / total_count));
            percent2 = (float) Math.round((float) ((count2 * 100) / total_count));
            percent5 = (float) Math.round((float) ((count4 * 100) / total_count));
            percent3 = 100.0f - ((percent1 + percent2) + percent5);
        } else {
            percent1 = 0.0f;
            percent2 = 0.0f;
            percent5 = 0.0f;
        }
        if (percent1 == 0.0f && percent2 == 0.0f && percent3 == 0.0f && percent5 == 0.0f) {
            percent4 = 100.0f;
        }
        String legend01 = count1 + " (" + percent1 + "%)";
        String legend02 = count2 + " (" + percent2 + "%)";
        String legend04 = count4 + " (" + percent5 + "%)";
        String legend03 = count3 + " (" + percent3 + "%)";
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart03_tv_value01)).setText(legend01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart03_tv_value02)).setText(legend02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart03_tv_value04)).setText(legend04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart03_tv_value03)).setText(legend03);
        PIChart piChart = (PIChart) this.f15v.findViewById(C0213R.id.stats_chart_03);
        piChart.reset();
        piChart.setShowText(false);
        piChart.setForm(TypedValue.applyDimension(2, 3.0f, getResources().getDisplayMetrics()), 0.0f, BubbleChartData.DEFAULT_BUBBLE_SCALE);
        if (percent1 > 0.0f) {
            piChart.addItem("item01", percent1, -6504352);
            this.mChartData.setChart03_color01("#9cc060");
        } else {
            this.mChartData.setChart03_color01("#9cc060");
        }
        if (percent2 > 0.0f) {
            piChart.addItem("item02", percent2, -1352105);
            this.mChartData.setChart03_color02("#eb5e57");
        } else {
            this.mChartData.setChart03_color02("#eb5e57");
        }
        if (percent3 > 0.0f) {
            piChart.addItem("item03", percent3, -526345);
            this.mChartData.setChart03_color03("#f7f7f7");
        } else {
            this.mChartData.setChart03_color03("#cbcbcb");
        }
        if (percent5 > 0.0f) {
            piChart.addItem("item05", percent5, -1334185);
            this.mChartData.setChart03_color04("#eba457");
        } else {
            this.mChartData.setChart03_color04("#eba457");
        }
        if (percent4 == 100.0f) {
            piChart.addItem("item04", percent4, -3421237);
            this.mChartData.setChart03_color03("#cbcbcb");
        }
        piChart.generate(false);
        int web_count01 = count1;
        int web_count02 = count2;
        int web_count03 = count3;
        float web_percent01 = percent1;
        float web_percent02 = percent2;
        float web_percent03 = percent3;
        if (web_count01 != 0 && web_count02 == 0 && web_count03 == 0) {
            web_percent01 = 99.8f;
            web_percent02 = 0.1f;
            web_percent03 = 0.1f;
        } else if (web_count01 == 0 && web_count02 != 0 && web_count03 == 0) {
            web_percent01 = 0.1f;
            web_percent02 = 99.8f;
            web_percent03 = 0.1f;
        } else if (web_count01 == 0 && web_count02 == 0 && web_count03 != 0) {
            web_percent01 = 0.1f;
            web_percent02 = 0.1f;
            web_percent03 = 99.8f;
        } else if (web_count01 == 0 && web_count02 == 0 && web_count03 == 0) {
            web_percent01 = 0.1f;
            web_percent02 = 0.1f;
            web_percent03 = 99.8f;
        }
        this.mChartData.setChart03_count01(String.valueOf(web_count01));
        this.mChartData.setChart03_count02(String.valueOf(web_count02));
        this.mChartData.setChart03_count03(String.valueOf(web_count03));
        this.mChartData.setChart03_percent01(String.valueOf(web_percent01));
        this.mChartData.setChart03_percent02(String.valueOf(web_percent02));
        this.mChartData.setChart03_percent03(String.valueOf(web_percent03));
    }

    public void setChart04(ArrayList<LogDM> arr) {
        float percent1;
        float percent2;
        float percent5;
        float percent3;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        float percent4 = 0.0f;
        for (int i = 0; i < arr.size(); i++) {
            if (Integer.parseInt(((LogDM) arr.get(i)).category) == 0) {
                int eat = Integer.parseInt(((LogDM) arr.get(i)).blood_sugar_eat);
                if (Float.parseFloat(((LogDM) arr.get(i)).blood_sugar_value) <= Float.parseFloat(this.myHypo)) {
                    if (eat == 1) {
                        count1++;
                    } else if (eat == 0) {
                        count2++;
                    } else if (eat == 3) {
                        count4++;
                    } else {
                        count3++;
                    }
                }
            }
        }
        int total_count = ((count1 + count2) + count3) + count4;
        if (total_count != 0) {
            percent1 = (float) Math.round((float) ((count1 * 100) / total_count));
            percent2 = (float) Math.round((float) ((count2 * 100) / total_count));
            percent5 = (float) Math.round((float) ((count4 * 100) / total_count));
            percent3 = 100.0f - ((percent1 + percent2) + percent5);
        } else {
            percent1 = 0.0f;
            percent2 = 0.0f;
            percent3 = 0.0f;
            percent5 = 0.0f;
        }
        if (percent1 == 0.0f && percent2 == 0.0f && percent3 == 0.0f && percent5 == 0.0f) {
            percent4 = 100.0f;
        }
        String legend01 = count1 + " (" + percent1 + "%)";
        String legend02 = count2 + " (" + percent2 + "%)";
        String legend04 = count4 + " (" + percent5 + "%)";
        String legend03 = count3 + " (" + percent3 + "%)";
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart04_tv_value01)).setText(legend01);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart04_tv_value02)).setText(legend02);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart04_tv_value04)).setText(legend04);
        ((TextView) this.f15v.findViewById(C0213R.id.stats_chart04_tv_value03)).setText(legend03);
        PIChart piChart = (PIChart) this.f15v.findViewById(C0213R.id.stats_chart_04);
        piChart.reset();
        piChart.setShowText(false);
        piChart.setForm(TypedValue.applyDimension(2, 3.0f, getResources().getDisplayMetrics()), 0.0f, BubbleChartData.DEFAULT_BUBBLE_SCALE);
        if (percent1 > 0.0f) {
            piChart.addItem("item01", percent1, -6504352);
            this.mChartData.setChart04_color01("#9cc060");
        } else {
            this.mChartData.setChart04_color01("#9cc060");
        }
        if (percent2 > 0.0f) {
            piChart.addItem("item02", percent2, -1352105);
            this.mChartData.setChart04_color02("#eb5e57");
        } else {
            this.mChartData.setChart04_color02("#eb5e57");
        }
        if (percent3 > 0.0f) {
            piChart.addItem("item03", percent3, -526345);
            this.mChartData.setChart04_color03("#f7f7f7");
        } else {
            this.mChartData.setChart04_color03("#cbcbcb");
        }
        if (percent5 > 0.0f) {
            piChart.addItem("item05", percent5, -1334185);
            this.mChartData.setChart04_color04("#eba457");
        } else {
            this.mChartData.setChart04_color04("#eba457");
        }
        if (percent4 == 100.0f) {
            piChart.addItem("item04", percent4, -3421237);
            this.mChartData.setChart04_color03("#cbcbcb");
        }
        piChart.generate(false);
        int web_count01 = count1;
        int web_count02 = count2;
        int web_count03 = count3;
        float web_percent01 = percent1;
        float web_percent02 = percent2;
        float web_percent03 = percent3;
        if (web_count01 != 0 && web_count02 == 0 && web_count03 == 0) {
            web_percent01 = 99.8f;
            web_percent02 = 0.1f;
            web_percent03 = 0.1f;
        } else if (web_count01 == 0 && web_count02 != 0 && web_count03 == 0) {
            web_percent01 = 0.1f;
            web_percent02 = 99.8f;
            web_percent03 = 0.1f;
        } else if (web_count01 == 0 && web_count02 == 0 && web_count03 != 0) {
            web_percent01 = 0.1f;
            web_percent02 = 0.1f;
            web_percent03 = 99.8f;
        } else if (web_count01 == 0 && web_count02 == 0 && web_count03 == 0) {
            web_percent01 = 0.1f;
            web_percent02 = 0.1f;
            web_percent03 = 99.8f;
        }
        this.mChartData.setChart04_count01(String.valueOf(web_count01));
        this.mChartData.setChart04_count02(String.valueOf(web_count02));
        this.mChartData.setChart04_count03(String.valueOf(web_count03));
        this.mChartData.setChart04_percent01(String.valueOf(web_percent01));
        this.mChartData.setChart04_percent02(String.valueOf(web_percent02));
        this.mChartData.setChart04_percent03(String.valueOf(web_percent03));
    }

    private String getBsValue(int value) {
        String strValue = String.valueOf(((double) value) / 18.01d);
        String[] strArray = strValue.split("\\.");
        if (strArray.length != 2 || strArray[1].length() <= 1) {
            return strValue;
        }
        return strArray[0] + "." + strArray[1].substring(0, 1);
    }

    public int getYear() {
        return Integer.parseInt(new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime()));
    }

    public int getMonth() {
        return Integer.parseInt(new SimpleDateFormat("MM").format(Calendar.getInstance().getTime()));
    }

    public int getDay() {
        return Integer.parseInt(new SimpleDateFormat("dd").format(Calendar.getInstance().getTime()));
    }

    public String conversionStrDateTimeFormat(String date) {
        String rdate = "";
        if (date == null) {
            return rdate;
        }
        return date.replaceAll("-", "").replaceAll(":", "").replaceAll("\\.", "").replaceAll("\\p{Space}", "");
    }

    public String convertDateValue(int value) {
        if (value > 9) {
            return String.valueOf(value);
        }
        return String.valueOf(addZero(value));
    }

    public String addZero(int value) {
        if (value < 10) {
            return "0" + String.valueOf(value);
        }
        return String.valueOf(value);
    }

    public Integer[] getCalendar(int type, int year, int month, int date, int value) {
        Calendar cal = Calendar.getInstance();
        if (type == 1) {
            cal.set(year, (month - 1) + value, date);
        } else if (type == 0) {
            cal.set(year, month - 1, date + value);
        }
        SimpleDateFormat f1 = new SimpleDateFormat("yyyy");
        SimpleDateFormat f2 = new SimpleDateFormat("MM");
        SimpleDateFormat f3 = new SimpleDateFormat("dd");
        year = Integer.parseInt(f1.format(cal.getTime()));
        month = Integer.parseInt(f2.format(cal.getTime()));
        date = Integer.parseInt(f3.format(cal.getTime()));
        return new Integer[]{Integer.valueOf(year), Integer.valueOf(month), Integer.valueOf(date)};
    }

    public int getDay(String strDate) {
        strDate = conversionStrDateTimeFormat(strDate);
        Calendar cal = Calendar.getInstance();
        int year = Integer.parseInt(strDate.substring(0, 4));
        int month = Integer.parseInt(strDate.substring(4, 6));
        int date = Integer.parseInt(strDate.substring(6, 8));
        cal.set(1, year);
        cal.set(2, month - 1);
        cal.set(5, date);
        return cal.get(7);
    }

    public String getStrDay(String strDate) {
        Calendar cal = Calendar.getInstance();
        int year = Integer.parseInt(strDate.substring(0, 4));
        int month = Integer.parseInt(strDate.substring(4, 6));
        int date = Integer.parseInt(strDate.substring(6));
        cal.set(1, year);
        cal.set(2, month - 1);
        cal.set(5, date);
        String day = "";
        switch (cal.get(7)) {
            case 1:
                return getString(C0213R.string.html_sunday);
            case 2:
                return getString(C0213R.string.html_monday);
            case 3:
                return getString(C0213R.string.html_tuesday);
            case 4:
                return getString(C0213R.string.html_wednesday);
            case 5:
                return getString(C0213R.string.html_thursday);
            case 6:
                return getString(C0213R.string.html_friday);
            case 7:
                return getString(C0213R.string.html_saturday);
            default:
                return day;
        }
    }

    public String getInsulinName(String no) {
        String return_value = "";
        switch (Integer.parseInt(no)) {
            case 0:
                return getString(C0213R.string.insulin_name_novorapid);
            case 1:
                return getString(C0213R.string.insulin_name_apidra);
            case 2:
                return getString(C0213R.string.insulin_name_humalog);
            case 3:
                return getString(C0213R.string.insulin_name_humulin_r);
            case 4:
                return getString(C0213R.string.insulin_name_novorin_r);
            case 5:
                return getString(C0213R.string.insulin_name_insulatard);
            case 6:
                return getString(C0213R.string.insulin_name_lantus);
            case 7:
                return getString(C0213R.string.insulin_name_levemir);
            case 8:
                return getString(C0213R.string.insulin_name_novomix_30);
            case 9:
                return getString(C0213R.string.insulin_name_novomix_50);
            case 10:
                return getString(C0213R.string.insulin_name_novomix_70);
            case 11:
                return getString(C0213R.string.insulin_name_mixtard);
            case 12:
                return getString(C0213R.string.insulin_name_humulin_30);
            case 13:
                return getString(C0213R.string.insulin_name_humulin_70);
            case 14:
                return getString(C0213R.string.insulin_name_humalogmix_25);
            case 15:
                return getString(C0213R.string.insulin_name_humalogmix_50);
            default:
                return return_value;
        }
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.statsFragmentListener = (StatsFragmentListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + "let's implement StatsFragment");
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        this.logCat.log(className, "onSaveInstanceState", "in");
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == 1) {
            this.mBottomDivider.setVisibility(0);
            this.mLLBottomLayout.setVisibility(0);
        } else if (newConfig.orientation == 2) {
            this.mBottomDivider.setVisibility(8);
            this.mLLBottomLayout.setVisibility(8);
        }
    }
}
