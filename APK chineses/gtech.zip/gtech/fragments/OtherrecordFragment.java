package com.accumed.gtech.fragments;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.ScrollView;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.ThrAddOtherrecord;
import com.accumed.gtech.thread.ThrDelOtherrecord;
import com.accumed.gtech.thread.ThrModOtherrecord;
import com.accumed.gtech.thread.datamodel.OtherrecordThrDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.util.Util;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class OtherrecordFragment extends Fragment {
    public static int DELETE = 2;
    public static int INPUT = 0;
    public static int UPDATE = 1;
    int PAGE_NUM;
    String SEQ;
    final String className = "OtherrecordFragment";
    private OnDateSetListener datePickerListener = new C02833();
    LogCat logCat;
    int mAppStatus;
    String mBloodpressure = "";
    String mBmi = "";
    Context mContext;
    private int mDate;
    String mEmail = "";
    String mHba1c1 = "";
    String mHba1cunit = "";
    String mHdl = "";
    String mInput_date = "";
    String mLdl = "";
    private int mMonth;
    String mOdate = "";
    String mSeq = "";
    String mSystem_date = "";
    String mTc = "";
    String mTg = "";
    String mUpdate_flag = "";
    String mWaist = "";
    String mWaistunit = "";
    String mWeight = "";
    private int mYear;
    String m_id = "";
    OnOtherrecordListener onOtherrecordListener;
    OtherrecordThrDM otherrecordThrDM;
    Button otherrecord_btn_complete;
    EditText otherrecord_edit_02;
    EditText otherrecord_edit_03;
    EditText otherrecord_edit_04;
    EditText otherrecord_edit_05;
    EditText otherrecord_edit_06_01;
    EditText otherrecord_edit_06_02;
    EditText otherrecord_edit_07;
    EditText otherrecord_edit_08;
    EditText otherrecord_edit_09;
    EditText otherrecord_edit_10;
    RadioButton otherrecord_rbtn_01;
    RadioButton otherrecord_rbtn_02;
    RadioButton otherrecord_rbtn_03;
    RadioButton otherrecord_rbtn_04;
    RadioGroup otherrecord_rbtn_group0;
    RadioGroup otherrecord_rbtn_group1;
    TextView otherrecord_tv_01;
    TextView otherrecord_tv_unit_02;
    TextView otherrecord_tv_unit_03;
    TextView otherrecord_tv_unit_04;
    TextView otherrecord_tv_unit_05;
    TextView otherrecord_tv_unit_06;
    TextView otherrecord_tv_unit_07;
    TextView otherrecord_tv_unit_08;
    TextView otherrecord_tv_unit_09;
    TextView otherrecord_tv_unit_10;
    ScrollView scrollView1;
    Util util;

    public interface OnOtherrecordListener {
        void onAddData();

        void onAddDataSend(Object obj, OtherrecordThrDM otherrecordThrDM);

        void onDelData();

        void onDelDataSend(Object obj, OtherrecordThrDM otherrecordThrDM);

        void onRestartAfterDelete();

        void onRestartAfterInput();

        void onRestartAfterUpdate();

        void onUpdateData();

        void onUpdateDataSend(Object obj, OtherrecordThrDM otherrecordThrDM);
    }

    class C02811 implements OnTouchListener {
        C02811() {
        }

        public boolean onTouch(View arg0, MotionEvent arg1) {
            ((InputMethodManager) OtherrecordFragment.this.mContext.getSystemService("input_method")).hideSoftInputFromWindow(OtherrecordFragment.this.otherrecord_tv_01.getWindowToken(), 0);
            return false;
        }
    }

    class C02822 implements OnClickListener {
        C02822() {
        }

        public void onClick(View v) {
            OtherrecordFragment.this.showBirthDayPicker();
        }
    }

    class C02833 implements OnDateSetListener {
        C02833() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            OtherrecordFragment.this.mYear = year;
            OtherrecordFragment.this.mMonth = monthOfYear + 1;
            OtherrecordFragment.this.mDate = dayOfMonth;
            OtherrecordFragment.this.mOdate = OtherrecordFragment.this.util.convertDateValue(OtherrecordFragment.this.mYear) + "." + OtherrecordFragment.this.util.convertDateValue(OtherrecordFragment.this.mMonth) + "." + OtherrecordFragment.this.util.convertDateValue(OtherrecordFragment.this.mDate);
            OtherrecordFragment.this.otherrecord_tv_01.setText(OtherrecordFragment.this.mOdate);
        }
    }

    class RadioChangeListener implements OnCheckedChangeListener {
        RadioChangeListener() {
        }

        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == C0213R.id.otherrecord_rbtn_01) {
                OtherrecordFragment.this.mWaistunit = "cm";
                OtherrecordFragment.this.logCat.log("OtherrecordFragment", "mWaistunit", OtherrecordFragment.this.mWaistunit);
            }
            if (checkedId == C0213R.id.otherrecord_rbtn_02) {
                OtherrecordFragment.this.mWaistunit = "inch";
                OtherrecordFragment.this.logCat.log("OtherrecordFragment", "mWaistunit", OtherrecordFragment.this.mWaistunit);
            }
            if (checkedId == C0213R.id.otherrecord_rbtn_03) {
                OtherrecordFragment.this.mHba1cunit = "%";
            }
            if (checkedId == C0213R.id.otherrecord_rbtn_04) {
                OtherrecordFragment.this.mHba1cunit = "mmol/mol";
            }
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (container == null) {
            return null;
        }
        this.util = new Util();
        View v = inflater.inflate(C0213R.layout.otherrecord_fragment, container, false);
        this.mContext = getActivity();
        this.logCat = new LogCat();
        this.otherrecordThrDM = new OtherrecordThrDM();
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        this.otherrecord_rbtn_group0 = (RadioGroup) v.findViewById(C0213R.id.otherrecord_rbtn_group0);
        this.otherrecord_rbtn_group1 = (RadioGroup) v.findViewById(C0213R.id.otherrecord_rbtn_group1);
        this.otherrecord_rbtn_group0.setOnCheckedChangeListener(new RadioChangeListener());
        this.otherrecord_rbtn_group1.setOnCheckedChangeListener(new RadioChangeListener());
        this.otherrecord_rbtn_01 = (RadioButton) v.findViewById(C0213R.id.otherrecord_rbtn_01);
        this.otherrecord_rbtn_02 = (RadioButton) v.findViewById(C0213R.id.otherrecord_rbtn_02);
        this.otherrecord_rbtn_03 = (RadioButton) v.findViewById(C0213R.id.otherrecord_rbtn_03);
        this.otherrecord_rbtn_04 = (RadioButton) v.findViewById(C0213R.id.otherrecord_rbtn_04);
        this.otherrecord_tv_01 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_01);
        this.otherrecord_edit_02 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_02);
        this.otherrecord_edit_03 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_03);
        this.otherrecord_edit_04 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_04);
        this.otherrecord_edit_05 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_05);
        this.otherrecord_edit_06_01 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_06_01);
        this.otherrecord_edit_06_02 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_06_02);
        this.otherrecord_edit_07 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_07);
        this.otherrecord_edit_08 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_08);
        this.otherrecord_edit_09 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_09);
        this.otherrecord_edit_10 = (EditText) v.findViewById(C0213R.id.otherrecord_edit_10);
        this.otherrecord_tv_unit_02 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_02);
        this.otherrecord_tv_unit_03 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_03);
        this.otherrecord_tv_unit_04 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_04);
        this.otherrecord_tv_unit_05 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_05);
        this.otherrecord_tv_unit_06 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_06);
        this.otherrecord_tv_unit_07 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_07);
        this.otherrecord_tv_unit_08 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_08);
        this.otherrecord_tv_unit_09 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_09);
        this.otherrecord_tv_unit_10 = (TextView) v.findViewById(C0213R.id.otherrecord_tv_unit_10);
        this.scrollView1 = (ScrollView) v.findViewById(C0213R.id.scrollView1);
        this.scrollView1.setOnTouchListener(new C02811());
        this.mWaistunit = "cm";
        this.mHba1cunit = "%";
        this.otherrecord_rbtn_01.setChecked(true);
        this.otherrecord_rbtn_03.setChecked(true);
        this.otherrecord_tv_01.setOnClickListener(new C02822());
        this.otherrecordThrDM = new DBAction(this.mContext).otherrecordOneSelect(this.SEQ);
        this.logCat.log("OtherrecordFragment", "Page_num", this.PAGE_NUM + "");
        this.logCat.log("OtherrecordFragment", "otherrecordThrDM.odate", this.otherrecordThrDM.odate);
        this.otherrecord_tv_01.setText(this.otherrecordThrDM.odate);
        this.otherrecord_edit_02.setText(this.otherrecordThrDM.weight);
        this.otherrecord_edit_03.setText(this.otherrecordThrDM.bmi);
        this.otherrecord_edit_04.setText(this.otherrecordThrDM.waist);
        if (this.otherrecordThrDM.waistunit.equals("cm")) {
            this.otherrecord_rbtn_01.setChecked(true);
            this.otherrecord_rbtn_02.setChecked(false);
        } else if (this.otherrecordThrDM.waistunit.equals("inch")) {
            this.otherrecord_rbtn_01.setChecked(false);
            this.otherrecord_rbtn_02.setChecked(true);
        }
        this.otherrecord_edit_05.setText(this.otherrecordThrDM.hba1c);
        if (this.otherrecordThrDM.hba1cunit.equals("%")) {
            this.otherrecord_rbtn_03.setChecked(true);
            this.otherrecord_rbtn_04.setChecked(false);
        } else if (this.otherrecordThrDM.hba1cunit.equals("mmol/mol")) {
            this.otherrecord_rbtn_03.setChecked(false);
            this.otherrecord_rbtn_04.setChecked(true);
        }
        try {
            this.otherrecord_edit_06_01.setText(this.otherrecordThrDM.bloodpressure.split("/")[0]);
            this.otherrecord_edit_06_02.setText(this.otherrecordThrDM.bloodpressure.split("/")[1]);
        } catch (Exception e) {
            this.otherrecord_edit_06_01.setText("");
            this.otherrecord_edit_06_02.setText("");
        }
        this.otherrecord_edit_07.setText(this.otherrecordThrDM.tc);
        this.otherrecord_edit_08.setText(this.otherrecordThrDM.tg);
        this.otherrecord_edit_09.setText(this.otherrecordThrDM.hdl);
        this.otherrecord_edit_10.setText(this.otherrecordThrDM.ldl);
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        this.otherrecord_tv_unit_02.setText(pref.getString(PreferenceAction.MY_WEIGHT_UNIT));
        this.otherrecord_tv_unit_03.setText(getString(C0213R.string.unit_kgm));
        this.otherrecord_tv_unit_04.setText("");
        this.otherrecord_tv_unit_05.setText("");
        this.otherrecord_tv_unit_06.setText(getString(C0213R.string.unit_mmhg));
        this.otherrecord_tv_unit_07.setText(pref.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT));
        this.otherrecord_tv_unit_08.setText(pref.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT));
        this.otherrecord_tv_unit_09.setText(pref.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT));
        this.otherrecord_tv_unit_10.setText(pref.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT));
        return v;
    }

    public void setPageNum(int pageNum) {
        this.PAGE_NUM = pageNum;
    }

    public void setSeq(String seq) {
        this.SEQ = seq;
    }

    String kg_cm_To_ft_lb(String val) {
        String kg_Str = this.otherrecord_edit_02.getText().toString().trim();
        return "";
    }

    double roundOff(double num, int point) {
        return Math.floor((Math.pow(10.0d, (double) point) * num) + 0.5d) / Math.pow(10.0d, (double) point);
    }

    private void inputDB() {
        this.logCat.log("OtherrecordFragment", "inputDB()--", "in");
        if (this.otherrecord_tv_01.getText().toString().equals("")) {
            new ShowAlert(this.mContext).alert0(getString(C0213R.string.alert_title), getString(C0213R.string.alert_type13), getString(C0213R.string.btn_ok));
            return;
        }
        DBAction dbAction = new DBAction(this.mContext);
        dbAction.insertOtherrecord(makeDM(INPUT));
        dbAction.otherrecordSelect();
        this.onOtherrecordListener.onAddData();
    }

    private void updateDB() {
        DBAction dbAction = new DBAction(this.mContext);
        dbAction.updateOtherrecord(makeDM(UPDATE));
        dbAction.otherrecordSelect();
        this.onOtherrecordListener.onUpdateData();
    }

    private void deleteDB() {
        DBAction dbAction = new DBAction(this.mContext);
        dbAction.delOtherrecord(makeDM(UPDATE).seq);
        dbAction.otherrecordSelect();
        this.onOtherrecordListener.onDelData();
    }

    private OtherrecordThrDM makeDM(int gubun) {
        OtherrecordThrDM dm = new OtherrecordThrDM();
        dm.email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        dm.odate = this.otherrecord_tv_01.getText().toString().trim();
        dm.weight = this.otherrecord_edit_02.getText().toString().trim();
        dm.bmi = this.otherrecord_edit_03.getText().toString().trim();
        dm.waist = this.otherrecord_edit_04.getText().toString().trim();
        dm.waistunit = this.mWaistunit;
        dm.hba1c = this.otherrecord_edit_05.getText().toString().trim();
        dm.hba1cunit = this.mHba1cunit;
        dm.bloodpressure = this.otherrecord_edit_06_01.getText().toString().trim() + "/" + this.otherrecord_edit_06_02.getText().toString().trim();
        dm.tc = this.otherrecord_edit_07.getText().toString().trim();
        dm.tg = this.otherrecord_edit_08.getText().toString().trim();
        dm.hdl = this.otherrecord_edit_09.getText().toString().trim();
        dm.ldl = this.otherrecord_edit_10.getText().toString().trim();
        if (gubun == INPUT) {
            Calendar c = Calendar.getInstance();
            dm.input_date = Integer.toString(c.get(1)) + Integer.toString(c.get(2)) + Integer.toString(c.get(5)) + Integer.toString(c.get(10)) + Integer.toString(c.get(12));
            dm.system_date = new SimpleDateFormat("yyyyMMddHHmmss").format(Long.valueOf(System.currentTimeMillis()));
            dm.update_flag = "insert";
        } else if (gubun == UPDATE) {
            dm.seq = this.otherrecordThrDM.seq;
            dm._id = this.otherrecordThrDM._id;
            dm.update_flag = "update";
        } else if (gubun == DELETE) {
            dm._id = this.otherrecordThrDM._id;
            dm.email = this.otherrecordThrDM.email;
        }
        return dm;
    }

    private void showBirthDayPicker() {
        if (this.mYear == 0) {
            this.mYear = this.util.getYear();
        }
        if (this.mMonth == 0) {
            this.mMonth = this.util.getMonth();
        }
        if (this.mDate == 0) {
            this.mDate = this.util.getDay();
        }
        new DatePickerDialog(this.mContext, this.datePickerListener, this.mYear, this.mMonth - 1, this.mDate).show();
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.onOtherrecordListener = (OnOtherrecordListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + "let's implement OnOtherrecordListener");
        }
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void actionDefine(int gubun) {
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_x");
                return;
            case 1:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == INPUT) {
                    inputDB();
                    this.onOtherrecordListener.onRestartAfterInput();
                }
                if (gubun == UPDATE) {
                    updateDB();
                    this.onOtherrecordListener.onRestartAfterUpdate();
                }
                if (gubun == DELETE) {
                    deleteDB();
                    this.onOtherrecordListener.onRestartAfterDelete();
                    return;
                }
                return;
            case 5:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == INPUT) {
                    inputDB();
                    this.onOtherrecordListener.onRestartAfterInput();
                }
                if (gubun == UPDATE) {
                    updateDB();
                    this.onOtherrecordListener.onRestartAfterUpdate();
                }
                if (gubun == DELETE) {
                    deleteDB();
                    this.onOtherrecordListener.onRestartAfterDelete();
                    return;
                }
                return;
            case 10:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == INPUT) {
                    inputDB();
                    this.onOtherrecordListener.onRestartAfterInput();
                }
                if (gubun == UPDATE) {
                    updateDB();
                    this.onOtherrecordListener.onRestartAfterUpdate();
                }
                if (gubun == DELETE) {
                    deleteDB();
                    this.onOtherrecordListener.onRestartAfterDelete();
                    return;
                }
                return;
            case 14:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == INPUT) {
                    inputDB();
                    this.onOtherrecordListener.onRestartAfterInput();
                }
                if (gubun == UPDATE) {
                    updateDB();
                    this.onOtherrecordListener.onRestartAfterUpdate();
                }
                if (gubun == DELETE) {
                    deleteDB();
                    this.onOtherrecordListener.onRestartAfterDelete();
                    return;
                }
                return;
            case 17:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == INPUT) {
                    inputDB();
                    this.onOtherrecordListener.onRestartAfterInput();
                }
                if (gubun == UPDATE) {
                    updateDB();
                    this.onOtherrecordListener.onRestartAfterUpdate();
                }
                if (gubun == DELETE) {
                    deleteDB();
                    this.onOtherrecordListener.onRestartAfterDelete();
                    return;
                }
                return;
            case 21:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == INPUT) {
                    inputDB();
                    this.onOtherrecordListener.onRestartAfterInput();
                }
                if (gubun == UPDATE) {
                    updateDB();
                    this.onOtherrecordListener.onRestartAfterUpdate();
                }
                if (gubun == DELETE) {
                    deleteDB();
                    this.onOtherrecordListener.onRestartAfterDelete();
                    return;
                }
                return;
            case 26:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == INPUT) {
                    inputDB();
                    this.onOtherrecordListener.onRestartAfterInput();
                }
                if (gubun == UPDATE) {
                    updateDB();
                    this.onOtherrecordListener.onRestartAfterUpdate();
                }
                if (gubun == DELETE) {
                    deleteDB();
                    this.onOtherrecordListener.onRestartAfterDelete();
                    return;
                }
                return;
            case 30:
                this.logCat.log("OtherrecordFragment", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == INPUT) {
                    inputDB();
                    new ThrAddOtherrecord(this.mContext, makeDM(INPUT), this.onOtherrecordListener).start();
                }
                if (gubun == UPDATE) {
                    updateDB();
                    new ThrModOtherrecord(this.mContext, makeDM(UPDATE), this.onOtherrecordListener).start();
                }
                if (gubun == DELETE) {
                    deleteDB();
                    new ThrDelOtherrecord(this.mContext, makeDM(DELETE), this.onOtherrecordListener).start();
                    return;
                }
                return;
            default:
                return;
        }
    }
}
