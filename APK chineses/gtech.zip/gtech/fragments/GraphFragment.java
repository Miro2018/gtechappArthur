package com.accumed.gtech.fragments;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.customview.CustomComboLineColumnChartView;
import com.accumed.gtech.fma.android.chart.type.GlucoseItem;
import com.accumed.gtech.fma.android.chart.widget.GlucoseChart;
import com.accumed.gtech.util.LogCat;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import lecho.lib.hellocharts.formatter.SimpleAxisValueFormatter;
import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Column;
import lecho.lib.hellocharts.model.ColumnChartData;
import lecho.lib.hellocharts.model.ComboLineColumnChartData;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.SubcolumnValue;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.util.ChartUtils;

public class GraphFragment extends Fragment {
    public static final long DATE_3DAYS = 259200000;
    public static final long DATE_DAY = 86400000;
    public static final long DATE_MONTH = -1616567296;
    public static final long DATE_WEEK = 604800000;
    private static final long ONE_DAY = 86400000;
    public static final int VIEW_AFTER = 2;
    public static final int VIEW_ALL = 4;
    public static final int VIEW_BEFORE = 1;
    public static final int VIEW_FASTING = 3;
    static final String className = "GraphFragment";
    private GlucoseChart bpChart;
    private Vector<GlucoseItem> chartList = new Vector();
    private int days = 0;
    private Vector<GlucoseItem> filterChartList = new Vector();
    private long firstTimestamp = 0;
    private int flag = 4;
    GraphFragmentListener graphFragmentListener;
    LogCat logCat = new LogCat();
    private CustomComboLineColumnChartView mChart;
    Context mContext;
    private ComboLineColumnChartData mData;
    private Spinner mDateSpinner;
    private long mDateState = 0;
    View mView;
    private Spinner mViewSpinner;
    private int mViewState = 0;

    public interface GraphFragmentListener {
        void checkout_noDataMining_LogList_from_graph();

        void onHideMenu();

        void onShowMenu();
    }

    class C02621 implements OnItemSelectedListener {
        C02621() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            switch (position) {
                case 0:
                    GraphFragment.this.mDateState = 86400000;
                    break;
                case 1:
                    GraphFragment.this.mDateState = GraphFragment.DATE_3DAYS;
                    break;
                case 2:
                    GraphFragment.this.mDateState = 604800000;
                    break;
                case 3:
                    GraphFragment.this.mDateState = GraphFragment.DATE_MONTH;
                    break;
            }
            GraphFragment.this.setFilter();
            GraphFragment.this.generateData();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C02632 implements OnItemSelectedListener {
        C02632() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            switch (position) {
                case 0:
                    GraphFragment.this.mViewState = 4;
                    break;
                case 1:
                    GraphFragment.this.mViewState = 1;
                    break;
                case 2:
                    GraphFragment.this.mViewState = 2;
                    break;
                case 3:
                    GraphFragment.this.mViewState = 3;
                    break;
            }
            GraphFragment.this.setFilter();
            GraphFragment.this.generateData();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    private static class InsulinValueFormatter extends SimpleAxisValueFormatter {
        private int decimalDigits;
        BigDecimal mScale;
        BigDecimal mSub;
        BigDecimal mValue;

        public InsulinValueFormatter(float scale, float sub, int decimalDigits) {
            this.mScale = new BigDecimal(String.valueOf(scale));
            this.mSub = new BigDecimal(String.valueOf(sub));
            this.decimalDigits = decimalDigits;
        }

        public int formatValueForAutoGeneratedAxis(char[] formattedValue, float value, int autoDecimalDigits) {
            this.mValue = new BigDecimal(String.valueOf(value));
            return super.formatValueForAutoGeneratedAxis(formattedValue, this.mValue.multiply(this.mScale).setScale(1, 1).floatValue(), this.decimalDigits);
        }
    }

    class ItemComparator implements Comparator<GlucoseItem> {
        ItemComparator() {
        }

        public int compare(GlucoseItem arg0, GlucoseItem arg1) {
            return arg0.timestamp > arg1.timestamp ? 1 : -1;
        }
    }

    public void onResume() {
        super.onResume();
        init();
    }

    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0213R.layout.graph_fragment, null);
        this.mView = v;
        this.mContext = getActivity();
        this.logCat = new LogCat();
        this.mDateSpinner = (Spinner) this.mView.findViewById(C0213R.id.sp_graph_date);
        this.mViewSpinner = (Spinner) this.mView.findViewById(C0213R.id.sp_graph_view);
        this.mChart = (CustomComboLineColumnChartView) v.findViewById(C0213R.id.chart);
        this.mChart.setZoomType(ZoomType.HORIZONTAL);
        this.mChart.setZoomEnabled(true);
        String[] dateArrayString = getResources().getStringArray(C0213R.array.graph_date_array);
        String[] viewArrayString = getResources().getStringArray(C0213R.array.graph_view_array);
        ArrayAdapter<String> mDateSpinnerAdapter = new ArrayAdapter(this.mContext, 17367049, dateArrayString);
        ArrayAdapter<String> mViewSpinnerAdapter = new ArrayAdapter(this.mContext, 17367049, viewArrayString);
        this.mDateSpinner.setAdapter(mDateSpinnerAdapter);
        this.mDateSpinner.setSelection(1);
        this.mDateSpinner.setOnItemSelectedListener(new C02621());
        this.mViewSpinner.setAdapter(mViewSpinnerAdapter);
        this.mViewSpinner.setSelection(0);
        this.mViewSpinner.setOnItemSelectedListener(new C02632());
        return v;
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    private void init() {
        this.graphFragmentListener.checkout_noDataMining_LogList_from_graph();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.graphFragmentListener = (GraphFragmentListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + "let's implement GraphFragmentListener");
        }
    }

    private void setPortraitView() {
        this.graphFragmentListener.onShowMenu();
        this.graphFragmentListener.checkout_noDataMining_LogList_from_graph();
    }

    private void setLandscapeView() {
        this.graphFragmentListener.onHideMenu();
        this.graphFragmentListener.checkout_noDataMining_LogList_from_graph();
    }

    public void setGraph(Vector<GlucoseItem> list) {
        this.chartList = list;
        setFilter();
    }

    private void generateData() {
        BigDecimal mAxisValueCount;
        List lines = new ArrayList();
        List columns = new ArrayList();
        List axisValues = new ArrayList();
        List<PointValue> values = new ArrayList();
        float scale = 80.0f / 600.0f;
        float sub = (10.0f * scale) / PullToRefreshBase.DEFAULT_FRICTION;
        BigDecimal bigDecimal = new BigDecimal(String.valueOf(0));
        BigDecimal AddNum = new BigDecimal(String.valueOf(1));
        String mBottomDate = "0";
        for (int i = 0; i < this.filterChartList.size(); i++) {
            int insulin_color;
            float insulin_value;
            axisValues.add(new AxisValue((float) mAxisValueCount.intValue()).setLabel(new SimpleDateFormat("MM/dd HH:mm").format(new Date(((GlucoseItem) this.filterChartList.get(i)).timestamp))));
            mBottomDate = String.valueOf(((GlucoseItem) this.filterChartList.get(i)).timestamp);
            if (((GlucoseItem) this.filterChartList.get(i)).glucose > 0.0f) {
                if (((GlucoseItem) this.filterChartList.get(i)).glucose > 600.0f) {
                    values.add(new PointValue((float) mAxisValueCount.intValue(), 600.0f));
                } else {
                    values.add(new PointValue((float) mAxisValueCount.intValue(), ((GlucoseItem) this.filterChartList.get(i)).glucose));
                }
            }
            List columnValues = new ArrayList();
            switch (((GlucoseItem) this.filterChartList.get(i)).instype) {
                case 1:
                    insulin_color = getResources().getColor(C0213R.color.insulin_rapid_color);
                    break;
                case 2:
                    insulin_color = getResources().getColor(C0213R.color.insulin_short_color);
                    break;
                case 3:
                    insulin_color = getResources().getColor(C0213R.color.insulin_nph_color);
                    break;
                case 4:
                    insulin_color = getResources().getColor(C0213R.color.insulin_long_color);
                    break;
                default:
                    insulin_color = getResources().getColor(C0213R.color.insulin_mix_color);
                    break;
            }
            bigDecimal = new BigDecimal(String.valueOf(scale));
            if (((GlucoseItem) this.filterChartList.get(i)).insulin > 80.0f) {
                insulin_value = 80.0f;
            } else {
                insulin_value = ((GlucoseItem) this.filterChartList.get(i)).insulin;
            }
            SubcolumnValue subcolumnValue = new SubcolumnValue(new BigDecimal(String.valueOf(insulin_value)).divide(bigDecimal, 2, 4).floatValue(), insulin_color);
            subcolumnValue.setTarget((float) mAxisValueCount.intValue());
            subcolumnValue.setLabel(String.valueOf(((GlucoseItem) this.filterChartList.get(i)).insulin));
            columnValues.add(subcolumnValue);
            columns.add(mAxisValueCount.intValue(), new Column(columnValues).setHasLabels(true).setHasLabelsOnlyForSelected(true));
            mAxisValueCount = mAxisValueCount.add(AddNum);
        }
        Line line = new Line((List) values);
        line.setColor(ChartUtils.COLOR_GREEN);
        line.setPointColor(ChartUtils.COLOR_GREEN);
        line.setCubic(false);
        line.setHasLabelsOnlyForSelected(true);
        line.setHasLines(true);
        line.setHasPoints(true);
        lines.add(line);
        ColumnChartData columnChartData = new ColumnChartData(columns);
        columnChartData.setValueLabelBackgroundEnabled(true);
        columnChartData.setValueLabelTextSize(20);
        columnChartData.setValueLabelsTextColor(getResources().getColor(C0213R.color.public_color_white));
        this.mData = new ComboLineColumnChartData(columnChartData, new LineChartData(lines));
        Axis axisX = new Axis(axisValues).setTextColor(getResources().getColor(C0213R.color.public_color_black)).setTextSize(10).setMaxLabelChars(8);
        Axis axisY = new Axis().setHasLines(true).setMaxLabelChars(3).setTextColor(getResources().getColor(C0213R.color.public_color_black));
        this.mData.setAxisXBottom(axisX);
        this.mData.setAxisYLeft(axisY);
        this.mData.setAxisYRight(new Axis().setName("Insulin").setMaxLabelChars(3).setFormatter(new InsulinValueFormatter(scale, sub, 0)).setTextColor(getResources().getColor(C0213R.color.public_color_black)));
        this.mChart.setViewportCalculationEnabled(false);
        this.mChart.setValueSelectionEnabled(true);
        this.mChart.setComboLineColumnChartData(this.mData);
        this.mChart.setZoomType(ZoomType.HORIZONTAL);
        this.mChart.setZoomEnabled(true);
        Viewport viewport = new Viewport(this.mChart.getMaximumViewport());
        viewport.left = -0.5f;
        viewport.top = 600.0f;
        viewport.right = mAxisValueCount.floatValue();
        viewport.bottom = 0.0f;
        this.mChart.setMaximumViewport(viewport);
        Viewport currentViewport = new Viewport(-1.5f, 600.0f, mAxisValueCount.add(AddNum).floatValue() - ClassConstant.INPUT_GLUCOSE_MMOL_MIN, 0.0f);
        this.mChart.setMaximumViewport(currentViewport);
        this.mChart.setCurrentViewport(currentViewport);
        this.mChart.invalidate();
    }

    public void setItems() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
            Iterator it = this.chartList.iterator();
            while (it.hasNext()) {
                GlucoseItem item = (GlucoseItem) it.next();
                item.timestamp = sdf.parse(item.date + item.time).getTime();
            }
            Collections.sort(this.chartList, new ItemComparator());
        } catch (Exception e) {
        }
    }

    private void setFilter() {
        try {
            this.filterChartList.clear();
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
            SimpleDateFormat mmddf = new SimpleDateFormat("yyyyMMdd");
            if (this.mDateState == 86400000) {
                cal.add(5, -1);
            } else if (this.mDateState == DATE_3DAYS) {
                cal.add(5, -3);
            } else if (this.mDateState == 604800000) {
                cal.add(5, -7);
            } else if (this.mDateState == DATE_MONTH) {
                cal.add(2, -1);
            }
            long cal_date = mmddf.parse(new SimpleDateFormat("yyyyMMdd").format(cal.getTime())).getTime();
            Iterator it = this.chartList.iterator();
            while (it.hasNext()) {
                GlucoseItem glucoseItem = (GlucoseItem) it.next();
                glucoseItem.timestamp = sdf.parse(glucoseItem.date + glucoseItem.time).getTime();
                if (cal_date < glucoseItem.timestamp && (this.mViewState == glucoseItem.glutype || this.mViewState == 4)) {
                    this.filterChartList.add(glucoseItem);
                }
            }
            Collections.sort(this.filterChartList, new ItemComparator());
        } catch (Exception e) {
        }
    }
}
