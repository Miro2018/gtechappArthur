package com.accumed.gtech;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.NfcF;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.accumed.gtech.adapter.OnModiDelLogListener;
import com.accumed.gtech.customview.RoundProgressBar;
import com.accumed.gtech.datamining.DataMiningInputLog;
import com.accumed.gtech.datamining.DataMiningProgressListener;
import com.accumed.gtech.datamining.DataMiningSelectLog;
import com.accumed.gtech.datamodel.DeviceDM;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.fma.android.chart.type.GlucoseItem;
import com.accumed.gtech.fragments.GraphFragment;
import com.accumed.gtech.fragments.GraphFragment.GraphFragmentListener;
import com.accumed.gtech.fragments.LogListFragment;
import com.accumed.gtech.fragments.LogListFragment.LogListFragmentListener;
import com.accumed.gtech.fragments.MoreFragment;
import com.accumed.gtech.fragments.MoreFragment.MoreFragmentListener;
import com.accumed.gtech.fragments.StatsFragment;
import com.accumed.gtech.fragments.StatsFragment.StatsFragmentListener;
import com.accumed.gtech.gcm.GCMManager;
import com.accumed.gtech.glucose.DataTransActivity;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.input.InputComment;
import com.accumed.gtech.input.InputGlucose;
import com.accumed.gtech.input.InputInsulin;
import com.accumed.gtech.input.InputNote;
import com.accumed.gtech.input.ModifyComment;
import com.accumed.gtech.input.ModifyGlucose;
import com.accumed.gtech.input.ModifyInsulin;
import com.accumed.gtech.input.ModifyNote;
import com.accumed.gtech.intro.Agreement;
import com.accumed.gtech.intro.Login;
import com.accumed.gtech.intro.SplashRoute;
import com.accumed.gtech.nfc.NfcUtils;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.settings.Profile;
import com.accumed.gtech.settings.Setting;
import com.accumed.gtech.thread.OnDelDataServerListener;
import com.accumed.gtech.thread.OnFriendMapListener;
import com.accumed.gtech.thread.OnLoginListener;
import com.accumed.gtech.thread.OnModGlucoseListener;
import com.accumed.gtech.thread.OnSyncListener;
import com.accumed.gtech.thread.OnSyncTimlineListener;
import com.accumed.gtech.thread.OnTimeLineLimitListener;
import com.accumed.gtech.thread.OnTimeLineListener;
import com.accumed.gtech.thread.SyncAddMod;
import com.accumed.gtech.thread.SyncOnAddModListener;
import com.accumed.gtech.thread.SyncProfileDevice;
import com.accumed.gtech.thread.SyncTimeline;
import com.accumed.gtech.thread.ThrDelData;
import com.accumed.gtech.thread.ThrFriendList;
import com.accumed.gtech.thread.ThrLogin;
import com.accumed.gtech.thread.ThrTimeLine;
import com.accumed.gtech.thread.ThrTimeLineLimit;
import com.accumed.gtech.thread.datamodel.DelDataReturnDM;
import com.accumed.gtech.thread.datamodel.DelDataThrDM;
import com.accumed.gtech.thread.datamodel.FriendListThrDM;
import com.accumed.gtech.thread.datamodel.LoginReturnDM;
import com.accumed.gtech.thread.datamodel.LoginThrDM;
import com.accumed.gtech.thread.datamodel.ModGlucoseDM;
import com.accumed.gtech.thread.datamodel.ModGlucoseReturnDM;
import com.accumed.gtech.thread.datamodel.TimeLineThrDM;
import com.accumed.gtech.thread.datamodel.UserProfileReturnDM;
import com.accumed.gtech.util.Anim;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.GlucoseEvent;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.PreferenceUtil;
import com.accumed.gtech.util.PreferenceUtil.PREF_NAME_MY_DEVICE_TABLE;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.util.Util;
import com.google.android.gcm.GCMRegistrar;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Vector;
import java.util.concurrent.ExecutionException;

@SuppressLint({"SimpleDateFormat", "HandlerLeak", "DefaultLocale"})
public class ContainerFragmentActivity extends FragmentActivity implements LogListFragmentListener, GraphFragmentListener, MoreFragmentListener, StatsFragmentListener, OnModiDelLogListener, OnLoginListener, OnSyncListener, OnDelDataServerListener, OnTimeLineListener, OnTimeLineLimitListener, SyncOnAddModListener, OnSyncTimlineListener, OnFriendMapListener, DataMiningProgressListener, OnModGlucoseListener {
    public static final int ACTION_LOGIN = 0;
    public static final int ACTION_SYNC = 1;
    public static final int FINISH_SETTING = 20;
    public static String FRIEND_EMAIL = new String();
    public static String FRIEND_NAME = new String();
    static final int Failed_calibration_time = 3;
    public static final int GET_FRIEND_TIMELINE = 55;
    public static final int GET_FRIEND_TIMELINE_LIMIT = 56;
    public static final int GET_SYNC_TMELINE_LIMIT = 57;
    public static int GLUCOSE_COUNT = 0;
    public static float GLUCOSE_ONE_VALUE = 0.0f;
    public static final int GRAPH = 1;
    public static final int INPUT_BLUETOOTH = 211;
    public static final int INPUT_COMMENT = 210;
    public static final int INPUT_GLUCOSE = 200;
    public static final int INPUT_INSULIN = 201;
    public static final int INPUT_METHOD_DEVICE = 0;
    public static final int INPUT_NOTE = 202;
    public static final int INPUT_NOTE_UPLOAD = 206;
    public static final int INTRO = 5;
    public static final int JOIN = 11;
    public static final int LOGBOOK = 0;
    public static final int MODIFY_COMMENT = 209;
    public static final int MODIFY_GLUCOSE = 203;
    public static final int MODIFY_INSULIN = 204;
    public static final int MODIFY_NOTE = 205;
    public static final int MORE = 3;
    public static int NOW_SPLASH_STATUS = 0;
    static final int Normal_termination = 5;
    public static final int ON_DEVICE_DATA_DELETE = 58;
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    public static int PROGRESSBAR_AREA_PERCENT = 30;
    static final int Please_contact_again = 2;
    static final int Run_the_measurement = 0;
    public static final int SPLASH = 6;
    public static final int SPLASH_AGREEMENT = 7;
    public static final int SPLASH_LOGIN = 9;
    public static final int SPLASH_PROFILE = 8;
    public static final int SPLASH_SETDIARY = 12;
    public static final int SPLASH_SETTING = 10;
    public static final int STATS = 2;
    public static final int SYNC_ADD_DOD = 1000;
    public static final int TABCHANGE_GRAPH = 1;
    public static final int TABCHANGE_LOGBOOK = 0;
    public static final int TABCHANGE_MORE = 3;
    public static final int TABCHANGE_STATS = 2;
    public static final int USER_BTN = 101;
    public static final int USER_MANAGER = 207;
    public static final int USER_MANAGER_FINISH = 208;
    static final int Unconditional_hide_progressBar = 6;
    static final int Would_you_like_to_register_a_device = 1;
    static final String className = "ContainerFragmentActivity";
    public static ContainerFragmentActivity containerFragmentActivity;
    public static String mAction;
    public static Tag mTag;
    static Bitmap photo;
    int APP_STATUS;
    String DEVICE_ID = new String();
    boolean FLAG_FOLLOW_CONTROL_MEASURE_DATA;
    boolean FLAG_MEASURE;
    int FRIEND_TIMELINE_STARTNUM;
    private int MESSAGE_INPUT = 500;
    boolean NFC_TIME_SET_MODE;
    float SET_PROGRESSBAR_VALUE = 0.0f;
    boolean blockNFC = false;
    LinearLayout bottomSyncLy0;
    TextView bottomSyncTv0;
    RoundProgressBar containerOrangeProgressBar;
    DBAction dbAction;
    AlertDialog deviceRegisterAlert;
    FragmentTransaction fTransaction;
    Vector<Fragment> fragments;
    HashMap<String, String> friendsMap = new HashMap();
    GraphFragment graphFragment;
    final Handler hideH = new C01811();
    ImageView ibtn_user;
    TextView ibtn_user_me;
    LinearLayout inputLy01;
    LinearLayout inputLy02;
    LinearLayout inputLy03;
    LinearLayout inputLy04;
    LinearLayout inputLy05;
    ArrayList<String> lastValuesList;
    Vector<GlucoseItem> listGraphDM;
    ArrayList<LogDM> listLogDM;
    ArrayList<LogDM> listLogDMDynamic;
    LogCat logCat = new LogCat();
    LogListFragment logListFragment;
    TextView logTvSmenu01;
    TextView logTvSmenu02;
    TextView logTvSmenu03;
    TextView logTvSmenu04;
    TextView logTvSmenu05;
    int mAppStatus;
    Context mContext;
    private int mMargin = 0;
    NfcF mNfcf;
    private int mTabMenu = 0;
    Handler mainHandler = new C01872();
    LinearLayout manualInputLinearLy;
    DataMiningInputLog miningInput;
    MoreFragment moreFragment;
    String myEmail;
    TextView name;
    private long nfcAstartTime = 0;
    ProgressBar progressState;
    private int resumeCount = 0;
    ProgressBar roadingProgressBar;
    private long startTime = 0;
    StatsFragment statsFragment;
    public boolean syncAddModTimeline;
    String system_date__device_data_del;
    LinearLayout tabMenu0;
    LinearLayout tabMenu1;
    LinearLayout tabMenu2;
    LinearLayout tabMenu3;
    private long test_Time1;
    private long test_Time2;
    LinearLayout topLinearLy;
    LinearLayout topmenuRelativeLy;
    TextView tvName;
    TextView tvTab01;
    TextView tvTab02;
    TextView tvTab03;
    TextView tvTab04;
    byte[] uid;
    UserProfileSettingData userProfileSettingData;
    Util util;

    class C01811 extends Handler {

        class C01781 implements Runnable {
            C01781() {
            }

            public void run() {
                try {
                    ContainerFragmentActivity.this.containerOrangeProgressBar.setVisibility(8);
                } catch (Exception e) {
                }
                ContainerFragmentActivity.this.FLAG_MEASURE = false;
            }
        }

        C01811() {
        }

        public void handleMessage(Message msg) {
            ContainerFragmentActivity.this.runOnUiThread(new C01781());
        }
    }

    class C01872 extends Handler {

        class C01821 implements OnClickListener {
            C01821() {
            }

            public void onClick(DialogInterface arg0, int arg1) {
                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "failed", "디바이스 등록취소");
                ContainerFragmentActivity.this.FLAG_FOLLOW_CONTROL_MEASURE_DATA = false;
                ContainerFragmentActivity.this.deviceRegisterAlert = null;
            }
        }

        class C01832 implements OnClickListener {
            C01832() {
            }

            public void onClick(DialogInterface arg0, int arg1) {
                DeviceDM deviceDM = new DeviceDM();
                deviceDM.device_id = ContainerFragmentActivity.this.DEVICE_ID;
                deviceDM.update_date = new SimpleDateFormat("yyyyMMddHHmmssmmm").format(Long.valueOf(System.currentTimeMillis()));
                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "deviceDM.device_id", deviceDM.device_id);
                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "deviceDM.update_date", deviceDM.update_date);
                ContainerFragmentActivity.this.FLAG_FOLLOW_CONTROL_MEASURE_DATA = true;
                if (ContainerFragmentActivity.this.dbAction.insertDevice(deviceDM)) {
                    ContainerFragmentActivity.this.appStatus();
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "ok", "디바이스 등록성공");
                    ContainerFragmentActivity.this.deviceRegisterAlert = null;
                    return;
                }
                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "failed", "디바이스 등록실패");
                ContainerFragmentActivity.this.FLAG_FOLLOW_CONTROL_MEASURE_DATA = false;
                ContainerFragmentActivity.this.deviceRegisterAlert = null;
            }
        }

        class C01843 implements Runnable {
            C01843() {
            }

            public void run() {
                ContainerFragmentActivity.this.containerOrangeProgressBar.setProgress(100.0d);
            }
        }

        C01872() {
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "mainHandler", "Run_the_measurement");
                    ContainerFragmentActivity.this.hideProgressBar();
                    return;
                case 1:
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "mainHandler", "Would_you_like_to_register_a_device");
                    ContainerFragmentActivity.this.hideProgressBar();
                    if (ContainerFragmentActivity.this.deviceRegisterAlert == null) {
                        ContainerFragmentActivity.this.deviceRegisterAlert = new Builder(ContainerFragmentActivity.this).setTitle(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_title)).setMessage(ContainerFragmentActivity.this.getString(C0213R.string.nfc_alert400)).setPositiveButton(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_confirm), new C01832()).setNegativeButton(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_cancel), new C01821()).show();
                        return;
                    }
                    return;
                case 2:
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "mainHandler", "Please_contact_again");
                    ContainerFragmentActivity.this.hideProgressBar();
                    Toast.makeText(ContainerFragmentActivity.this.mContext, ContainerFragmentActivity.this.getString(C0213R.string.nfc_alert103), 0).show();
                    return;
                case 3:
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "mainHandler", "Failed_calibration_time");
                    return;
                case 5:
                    ContainerFragmentActivity.this.containerOrangeProgressBar.setProgress(10.0d);
                    ContainerFragmentActivity.this.name.setText(new PreferenceAction(ContainerFragmentActivity.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_NAME));
                    ContainerFragmentActivity.this.ibtn_user_me.setVisibility(8);
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "mainHandler", "Normal_termination");
                    DataMiningInputLog mining = new DataMiningInputLog(ContainerFragmentActivity.this.mContext, ContainerFragmentActivity.this.listLogDMDynamic, ContainerFragmentActivity.this.DEVICE_ID, ContainerFragmentActivity.this);
                    ContainerFragmentActivity.this.listLogDM = mining.getList();
                    DataMiningSelectLog miningSelect = new DataMiningSelectLog(ContainerFragmentActivity.this.mContext, ContainerFragmentActivity.this);
                    ContainerFragmentActivity.this.listGraphDM = miningSelect.getGraphList(ContainerFragmentActivity.this.listLogDM);
                    if (ContainerFragmentActivity.this.logListFragment != null) {
                        ContainerFragmentActivity.this.tabChange(0);
                        ContainerFragmentActivity.this.showTopTabs();
                        ContainerFragmentActivity.this.showTop();
                        ContainerFragmentActivity.this.goFragment(0);
                        ContainerFragmentActivity.this.showManualInput();
                        ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(true, ContainerFragmentActivity.this.listLogDM);
                        ContainerFragmentActivity.this.logListFragment.listViewSetSelection(0);
                    }
                    if (!ContainerFragmentActivity.this.syncAddModTimeline) {
                        new SyncAddMod(ContainerFragmentActivity.this, null).start();
                    }
                    ContainerFragmentActivity.this.runOnUiThread(new C01843());
                    ContainerFragmentActivity.this.hideProgressBar();
                    return;
                case 6:
                    ContainerFragmentActivity.this.hideProgressBar();
                    return;
                default:
                    return;
            }
        }
    }

    class C01893 implements OnClickListener {

        class C01881 implements Runnable {
            C01881() {
            }

            public void run() {
                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "finish", "in");
                Intent intent = new Intent(ContainerFragmentActivity.this, UserManager.class);
                intent.setFlags(67108864);
                intent.putExtra("FINISH", "FINISH");
                ContainerFragmentActivity.this.startActivity(intent);
                ContainerFragmentActivity.this.finish();
            }
        }

        C01893() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            ContainerFragmentActivity.this.runOnUiThread(new C01881());
        }
    }

    class C01904 implements OnClickListener {
        C01904() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
        }
    }

    class C01915 implements Runnable {
        C01915() {
        }

        public void run() {
            ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(true, ContainerFragmentActivity.this.listLogDM);
        }
    }

    class C01926 implements Runnable {
        C01926() {
        }

        public void run() {
            ContainerFragmentActivity.this.roadingProgressBar.setVisibility(0);
        }
    }

    class C01957 implements Runnable {
        C01957() {
        }

        public void run() {
            ContainerFragmentActivity.this.roadingProgressBar.setVisibility(0);
        }
    }

    class C01978 implements Runnable {
        C01978() {
        }

        public void run() {
            ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(true, ContainerFragmentActivity.this.listLogDM);
        }
    }

    class C01989 implements Runnable {
        C01989() {
        }

        public void run() {
            ContainerFragmentActivity.this.startActivityForResult(new Intent(ContainerFragmentActivity.this, SplashRoute.class), 6);
        }
    }

    private class AppStatus extends AsyncTask<Integer, Integer, Integer> {
        private AppStatus() {
        }

        protected Integer doInBackground(Integer... params) {
            int result = new AppStatusRouter(ContainerFragmentActivity.this.mContext).getAppStatus();
            ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "StrictMode", "1. get async appstatus:" + result);
            return Integer.valueOf(result);
        }
    }

    void appFinish() {
        new Builder(this).setTitle(getString(C0213R.string.alert_text_title)).setMessage(getString(C0213R.string.alert_text_finish)).setNegativeButton(getString(C0213R.string.alert_text_cancel), new C01904()).setPositiveButton(getString(C0213R.string.alert_text_confirm), new C01893()).show();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        NOW_SPLASH_STATUS = 0;
        this.logCat.log(className, "onActivityResult requestCode", requestCode + "");
        this.logCat.log(className, "onActivityResult resultCode", resultCode + "");
        if (requestCode == 6) {
            if (resultCode == -1) {
                finish();
            } else if (resultCode == 7) {
                this.logCat.log(className, "SPLASH_AGREEMENT", "in0");
                startActivityForResult(new Intent(this, Agreement.class), 7);
            } else if (resultCode == 9) {
                startActivityForResult(new Intent(this, Login.class), 9);
            }
        }
        if (requestCode == 7 || requestCode == 5) {
            this.logCat.log(className, "SPLASH_AGREEMENT", "in");
            if (resultCode == -1) {
                finish();
            }
            if (resultCode == 8) {
                startActivityForResult(new Intent(this, Profile.class), 8);
            }
        }
        if (requestCode == 8) {
            this.userProfileSettingData.changeData();
            this.logCat.log(className, "SPLASH_PROFILE", "in");
            if (resultCode == -1) {
                finish();
            }
            if (resultCode == 10) {
                NOW_SPLASH_STATUS = 10;
                startActivityForResult(new Intent(this, Setting.class), 10);
            }
        }
        if (requestCode == 10) {
            this.userProfileSettingData.changeData();
            if (resultCode == -1) {
                finish();
            }
            if (resultCode == 20) {
                startActivity(new Intent(this, ContainerFragmentActivity.class));
            }
        }
        if (requestCode == 9) {
            NOW_SPLASH_STATUS = 9;
            if (resultCode != -1 && resultCode == 11) {
                this.logCat.log(className, "SPLASH_LOGIN join", "in");
                actionDefine(0);
            }
        }
        if (requestCode == 200) {
            if (resultCode == -1) {
                this.logCat.log(className, "called miningLogs()", "call3");
                miningLogs();
                this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
                this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
                this.logListFragment.listViewSetSelection(0);
            }
        } else if (requestCode == INPUT_INSULIN) {
            if (resultCode == -1) {
                this.logCat.log(className, "INPUT_INSULIN", "in");
                this.logCat.log(className, "called miningLogs()", "call4");
                miningLogs();
                this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
                this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
                this.logListFragment.listViewSetSelection(0);
            }
        } else if (requestCode == INPUT_NOTE) {
            if (resultCode == -1) {
                this.logCat.log(className, "INPUT_NOTE", "in");
                this.logCat.log(className, "called miningLogs()", "call5");
                miningLogs();
                this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
                this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
                this.logListFragment.listViewSetSelection(0);
            }
        } else if (requestCode == INPUT_COMMENT) {
            if (resultCode == -1) {
                this.logCat.log(className, "INPUT_COMMENT", "in");
                PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                if (FRIEND_EMAIL == null || pref.getString(PreferenceAction.MY_EMAIL).equals(FRIEND_EMAIL)) {
                    this.logCat.log(className, "called miningLogs()", "call6");
                    miningLogs();
                    this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
                    this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
                    this.logListFragment.listViewSetSelection(0);
                } else {
                    this.FRIEND_TIMELINE_STARTNUM = 0;
                    actionDefine(56);
                }
            }
        } else if (requestCode == MODIFY_GLUCOSE) {
            if (resultCode == -1) {
                this.logCat.log(className, "MODIFY_GLUCOSE", "in");
                this.logCat.log(className, "called miningLogs()", "call7");
                miningLogs();
                this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
                this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
            }
        } else if (requestCode == MODIFY_INSULIN) {
            if (resultCode == -1) {
                this.logCat.log(className, "MODIFY_INSULIN", "in");
                this.logCat.log(className, "called miningLogs()", "call8");
                miningLogs();
                this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
                this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
            }
        } else if (requestCode == MODIFY_NOTE) {
            if (resultCode == -1) {
                this.logCat.log(className, "MODIFY_NOTE", "in");
                this.logCat.log(className, "called miningLogs()", "call9");
                miningLogs();
                this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
                this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
                this.logListFragment.listViewSetSelection(0);
            }
        } else if (requestCode == MODIFY_COMMENT && resultCode == -1) {
        }
        if (requestCode == INPUT_BLUETOOTH && resultCode == -1) {
            this.listLogDM = new DataMiningInputLog(this.mContext, (ArrayList) intent.getSerializableExtra("bt_log"), new PreferenceUtil(this.mContext, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME).getString(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS), this).getList();
            this.listGraphDM = new DataMiningSelectLog(this.mContext, this).getGraphList(this.listLogDM);
            if (this.logListFragment != null) {
                tabChange(0);
                showTopTabs();
                showTop();
                goFragment(0);
                showManualInput();
                this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
                this.logListFragment.listViewSetSelection(0);
            }
            if (!this.syncAddModTimeline) {
                new SyncAddMod(this, null).start();
            }
        }
    }

    public void onNewIntent(Intent intent) {
        this.logCat.log(className, "onNewIntent", "in");
        this.logCat.log(className, "inininini onNewIntent", "in");
        appStatus();
        if (this.dbAction == null) {
            this.dbAction = new DBAction(this.mContext);
        }
        mAction = intent.getAction();
        mTag = (Tag) intent.getParcelableExtra("android.nfc.extra.TAG");
        this.logCat.log(className, "D-Tag", "mAction:" + mAction);
        this.logCat.log(className, "D-Tag", "mTag:" + mTag);
        if (!(mAction == null || mTag == null)) {
            this.logCat.log(className, "mAction", "not null");
        }
        if (mAction == null || mTag == null) {
            this.logCat.log(className, "mAction", "null");
            new ShowAlert(this.mContext).showToast(getString(C0213R.string.nfc_alert102));
        } else if ("android.nfc.action.NDEF_DISCOVERED".equals(mAction) || "android.nfc.action.TECH_DISCOVERED".equals(mAction)) {
            boolean isNfcA = false;
            for (String string : mTag.getTechList()) {
                this.logCat.log(className, "D-Tag", "mTag.getTechList(): " + string);
                if (string.equals("android.nfc.tech.NfcA")) {
                    isNfcA = true;
                }
            }
            this.logCat.log(className, "D-Tag", "isNfcA: " + isNfcA);
            this.uid = mTag.getId();
            this.logCat.log(className, "D-Tag", "UID In Hex: " + NfcUtils.byteArrayToHex(this.uid));
            this.logCat.log(className, "getManufacturer", "UID In Hex: " + NfcUtils.byteArrayToHex(this.uid));
            this.logCat.log(className, "mAction", "not null");
            if (this.NFC_TIME_SET_MODE) {
                this.logCat.log(className, "NFC_TIME_SET_MODE", "true");
                setGlucometerTime();
            } else {
                this.logCat.log(className, "NFC_TIME_SET_MODE", "false");
                if (this.blockNFC) {
                    this.logCat.log(className, "blockNFC", "now sync.....");
                    Toast.makeText(this.mContext, C0213R.string.data_sending, 0).show();
                } else {
                    this.nfcAstartTime = System.currentTimeMillis();
                    if (isNfcA) {
                        getGlucometerDataByDTag();
                    } else {
                        getGlucometerData();
                    }
                }
            }
        }
        String intentStr = intent.getStringExtra(ClassConstant.GO_LOGBOOK);
        if (intentStr != null && intentStr.equals(ClassConstant.GO_LOGBOOK)) {
            goFragment(0);
            tabChange(0);
            showTopTabs();
            showTop();
            showManualInput();
        }
        FRIEND_EMAIL = intent.getStringExtra(PreferenceAction.FRIEND_EMAIL);
        FRIEND_NAME = intent.getStringExtra("FRIEND_NAME");
        String PANDING = intent.getStringExtra("PANDING");
        this.logCat.log(className, PreferenceAction.FRIEND_EMAIL, FRIEND_EMAIL);
        PreferenceAction pref;
        if (FRIEND_EMAIL != null && PANDING == null) {
            this.FRIEND_TIMELINE_STARTNUM = 0;
            goFragment(0);
            tabChange(0);
            showTopTabs();
            showTop();
            showManualInput();
            this.listLogDM.clear();
            if (this.userProfileSettingData.isMe(FRIEND_EMAIL)) {
                this.logCat.log(className, "intent my data", "");
                this.ibtn_user_me.setVisibility(8);
                showManualInput();
                pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                this.name.setText(pref.getString(PreferenceAction.MY_NAME));
                miningLogs();
                this.userProfileSettingData.USER_EMAIL = null;
                this.userProfileSettingData.changeData();
                runOnUiThread(new C01915());
                requestFriendListByEmail(pref.getString(PreferenceAction.MY_EMAIL));
                return;
            }
            this.FRIEND_TIMELINE_STARTNUM = 0;
            this.ibtn_user_me.setVisibility(0);
            this.roadingProgressBar.post(new C01926());
            hideManualInput(false);
            actionDefine(56);
            requestFriendListByEmail(FRIEND_EMAIL);
        } else if (FRIEND_EMAIL != null && PANDING != null) {
            this.logCat.log(className, "friends data", "in");
            this.listLogDM.clear();
            if (this.userProfileSettingData.isMe(FRIEND_EMAIL)) {
                this.logCat.log(className, "intent my data from noti click", "");
                this.ibtn_user_me.setVisibility(8);
                if (intent.getStringExtra("GUBUN_NUM").equals(LogDM.GLUCOSE_EAT_NONE)) {
                    this.logCat.log(className, "onNewIntent", "in pop click");
                    startActivity(new Intent(this, UserManager.class));
                }
                showManualInput();
                pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                this.name.setText(pref.getString(PreferenceAction.MY_NAME));
                Toast.makeText(this.mContext, getString(C0213R.string.new_sync_message), 0).show();
                miningLogs();
                this.userProfileSettingData.USER_EMAIL = null;
                this.userProfileSettingData.changeData();
                runOnUiThread(new C01978());
                requestFriendListByEmail(pref.getString(PreferenceAction.FRIEND_EMAIL));
                return;
            }
            this.ibtn_user_me.setVisibility(0);
            this.name.setText(FRIEND_NAME);
            this.FRIEND_TIMELINE_STARTNUM = 0;
            this.roadingProgressBar.post(new C01957());
            hideManualInput(false);
            actionDefine(56);
            requestFriendListByEmail(FRIEND_EMAIL);
        }
    }

    void requestFriendListByEmail(String email) {
        FriendListThrDM friendListThrDM = new FriendListThrDM();
        friendListThrDM.email = email;
        new ThrFriendList(getApplicationContext(), friendListThrDM, null, this, ClassConstant.SUBDIR_SUPORT_FRIENDS).start();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        this.logCat.log(className, "orientation", "in");
        tabChange(this.mTabMenu);
        localeEvent();
    }

    void appStatus() {
        this.logCat.log(className, "StrictMode", "appStatus() skipped, now mAppStatus:" + this.mAppStatus);
    }

    int appStatusAsync() {
        int appstatus = -1;
        try {
            appstatus = ((Integer) new AppStatus().execute(new Integer[]{null, null, null}).get()).intValue();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e2) {
            e2.printStackTrace();
        }
        this.logCat.log(className, "StrictMode", "2. get async appstatus > appStatusAsync() return appstatus:" + appstatus);
        return appstatus;
    }

    private void testHeapMemory() {
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.logCat.log(className, "onLowMemory()", "in");
    }

    public void onCreate(Bundle savedInstanceState) {
        this.startTime = System.nanoTime();
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        try {
            if (getIntent().getStringExtra("PANDING") == null) {
                new Thread(new C01989()).start();
            }
        } catch (Exception e) {
            new Thread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.startActivityForResult(new Intent(ContainerFragmentActivity.this, SplashRoute.class), 6);
                }
            }).start();
        }
        this.mContext = this;
        this.util = new Util();
        containerFragmentActivity = this;
        setContentView(C0213R.layout.container);
        this.logCat.log(className, "onCreate", "in");
        this.logCat.log(className, "inininini onCreate", "in");
        this.myEmail = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        this.listLogDM = new ArrayList();
        this.listGraphDM = new Vector();
        this.listLogDMDynamic = new ArrayList();
        this.lastValuesList = new ArrayList();
        if (this.dbAction == null) {
            this.dbAction = new DBAction(this.mContext);
        }
        this.topLinearLy = (LinearLayout) findViewById(C0213R.id.top);
        this.topmenuRelativeLy = (LinearLayout) findViewById(C0213R.id.topmenu_relative);
        this.manualInputLinearLy = (LinearLayout) findViewById(C0213R.id.log_ll_smenu);
        this.tabMenu0 = (LinearLayout) findViewById(C0213R.id.ll_tab01);
        this.tabMenu1 = (LinearLayout) findViewById(C0213R.id.ll_tab02);
        this.tabMenu2 = (LinearLayout) findViewById(C0213R.id.ll_tab03);
        this.tabMenu3 = (LinearLayout) findViewById(C0213R.id.ll_tab04);
        this.bottomSyncLy0 = (LinearLayout) findViewById(C0213R.id.bottomSyncLy0);
        this.bottomSyncLy0.setVisibility(8);
        this.ibtn_user = (ImageButton) findViewById(C0213R.id.ibtn_user);
        this.ibtn_user_me = (TextView) findViewById(C0213R.id.ibtn_user_me);
        this.tvTab01 = (TextView) findViewById(C0213R.id.tv_tab01);
        this.tvTab02 = (TextView) findViewById(C0213R.id.tv_tab02);
        this.tvTab03 = (TextView) findViewById(C0213R.id.tv_tab03);
        this.tvTab04 = (TextView) findViewById(C0213R.id.tv_tab04);
        this.tvName = (TextView) findViewById(C0213R.id.tv_name);
        this.tvName.setVisibility(8);
        this.bottomSyncTv0 = (TextView) findViewById(C0213R.id.bottomSyncTv0);
        this.name = (TextView) findViewById(C0213R.id.name);
        this.ibtn_user_me.setVisibility(8);
        this.containerOrangeProgressBar = (RoundProgressBar) findViewById(C0213R.id.containerOrangeProgressBar);
        this.userProfileSettingData = new UserProfileSettingData(this.mContext);
        PreferenceAction prefProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        this.userProfileSettingData.USER_EMAIL = prefProfile.getString(PreferenceAction.MY_EMAIL);
        this.name.setText(prefProfile.getString(PreferenceAction.MY_NAME));
        this.logCat.log(className, "userProfileSettingData-USER_EMAIL", this.userProfileSettingData.USER_EMAIL);
        this.logCat.log(className, "userProfileSettingData-USER_HIGH_BLOOD_SUGAR", this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR);
        this.logCat.log(className, "userProfileSettingData-USER_BLOOD_SUGAR_UNIT", this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT);
        this.inputLy01 = (LinearLayout) findViewById(C0213R.id.log_ll_smenu01);
        this.inputLy02 = (LinearLayout) findViewById(C0213R.id.log_ll_smenu02);
        this.inputLy03 = (LinearLayout) findViewById(C0213R.id.log_ll_smenu03);
        this.inputLy04 = (LinearLayout) findViewById(C0213R.id.log_ll_smenu04);
        this.inputLy05 = (LinearLayout) findViewById(C0213R.id.log_ll_smenu05);
        this.logTvSmenu01 = (TextView) findViewById(C0213R.id.log_tv_smenu01);
        this.logTvSmenu02 = (TextView) findViewById(C0213R.id.log_tv_smenu02);
        this.logTvSmenu03 = (TextView) findViewById(C0213R.id.log_tv_smenu03);
        this.logTvSmenu04 = (TextView) findViewById(C0213R.id.log_tv_smenu04);
        this.logTvSmenu05 = (TextView) findViewById(C0213R.id.log_tv_smenu05);
        this.roadingProgressBar = (ProgressBar) findViewById(C0213R.id.roadingProgressBar);
        this.roadingProgressBar.setVisibility(8);
        this.progressState = (ProgressBar) findViewById(C0213R.id.progressState);
        appStatus();
        this.ibtn_user.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.appStatus();
                ContainerFragmentActivity.this.actionDefine(ContainerFragmentActivity.USER_BTN);
            }
        });
        this.ibtn_user_me.setOnClickListener(new View.OnClickListener() {

            class C01791 implements Runnable {
                C01791() {
                }

                public void run() {
                    ContainerFragmentActivity.this.ibtn_user_me.setVisibility(8);
                }
            }

            class C01802 implements Runnable {
                C01802() {
                }

                public void run() {
                    ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(true, ContainerFragmentActivity.this.listLogDM);
                }
            }

            public void onClick(View arg0) {
                ContainerFragmentActivity.this.runOnUiThread(new C01791());
                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "intent my data", "");
                PreferenceAction pref = new PreferenceAction(ContainerFragmentActivity.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                ContainerFragmentActivity.this.name.setText(pref.getString(PreferenceAction.MY_NAME));
                new Anim(ContainerFragmentActivity.this.mContext).startAnimSlow(ContainerFragmentActivity.this.name, "in");
                ContainerFragmentActivity.FRIEND_EMAIL = pref.getString(PreferenceAction.MY_EMAIL);
                ContainerFragmentActivity.this.miningLogs();
                ContainerFragmentActivity.this.userProfileSettingData.USER_EMAIL = null;
                ContainerFragmentActivity.this.userProfileSettingData.changeData();
                ContainerFragmentActivity.this.runOnUiThread(new C01802());
                ContainerFragmentActivity.this.requestFriendListByEmail(pref.getString(PreferenceAction.MY_EMAIL));
                ContainerFragmentActivity.this.fragmentHome();
            }
        });
        this.tabMenu0.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.goFragment(0);
                ContainerFragmentActivity.this.showTopTabs();
                ContainerFragmentActivity.this.showTop();
                ContainerFragmentActivity.this.tabChange(0);
                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "tabchang list size", ContainerFragmentActivity.this.listLogDM.size() + "");
                if (ContainerFragmentActivity.this.userProfileSettingData == null) {
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "is null", "userProfileSettingData is null");
                }
                if (ContainerFragmentActivity.FRIEND_EMAIL == null) {
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "is null", "FRIEND_EMAIL is null");
                }
                if (ContainerFragmentActivity.this.userProfileSettingData.isMe(ContainerFragmentActivity.FRIEND_EMAIL)) {
                    ContainerFragmentActivity.this.showManualInput();
                } else {
                    ContainerFragmentActivity.this.hideManualInput(false);
                }
            }
        });
        this.tabMenu1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.goFragment(1);
                ContainerFragmentActivity.this.hideManualInput(true);
                ContainerFragmentActivity.this.graphFragment.setGraph(ContainerFragmentActivity.this.listGraphDM);
                ContainerFragmentActivity.this.showTopTabs();
                ContainerFragmentActivity.this.showTop();
                ContainerFragmentActivity.this.tabChange(1);
            }
        });
        this.tabMenu2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.goFragment(2);
                ContainerFragmentActivity.this.hideManualInput(true);
                ContainerFragmentActivity.this.graphFragment.setGraph(ContainerFragmentActivity.this.listGraphDM);
                ContainerFragmentActivity.this.showTopTabs();
                ContainerFragmentActivity.this.showTop();
                ContainerFragmentActivity.this.tabChange(2);
            }
        });
        this.tabMenu3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.goFragment(3);
                ContainerFragmentActivity.this.hideManualInput(true);
                ContainerFragmentActivity.this.showTopTabs();
                ContainerFragmentActivity.this.showTop();
                ContainerFragmentActivity.this.tabChange(3);
            }
        });
        this.inputLy01.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.startActivityForResult(new Intent(ContainerFragmentActivity.this.mContext, InputGlucose.class), 200);
            }
        });
        this.inputLy02.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.startActivityForResult(new Intent(ContainerFragmentActivity.this.mContext, InputInsulin.class), ContainerFragmentActivity.INPUT_INSULIN);
            }
        });
        this.inputLy03.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.startActivityForResult(new Intent(ContainerFragmentActivity.this.mContext, InputNote.class), ContainerFragmentActivity.INPUT_NOTE);
            }
        });
        this.inputLy04.setOnClickListener(new View.OnClickListener() {

            class C01851 implements OnClickListener {
                C01851() {
                }

                @TargetApi(23)
                public void onClick(DialogInterface dialog, int which) {
                    ContainerFragmentActivity.this.requestPermissions(new String[]{"android.permission.ACCESS_COARSE_LOCATION"}, 1);
                }
            }

            class C01862 implements OnClickListener {
                C01862() {
                }

                public void onClick(DialogInterface dialog, int which) {
                }
            }

            public void onClick(View arg0) {
                if (VERSION.SDK_INT >= 23) {
                    Log.e("dckim", "PERMISSION::::" + ContextCompat.checkSelfPermission(ContainerFragmentActivity.this.mContext, "android.permission.ACCESS_COARSE_LOCATION"));
                    if (ContextCompat.checkSelfPermission(ContainerFragmentActivity.this.mContext, "android.permission.ACCESS_COARSE_LOCATION") != 0) {
                        Builder builder = new Builder(ContainerFragmentActivity.this.mContext);
                        builder.setTitle(ContainerFragmentActivity.this.getResources().getString(C0213R.string.location_access_title));
                        builder.setMessage(ContainerFragmentActivity.this.getResources().getString(C0213R.string.location_access_message));
                        builder.setPositiveButton(C0213R.string.btn_ok, new C01851());
                        builder.setNegativeButton(C0213R.string.btn_cancel, new C01862());
                        builder.show();
                        return;
                    }
                    Intent intent = new Intent(ContainerFragmentActivity.this.mContext, DataTransActivity.class);
                    intent.putExtra(DataTransActivity.ACTION_DATA_CATEGORY, 0);
                    ContainerFragmentActivity.this.startActivityForResult(intent, ContainerFragmentActivity.INPUT_BLUETOOTH);
                    return;
                }
                intent = new Intent(ContainerFragmentActivity.this.mContext, DataTransActivity.class);
                intent.putExtra(DataTransActivity.ACTION_DATA_CATEGORY, 0);
                ContainerFragmentActivity.this.startActivityForResult(intent, ContainerFragmentActivity.INPUT_BLUETOOTH);
            }
        });
        this.inputLy05.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                ContainerFragmentActivity.this.appStatus();
                ContainerFragmentActivity.this.actionDefine(ContainerFragmentActivity.this.MESSAGE_INPUT);
            }
        });
        if (this.listLogDM.size() == 0) {
            this.logCat.log(className, "called miningLogs()", "call11");
            miningLogs();
            requestFriendListByEmail(new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL));
        }
        this.logCat.log(className, "listGraphDM size", this.listGraphDM.size() + "");
        this.fTransaction = getSupportFragmentManager().beginTransaction();
        this.logListFragment = (LogListFragment) Fragment.instantiate(this, LogListFragment.class.getName());
        this.graphFragment = (GraphFragment) Fragment.instantiate(this, GraphFragment.class.getName());
        this.statsFragment = (StatsFragment) Fragment.instantiate(this, StatsFragment.class.getName());
        this.moreFragment = (MoreFragment) Fragment.instantiate(this, MoreFragment.class.getName());
        this.fragments = new Vector();
        this.fragments.add(this.logListFragment);
        this.fragments.add(this.graphFragment);
        this.fragments.add(this.statsFragment);
        this.fragments.add(this.moreFragment);
        tabChange(0);
        showTopTabs();
        showTop();
        showManualInput();
        goFragment(0);
        FRIEND_EMAIL = getIntent().getStringExtra(PreferenceAction.FRIEND_EMAIL);
        FRIEND_NAME = getIntent().getStringExtra("FRIEND_NAME");
        String PANDING = getIntent().getStringExtra("PANDING");
        this.logCat.log(className, PreferenceAction.FRIEND_EMAIL, FRIEND_EMAIL);
        PreferenceAction prefMyProfile;
        if (FRIEND_EMAIL != null && PANDING == null) {
            prefMyProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            this.FRIEND_TIMELINE_STARTNUM = 0;
            goFragment(0);
            tabChange(0);
            showTopTabs();
            showTop();
            showManualInput();
            this.listLogDM.clear();
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(false, ContainerFragmentActivity.this.listLogDM);
                    ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                }
            });
            if (this.userProfileSettingData.isMe(FRIEND_EMAIL)) {
                this.logCat.log(className, "intent my data", "");
                this.ibtn_user_me.setVisibility(8);
                showManualInput();
                this.name.setText(prefMyProfile.getString(PreferenceAction.MY_NAME));
                miningLogs();
                this.userProfileSettingData.USER_EMAIL = null;
                this.userProfileSettingData.changeData();
                runOnUiThread(new Runnable() {
                    public void run() {
                        ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(true, ContainerFragmentActivity.this.listLogDM);
                    }
                });
                requestFriendListByEmail(prefMyProfile.getString(PreferenceAction.MY_EMAIL));
            } else {
                this.FRIEND_TIMELINE_STARTNUM = 0;
                this.ibtn_user_me.setVisibility(0);
                this.roadingProgressBar.post(new Runnable() {
                    public void run() {
                        ContainerFragmentActivity.this.roadingProgressBar.setVisibility(0);
                    }
                });
                hideManualInput(false);
                runOnUiThread(new Runnable() {
                    public void run() {
                        ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                    }
                });
                actionDefine(56);
                requestFriendListByEmail(FRIEND_EMAIL);
            }
        } else if (!(FRIEND_EMAIL == null || PANDING == null)) {
            prefMyProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            this.logCat.log(className, "friends data", "in");
            this.listLogDM.clear();
            if (this.userProfileSettingData.isMe(FRIEND_EMAIL)) {
                this.ibtn_user_me.setVisibility(8);
                this.logCat.log(className, "intent my data from noti click", "");
                requestFriendListByEmail(prefMyProfile.getString(PreferenceAction.MY_EMAIL));
            } else {
                this.ibtn_user_me.setVisibility(0);
                this.name.setText(FRIEND_NAME);
                this.FRIEND_TIMELINE_STARTNUM = 0;
                this.roadingProgressBar.post(new Runnable() {
                    public void run() {
                        ContainerFragmentActivity.this.roadingProgressBar.setVisibility(0);
                    }
                });
                hideManualInput(false);
                runOnUiThread(new Runnable() {
                    public void run() {
                        ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                    }
                });
                actionDefine(56);
                requestFriendListByEmail(FRIEND_EMAIL);
            }
        }
        this.logCat.log(className, "abc FRIEND_EMAIL", FRIEND_EMAIL);
        this.logCat.log(className, "abc PANDING", PANDING);
        if (FRIEND_EMAIL == null || PANDING == null) {
            this.logCat.log(className, "abc", "2");
            this.ibtn_user_me.setVisibility(0);
            actionDefine(1000);
        } else {
            this.logCat.log(className, "abc", "0");
            if (FRIEND_EMAIL.equals(new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL))) {
                this.logCat.log(className, "abc", "1");
                this.ibtn_user_me.setVisibility(8);
                actionDefine(1000);
            }
        }
        if (FRIEND_EMAIL == null && PANDING == null) {
            this.ibtn_user_me.setVisibility(8);
        }
        testHeapMemory();
        if (!(getIntent().getStringExtra("GUBUN_NUM") == null || !getIntent().getStringExtra("GUBUN_NUM").equals(LogDM.GLUCOSE_EAT_NONE) || isRunningUserManager())) {
            this.logCat.log(className, "onCreate", "in pop click");
            Intent intent = new Intent(this, UserManager.class);
            intent.setFlags(536870912);
            startActivity(intent);
        }
        localeEvent();
    }

    boolean isRunningUserManager() {
        for (RunningTaskInfo runningTaskInfo : ((ActivityManager) getSystemService("activity")).getRunningTasks(7)) {
            this.logCat.log(className, "task className", runningTaskInfo.baseActivity.getClassName());
            if (runningTaskInfo.baseActivity.getClassName().matches(".*com.sdbio.UserManager.*")) {
                this.logCat.log(className, "isRunningUserManager", "usermanager runing");
                return true;
            }
        }
        return false;
    }

    private float getDensity() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        return metrics.density;
    }

    public void onResume() {
        super.onResume();
        this.logCat.log(className, "onResume", "in");
        this.logCat.log(className, "inininini onResume", "in");
        appStatus();
        localeEvent();
        this.resumeCount++;
        this.logCat.log(className, "NDEFTAGTest", "onNewIntent by onResume===================");
        this.logCat.log(className, "NDEFTAGTest", "resumeCount:" + this.resumeCount);
        if (this.resumeCount == 1) {
            onNewIntent(getIntent());
            if (getIntent() != null) {
                this.logCat.log(className, "NDEFTAGTest", "if (getIntent()!=null)");
            } else {
                this.logCat.log(className, "NDEFTAGTest", "if (getIntent()==null)");
            }
        }
        enableDispatch();
        tabChange(this.mTabMenu);
    }

    public void onPause() {
        super.onPause();
        disableDispatch();
    }

    public void onDestroy() {
        super.onDestroy();
        this.NFC_TIME_SET_MODE = false;
    }

    private void disableDispatch() {
        NfcAdapter nfcAp = NfcAdapter.getDefaultAdapter(this);
        if (nfcAp != null) {
            nfcAp.disableForegroundDispatch(this);
        }
    }

    private void enableDispatch() {
        NfcAdapter nfcAp = NfcAdapter.getDefaultAdapter(this);
        Intent in = new Intent(this.mContext, getClass());
        in.setFlags(67108864);
        PendingIntent pi = PendingIntent.getActivity(this, 0, in, 134217728);
        filter = new String[2][];
        filter[0] = new String[]{"android.nfc.tech.NfcA"};
        filter[1] = new String[]{"android.nfc.tech.NfcF"};
        if (nfcAp != null) {
            try {
                nfcAp.enableForegroundDispatch(this, pi, null, filter);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void showProgressBar() {
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.containerOrangeProgressBar.setVisibility(0);
            }
        });
    }

    public void hideProgressBar() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Message msg = Message.obtain();
                msg.what = 0;
                ContainerFragmentActivity.this.hideH.sendMessage(msg);
            }
        }).start();
    }

    public void showStatsProgressBar() {
        if (this.containerOrangeProgressBar.getVisibility() == 0) {
            this.logCat.log(className, "showProOrag", "yes");
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.progressState.setVisibility(8);
                }
            });
            return;
        }
        this.logCat.log(className, "showProOrag", "no");
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.progressState.setVisibility(0);
            }
        });
    }

    public void hideStatsProgressBar() {
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.progressState.setVisibility(8);
            }
        });
    }

    public void getGlucometerData() {
        this.containerOrangeProgressBar.setProgress(1.0d);
        this.lastValuesList.clear();
        if (this.FLAG_MEASURE) {
            hideProgressBar();
            return;
        }
        this.FLAG_MEASURE = true;
        this.myEmail = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        this.listLogDMDynamic.clear();
        this.logCat.log(className, "getGlucometerData", "in");
        showProgressBar();
        this.FLAG_FOLLOW_CONTROL_MEASURE_DATA = false;
        new Thread(new Runnable() {
            /* JADX WARNING: inconsistent code. */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                r61 = this;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "run()";
                r55.log(r56, r57, r58);
                r55 = com.accumed.gtech.ContainerFragmentActivity.mTag;
                r45 = android.nfc.tech.NfcF.get(r55);
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "nfc:";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r45;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r45.connect();	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "NfcF.connect() by UID : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r0 = r59;
                r0 = r0.uid;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r59 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r59);	 Catch:{ Exception -> 0x02f0 }
                r59 = r59.toUpperCase();	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "getManufacturer";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "nfc.getManufacturer():";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r59 = r45.getManufacturer();	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "getManufacturer";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "NfcUtils.byteArrayToHex(nfc.getManufacturer()):";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r59 = r45.getManufacturer();	 Catch:{ Exception -> 0x02f0 }
                r59 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "follow";
                r58 = "device info";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r55 = 18;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r24 = r0;
                r24 = {18, 6, 3, -2, 17, 34, 51, 68, 85, 102, 1, 0, 11, 2, 6, 2, 16, 64};	 Catch:{ Exception -> 0x02f0 }
                r0 = r45;
                r1 = r24;
                r27 = r0.transceive(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r27);	 Catch:{ Exception -> 0x02f0 }
                r0 = r56;
                r1 = r55;
                r1.DEVICE_ID = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "getManufacturer";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "DEVICE_ID:";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r0 = r59;
                r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r55 = 16;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r25 = r0;
                r55 = 0;
                r56 = 29;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 30;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 31;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = 32;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r56 = 33;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 5;
                r56 = 34;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 6;
                r56 = 35;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 7;
                r56 = 36;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 8;
                r56 = 37;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 9;
                r56 = 38;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 10;
                r56 = 39;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 11;
                r56 = 40;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 12;
                r56 = 41;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 13;
                r56 = 42;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 14;
                r56 = 43;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 15;
                r56 = 44;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r25[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r0 = r56;
                r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r57 = 52;
                r56 = r56.substring(r57);	 Catch:{ Exception -> 0x02f0 }
                r56 = r56.toUpperCase();	 Catch:{ Exception -> 0x02f0 }
                r0 = r56;
                r1 = r55;
                r1.DEVICE_ID = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.dbAction;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r0 = r56;
                r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r37 = r55.isRegisterDevice(r56);	 Catch:{ Exception -> 0x02f0 }
                if (r37 != 0) goto L_0x028c;
            L_0x020c:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = " 디바이스 등록여부";
                r58 = "등록되지 않음";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r44 = android.os.Message.obtain();	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r0 = r55;
                r1 = r44;
                r1.what = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.mainHandler;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r44;
                r0.sendMessage(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x02f0 }
            L_0x024e:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "follow measure date";
                r58 = "continue0";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.FLAG_FOLLOW_CONTROL_MEASURE_DATA;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                if (r55 != 0) goto L_0x03f7;
            L_0x0271:
                if (r45 == 0) goto L_0x028b;
            L_0x0273:
                r45.close();	 Catch:{ IOException -> 0x03c7 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x03c7 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x03c7 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "if (nfc != null) nfc.close();";
                r55.log(r56, r57, r58);	 Catch:{ IOException -> 0x03c7 }
            L_0x028b:
                return;
            L_0x028c:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = " 디바이스 등록여부";
                r58 = "이미 등록되어 있음";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r31 = new java.text.SimpleDateFormat;	 Catch:{ Exception -> 0x02f0 }
                r55 = "yyyyMMddHHmmssmmm";
                r0 = r31;
                r1 = r55;
                r0.<init>(r1);	 Catch:{ Exception -> 0x02f0 }
                r56 = java.lang.System.currentTimeMillis();	 Catch:{ Exception -> 0x02f0 }
                r55 = java.lang.Long.valueOf(r56);	 Catch:{ Exception -> 0x02f0 }
                r0 = r31;
                r1 = r55;
                r51 = r0.format(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.dbAction;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r0 = r56;
                r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r0 = r55;
                r1 = r56;
                r2 = r51;
                r55 = r0.updateDateDevice(r1, r2);	 Catch:{ Exception -> 0x02f0 }
                if (r55 == 0) goto L_0x0394;
            L_0x02e0:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = 1;
                r0 = r56;
                r1 = r55;
                r1.FLAG_FOLLOW_CONTROL_MEASURE_DATA = r0;	 Catch:{ Exception -> 0x02f0 }
                goto L_0x024e;
            L_0x02f0:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ all -> 0x03ab }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ all -> 0x03ab }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;	 Catch:{ all -> 0x03ab }
                r58.<init>();	 Catch:{ all -> 0x03ab }
                r59 = "} catch(Exception e){:";
                r58 = r58.append(r59);	 Catch:{ all -> 0x03ab }
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);	 Catch:{ all -> 0x03ab }
                r58 = r58.toString();	 Catch:{ all -> 0x03ab }
                r55.log(r56, r57, r58);	 Catch:{ all -> 0x03ab }
                r44 = android.os.Message.obtain();	 Catch:{ all -> 0x03ab }
                r55 = 2;
                r0 = r55;
                r1 = r44;
                r1.what = r0;	 Catch:{ all -> 0x03ab }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ all -> 0x03ab }
                r55 = r0;
                r0 = r55;
                r0 = r0.mainHandler;	 Catch:{ all -> 0x03ab }
                r55 = r0;
                r0 = r55;
                r1 = r44;
                r0.sendMessage(r1);	 Catch:{ all -> 0x03ab }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ all -> 0x03ab }
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;	 Catch:{ all -> 0x03ab }
                if (r45 == 0) goto L_0x028b;
            L_0x034a:
                r45.close();	 Catch:{ IOException -> 0x0364 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x0364 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x0364 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "if (nfc != null) nfc.close();";
                r55.log(r56, r57, r58);	 Catch:{ IOException -> 0x0364 }
                goto L_0x028b;
            L_0x0364:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "IOException";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r28.printStackTrace();
                goto L_0x028b;
            L_0x0394:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "failed";
                r58 = "디바이스 날짜 업데이트 실패 - 디비액션 실패";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                goto L_0x02e0;
            L_0x03ab:
                r55 = move-exception;
                if (r45 == 0) goto L_0x03c6;
            L_0x03ae:
                r45.close();	 Catch:{ IOException -> 0x19b8 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x19b8 }
                r56 = r0;
                r0 = r56;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x19b8 }
                r56 = r0;
                r57 = "ContainerFragmentActivity";
                r58 = "D-Tag";
                r59 = "if (nfc != null) nfc.close();";
                r56.log(r57, r58, r59);	 Catch:{ IOException -> 0x19b8 }
            L_0x03c6:
                throw r55;
            L_0x03c7:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "IOException";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r28.printStackTrace();
                goto L_0x028b;
            L_0x03f7:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "follow measure date";
                r58 = "continue1";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r50 = r0;
                r55 = 0;
                r56 = 0;
                r50[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r50[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 20;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r50[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = 21;
                r56 = r27[r56];	 Catch:{ Exception -> 0x02f0 }
                r50[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r50;
                r1 = r55;
                r19 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r0, r1);	 Catch:{ Exception -> 0x02f0 }
                r10 = r19;
                r12 = r10 / 24;
                r17 = r10 % 24;
                r36 = 1;
                r35 = 24;
                if (r17 <= 0) goto L_0x0c00;
            L_0x0446:
                r55 = 1;
            L_0x0448:
                r26 = r10 + r55;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "Measure Data count:";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r58;
                r1 = r19;
                r58 = r0.append(r1);	 Catch:{ Exception -> 0x02f0 }
                r59 = ", 몫 :";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r58;
                r58 = r0.append(r10);	 Catch:{ Exception -> 0x02f0 }
                r59 = ", 나머지:";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r58;
                r1 = r17;
                r58 = r0.append(r1);	 Catch:{ Exception -> 0x02f0 }
                r59 = ">> dueCnt:";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r58;
                r1 = r26;
                r58 = r0.append(r1);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r34 = 0;
            L_0x049e:
                r0 = r34;
                if (r0 >= r12) goto L_0x0cb0;
            L_0x04a2:
                r0 = r36;
                r0 = r0 / 256;
                r20 = r0;
                r0 = r36;
                r0 = r0 % 256;
                r28 = r0;
                r0 = r35;
                r0 = r0 / 256;
                r31 = r0;
                r0 = r35;
                r0 = r0 % 256;
                r32 = r0;
                r55 = 20;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r41 = r0;
                r55 = 0;
                r56 = 20;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 6;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 3;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = -2;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r56 = 17;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 5;
                r56 = 34;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 6;
                r56 = 51;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 7;
                r56 = 68;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 8;
                r56 = 85;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 9;
                r56 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 10;
                r56 = 1;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 11;
                r56 = 0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 12;
                r56 = 11;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 13;
                r56 = 12;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 14;
                r56 = 6;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 15;
                r56 = 12;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 16;
                r0 = r20;
                r0 = (byte) r0;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 17;
                r0 = r28;
                r0 = (byte) r0;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 18;
                r0 = r31;
                r0 = (byte) r0;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 19;
                r0 = r32;
                r0 = (byte) r0;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r40 = 0;
                r0 = r45;
                r1 = r41;
                r40 = r0.transceive(r1);	 Catch:{ Exception -> 0x0c04 }
                r46 = 13;
                r52 = 0;
            L_0x0554:
                r55 = 24;
                r0 = r52;
                r1 = r55;
                if (r0 >= r1) goto L_0x0ca8;
            L_0x055c:
                r55 = 4;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r53 = r0;
                r55 = 0;
                r56 = 0;
                r53[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r53[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r53[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 0;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r53[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r53;
                r1 = r55;
                r54 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r0, r1);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r7 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r56 = 0;
                r7[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r7[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r7[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 1;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r7[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r43 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r7, r0);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r4 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r56 = 0;
                r4[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r4[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r4[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 2;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r4[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r23 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r4, r0);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r6 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r56 = 0;
                r6[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r6[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r6[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 3;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r6[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r33 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r6, r0);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r39 = r0;
                r55 = 0;
                r56 = 0;
                r39[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r39[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r39[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 4;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r39[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r39;
                r1 = r55;
                r42 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r0, r1);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r14 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r56 = 0;
                r14[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r14[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 5;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r14[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 6;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r14[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r16 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r14, r0);	 Catch:{ Exception -> 0x02f0 }
                r55 = r52 * 8;
                r55 = r55 + r46;
                r55 = r55 + 7;
                r15 = r40[r55];	 Catch:{ Exception -> 0x02f0 }
                r18 = 0;
                r13 = 0;
                r11 = 0;
                r55 = r15 & 2;
                if (r55 <= 0) goto L_0x0684;
            L_0x0682:
                r18 = 1;
            L_0x0684:
                r55 = r15 & 16;
                if (r55 <= 0) goto L_0x0689;
            L_0x0688:
                r13 = 1;
            L_0x0689:
                r55 = r15 & 32;
                if (r55 <= 0) goto L_0x068e;
            L_0x068d:
                r11 = 1;
            L_0x068e:
                r38 = new com.accumed.gtech.datamodel.LogDM;	 Catch:{ Exception -> 0x02f0 }
                r38.<init>();	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r38;
                r1.device_id = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r55.<init>();	 Catch:{ Exception -> 0x02f0 }
                r56 = "20";
                r55 = r55.append(r56);	 Catch:{ Exception -> 0x02f0 }
                r56 = "%02d%02d%02d%02d%02d";
                r57 = 5;
                r0 = r57;
                r0 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x02f0 }
                r57 = r0;
                r58 = 0;
                r59 = java.lang.Integer.valueOf(r54);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r58 = 1;
                r59 = java.lang.Integer.valueOf(r43);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r58 = 2;
                r59 = java.lang.Integer.valueOf(r23);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r58 = 3;
                r59 = java.lang.Integer.valueOf(r33);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r58 = 4;
                r59 = java.lang.Integer.valueOf(r42);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r56 = java.lang.String.format(r56, r57);	 Catch:{ Exception -> 0x02f0 }
                r55 = r55.append(r56);	 Catch:{ Exception -> 0x02f0 }
                r56 = "00000";
                r55 = r55.append(r56);	 Catch:{ Exception -> 0x02f0 }
                r55 = r55.toString();	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.input_date = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = java.lang.Integer.toString(r16);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_value = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = "0";
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_type = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.category = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = "insert";
                r0 = r55;
                r1 = r38;
                r1.update_flag = r0;	 Catch:{ Exception -> 0x02f0 }
                r29 = 0;
                r55 = 1;
                r0 = r18;
                r1 = r55;
                if (r0 != r1) goto L_0x0738;
            L_0x072a:
                r55 = 2;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
                r29 = r29 + 1;
            L_0x0738:
                r55 = 1;
                r0 = r55;
                if (r13 != r0) goto L_0x074c;
            L_0x073e:
                r55 = 1;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
                r29 = r29 + 1;
            L_0x074c:
                r55 = 1;
                r0 = r55;
                if (r11 != r0) goto L_0x0760;
            L_0x0752:
                r55 = 0;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
                r29 = r29 + 1;
            L_0x0760:
                if (r29 != 0) goto L_0x076e;
            L_0x0762:
                r55 = 4;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
            L_0x076e:
                r55 = "";
                r0 = r55;
                r1 = r38;
                r1._id = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = "";
                r0 = r55;
                r1 = r38;
                r1.user_id = r0;	 Catch:{ Exception -> 0x02f0 }
                r47 = new java.text.SimpleDateFormat;	 Catch:{ Exception -> 0x02f0 }
                r55 = "yyyyMMddHHmmss";
                r0 = r47;
                r1 = r55;
                r0.<init>(r1);	 Catch:{ Exception -> 0x02f0 }
                r48 = java.lang.System.nanoTime();	 Catch:{ Exception -> 0x02f0 }
                r55 = java.lang.Long.toString(r48);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.system_date = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r9 = r0.input_date;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.util;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r38;
                r0 = r0.blood_sugar_value;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r8 = r55.vvv(r56);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.util;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r38;
                r0 = r0.blood_sugar_eat;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r5 = r55.ee(r56);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "checked YYYYMMDDHHNN";
                r0 = r55;
                r1 = r56;
                r2 = r57;
                r0.log(r1, r2, r9);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "checked VVV";
                r0 = r55;
                r1 = r56;
                r2 = r57;
                r0.log(r1, r2, r8);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "checked EE";
                r0 = r55;
                r1 = r56;
                r2 = r57;
                r0.log(r1, r2, r5);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM";
                r58 = "-------------------------------";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM _id";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0._id;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM blood_sugar_eat";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.blood_sugar_eat;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM blood_sugar_type";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.blood_sugar_type;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM_blood_sugar_value";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.blood_sugar_value;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM category";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.category;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM device_id";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.device_id;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM input_date";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.input_date;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM insulin_name";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.insulin_name;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM insulin_type";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.insulin_type;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM insulin_value";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.insulin_value;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM note_content";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.note_content;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM note_picture";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.note_picture;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM note_picture_thumb";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.note_picture_thumb;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM note_type";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.note_type;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM seq";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.seq;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM system_date";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.system_date;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM update_flag";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.update_flag;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM user_id";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.user_id;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM";
                r58 = "-------------------------------";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.myEmail;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r38;
                r1.user_id = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "myEmail";
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r58 = r0;
                r0 = r58;
                r0 = r0.myEmail;	 Catch:{ Exception -> 0x02f0 }
                r58 = r0;
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.listLogDMDynamic;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r38;
                r0.add(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.lastValuesList;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r56.<init>();	 Catch:{ Exception -> 0x02f0 }
                r57 = "20";
                r56 = r56.append(r57);	 Catch:{ Exception -> 0x02f0 }
                r57 = "%02d%02d%02d%02d%02d";
                r58 = 5;
                r0 = r58;
                r0 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x02f0 }
                r58 = r0;
                r59 = 0;
                r60 = java.lang.Integer.valueOf(r54);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r59 = 1;
                r60 = java.lang.Integer.valueOf(r43);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r59 = 2;
                r60 = java.lang.Integer.valueOf(r23);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r59 = 3;
                r60 = java.lang.Integer.valueOf(r33);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r59 = 4;
                r60 = java.lang.Integer.valueOf(r42);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r57 = java.lang.String.format(r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r56 = r56.append(r57);	 Catch:{ Exception -> 0x02f0 }
                r0 = r56;
                r56 = r0.append(r8);	 Catch:{ Exception -> 0x02f0 }
                r0 = r56;
                r56 = r0.append(r5);	 Catch:{ Exception -> 0x02f0 }
                r56 = r56.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.add(r56);	 Catch:{ Exception -> 0x02f0 }
                r52 = r52 + 1;
                goto L_0x0554;
            L_0x0c00:
                r55 = 0;
                goto L_0x0448;
            L_0x0c04:
                r30 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "meas_res = nfc.transceive(measure_data);1} catch (Exception err) {";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r58;
                r1 = r30;
                r58 = r0.append(r1);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r44 = android.os.Message.obtain();	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r0 = r55;
                r1 = r44;
                r1.what = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.mainHandler;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r44;
                r0.sendMessage(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x02f0 }
                if (r45 == 0) goto L_0x028b;
            L_0x0c5e:
                r45.close();	 Catch:{ IOException -> 0x0c78 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x0c78 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x0c78 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "if (nfc != null) nfc.close();";
                r55.log(r56, r57, r58);	 Catch:{ IOException -> 0x0c78 }
                goto L_0x028b;
            L_0x0c78:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "IOException";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r28.printStackTrace();
                goto L_0x028b;
            L_0x0ca8:
                r36 = r36 + 24;
                r35 = r35 + 24;
                r34 = r34 + 1;
                goto L_0x049e;
            L_0x0cb0:
                r40 = 0;
                if (r17 == 0) goto L_0x0d60;
            L_0x0cb4:
                r0 = r36;
                r0 = r0 / 256;
                r20 = r0;
                r0 = r36;
                r0 = r0 % 256;
                r28 = r0;
                r0 = r35;
                r0 = r0 / 256;
                r31 = r0;
                r0 = r35;
                r0 = r0 % 256;
                r32 = r0;
                r55 = 20;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r41 = r0;
                r55 = 0;
                r56 = 20;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 6;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 3;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = -2;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r56 = 17;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 5;
                r56 = 34;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 6;
                r56 = 51;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 7;
                r56 = 68;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 8;
                r56 = 85;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 9;
                r56 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 10;
                r56 = 1;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 11;
                r56 = 0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 12;
                r56 = 11;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 13;
                r56 = 12;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 14;
                r56 = 6;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 15;
                r56 = 12;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 16;
                r0 = r20;
                r0 = (byte) r0;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 17;
                r0 = r28;
                r0 = (byte) r0;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 18;
                r0 = r31;
                r0 = (byte) r0;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 19;
                r0 = r32;
                r0 = (byte) r0;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r41[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r0 = r45;
                r1 = r41;
                r40 = r0.transceive(r1);	 Catch:{ Exception -> 0x0f0e }
            L_0x0d60:
                if (r12 > 0) goto L_0x1059;
            L_0x0d62:
                if (r17 != 0) goto L_0x1059;
            L_0x0d64:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r21 = r55.getTimeArray();	 Catch:{ Exception -> 0x02f0 }
                r55 = 50;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r22 = r0;
                r55 = 0;
                r56 = 50;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 8;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 3;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = -2;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r56 = 17;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 5;
                r56 = 34;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 6;
                r56 = 51;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 7;
                r56 = 68;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 8;
                r56 = 85;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 9;
                r56 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 10;
                r56 = 1;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 11;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 12;
                r56 = 11;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 13;
                r56 = 2;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 14;
                r56 = 8;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 15;
                r56 = 2;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 16;
                r56 = 65;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 17;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 18;
                r56 = 0;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 19;
                r56 = 1;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 20;
                r56 = 2;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 21;
                r56 = 3;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 22;
                r56 = 4;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 23;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 24;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 25;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 26;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 27;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 28;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 29;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 30;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 31;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 32;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 33;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 34;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 35;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 36;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 37;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 38;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 39;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 40;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 41;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 42;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 43;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 44;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 45;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 46;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 47;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 48;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 49;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r0 = r45;
                r1 = r22;
                r22 = r0.transceive(r1);	 Catch:{ Exception -> 0x0fb2 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x02f0 }
                if (r45 == 0) goto L_0x028b;
            L_0x0ec4:
                r45.close();	 Catch:{ IOException -> 0x0ede }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x0ede }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x0ede }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "if (nfc != null) nfc.close();";
                r55.log(r56, r57, r58);	 Catch:{ IOException -> 0x0ede }
                goto L_0x028b;
            L_0x0ede:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "IOException";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r28.printStackTrace();
                goto L_0x028b;
            L_0x0f0e:
                r30 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "meas_res = nfc.transceive(measure_data);} catch (Exception err) {";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r58;
                r1 = r30;
                r58 = r0.append(r1);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r44 = android.os.Message.obtain();	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r0 = r55;
                r1 = r44;
                r1.what = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.mainHandler;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r44;
                r0.sendMessage(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x02f0 }
                if (r45 == 0) goto L_0x028b;
            L_0x0f68:
                r45.close();	 Catch:{ IOException -> 0x0f82 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x0f82 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x0f82 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "if (nfc != null) nfc.close();";
                r55.log(r56, r57, r58);	 Catch:{ IOException -> 0x0f82 }
                goto L_0x028b;
            L_0x0f82:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "IOException";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r28.printStackTrace();
                goto L_0x028b;
            L_0x0fb2:
                r30 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "date_time = nfc.transceive(date_time);} catch (Exception err) {";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r58;
                r1 = r30;
                r58 = r0.append(r1);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r30.printStackTrace();	 Catch:{ Exception -> 0x02f0 }
                r44 = android.os.Message.obtain();	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r1 = r44;
                r1.what = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.mainHandler;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r44;
                r0.sendMessage(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x02f0 }
                if (r45 == 0) goto L_0x028b;
            L_0x100f:
                r45.close();	 Catch:{ IOException -> 0x1029 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x1029 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x1029 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "if (nfc != null) nfc.close();";
                r55.log(r56, r57, r58);	 Catch:{ IOException -> 0x1029 }
                goto L_0x028b;
            L_0x1029:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "IOException";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r28.printStackTrace();
                goto L_0x028b;
            L_0x1059:
                r46 = 13;
                r52 = 0;
            L_0x105d:
                r0 = r52;
                r1 = r17;
                if (r0 >= r1) goto L_0x16f8;
            L_0x1063:
                r55 = 4;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r53 = r0;
                r55 = 0;
                r56 = 0;
                r53[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r53[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r53[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 0;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r53[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r53;
                r1 = r55;
                r54 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r0, r1);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r7 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r56 = 0;
                r7[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r7[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r7[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 1;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r7[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r43 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r7, r0);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r4 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r56 = 0;
                r4[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r4[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r4[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 2;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r4[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r23 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r4, r0);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r6 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r56 = 0;
                r6[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r6[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r6[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 3;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r6[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r33 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r6, r0);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r39 = r0;
                r55 = 0;
                r56 = 0;
                r39[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r39[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 0;
                r39[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 4;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r39[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r39;
                r1 = r55;
                r42 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r0, r1);	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r0 = r55;
                r14 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r56 = 0;
                r14[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 0;
                r14[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 5;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r14[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = r52 * 8;
                r56 = r56 + r46;
                r56 = r56 + 6;
                r56 = r40[r56];	 Catch:{ Exception -> 0x02f0 }
                r14[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r0 = r55;
                r16 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r14, r0);	 Catch:{ Exception -> 0x02f0 }
                r55 = r52 * 8;
                r55 = r55 + r46;
                r55 = r55 + 7;
                r15 = r40[r55];	 Catch:{ Exception -> 0x02f0 }
                r18 = 0;
                r13 = 0;
                r11 = 0;
                r55 = r15 & 2;
                if (r55 <= 0) goto L_0x118b;
            L_0x1189:
                r18 = 1;
            L_0x118b:
                r55 = r15 & 16;
                if (r55 <= 0) goto L_0x1190;
            L_0x118f:
                r13 = 1;
            L_0x1190:
                r55 = r15 & 32;
                if (r55 <= 0) goto L_0x1195;
            L_0x1194:
                r11 = 1;
            L_0x1195:
                r38 = new com.accumed.gtech.datamodel.LogDM;	 Catch:{ Exception -> 0x02f0 }
                r38.<init>();	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r38;
                r1.device_id = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r55.<init>();	 Catch:{ Exception -> 0x02f0 }
                r56 = "20";
                r55 = r55.append(r56);	 Catch:{ Exception -> 0x02f0 }
                r56 = "%02d%02d%02d%02d%02d";
                r57 = 5;
                r0 = r57;
                r0 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x02f0 }
                r57 = r0;
                r58 = 0;
                r59 = java.lang.Integer.valueOf(r54);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r58 = 1;
                r59 = java.lang.Integer.valueOf(r43);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r58 = 2;
                r59 = java.lang.Integer.valueOf(r23);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r58 = 3;
                r59 = java.lang.Integer.valueOf(r33);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r58 = 4;
                r59 = java.lang.Integer.valueOf(r42);	 Catch:{ Exception -> 0x02f0 }
                r57[r58] = r59;	 Catch:{ Exception -> 0x02f0 }
                r56 = java.lang.String.format(r56, r57);	 Catch:{ Exception -> 0x02f0 }
                r55 = r55.append(r56);	 Catch:{ Exception -> 0x02f0 }
                r56 = "00000";
                r55 = r55.append(r56);	 Catch:{ Exception -> 0x02f0 }
                r55 = r55.toString();	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.input_date = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = java.lang.Integer.toString(r16);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_value = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = java.lang.Integer.toString(r15);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = "0";
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_type = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = 0;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.category = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = "insert";
                r0 = r55;
                r1 = r38;
                r1.update_flag = r0;	 Catch:{ Exception -> 0x02f0 }
                r29 = 0;
                r55 = 1;
                r0 = r18;
                r1 = r55;
                if (r0 != r1) goto L_0x1249;
            L_0x123b:
                r55 = 2;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
                r29 = r29 + 1;
            L_0x1249:
                r55 = 1;
                r0 = r55;
                if (r13 != r0) goto L_0x125d;
            L_0x124f:
                r55 = 1;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
                r29 = r29 + 1;
            L_0x125d:
                r55 = 1;
                r0 = r55;
                if (r11 != r0) goto L_0x1271;
            L_0x1263:
                r55 = 0;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
                r29 = r29 + 1;
            L_0x1271:
                if (r29 != 0) goto L_0x127f;
            L_0x1273:
                r55 = 4;
                r55 = java.lang.Integer.toString(r55);	 Catch:{ Exception -> 0x02f0 }
                r0 = r55;
                r1 = r38;
                r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x02f0 }
            L_0x127f:
                r55 = "";
                r0 = r55;
                r1 = r38;
                r1._id = r0;	 Catch:{ Exception -> 0x02f0 }
                r55 = "";
                r0 = r55;
                r1 = r38;
                r1.user_id = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r9 = r0.input_date;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.util;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r38;
                r0 = r0.blood_sugar_value;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r8 = r55.vvv(r56);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.util;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r38;
                r0 = r0.blood_sugar_eat;	 Catch:{ Exception -> 0x02f0 }
                r56 = r0;
                r5 = r55.ee(r56);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "checked YYYYMMDDHHNN";
                r0 = r55;
                r1 = r56;
                r2 = r57;
                r0.log(r1, r2, r9);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "checked VVV";
                r0 = r55;
                r1 = r56;
                r2 = r57;
                r0.log(r1, r2, r8);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "checked EE";
                r0 = r55;
                r1 = r56;
                r2 = r57;
                r0.log(r1, r2, r5);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM";
                r58 = "-------------------------------";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM _id";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0._id;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM blood_sugar_eat";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.blood_sugar_eat;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM blood_sugar_type";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.blood_sugar_type;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM_blood_sugar_value";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.blood_sugar_value;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM category";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.category;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM device_id";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.device_id;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM input_date";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.input_date;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM insulin_name";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.insulin_name;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM insulin_type";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.insulin_type;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM insulin_value";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.insulin_value;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM note_content";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.note_content;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM note_picture";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.note_picture;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM note_picture_thumb";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.note_picture_thumb;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM note_type";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.note_type;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM seq";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.seq;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM system_date";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.system_date;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM update_flag";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.update_flag;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM user_id";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = " : ";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r38;
                r0 = r0.user_id;	 Catch:{ Exception -> 0x02f0 }
                r59 = r0;
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "logDM";
                r58 = "-------------------------------";
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.myEmail;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r38;
                r1.user_id = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "myEmail";
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r58 = r0;
                r0 = r58;
                r0 = r0.myEmail;	 Catch:{ Exception -> 0x02f0 }
                r58 = r0;
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.listLogDMDynamic;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r38;
                r0.add(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.lastValuesList;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r56.<init>();	 Catch:{ Exception -> 0x02f0 }
                r57 = "20";
                r56 = r56.append(r57);	 Catch:{ Exception -> 0x02f0 }
                r57 = "%02d%02d%02d%02d%02d";
                r58 = 5;
                r0 = r58;
                r0 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x02f0 }
                r58 = r0;
                r59 = 0;
                r60 = java.lang.Integer.valueOf(r54);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r59 = 1;
                r60 = java.lang.Integer.valueOf(r43);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r59 = 2;
                r60 = java.lang.Integer.valueOf(r23);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r59 = 3;
                r60 = java.lang.Integer.valueOf(r33);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r59 = 4;
                r60 = java.lang.Integer.valueOf(r42);	 Catch:{ Exception -> 0x02f0 }
                r58[r59] = r60;	 Catch:{ Exception -> 0x02f0 }
                r57 = java.lang.String.format(r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r56 = r56.append(r57);	 Catch:{ Exception -> 0x02f0 }
                r0 = r56;
                r56 = r0.append(r8);	 Catch:{ Exception -> 0x02f0 }
                r0 = r56;
                r56 = r0.append(r5);	 Catch:{ Exception -> 0x02f0 }
                r56 = r56.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.add(r56);	 Catch:{ Exception -> 0x02f0 }
                r52 = r52 + 1;
                goto L_0x105d;
            L_0x16f8:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r21 = r55.getTimeArray();	 Catch:{ Exception -> 0x02f0 }
                r55 = 50;
                r0 = r55;
                r0 = new byte[r0];	 Catch:{ Exception -> 0x02f0 }
                r22 = r0;
                r55 = 0;
                r56 = 50;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 1;
                r56 = 8;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r56 = 3;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 3;
                r56 = -2;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 4;
                r56 = 17;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 5;
                r56 = 34;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 6;
                r56 = 51;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 7;
                r56 = 68;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 8;
                r56 = 85;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 9;
                r56 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 10;
                r56 = 1;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 11;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 12;
                r56 = 11;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 13;
                r56 = 2;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 14;
                r56 = 8;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 15;
                r56 = 2;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 16;
                r56 = 65;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 17;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 18;
                r56 = 0;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 19;
                r56 = 1;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 20;
                r56 = 2;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 21;
                r56 = 3;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 22;
                r56 = 4;
                r56 = r21[r56];	 Catch:{ Exception -> 0x02f0 }
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 23;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 24;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 25;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 26;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 27;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 28;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 29;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 30;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 31;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 32;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 33;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 34;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 35;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 36;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 37;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 38;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 39;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 40;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 41;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 42;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 43;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 44;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 45;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 46;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 47;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 48;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r55 = 49;
                r56 = 0;
                r22[r55] = r56;	 Catch:{ Exception -> 0x02f0 }
                r0 = r45;
                r1 = r22;
                r22 = r0.transceive(r1);	 Catch:{ Exception -> 0x18e1 }
                r44 = android.os.Message.obtain();	 Catch:{ Exception -> 0x02f0 }
                r55 = 5;
                r0 = r55;
                r1 = r44;
                r1.what = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.mainHandler;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r44;
                r0.sendMessage(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x02f0 }
                if (r45 == 0) goto L_0x188f;
            L_0x1877:
                r45.close();	 Catch:{ IOException -> 0x1988 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x1988 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x1988 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "if (nfc != null) nfc.close();";
                r55.log(r56, r57, r58);	 Catch:{ IOException -> 0x1988 }
            L_0x188f:
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "void run";
                r58 = "end";
                r55.log(r56, r57, r58);
                r44 = android.os.Message.obtain();
                r55 = 6;
                r0 = r55;
                r1 = r44;
                r1.what = r0;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.mainHandler;
                r55 = r0;
                r0 = r55;
                r1 = r44;
                r0.sendMessage(r1);
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r56 = "";
                r0 = r56;
                r1 = r55;
                r1.DEVICE_ID = r0;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;
                goto L_0x028b;
            L_0x18e1:
                r30 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x02f0 }
                r58.<init>();	 Catch:{ Exception -> 0x02f0 }
                r59 = "} catch (Exception err) {";
                r58 = r58.append(r59);	 Catch:{ Exception -> 0x02f0 }
                r0 = r58;
                r1 = r30;
                r58 = r0.append(r1);	 Catch:{ Exception -> 0x02f0 }
                r58 = r58.toString();	 Catch:{ Exception -> 0x02f0 }
                r55.log(r56, r57, r58);	 Catch:{ Exception -> 0x02f0 }
                r30.printStackTrace();	 Catch:{ Exception -> 0x02f0 }
                r44 = android.os.Message.obtain();	 Catch:{ Exception -> 0x02f0 }
                r55 = 2;
                r0 = r55;
                r1 = r44;
                r1.what = r0;	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r0 = r0.mainHandler;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r0 = r55;
                r1 = r44;
                r0.sendMessage(r1);	 Catch:{ Exception -> 0x02f0 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x02f0 }
                r55 = r0;
                r56 = 0;
                r0 = r56;
                r1 = r55;
                r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x02f0 }
                if (r45 == 0) goto L_0x028b;
            L_0x193e:
                r45.close();	 Catch:{ IOException -> 0x1958 }
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x1958 }
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;	 Catch:{ IOException -> 0x1958 }
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = "if (nfc != null) nfc.close();";
                r55.log(r56, r57, r58);	 Catch:{ IOException -> 0x1958 }
                goto L_0x028b;
            L_0x1958:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "IOException";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r28.printStackTrace();
                goto L_0x028b;
            L_0x1988:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r55 = r0;
                r0 = r55;
                r0 = r0.logCat;
                r55 = r0;
                r56 = "ContainerFragmentActivity";
                r57 = "D-Tag";
                r58 = new java.lang.StringBuilder;
                r58.<init>();
                r59 = "IOException";
                r58 = r58.append(r59);
                r0 = r58;
                r1 = r28;
                r58 = r0.append(r1);
                r58 = r58.toString();
                r55.log(r56, r57, r58);
                r28.printStackTrace();
                goto L_0x188f;
            L_0x19b8:
                r28 = move-exception;
                r0 = r61;
                r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                r56 = r0;
                r0 = r56;
                r0 = r0.logCat;
                r56 = r0;
                r57 = "ContainerFragmentActivity";
                r58 = "D-Tag";
                r59 = new java.lang.StringBuilder;
                r59.<init>();
                r60 = "IOException";
                r59 = r59.append(r60);
                r0 = r59;
                r1 = r28;
                r59 = r0.append(r1);
                r59 = r59.toString();
                r56.log(r57, r58, r59);
                r28.printStackTrace();
                goto L_0x03c6;
                */
                throw new UnsupportedOperationException("Method not decompiled: com.accumed.gtech.ContainerFragmentActivity.33.run():void");
            }
        }).start();
    }

    public void getGlucometerDataByDTag() {
        this.lastValuesList.clear();
        if (!this.FLAG_MEASURE) {
            this.FLAG_MEASURE = true;
            this.myEmail = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
            this.listLogDMDynamic.clear();
            this.logCat.log(className, "getGlucometerData", "in");
            showProgressBar();
            this.FLAG_FOLLOW_CONTROL_MEASURE_DATA = false;
            new Thread(new Runnable() {
                /* JADX WARNING: inconsistent code. */
                /* Code decompiled incorrectly, please refer to instructions dump. */
                public void run() {
                    /*
                    r87 = this;
                    r79 = com.accumed.gtech.ContainerFragmentActivity.mTag;
                    r60 = android.nfc.tech.NfcA.get(r79);
                    r36 = 0;
                    r64 = 14;
                    r60.connect();	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "NfcA.connect() by UID : ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r83 = r0;
                    r0 = r83;
                    r0 = r0.uid;	 Catch:{ Exception -> 0x05bc }
                    r83 = r0;
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "nfc.getTimeout() : ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r60.getTimeout();	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", nfc.getMaxTransceiveLength():";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r60.getMaxTransceiveLength();	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", nfc.getAtqa() : ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r60.getAtqa();	 Catch:{ Exception -> 0x05bc }
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", nfc.getSak() : ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r60.getSak();	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r0 = r79;
                    r0 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r18 = r0;
                    r18 = {-76, -1};	 Catch:{ Exception -> 0x05bc }
                    r0 = r60;
                    r1 = r18;
                    r19 = r0.transceive(r1);	 Catch:{ Exception -> 0x05bc }
                    r79 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r19);	 Catch:{ Exception -> 0x05bc }
                    r79 = r79.toUpperCase();	 Catch:{ Exception -> 0x05bc }
                    r80 = "1A";
                    r79 = r79.startsWith(r80);	 Catch:{ Exception -> 0x05bc }
                    if (r79 != 0) goto L_0x00d6;
                L_0x00c6:
                    r79 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r19);	 Catch:{ Exception -> 0x05bc }
                    r79 = r79.toUpperCase();	 Catch:{ Exception -> 0x05bc }
                    r80 = "88";
                    r79 = r79.startsWith(r80);	 Catch:{ Exception -> 0x05bc }
                    if (r79 == 0) goto L_0x0587;
                L_0x00d6:
                    r36 = 1;
                L_0x00d8:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "clear flag[res]:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r19);	 Catch:{ Exception -> 0x05bc }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", dueNext:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r36;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r79 = 20;
                    r0 = r79;
                    r0 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r31 = r0;
                    r31 = {-77, 19, 6, 67, 16, 17, 34, 51, 68, 85, 102, 1, 0, 11, 2, 6, 2, 16, 64, -86};	 Catch:{ Exception -> 0x05bc }
                    r0 = r60;
                    r1 = r31;
                    r37 = r0.transceive(r1);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "device info[req]:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r31);	 Catch:{ Exception -> 0x05bc }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "device info[res]:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r37);	 Catch:{ Exception -> 0x05bc }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r23 = new java.text.SimpleDateFormat;	 Catch:{ Exception -> 0x05bc }
                    r79 = "yyyy-MM-dd HH:mm";
                    r0 = r23;
                    r1 = r79;
                    r0.<init>(r1);	 Catch:{ Exception -> 0x05bc }
                    r79 = 16;
                    r79 = r37[r79];	 Catch:{ Exception -> 0x05bc }
                    r79 = com.accumed.gtech.nfc.NfcUtils.oneBytesToInt(r79);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r0 = r0 + 2000;
                    r78 = r0;
                    r79 = 17;
                    r79 = r37[r79];	 Catch:{ Exception -> 0x05bc }
                    r57 = com.accumed.gtech.nfc.NfcUtils.oneBytesToInt(r79);	 Catch:{ Exception -> 0x05bc }
                    r79 = 18;
                    r79 = r37[r79];	 Catch:{ Exception -> 0x05bc }
                    r25 = com.accumed.gtech.nfc.NfcUtils.oneBytesToInt(r79);	 Catch:{ Exception -> 0x05bc }
                    r79 = 19;
                    r79 = r37[r79];	 Catch:{ Exception -> 0x05bc }
                    r47 = com.accumed.gtech.nfc.NfcUtils.oneBytesToInt(r79);	 Catch:{ Exception -> 0x05bc }
                    r79 = 20;
                    r79 = r37[r79];	 Catch:{ Exception -> 0x05bc }
                    r56 = com.accumed.gtech.nfc.NfcUtils.oneBytesToInt(r79);	 Catch:{ Exception -> 0x05bc }
                    r28 = new java.util.Date;	 Catch:{ Exception -> 0x05bc }
                    r28.<init>();	 Catch:{ Exception -> 0x05bc }
                    r79 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r79.<init>();	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r78;
                    r79 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r80 = "-";
                    r79 = r79.append(r80);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r57;
                    r79 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r80 = "-";
                    r79 = r79.append(r80);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r25;
                    r79 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r80 = " ";
                    r79 = r79.append(r80);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r47;
                    r79 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r80 = ":";
                    r79 = r79.append(r80);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r56;
                    r79 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r79 = r79.toString();	 Catch:{ Exception -> 0x05bc }
                    r0 = r23;
                    r1 = r79;
                    r28 = r0.parse(r1);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "deviceDate >> yyyy-MM-dd HH:mm = ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r23;
                    r1 = r28;
                    r83 = r0.format(r1);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r13 = new java.util.Date;	 Catch:{ Exception -> 0x05bc }
                    r80 = java.lang.System.currentTimeMillis();	 Catch:{ Exception -> 0x05bc }
                    r0 = r80;
                    r13.<init>(r0);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "AppDate    >> yyyy-MM-dd HH:mm = ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r23;
                    r83 = r0.format(r13);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r27 = java.util.Calendar.getInstance();	 Catch:{ Exception -> 0x05bc }
                    r12 = java.util.Calendar.getInstance();	 Catch:{ Exception -> 0x05bc }
                    r27.setTime(r28);	 Catch:{ Exception -> 0x05bc }
                    r12.setTime(r13);	 Catch:{ Exception -> 0x05bc }
                    r80 = r12.getTimeInMillis();	 Catch:{ Exception -> 0x05bc }
                    r82 = r27.getTimeInMillis();	 Catch:{ Exception -> 0x05bc }
                    r80 = r80 - r82;
                    r0 = r80;
                    r0 = (int) r0;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r33 = java.lang.Math.abs(r79);	 Catch:{ Exception -> 0x05bc }
                    r79 = 60000; // 0xea60 float:8.4078E-41 double:2.9644E-319;
                    r0 = r33;
                    r1 = r79;
                    if (r0 <= r1) goto L_0x058b;
                L_0x02a1:
                    r35 = 1;
                L_0x02a3:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "diff[min]:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r33;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", dueFixTime:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r35;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    if (r35 == 0) goto L_0x0495;
                L_0x02dd:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r61 = r79.getTimeArray();	 Catch:{ Exception -> 0x05bc }
                    r79 = 52;
                    r0 = r79;
                    r0 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r44 = r0;
                    r79 = 0;
                    r80 = -77;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 51;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = 8;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = 67;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 4;
                    r80 = 16;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 5;
                    r80 = 17;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 6;
                    r80 = 34;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 7;
                    r80 = 51;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 8;
                    r80 = 68;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 9;
                    r80 = 85;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 10;
                    r80 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 11;
                    r80 = 1;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 12;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 13;
                    r80 = 11;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 14;
                    r80 = 2;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 15;
                    r80 = 8;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 16;
                    r80 = 2;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 17;
                    r80 = 65;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 18;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 19;
                    r80 = 0;
                    r80 = r61[r80];	 Catch:{ Exception -> 0x05bc }
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 20;
                    r80 = 1;
                    r80 = r61[r80];	 Catch:{ Exception -> 0x05bc }
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 21;
                    r80 = 2;
                    r80 = r61[r80];	 Catch:{ Exception -> 0x05bc }
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 22;
                    r80 = 3;
                    r80 = r61[r80];	 Catch:{ Exception -> 0x05bc }
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 23;
                    r80 = 4;
                    r80 = r61[r80];	 Catch:{ Exception -> 0x05bc }
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 24;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 25;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 26;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 27;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 28;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 29;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 30;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 31;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 32;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 33;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 34;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 35;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 36;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 37;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 38;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 39;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 40;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 41;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 42;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 43;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 44;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 45;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 46;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 47;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 48;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 49;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 50;
                    r80 = 0;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 51;
                    r80 = -86;
                    r44[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r0 = r60;
                    r1 = r44;
                    r45 = r0.transceive(r1);	 Catch:{ Exception -> 0x058f }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x058f }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x058f }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x058f }
                    r82.<init>();	 Catch:{ Exception -> 0x058f }
                    r83 = "fix_date_time[req]:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x058f }
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r44);	 Catch:{ Exception -> 0x058f }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x058f }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x058f }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x058f }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x058f }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x058f }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x058f }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x058f }
                    r82.<init>();	 Catch:{ Exception -> 0x058f }
                    r83 = "fix_date_time[res]:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x058f }
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r45);	 Catch:{ Exception -> 0x058f }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x058f }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x058f }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x058f }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x058f }
                L_0x0495:
                    r79 = 16;
                    r0 = r79;
                    r0 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r32 = r0;
                    r79 = 30;
                    r80 = 0;
                    r81 = 16;
                    r0 = r37;
                    r1 = r79;
                    r2 = r32;
                    r3 = r80;
                    r4 = r81;
                    java.lang.System.arraycopy(r0, r1, r2, r3, r4);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r32);	 Catch:{ Exception -> 0x05bc }
                    r80 = r80.toUpperCase();	 Catch:{ Exception -> 0x05bc }
                    r0 = r80;
                    r1 = r79;
                    r1.DEVICE_ID = r0;	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "DEVICE_ID:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r83 = r0;
                    r0 = r83;
                    r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x05bc }
                    r83 = r0;
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.dbAction;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r0 = r80;
                    r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r50 = r79.isRegisterDevice(r80);	 Catch:{ Exception -> 0x05bc }
                    if (r50 != 0) goto L_0x0660;
                L_0x0514:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = " 디바이스 등록여부";
                    r82 = "등록되지 않음";
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r59 = android.os.Message.obtain();	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r0 = r79;
                    r1 = r59;
                    r1.what = r0;	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.mainHandler;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r1 = r59;
                    r0.sendMessage(r1);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = 0;
                    r0 = r80;
                    r1 = r79;
                    r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x05bc }
                L_0x0556:
                    r26 = 3;
                    r29 = 2;
                    r30 = r26 * r29;
                    r62 = 1;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.FLAG_FOLLOW_CONTROL_MEASURE_DATA;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    if (r79 != 0) goto L_0x0726;
                L_0x056c:
                    if (r60 == 0) goto L_0x0586;
                L_0x056e:
                    r60.close();	 Catch:{ IOException -> 0x06f6 }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x06f6 }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ IOException -> 0x06f6 }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = "if (nfc != null) nfc.close();";
                    r79.log(r80, r81, r82);	 Catch:{ IOException -> 0x06f6 }
                L_0x0586:
                    return;
                L_0x0587:
                    r36 = 0;
                    goto L_0x00d8;
                L_0x058b:
                    r35 = 0;
                    goto L_0x02a3;
                L_0x058f:
                    r41 = move-exception;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "device time fix, catch (Exception err) {";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r41;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    goto L_0x0495;
                L_0x05bc:
                    r38 = move-exception;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ all -> 0x06c4 }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ all -> 0x06c4 }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ all -> 0x06c4 }
                    r82.<init>();	 Catch:{ all -> 0x06c4 }
                    r83 = "} catch(Exception e){:";
                    r82 = r82.append(r83);	 Catch:{ all -> 0x06c4 }
                    r0 = r82;
                    r1 = r38;
                    r82 = r0.append(r1);	 Catch:{ all -> 0x06c4 }
                    r82 = r82.toString();	 Catch:{ all -> 0x06c4 }
                    r79.log(r80, r81, r82);	 Catch:{ all -> 0x06c4 }
                    r59 = android.os.Message.obtain();	 Catch:{ all -> 0x06c4 }
                    r79 = 2;
                    r0 = r79;
                    r1 = r59;
                    r1.what = r0;	 Catch:{ all -> 0x06c4 }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ all -> 0x06c4 }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.mainHandler;	 Catch:{ all -> 0x06c4 }
                    r79 = r0;
                    r0 = r79;
                    r1 = r59;
                    r0.sendMessage(r1);	 Catch:{ all -> 0x06c4 }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ all -> 0x06c4 }
                    r79 = r0;
                    r80 = 0;
                    r0 = r80;
                    r1 = r79;
                    r1.FLAG_MEASURE = r0;	 Catch:{ all -> 0x06c4 }
                    if (r60 == 0) goto L_0x0586;
                L_0x0616:
                    r60.close();	 Catch:{ IOException -> 0x0630 }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x0630 }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ IOException -> 0x0630 }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = "if (nfc != null) nfc.close();";
                    r79.log(r80, r81, r82);	 Catch:{ IOException -> 0x0630 }
                    goto L_0x0586;
                L_0x0630:
                    r38 = move-exception;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;
                    r82.<init>();
                    r83 = "IOException";
                    r82 = r82.append(r83);
                    r0 = r82;
                    r1 = r38;
                    r82 = r0.append(r1);
                    r82 = r82.toString();
                    r79.log(r80, r81, r82);
                    r38.printStackTrace();
                    goto L_0x0586;
                L_0x0660:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = " 디바이스 등록여부";
                    r82 = "이미 등록되어 있음";
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r42 = new java.text.SimpleDateFormat;	 Catch:{ Exception -> 0x05bc }
                    r79 = "yyyyMMddHHmmssmmm";
                    r0 = r42;
                    r1 = r79;
                    r0.<init>(r1);	 Catch:{ Exception -> 0x05bc }
                    r80 = java.lang.System.currentTimeMillis();	 Catch:{ Exception -> 0x05bc }
                    r79 = java.lang.Long.valueOf(r80);	 Catch:{ Exception -> 0x05bc }
                    r0 = r42;
                    r1 = r79;
                    r74 = r0.format(r1);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.dbAction;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r0 = r80;
                    r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r0 = r79;
                    r1 = r80;
                    r2 = r74;
                    r79 = r0.updateDateDevice(r1, r2);	 Catch:{ Exception -> 0x05bc }
                    if (r79 == 0) goto L_0x06e0;
                L_0x06b4:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = 1;
                    r0 = r80;
                    r1 = r79;
                    r1.FLAG_FOLLOW_CONTROL_MEASURE_DATA = r0;	 Catch:{ Exception -> 0x05bc }
                    goto L_0x0556;
                L_0x06c4:
                    r79 = move-exception;
                    if (r60 == 0) goto L_0x06df;
                L_0x06c7:
                    r60.close();	 Catch:{ IOException -> 0x0ede }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x0ede }
                    r80 = r0;
                    r0 = r80;
                    r0 = r0.logCat;	 Catch:{ IOException -> 0x0ede }
                    r80 = r0;
                    r81 = "ContainerFragmentActivity";
                    r82 = "D-Tag";
                    r83 = "if (nfc != null) nfc.close();";
                    r80.log(r81, r82, r83);	 Catch:{ IOException -> 0x0ede }
                L_0x06df:
                    throw r79;
                L_0x06e0:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "failed";
                    r82 = "디바이스 날짜 업데이트 실패 - 디비액션 실패";
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    goto L_0x06b4;
                L_0x06f6:
                    r38 = move-exception;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;
                    r82.<init>();
                    r83 = "IOException";
                    r82 = r82.append(r83);
                    r0 = r82;
                    r1 = r38;
                    r82 = r0.append(r1);
                    r82 = r82.toString();
                    r79.log(r80, r81, r82);
                    r38.printStackTrace();
                    goto L_0x0586;
                L_0x0726:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = "Measure Data Start...";
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r79 = 4;
                    r0 = r79;
                    r0 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r73 = r0;
                    r79 = 0;
                    r80 = 0;
                    r73[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 0;
                    r73[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = 21;
                    r80 = r37[r80];	 Catch:{ Exception -> 0x05bc }
                    r73[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = 22;
                    r80 = r37[r80];	 Catch:{ Exception -> 0x05bc }
                    r73[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r0 = r73;
                    r1 = r79;
                    r21 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r0, r1);	 Catch:{ Exception -> 0x05bc }
                    r68 = r21 / r30;
                    r65 = r21 % r30;
                    r72 = 1;
                    r40 = r30;
                    if (r65 <= 0) goto L_0x0d43;
                L_0x0773:
                    r79 = 1;
                L_0x0775:
                    r34 = r68 + r79;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "Measure Data count:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r21;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", 몫 :";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r68;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", 나머지:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r65;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r83 = ">> dueCnt:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r34;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r49 = 0;
                L_0x07cd:
                    r0 = r49;
                    r1 = r34;
                    if (r0 >= r1) goto L_0x0e2b;
                L_0x07d3:
                    r79 = r49 * 6;
                    r79 = r79 + r72;
                    r0 = r79;
                    r0 = r0 / 256;
                    r22 = r0;
                    r79 = r49 * 6;
                    r79 = r79 + r72;
                    r0 = r79;
                    r0 = r0 % 256;
                    r38 = r0;
                    r79 = r49 * 6;
                    r79 = r79 + 6;
                    r0 = r79;
                    r0 = r0 / 256;
                    r42 = r0;
                    r79 = r49 * 6;
                    r79 = r79 + 6;
                    r0 = r79;
                    r0 = r0 % 256;
                    r46 = r0;
                    r79 = r34 + -1;
                    r0 = r49;
                    r1 = r79;
                    if (r0 != r1) goto L_0x0d47;
                L_0x0803:
                    if (r65 <= 0) goto L_0x0d47;
                L_0x0805:
                    r79 = r49 * 6;
                    r79 = r79 + r72;
                    r79 = r79 + r65;
                    r0 = r79;
                    r0 = r0 / 256;
                    r42 = r0;
                    r79 = r49 * 6;
                    r79 = r79 + r72;
                    r79 = r79 + r65;
                    r0 = r79;
                    r0 = r0 % 256;
                    r46 = r0;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "start_byte : ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r49 * 6;
                    r83 = r83 + r72;
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", end_byte : ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r49 * 6;
                    r83 = r83 + r72;
                    r83 = r83 + r65;
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                L_0x0857:
                    r79 = 22;
                    r0 = r79;
                    r0 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r54 = r0;
                    r79 = 0;
                    r80 = -77;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 21;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = 6;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = 67;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 4;
                    r80 = 16;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 5;
                    r80 = 17;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 6;
                    r80 = 34;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 7;
                    r80 = 51;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 8;
                    r80 = 68;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 9;
                    r80 = 85;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 10;
                    r80 = 102; // 0x66 float:1.43E-43 double:5.04E-322;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 11;
                    r80 = 1;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 12;
                    r80 = 0;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 13;
                    r80 = 11;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 14;
                    r80 = 3;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 15;
                    r80 = 6;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 16;
                    r80 = 2;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 17;
                    r0 = r22;
                    r0 = (byte) r0;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 18;
                    r0 = r38;
                    r0 = (byte) r0;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 19;
                    r0 = r42;
                    r0 = (byte) r0;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 20;
                    r0 = r46;
                    r0 = (byte) r0;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 21;
                    r80 = -86;
                    r54[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r53 = 0;
                    r0 = r60;
                    r1 = r54;
                    r53 = r0.transceive(r1);	 Catch:{ Exception -> 0x0d81 }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x0d81 }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x0d81 }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0d81 }
                    r82.<init>();	 Catch:{ Exception -> 0x0d81 }
                    r83 = "measure_data[req]:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x0d81 }
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r54);	 Catch:{ Exception -> 0x0d81 }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x0d81 }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x0d81 }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x0d81 }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x0d81 }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x0d81 }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x0d81 }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x0d81 }
                    r82.<init>();	 Catch:{ Exception -> 0x0d81 }
                    r83 = "measure_data[res]:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x0d81 }
                    r83 = com.accumed.gtech.nfc.NfcUtils.byteArrayToHex(r53);	 Catch:{ Exception -> 0x0d81 }
                    r83 = r83.toUpperCase();	 Catch:{ Exception -> 0x0d81 }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x0d81 }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x0d81 }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x0d81 }
                    r66 = r30;
                    r67 = "";
                    r79 = r34 + -1;
                    r0 = r49;
                    r1 = r79;
                    if (r0 != r1) goto L_0x0967;
                L_0x0961:
                    if (r65 <= 0) goto L_0x0967;
                L_0x0963:
                    r66 = r65;
                    r67 = "rest:";
                L_0x0967:
                    r75 = 0;
                    r63 = r62;
                L_0x096b:
                    r0 = r75;
                    r1 = r66;
                    if (r0 >= r1) goto L_0x0e25;
                L_0x0971:
                    r79 = 4;
                    r0 = r79;
                    r0 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r76 = r0;
                    r79 = 0;
                    r80 = 0;
                    r76[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 0;
                    r76[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = 0;
                    r76[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = r75 * 8;
                    r80 = r80 + r64;
                    r80 = r80 + 0;
                    r80 = r53[r80];	 Catch:{ Exception -> 0x05bc }
                    r76[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r0 = r76;
                    r1 = r79;
                    r77 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r0, r1);	 Catch:{ Exception -> 0x05bc }
                    r79 = 4;
                    r0 = r79;
                    r9 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r80 = 0;
                    r9[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 0;
                    r9[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = 0;
                    r9[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = r75 * 8;
                    r80 = r80 + r64;
                    r80 = r80 + 1;
                    r80 = r53[r80];	 Catch:{ Exception -> 0x05bc }
                    r9[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r0 = r79;
                    r58 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r9, r0);	 Catch:{ Exception -> 0x05bc }
                    r79 = 4;
                    r0 = r79;
                    r6 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r80 = 0;
                    r6[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 0;
                    r6[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = 0;
                    r6[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = r75 * 8;
                    r80 = r80 + r64;
                    r80 = r80 + 2;
                    r80 = r53[r80];	 Catch:{ Exception -> 0x05bc }
                    r6[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r0 = r79;
                    r24 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r6, r0);	 Catch:{ Exception -> 0x05bc }
                    r79 = 4;
                    r0 = r79;
                    r8 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r80 = 0;
                    r8[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 0;
                    r8[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = 0;
                    r8[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = r75 * 8;
                    r80 = r80 + r64;
                    r80 = r80 + 3;
                    r80 = r53[r80];	 Catch:{ Exception -> 0x05bc }
                    r8[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r0 = r79;
                    r48 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r8, r0);	 Catch:{ Exception -> 0x05bc }
                    r79 = 4;
                    r0 = r79;
                    r0 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r52 = r0;
                    r79 = 0;
                    r80 = 0;
                    r52[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 0;
                    r52[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = 0;
                    r52[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = r75 * 8;
                    r80 = r80 + r64;
                    r80 = r80 + 4;
                    r80 = r53[r80];	 Catch:{ Exception -> 0x05bc }
                    r52[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r0 = r52;
                    r1 = r79;
                    r55 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r0, r1);	 Catch:{ Exception -> 0x05bc }
                    r79 = 4;
                    r0 = r79;
                    r15 = new byte[r0];	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r80 = 0;
                    r15[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 1;
                    r80 = 0;
                    r15[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r80 = r75 * 8;
                    r80 = r80 + r64;
                    r80 = r80 + 5;
                    r80 = r53[r80];	 Catch:{ Exception -> 0x05bc }
                    r15[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 3;
                    r80 = r75 * 8;
                    r80 = r80 + r64;
                    r80 = r80 + 6;
                    r80 = r53[r80];	 Catch:{ Exception -> 0x05bc }
                    r15[r79] = r80;	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r0 = r79;
                    r17 = com.accumed.gtech.nfc.NfcUtils.bytesToInt(r15, r0);	 Catch:{ Exception -> 0x05bc }
                    r79 = r75 * 8;
                    r79 = r79 + r64;
                    r79 = r79 + 7;
                    r16 = r53[r79];	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "[";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r62 = r63 + 1;
                    r0 = r82;
                    r1 = r63;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r83 = "]logDM.device_id:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r83 = r0;
                    r0 = r83;
                    r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x05bc }
                    r83 = r0;
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ",logDM.input_date:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = "%02d%02d%02d%02d%02d";
                    r84 = 5;
                    r0 = r84;
                    r0 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x05bc }
                    r84 = r0;
                    r85 = 0;
                    r86 = java.lang.Integer.valueOf(r77);	 Catch:{ Exception -> 0x05bc }
                    r84[r85] = r86;	 Catch:{ Exception -> 0x05bc }
                    r85 = 1;
                    r86 = java.lang.Integer.valueOf(r58);	 Catch:{ Exception -> 0x05bc }
                    r84[r85] = r86;	 Catch:{ Exception -> 0x05bc }
                    r85 = 2;
                    r86 = java.lang.Integer.valueOf(r24);	 Catch:{ Exception -> 0x05bc }
                    r84[r85] = r86;	 Catch:{ Exception -> 0x05bc }
                    r85 = 3;
                    r86 = java.lang.Integer.valueOf(r48);	 Catch:{ Exception -> 0x05bc }
                    r84[r85] = r86;	 Catch:{ Exception -> 0x05bc }
                    r85 = 4;
                    r86 = java.lang.Integer.valueOf(r55);	 Catch:{ Exception -> 0x05bc }
                    r84[r85] = r86;	 Catch:{ Exception -> 0x05bc }
                    r83 = java.lang.String.format(r83, r84);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = "00000,bloodsugar:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = java.lang.Integer.toString(r17);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ",blood_sugar_event:";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = com.accumed.gtech.nfc.NfcUtils.oneBytesToInt(r16);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r67;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r83 = "[";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r75 + 1;
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = "]";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r20 = 0;
                    r14 = 0;
                    r11 = 0;
                    r43 = 0;
                    r79 = r16 & 2;
                    if (r79 <= 0) goto L_0x0b59;
                L_0x0b57:
                    r20 = 1;
                L_0x0b59:
                    r79 = r16 & 16;
                    if (r79 <= 0) goto L_0x0b5e;
                L_0x0b5d:
                    r14 = 1;
                L_0x0b5e:
                    r79 = r16 & 32;
                    if (r79 <= 0) goto L_0x0b63;
                L_0x0b62:
                    r11 = 1;
                L_0x0b63:
                    r79 = r16 & 64;
                    if (r79 <= 0) goto L_0x0b69;
                L_0x0b67:
                    r43 = 1;
                L_0x0b69:
                    r51 = new com.accumed.gtech.datamodel.LogDM;	 Catch:{ Exception -> 0x05bc }
                    r51.<init>();	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.DEVICE_ID;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r1 = r51;
                    r1.device_id = r0;	 Catch:{ Exception -> 0x05bc }
                    r79 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r79.<init>();	 Catch:{ Exception -> 0x05bc }
                    r80 = "20";
                    r79 = r79.append(r80);	 Catch:{ Exception -> 0x05bc }
                    r80 = "%02d%02d%02d%02d%02d";
                    r81 = 5;
                    r0 = r81;
                    r0 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x05bc }
                    r81 = r0;
                    r82 = 0;
                    r83 = java.lang.Integer.valueOf(r77);	 Catch:{ Exception -> 0x05bc }
                    r81[r82] = r83;	 Catch:{ Exception -> 0x05bc }
                    r82 = 1;
                    r83 = java.lang.Integer.valueOf(r58);	 Catch:{ Exception -> 0x05bc }
                    r81[r82] = r83;	 Catch:{ Exception -> 0x05bc }
                    r82 = 2;
                    r83 = java.lang.Integer.valueOf(r24);	 Catch:{ Exception -> 0x05bc }
                    r81[r82] = r83;	 Catch:{ Exception -> 0x05bc }
                    r82 = 3;
                    r83 = java.lang.Integer.valueOf(r48);	 Catch:{ Exception -> 0x05bc }
                    r81[r82] = r83;	 Catch:{ Exception -> 0x05bc }
                    r82 = 4;
                    r83 = java.lang.Integer.valueOf(r55);	 Catch:{ Exception -> 0x05bc }
                    r81[r82] = r83;	 Catch:{ Exception -> 0x05bc }
                    r80 = java.lang.String.format(r80, r81);	 Catch:{ Exception -> 0x05bc }
                    r79 = r79.append(r80);	 Catch:{ Exception -> 0x05bc }
                    r80 = "00000";
                    r79 = r79.append(r80);	 Catch:{ Exception -> 0x05bc }
                    r79 = r79.toString();	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.input_date = r0;	 Catch:{ Exception -> 0x05bc }
                    r79 = java.lang.Integer.toString(r17);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.blood_sugar_value = r0;	 Catch:{ Exception -> 0x05bc }
                    r79 = "0";
                    r0 = r79;
                    r1 = r51;
                    r1.blood_sugar_type = r0;	 Catch:{ Exception -> 0x05bc }
                    r79 = 0;
                    r79 = java.lang.Integer.toString(r79);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.category = r0;	 Catch:{ Exception -> 0x05bc }
                    r79 = "insert";
                    r0 = r79;
                    r1 = r51;
                    r1.update_flag = r0;	 Catch:{ Exception -> 0x05bc }
                    r39 = 0;
                    r79 = 1;
                    r0 = r20;
                    r1 = r79;
                    if (r0 != r1) goto L_0x0c13;
                L_0x0c05:
                    r79 = 2;
                    r79 = java.lang.Integer.toString(r79);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x05bc }
                    r39 = r39 + 1;
                L_0x0c13:
                    r79 = 1;
                    r0 = r79;
                    if (r14 != r0) goto L_0x0c27;
                L_0x0c19:
                    r79 = 1;
                    r79 = java.lang.Integer.toString(r79);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x05bc }
                    r39 = r39 + 1;
                L_0x0c27:
                    r79 = 1;
                    r0 = r79;
                    if (r11 != r0) goto L_0x0c3b;
                L_0x0c2d:
                    r79 = 0;
                    r79 = java.lang.Integer.toString(r79);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x05bc }
                    r39 = r39 + 1;
                L_0x0c3b:
                    r79 = 1;
                    r0 = r43;
                    r1 = r79;
                    if (r0 != r1) goto L_0x0c51;
                L_0x0c43:
                    r79 = 3;
                    r79 = java.lang.Integer.toString(r79);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x05bc }
                    r39 = r39 + 1;
                L_0x0c51:
                    if (r39 != 0) goto L_0x0c5f;
                L_0x0c53:
                    r79 = 4;
                    r79 = java.lang.Integer.toString(r79);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.blood_sugar_eat = r0;	 Catch:{ Exception -> 0x05bc }
                L_0x0c5f:
                    r79 = "";
                    r0 = r79;
                    r1 = r51;
                    r1._id = r0;	 Catch:{ Exception -> 0x05bc }
                    r79 = "";
                    r0 = r79;
                    r1 = r51;
                    r1.user_id = r0;	 Catch:{ Exception -> 0x05bc }
                    r69 = new java.text.SimpleDateFormat;	 Catch:{ Exception -> 0x05bc }
                    r79 = "yyyyMMddHHmmss";
                    r0 = r69;
                    r1 = r79;
                    r0.<init>(r1);	 Catch:{ Exception -> 0x05bc }
                    r70 = java.lang.System.nanoTime();	 Catch:{ Exception -> 0x05bc }
                    r79 = java.lang.Long.toString(r70);	 Catch:{ Exception -> 0x05bc }
                    r0 = r79;
                    r1 = r51;
                    r1.system_date = r0;	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.util;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r51;
                    r0 = r0.blood_sugar_value;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r10 = r79.vvv(r80);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.util;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r51;
                    r0 = r0.blood_sugar_eat;	 Catch:{ Exception -> 0x05bc }
                    r80 = r0;
                    r7 = r79.ee(r80);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.myEmail;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r1 = r51;
                    r1.user_id = r0;	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.listLogDMDynamic;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r1 = r51;
                    r0.add(r1);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.lastValuesList;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r80.<init>();	 Catch:{ Exception -> 0x05bc }
                    r81 = "20";
                    r80 = r80.append(r81);	 Catch:{ Exception -> 0x05bc }
                    r81 = "%02d%02d%02d%02d%02d";
                    r82 = 5;
                    r0 = r82;
                    r0 = new java.lang.Object[r0];	 Catch:{ Exception -> 0x05bc }
                    r82 = r0;
                    r83 = 0;
                    r84 = java.lang.Integer.valueOf(r77);	 Catch:{ Exception -> 0x05bc }
                    r82[r83] = r84;	 Catch:{ Exception -> 0x05bc }
                    r83 = 1;
                    r84 = java.lang.Integer.valueOf(r58);	 Catch:{ Exception -> 0x05bc }
                    r82[r83] = r84;	 Catch:{ Exception -> 0x05bc }
                    r83 = 2;
                    r84 = java.lang.Integer.valueOf(r24);	 Catch:{ Exception -> 0x05bc }
                    r82[r83] = r84;	 Catch:{ Exception -> 0x05bc }
                    r83 = 3;
                    r84 = java.lang.Integer.valueOf(r48);	 Catch:{ Exception -> 0x05bc }
                    r82[r83] = r84;	 Catch:{ Exception -> 0x05bc }
                    r83 = 4;
                    r84 = java.lang.Integer.valueOf(r55);	 Catch:{ Exception -> 0x05bc }
                    r82[r83] = r84;	 Catch:{ Exception -> 0x05bc }
                    r81 = java.lang.String.format(r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r80 = r80.append(r81);	 Catch:{ Exception -> 0x05bc }
                    r0 = r80;
                    r80 = r0.append(r10);	 Catch:{ Exception -> 0x05bc }
                    r0 = r80;
                    r80 = r0.append(r7);	 Catch:{ Exception -> 0x05bc }
                    r80 = r80.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.add(r80);	 Catch:{ Exception -> 0x05bc }
                    r75 = r75 + 1;
                    r63 = r62;
                    goto L_0x096b;
                L_0x0d43:
                    r79 = 0;
                    goto L_0x0775;
                L_0x0d47:
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "start_byte : ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r49 * 6;
                    r83 = r83 + r72;
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = ", end_byte : ";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r83 = r49 * 6;
                    r83 = r83 + 6;
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    goto L_0x0857;
                L_0x0d81:
                    r41 = move-exception;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x05bc }
                    r82.<init>();	 Catch:{ Exception -> 0x05bc }
                    r83 = "measure_data = nfc.transceive(measure_data);1} catch (Exception err) {";
                    r82 = r82.append(r83);	 Catch:{ Exception -> 0x05bc }
                    r0 = r82;
                    r1 = r41;
                    r82 = r0.append(r1);	 Catch:{ Exception -> 0x05bc }
                    r82 = r82.toString();	 Catch:{ Exception -> 0x05bc }
                    r79.log(r80, r81, r82);	 Catch:{ Exception -> 0x05bc }
                    r59 = android.os.Message.obtain();	 Catch:{ Exception -> 0x05bc }
                    r79 = 2;
                    r0 = r79;
                    r1 = r59;
                    r1.what = r0;	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.mainHandler;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r1 = r59;
                    r0.sendMessage(r1);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = 0;
                    r0 = r80;
                    r1 = r79;
                    r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x05bc }
                    if (r60 == 0) goto L_0x0586;
                L_0x0ddb:
                    r60.close();	 Catch:{ IOException -> 0x0df5 }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x0df5 }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ IOException -> 0x0df5 }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = "if (nfc != null) nfc.close();";
                    r79.log(r80, r81, r82);	 Catch:{ IOException -> 0x0df5 }
                    goto L_0x0586;
                L_0x0df5:
                    r38 = move-exception;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;
                    r82.<init>();
                    r83 = "IOException";
                    r82 = r82.append(r83);
                    r0 = r82;
                    r1 = r38;
                    r82 = r0.append(r1);
                    r82 = r82.toString();
                    r79.log(r80, r81, r82);
                    r38.printStackTrace();
                    goto L_0x0586;
                L_0x0e25:
                    r49 = r49 + 1;
                    r62 = r63;
                    goto L_0x07cd;
                L_0x0e2b:
                    r59 = android.os.Message.obtain();	 Catch:{ Exception -> 0x05bc }
                    r79 = 5;
                    r0 = r79;
                    r1 = r59;
                    r1.what = r0;	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.mainHandler;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r0 = r79;
                    r1 = r59;
                    r0.sendMessage(r1);	 Catch:{ Exception -> 0x05bc }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ Exception -> 0x05bc }
                    r79 = r0;
                    r80 = 0;
                    r0 = r80;
                    r1 = r79;
                    r1.FLAG_MEASURE = r0;	 Catch:{ Exception -> 0x05bc }
                    if (r60 == 0) goto L_0x0e72;
                L_0x0e5a:
                    r60.close();	 Catch:{ IOException -> 0x0eaf }
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;	 Catch:{ IOException -> 0x0eaf }
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;	 Catch:{ IOException -> 0x0eaf }
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = "if (nfc != null) nfc.close();";
                    r79.log(r80, r81, r82);	 Catch:{ IOException -> 0x0eaf }
                L_0x0e72:
                    r59 = android.os.Message.obtain();
                    r79 = 6;
                    r0 = r79;
                    r1 = r59;
                    r1.what = r0;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.mainHandler;
                    r79 = r0;
                    r0 = r79;
                    r1 = r59;
                    r0.sendMessage(r1);
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                    r79 = r0;
                    r80 = "";
                    r0 = r80;
                    r1 = r79;
                    r1.DEVICE_ID = r0;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                    r79 = r0;
                    r80 = 0;
                    r0 = r80;
                    r1 = r79;
                    r1.FLAG_MEASURE = r0;
                    goto L_0x0586;
                L_0x0eaf:
                    r38 = move-exception;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                    r79 = r0;
                    r0 = r79;
                    r0 = r0.logCat;
                    r79 = r0;
                    r80 = "ContainerFragmentActivity";
                    r81 = "D-Tag";
                    r82 = new java.lang.StringBuilder;
                    r82.<init>();
                    r83 = "IOException";
                    r82 = r82.append(r83);
                    r0 = r82;
                    r1 = r38;
                    r82 = r0.append(r1);
                    r82 = r82.toString();
                    r79.log(r80, r81, r82);
                    r38.printStackTrace();
                    goto L_0x0e72;
                L_0x0ede:
                    r38 = move-exception;
                    r0 = r87;
                    r0 = com.accumed.gtech.ContainerFragmentActivity.this;
                    r80 = r0;
                    r0 = r80;
                    r0 = r0.logCat;
                    r80 = r0;
                    r81 = "ContainerFragmentActivity";
                    r82 = "D-Tag";
                    r83 = new java.lang.StringBuilder;
                    r83.<init>();
                    r84 = "IOException";
                    r83 = r83.append(r84);
                    r0 = r83;
                    r1 = r38;
                    r83 = r0.append(r1);
                    r83 = r83.toString();
                    r80.log(r81, r82, r83);
                    r38.printStackTrace();
                    goto L_0x06df;
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.accumed.gtech.ContainerFragmentActivity.34.run():void");
                }
            }).start();
        }
    }

    public void setGlucometerTime() {
        new Thread(new Runnable() {
            public void run() {
                NfcF nfc = NfcF.get(ContainerFragmentActivity.mTag);
                try {
                    nfc.connect();
                    byte[] dateTime = ContainerFragmentActivity.this.getTimeArray();
                    try {
                        byte[] date_time = nfc.transceive(new byte[]{(byte) 50, (byte) 8, (byte) 3, (byte) -2, (byte) 17, (byte) 34, (byte) 51, (byte) 68, (byte) 85, (byte) 102, (byte) 1, (byte) 0, (byte) 11, (byte) 2, (byte) 8, (byte) 2, (byte) 65, (byte) 0, dateTime[0], dateTime[1], dateTime[2], dateTime[3], dateTime[4], (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0, (byte) 0});
                        if (nfc != null) {
                            try {
                                nfc.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (Exception err) {
                        err.printStackTrace();
                        if (nfc != null) {
                            try {
                                nfc.close();
                            } catch (IOException e2) {
                                e2.printStackTrace();
                            }
                        }
                    }
                } catch (Exception e3) {
                    e3.printStackTrace();
                    if (nfc != null) {
                        try {
                            nfc.close();
                        } catch (IOException e22) {
                            e22.printStackTrace();
                        }
                    }
                } catch (Throwable th) {
                    if (nfc != null) {
                        try {
                            nfc.close();
                        } catch (IOException e222) {
                            e222.printStackTrace();
                        }
                    }
                }
            }
        }).start();
    }

    @SuppressLint({"SimpleDateFormat"})
    private byte[] getTimeArray() {
        String dateTime = new SimpleDateFormat("yyMMddHHmm").format(Long.valueOf(System.currentTimeMillis()));
        String strYear = dateTime.substring(0, 2);
        String strMonth = dateTime.substring(2, 4);
        String strDay = dateTime.substring(4, 6);
        String strHour = dateTime.substring(6, 8);
        String strMinute = dateTime.substring(8);
        byte year = Byte.parseByte(strYear);
        byte month = Byte.parseByte(strMonth);
        byte day = Byte.parseByte(strDay);
        byte hour = Byte.parseByte(strHour);
        byte minute = Byte.parseByte(strMinute);
        return new byte[]{year, month, day, hour, minute};
    }

    private void tabChange(int tabIndex) {
        this.mTabMenu = tabIndex;
        this.logCat.log(className, "tabChange()", "in");
        this.mMargin = 0;
        LinearLayout[] tabArr = new LinearLayout[]{this.tabMenu0, this.tabMenu1, this.tabMenu2, this.tabMenu3};
        for (int i = 0; i < tabArr.length; i++) {
            if (i == tabIndex) {
                tabArr[i].setSelected(true);
            } else {
                tabArr[i].setSelected(false);
            }
        }
    }

    private void showTopTabs() {
        runOnUiThread(new Runnable() {
            public void run() {
            }
        });
    }

    private void hideTopTabs() {
        runOnUiThread(new Runnable() {
            public void run() {
            }
        });
    }

    private void showManualInput() {
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.manualInputLinearLy.setVisibility(0);
                ContainerFragmentActivity.this.inputLy01.setVisibility(0);
                ContainerFragmentActivity.this.inputLy02.setVisibility(0);
                ContainerFragmentActivity.this.inputLy03.setVisibility(0);
                ContainerFragmentActivity.this.inputLy04.setVisibility(0);
                ContainerFragmentActivity.this.inputLy05.setVisibility(8);
            }
        });
    }

    private void hideManualInput(final boolean isAll) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (isAll) {
                    ContainerFragmentActivity.this.manualInputLinearLy.setVisibility(8);
                    return;
                }
                ContainerFragmentActivity.this.manualInputLinearLy.setVisibility(0);
                ContainerFragmentActivity.this.inputLy01.setVisibility(8);
                ContainerFragmentActivity.this.inputLy02.setVisibility(8);
                ContainerFragmentActivity.this.inputLy03.setVisibility(8);
                ContainerFragmentActivity.this.inputLy04.setVisibility(8);
                ContainerFragmentActivity.this.inputLy05.setVisibility(0);
            }
        });
    }

    private void showTop() {
        runOnUiThread(new Runnable() {
            public void run() {
            }
        });
    }

    private void hideTop() {
        runOnUiThread(new Runnable() {
            public void run() {
            }
        });
    }

    private void goFragment(int fragmentIndex) {
        if (fragmentIndex != 0) {
            this.containerOrangeProgressBar.setVisibility(8);
        }
        try {
            this.fTransaction = getSupportFragmentManager().beginTransaction();
            this.fTransaction.replace(C0213R.id.details, (Fragment) this.fragments.get(fragmentIndex));
            this.fTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            this.fTransaction.commit();
        } catch (Exception e) {
            this.fTransaction = getSupportFragmentManager().beginTransaction();
            this.fTransaction.replace(C0213R.id.details, (Fragment) this.fragments.get(fragmentIndex));
            this.fTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            this.fTransaction.commitAllowingStateLoss();
        }
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!(prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") || prefLang.getString(PreferenceAction.MY_LANGUAGE) == null)) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.tvTab01.setText(C0213R.string.menu_name01);
                ContainerFragmentActivity.this.tvTab02.setText(C0213R.string.menu_name02);
                ContainerFragmentActivity.this.tvTab03.setText(C0213R.string.menu_name03);
                ContainerFragmentActivity.this.tvTab04.setText(C0213R.string.menu_name04);
                ContainerFragmentActivity.this.logTvSmenu01.setText(C0213R.string.log_smenu01);
                ContainerFragmentActivity.this.logTvSmenu02.setText(C0213R.string.log_smenu02);
                ContainerFragmentActivity.this.logTvSmenu03.setText(C0213R.string.log_smenu03);
                ContainerFragmentActivity.this.logTvSmenu04.setText(C0213R.string.add_bluetooth);
                ContainerFragmentActivity.this.bottomSyncTv0 = (TextView) ContainerFragmentActivity.this.findViewById(C0213R.id.bottomSyncTv0);
            }
        });
        checkout_dataMining_LogList_from_logList();
    }

    public void miningLogs() {
        this.logCat.log(className, "dataMining", "in");
        DataMiningSelectLog dataMining = new DataMiningSelectLog(this.mContext);
        this.listLogDM = dataMining.getLogList();
        this.listGraphDM = dataMining.getGraphList(this.listLogDM);
    }

    public void checkout_dataMining_LogList_from_logList() {
        this.logCat.log(className, "requestDataMinig_logListFragment", "in");
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(true, ContainerFragmentActivity.this.listLogDM);
            }
        });
    }

    public void checkout_noDataMining_LogList_from_logList() {
        this.logCat.log(className, "requestNoDataMinig_logListFragment", "in");
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(false, ContainerFragmentActivity.this.listLogDM);
            }
        });
    }

    public void checkout_noDataMining_LogList_from_graph() {
        this.logCat.log(className, "", "in");
        this.graphFragment.setGraph(this.listGraphDM);
    }

    public void onShowMenu() {
        showTopTabs();
        showTop();
    }

    public void onHideMenu() {
        hideTopTabs();
        hideTop();
    }

    public void onModifyLog(LogDM logDM) {
        this.logCat.log(className, "onModify", logDM.seq);
        Bundle bundle = new Bundle();
        Intent intent;
        if (logDM.category.equals("0")) {
            if (logDM.blood_sugar_type.equals("0")) {
                this.logCat.log(className, "onModifyLog", "modi");
                new DBAction(this.mContext).updateLog(logDM);
                miningLogs();
                this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
                this.logListFragment.setLogListApFromContainer(true, this.listLogDM);
            } else if (logDM.blood_sugar_type.equals("1")) {
                bundle.putSerializable("MODIFY_GLUCOSE_LOGDM", logDM);
                intent = new Intent(this, ModifyGlucose.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, MODIFY_GLUCOSE);
            }
        } else if (logDM.category.equals("1")) {
            bundle.putSerializable("MODIFY_INSULIN_LOGDM", logDM);
            intent = new Intent(this, ModifyInsulin.class);
            intent.putExtras(bundle);
            startActivityForResult(intent, MODIFY_INSULIN);
        } else if (logDM.category.equals("2")) {
            bundle.putSerializable("MODIFY_NOTE_LOGDM", logDM);
            intent = new Intent(this, ModifyNote.class);
            intent.putExtras(bundle);
            startActivityForResult(intent, MODIFY_NOTE);
        } else if (logDM.category.equals(LogDM.GLUCOSE_EAT_FASTING)) {
            bundle.putSerializable("MODIFY_COMMENT_LOGDM", logDM);
            intent = new Intent(this, ModifyComment.class);
            intent.putExtras(bundle);
            startActivityForResult(intent, MODIFY_COMMENT);
        }
    }

    public void onDeleteLog(LogDM logDM) {
        if (new DBAction(this.mContext).delLog(logDM.seq)) {
            this.logCat.log(className, "del log", "ok");
            try {
                new File(ClassConstant.DIR_IMG + logDM.note_picture).delete();
            } catch (Exception e) {
            }
            try {
                new File(ClassConstant.DIR_IMG_THUMB + logDM.note_picture_thumb).delete();
            } catch (Exception e2) {
            }
        } else {
            this.logCat.log(className, "del log", "failed");
        }
        DataMiningSelectLog mining = new DataMiningSelectLog(this.mContext);
        this.listLogDM = mining.getLogList();
        this.listGraphDM = mining.getGraphList(this.listLogDM);
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(false, ContainerFragmentActivity.this.listLogDM);
            }
        });
    }

    public boolean onKeyDown(int KeyCode, KeyEvent event) {
        if (event.getAction() == 0 && KeyCode == 4) {
            appFinish();
        }
        return super.onKeyDown(KeyCode, event);
    }

    private void timeLineThr() {
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.roadingProgressBar.setVisibility(0);
            }
        });
        TimeLineThrDM dm = new TimeLineThrDM();
        dm.email = FRIEND_EMAIL;
        dm.enddate = this.util.getTomorrow();
        dm.startdate = "";
        dm.start_num = "0";
        dm.return_num = ClassConstant.TIMELINE_LIMIT;
        new ThrTimeLine(getApplicationContext(), dm, this, ClassConstant.SUBDIR_SUPORT_TIMELINE).start();
    }

    private void timeLineLimitThr() {
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.roadingProgressBar.setVisibility(0);
            }
        });
        TimeLineThrDM dm = new TimeLineThrDM();
        dm.email = FRIEND_EMAIL;
        dm.enddate = this.util.getTomorrow();
        dm.startdate = "";
        dm.start_num = Integer.toString(this.FRIEND_TIMELINE_STARTNUM);
        dm.return_num = ClassConstant.TIMELINE_LIMIT_FRIEND;
        new ThrTimeLineLimit(this.mContext, dm, this, ClassConstant.SUBDIR_SUPORT_TIMELINE).start();
    }

    private void excuteSyncTimelineLimit() {
        TimeLineThrDM dm = new TimeLineThrDM();
        dm.email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        dm.enddate = this.util.getTomorrow();
        dm.startdate = "";
        dm.start_num = Integer.toString(this.FRIEND_TIMELINE_STARTNUM);
        PreferenceAction prefTestLimit = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_TEST_LIMIT);
        if (prefTestLimit.getString(PreferenceAction.TEST_LIMIT) == null || prefTestLimit.getString(PreferenceAction.TEST_LIMIT).equals("")) {
            dm.return_num = ClassConstant.TIMELINE_LIMIT_FRIEND_SMALL;
        } else {
            dm.return_num = prefTestLimit.getString(PreferenceAction.TEST_LIMIT);
        }
        this.logCat.log(className, "dm.return_num", dm.return_num);
        new SyncTimeline(this.mContext, dm, this, ClassConstant.SUBDIR_SUPORT_TIMELINE).start();
    }

    private void sayCheckNetwork() {
        runOnUiThread(new Runnable() {
            public void run() {
                new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_title), ContainerFragmentActivity.this.getString(C0213R.string.alert_text_message), ContainerFragmentActivity.this.getString(C0213R.string.btn_ok));
            }
        });
    }

    private void actionDefineWithObj(int gubun, Object obj, Object obj1) {
        appStatus();
        switch (this.mAppStatus) {
            case 30:
                if (gubun == 58) {
                    final ModGlucoseDM modGlucoseDM = (ModGlucoseDM) obj;
                    final LogDM logDM = (LogDM) obj1;
                    new Thread(new Runnable() {
                        public void run() {
                            String result = new SDConnection(modGlucoseDM).getModGlucoseResult(ContainerFragmentActivity.this.mContext, ClassConstant.SUBDIR_MOD_GLUCOSE);
                            ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "result", result);
                            Log.e("result", result);
                            ModGlucoseReturnDM dm = new MagicReturnDM().modGlucoseReturnDM(result);
                            if (!dm.statusResult.equals("ok")) {
                                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "onModGlucose", "failed 2");
                            } else if (!dm.code.equals("200")) {
                                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "onModGlucose", "failed 1");
                            } else if (dm.result.equals("0")) {
                                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "onModGlucose", "ok");
                                DBAction dbAction = new DBAction(ContainerFragmentActivity.this.mContext);
                                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "system_date", logDM.system_date);
                                if (logDM.system_date != null && !logDM.system_date.equals("")) {
                                    if (dbAction.executeQuery("update log set update_flag = null where system_date='" + logDM.system_date + "'")) {
                                        ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "dbUpdate", "ok");
                                        ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "dbUpdate", "update log set update_flag = null where system_date='" + logDM.system_date + "'");
                                        return;
                                    }
                                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "dbUpdate", "failed");
                                }
                            } else {
                                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "onModGlucose", "failed 0");
                            }
                        }
                    }).start();
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void actionDefine(int gubun) {
        appStatus();
        int mAppStatusAsync = appStatusAsync();
        this.logCat.log(className, "StrictMode", "mAppStatusAsync@actionDefine:" + mAppStatusAsync);
        Intent intent;
        switch (mAppStatusAsync) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                runOnUiThread(new Runnable() {
                    public void run() {
                        ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                    }
                });
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == USER_BTN) {
                    startActivityForResult(new Intent(this, Login.class), 9);
                }
                if (gubun == 0) {
                    if (gubun != 1) {
                        if (gubun == 56) {
                            sayCheckNetwork();
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                                }
                            });
                        }
                    }
                } else if (gubun != 1) {
                    if (gubun == 56) {
                        sayCheckNetwork();
                        runOnUiThread(/* anonymous class already generated */);
                    }
                }
                if (gubun == 56) {
                    sayCheckNetwork();
                    runOnUiThread(/* anonymous class already generated */);
                }
                if (gubun == this.MESSAGE_INPUT) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_title), ContainerFragmentActivity.this.getString(C0213R.string.login_text_login), ContainerFragmentActivity.this.getString(C0213R.string.btn_ok));
                        }
                    });
                    return;
                }
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == USER_BTN) {
                    startActivityForResult(new Intent(this, Login.class), 9);
                }
                if (gubun == 0) {
                    if (gubun != 1) {
                        if (gubun == 56) {
                            sayCheckNetwork();
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                                }
                            });
                        }
                    }
                } else if (gubun != 1) {
                    if (gubun == 56) {
                        sayCheckNetwork();
                        runOnUiThread(/* anonymous class already generated */);
                    }
                }
                if (gubun == 56) {
                    sayCheckNetwork();
                    runOnUiThread(/* anonymous class already generated */);
                }
                if (gubun == this.MESSAGE_INPUT) {
                    sayCheckNetwork();
                    return;
                }
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == USER_BTN) {
                    startActivityForResult(new Intent(this, Login.class), 9);
                }
                if (gubun == 55) {
                    sayCheckNetwork();
                    runOnUiThread(new Runnable() {
                        public void run() {
                            ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                        }
                    });
                }
                if (gubun == this.MESSAGE_INPUT) {
                    sayCheckNetwork();
                    return;
                }
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == USER_BTN) {
                    startActivityForResult(new Intent(this, Login.class), 9);
                }
                if (gubun == 0) {
                    if (gubun != 1) {
                        if (gubun == 56) {
                            this.logCat.log(className, "GET_FRIEND_TIMELINE", "in");
                            sayCheckNetwork();
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                                }
                            });
                        }
                    }
                } else if (gubun != 1) {
                    if (gubun == 56) {
                        this.logCat.log(className, "GET_FRIEND_TIMELINE", "in");
                        sayCheckNetwork();
                        runOnUiThread(/* anonymous class already generated */);
                    }
                }
                if (gubun == 56) {
                    this.logCat.log(className, "GET_FRIEND_TIMELINE", "in");
                    sayCheckNetwork();
                    runOnUiThread(/* anonymous class already generated */);
                }
                if (gubun == this.MESSAGE_INPUT) {
                    sayCheckNetwork();
                    return;
                }
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == USER_BTN) {
                    startActivityForResult(new Intent(this, Login.class), 9);
                }
                if (gubun == 0) {
                    login();
                }
                if (gubun == 1) {
                    syncProfileDevice();
                }
                if (gubun == 56) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                        }
                    });
                }
                if (gubun == this.MESSAGE_INPUT) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_title), ContainerFragmentActivity.this.getString(C0213R.string.login_text_login), ContainerFragmentActivity.this.getString(C0213R.string.btn_ok));
                        }
                    });
                    return;
                }
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == USER_BTN) {
                    startActivityForResult(new Intent(this, Login.class), 9);
                }
                if (gubun == 0) {
                    if (gubun != 1) {
                        if (gubun == 56) {
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                                }
                            });
                        }
                    }
                } else if (gubun != 1) {
                    if (gubun == 56) {
                        runOnUiThread(/* anonymous class already generated */);
                    }
                }
                if (gubun == 56) {
                    runOnUiThread(/* anonymous class already generated */);
                }
                if (gubun == this.MESSAGE_INPUT) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_title), ContainerFragmentActivity.this.getString(C0213R.string.login_text_login), ContainerFragmentActivity.this.getString(C0213R.string.btn_ok));
                        }
                    });
                    return;
                }
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == USER_BTN) {
                    intent = new Intent(this, UserManager.class);
                    intent.setFlags(131072);
                    startActivity(intent);
                }
                if (gubun == 0) {
                    if (gubun != 1) {
                        if (gubun == 55) {
                            timeLineThr();
                        }
                    }
                } else if (gubun != 1) {
                    if (gubun == 55) {
                        timeLineThr();
                    }
                }
                if (gubun == 55) {
                    timeLineThr();
                }
                if (gubun == 56) {
                    timeLineLimitThr();
                }
                if (gubun == this.MESSAGE_INPUT) {
                    intent = new Intent(this.mContext, InputComment.class);
                    intent.putExtra(PreferenceAction.FRIEND_EMAIL, FRIEND_EMAIL);
                    startActivityForResult(intent, INPUT_COMMENT);
                    this.logCat.log(className, "friend_email", FRIEND_EMAIL);
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == USER_BTN) {
                    intent = new Intent(this, UserManager.class);
                    intent.setFlags(131072);
                    intent.putExtra("FRIEND_EMAIL_FROM_CONTAINER", FRIEND_EMAIL);
                    startActivity(intent);
                }
                if (gubun == 0) {
                    if (gubun != 1) {
                        if (gubun == 55) {
                            timeLineThr();
                        }
                    }
                } else if (gubun != 1) {
                    if (gubun == 55) {
                        timeLineThr();
                    }
                }
                if (gubun == 55) {
                    timeLineThr();
                }
                if (gubun == 56) {
                    timeLineLimitThr();
                }
                if (gubun == this.MESSAGE_INPUT) {
                    intent = new Intent(this.mContext, InputComment.class);
                    intent.putExtra(PreferenceAction.FRIEND_EMAIL, FRIEND_EMAIL);
                    this.logCat.log(className, "friend_email", FRIEND_EMAIL);
                    startActivityForResult(intent, INPUT_COMMENT);
                }
                if (gubun == 1000) {
                    new Anim(this.mContext).startAnimSlow(this.bottomSyncLy0, "in");
                    this.bottomSyncLy0.setVisibility(0);
                    if (!this.syncAddModTimeline) {
                        this.syncAddModTimeline = true;
                        new SyncAddMod(this, this).start();
                    }
                }
                if (gubun == 57) {
                    this.logCat.log(className, "actionDefine() GET_SYNC_IMELINE_LIMIT", "request");
                    excuteSyncTimelineLimit();
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void login() {
        this.logCat.log(className, "login()", "in");
        String regId = "";
        try {
            GCMRegistrar.checkDevice(this);
            GCMRegistrar.checkManifest(this);
            regId = "";
            regId = GCMRegistrar.getRegistrationId(this);
            this.logCat.log(className, "regId", regId);
            if ("".equals(regId)) {
                GCMRegistrar.register(this, GCMManager.PROJECT_ID);
            } else {
                this.logCat.log(className, "==============", regId);
                new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_GCM).putString(PreferenceAction.GCM_REGISTRED_ID, regId);
            }
        } catch (Exception e) {
        }
        PreferenceAction prefLogin = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        PreferenceAction prefGcm = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_GCM);
        LoginThrDM loginThrDM = new LoginThrDM();
        loginThrDM.email = prefLogin.getString(PreferenceAction.MY_EMAIL);
        loginThrDM.password = prefLogin.getString(PreferenceAction.MY_PASSWORD);
        loginThrDM.registration_id = prefGcm.getString(PreferenceAction.GCM_REGISTRED_ID);
        loginThrDM.registration_device = "android";
        this.logCat.log(className, "login() emali", loginThrDM.email);
        this.logCat.log(className, "login() password", loginThrDM.password);
        this.logCat.log(className, "login() registration_id", loginThrDM.registration_id);
        new ThrLogin(getApplicationContext(), loginThrDM, this).start();
    }

    private void syncProfileDevice() {
        this.logCat.log(className, "sync()", "in");
        new SyncProfileDevice(this.mContext, this).start();
    }

    void excuteSyncTimeline() {
        this.logCat.log(className, "excuteSyncTimeline()", "request sync timelines");
        actionDefine(57);
    }

    public void onLogin(Object obj) {
        this.logCat.log(className, "onLogin", "in");
        LoginReturnDM dm = (LoginReturnDM) obj;
        this.logCat.log(className, "loginReturnDM", dm.code);
        this.logCat.log(className, "loginReturnDM", dm.result);
        this.logCat.log(className, "loginReturnDM", dm.statusResult);
        if (!dm.statusResult.equals("ok")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_title), ContainerFragmentActivity.this.getString(C0213R.string.message_text41), ContainerFragmentActivity.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        } else if (!dm.code.equals("200")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_title), ContainerFragmentActivity.this.getString(C0213R.string.message_text42), ContainerFragmentActivity.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        } else if (dm.result.equals("0")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.roadingProgressBar.setVisibility(8);
                }
            });
            actionDefine(1);
        } else {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_title), ContainerFragmentActivity.this.getString(C0213R.string.message_text36), ContainerFragmentActivity.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        }
    }

    public void onDelSendServerLog(Object obj, String subDir) {
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.roadingProgressBar.setVisibility(0);
            }
        });
        DelDataThrDM delDataThrDM = new DelDataThrDM();
        delDataThrDM = (DelDataThrDM) obj;
        this.logCat.log(className, "delDataThrDM id", delDataThrDM.id);
        this.logCat.log(className, "delDataThrDM email", delDataThrDM.email);
        this.logCat.log(className, "delDataThrDM ntype", delDataThrDM.ntype);
        new ThrDelData(getApplicationContext(), (DelDataThrDM) obj, this, subDir).start();
    }

    public void onModifySendServerLog(Object obj, String subDir) {
        this.logCat.log(className, "onModifySendServerLog", "in");
    }

    public void onDelDataServer(Object ob) {
        this.logCat.log(className, "onDelDataServer", "in");
        DelDataReturnDM dm = (DelDataReturnDM) ob;
        this.logCat.log(className, "delDataReturnDM", dm.code);
        this.logCat.log(className, "delDataReturnDM", dm.result);
        this.logCat.log(className, "delDataReturnDM", dm.statusResult);
        if (!dm.statusResult.equals("ok")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_title), ContainerFragmentActivity.this.getString(C0213R.string.message_text41), ContainerFragmentActivity.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        } else if (!dm.code.equals("200")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_title), ContainerFragmentActivity.this.getString(C0213R.string.message_text42), ContainerFragmentActivity.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        } else if (dm.result.equals("0")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "data del", "ok");
                }
            });
        } else {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(ContainerFragmentActivity.this).alert0(ContainerFragmentActivity.this.getString(C0213R.string.alert_text_title), ContainerFragmentActivity.this.getString(C0213R.string.message_text36), ContainerFragmentActivity.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        }
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.roadingProgressBar.setVisibility(8);
            }
        });
    }

    public void roadingProgessBar(int visible) {
        if (visible == 0) {
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.roadingProgressBar.setVisibility(0);
                }
            });
        } else if (visible == 8) {
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.roadingProgressBar.setVisibility(8);
                }
            });
        }
    }

    public void onTimeLine(Object obj) {
    }

    public void onTimeLine_suport(Object obj) {
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
            }
        });
    }

    public void onTimeLIne_userprofile_suport(Object obj) {
        this.logCat.log(className, "onTimeLIne_userprofile_suport", "in");
    }

    public void checkout_UserProfileSettingData_from_logList() {
        if (this.userProfileSettingData != null) {
            try {
                this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
            } catch (Exception e) {
            }
        }
    }

    public void checkout_UserProfileSettingData_from_stats() {
        this.logCat.log(className, "checkout_UserProfileSettingData_from_stats()", "in");
        this.statsFragment.setUserProfileSettingData(this.userProfileSettingData);
    }

    public void request_showDialog_from_stats() {
        showStatsProgressBar();
    }

    public void request_hideDialog_from_stats() {
        hideStatsProgressBar();
    }

    public void checkout_LogList_from_logList() {
        this.startTime = System.nanoTime();
        this.blockNFC = true;
        this.logCat.log(className, "blockNFC", "start ...[blockNFC=" + this.blockNFC + "]");
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        if (FRIEND_EMAIL == null || pref.getString(PreferenceAction.MY_EMAIL).equals(FRIEND_EMAIL)) {
            this.logCat.log(className, "is me", "ok");
            if (this.syncAddModTimeline) {
                this.logCat.log(className, "syncAddModTimeline", "refresh syncAddModTimeline true");
                runOnUiThread(new Runnable() {
                    public void run() {
                        ContainerFragmentActivity.this.logListFragment.onRefreshCompleteOnly();
                    }
                });
                return;
            }
            this.logCat.log(className, "syncAddModTimeline", "refresh syncAddModTimeline false");
            actionDefine(1000);
            this.logCat.log(className, "called miningLogs()", "call1");
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(true, ContainerFragmentActivity.this.listLogDM);
                }
            });
            return;
        }
        this.logCat.log(className, "is me", "no");
        actionDefine(56);
    }

    public void onTimeLineLimit(Object obj) {
        boolean isFirst;
        this.logCat.log(className, "onTimeLineLimit", "in");
        if (this.FRIEND_TIMELINE_STARTNUM == 0) {
            this.listLogDM.clear();
            isFirst = true;
        } else {
            isFirst = false;
        }
        this.FRIEND_TIMELINE_STARTNUM += Integer.parseInt(ClassConstant.TIMELINE_LIMIT_FRIEND);
        runOnUiThread(new Runnable() {
            public void run() {
                ContainerFragmentActivity.this.name.setText(ContainerFragmentActivity.FRIEND_NAME);
                ContainerFragmentActivity.this.roadingProgressBar.setVisibility(8);
            }
        });
        ArrayList arrayList = new ArrayList();
        ArrayList<LogDM> getLogList = (ArrayList) obj;
        this.logCat.log(className, "ui", getLogList.size() + "");
        if (getLogList == null || getLogList.size() == 0) {
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.logListFragment.removeFooterView();
                    ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                }
            });
            return;
        }
        this.listLogDM.addAll(getLogList);
        this.listGraphDM = new DataMiningSelectLog(this.mContext).getGraphList(this.listLogDM);
        runOnUiThread(new Runnable() {

            class C01931 implements Runnable {
                C01931() {
                }

                public void run() {
                    ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(true, ContainerFragmentActivity.this.listLogDM);
                }
            }

            class C01942 implements Runnable {
                C01942() {
                }

                public void run() {
                    ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(false, ContainerFragmentActivity.this.listLogDM);
                }
            }

            public void run() {
                ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "setLogList()", "excute");
                if (isFirst) {
                    ContainerFragmentActivity.this.runOnUiThread(new C01931());
                } else {
                    ContainerFragmentActivity.this.runOnUiThread(new C01942());
                }
                ContainerFragmentActivity.this.statsFragment.setLogList(ContainerFragmentActivity.this.listLogDM);
            }
        });
    }

    public void onTimeLineLimit_userprofile_suport(Object obj) {
        this.logCat.log(className, "onTimeLIne_userprofile_suport", "in");
        UserProfileReturnDM userProfileReturnDM = new UserProfileReturnDM();
        userProfileReturnDM = (UserProfileReturnDM) obj;
        this.userProfileSettingData.USER_EMAIL = userProfileReturnDM.email;
        this.userProfileSettingData.USER_NAME = userProfileReturnDM.name;
        this.userProfileSettingData.USER_BIRTH = userProfileReturnDM.birth;
        this.userProfileSettingData.USER_GENDER = userProfileReturnDM.gender;
        this.userProfileSettingData.USER_HEIGHT_UNIT = userProfileReturnDM.height;
        this.userProfileSettingData.USER_HEIGHT_UNIT = userProfileReturnDM.heightunit;
        this.userProfileSettingData.USER_WEIGHT = userProfileReturnDM.weight;
        this.userProfileSettingData.USER_WEIGHT_UNIT = userProfileReturnDM.weightunit;
        this.userProfileSettingData.USER_OCCOURDAY = userProfileReturnDM.diabeticsince;
        this.userProfileSettingData.USER_BLOOD_SUGAR_TYPE = userProfileReturnDM.diabetestype;
        this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT = userProfileReturnDM.glucoseunit;
        this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR = userProfileReturnDM.hyper;
        this.userProfileSettingData.USER_LOW_BLOOD_SUGAR = userProfileReturnDM.hypo;
        this.userProfileSettingData.USER_DATE_METHOD = userProfileReturnDM.datetype;
        this.userProfileSettingData.USER_TIME_METHOD = userProfileReturnDM.timetype;
        this.userProfileSettingData.USER_LANGUAGE = userProfileReturnDM.language;
        this.userProfileSettingData.changeData();
        this.logCat.log(className, "USER_HIGH_BLOOD_SUGAR", userProfileReturnDM.hyper);
    }

    public void execute_timeLineLimitThr_from_logList() {
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        if (FRIEND_EMAIL != null && !pref.getString(PreferenceAction.MY_EMAIL).equals(FRIEND_EMAIL)) {
            timeLineLimitThr();
        }
    }

    public void change_friend_timeline_startnum_from_logList() {
        this.FRIEND_TIMELINE_STARTNUM = 0;
    }

    public void onSync(boolean result, int failedAction) {
    }

    public void syncOnAddMod(int section) {
        this.logCat.log(className, "syncOnAddModListener()", "in");
        final int getSection = section;
        this.bottomSyncLy0.setVisibility(0);
        runOnUiThread(new Runnable() {
            public void run() {
                if (getSection == 0) {
                    ContainerFragmentActivity.this.test_Time1 = System.currentTimeMillis();
                    ContainerFragmentActivity.this.bottomSyncTv0.setText(ContainerFragmentActivity.this.getString(C0213R.string.add_glucoses));
                }
                if (getSection == 1) {
                    ContainerFragmentActivity.this.bottomSyncTv0.setText(ContainerFragmentActivity.this.getString(C0213R.string.mod_glucoses));
                }
                if (getSection == 2) {
                    ContainerFragmentActivity.this.bottomSyncTv0.setText(ContainerFragmentActivity.this.getString(C0213R.string.add_insulins));
                }
                if (getSection == 3) {
                    ContainerFragmentActivity.this.bottomSyncTv0.setText(ContainerFragmentActivity.this.getString(C0213R.string.mod_glucoses));
                }
                if (getSection == 5) {
                    ContainerFragmentActivity.this.bottomSyncTv0.setText(ContainerFragmentActivity.this.getString(C0213R.string.add_notes));
                }
                if (getSection == 6) {
                    ContainerFragmentActivity.this.bottomSyncTv0.setText(ContainerFragmentActivity.this.getString(C0213R.string.mod_notes));
                }
                if (getSection == 4) {
                    ContainerFragmentActivity.this.bottomSyncTv0.setText(ContainerFragmentActivity.this.getString(C0213R.string.sync_timeline));
                    ContainerFragmentActivity.this.excuteSyncTimeline();
                }
            }
        });
    }

    private void TestTimeDialog(long time) {
        Builder alt_bld = new Builder(this);
        alt_bld.setMessage("" + time + "  Second").setCancelable(false).setNegativeButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog alert = alt_bld.create();
        alert.setTitle("Synchronization Time");
        alert.show();
    }

    public void onSyncTimeline(Object obj, Object order) {
        int sync_status = ((Integer) obj).intValue();
        final int order_ = ((Integer) order).intValue();
        if (sync_status == 1) {
            runOnUiThread(new Runnable() {
                public void run() {
                    ContainerFragmentActivity.this.bottomSyncLy0.setVisibility(8);
                    ContainerFragmentActivity.this.bottomSyncTv0.setText("");
                    ContainerFragmentActivity.this.logListFragment.onRefreshComplete();
                    PreferenceAction pref = new PreferenceAction(ContainerFragmentActivity.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                    if (ContainerFragmentActivity.FRIEND_EMAIL == null || pref.getString(PreferenceAction.MY_EMAIL).equals(ContainerFragmentActivity.FRIEND_EMAIL)) {
                        ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "called miningLogs()", "call2");
                        ContainerFragmentActivity.this.miningLogs();
                        ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(false, ContainerFragmentActivity.this.listLogDM);
                        ContainerFragmentActivity.this.blockNFC = false;
                        ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "blockNFC", "end.[blockNFC=" + ContainerFragmentActivity.this.blockNFC + "]");
                        long endTime = System.nanoTime();
                        NumberFormat.getNumberInstance();
                    }
                    ContainerFragmentActivity.this.syncAddModTimeline = false;
                    ContainerFragmentActivity.this.test_Time2 = System.currentTimeMillis();
                    long runtime = ContainerFragmentActivity.this.test_Time2 - ContainerFragmentActivity.this.test_Time1;
                }
            });
        } else if (sync_status == 2) {
            runOnUiThread(new Runnable() {

                class C01961 implements Runnable {
                    C01961() {
                    }

                    public void run() {
                        ContainerFragmentActivity.this.logListFragment.setLogListApFromContainer(false, ContainerFragmentActivity.this.listLogDM);
                    }
                }

                public void run() {
                    if (order_ == 1) {
                        PreferenceAction pref = new PreferenceAction(ContainerFragmentActivity.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                        if (ContainerFragmentActivity.FRIEND_EMAIL == null || pref.getString(PreferenceAction.MY_EMAIL).equals(ContainerFragmentActivity.FRIEND_EMAIL)) {
                            ContainerFragmentActivity.this.logCat.log(ContainerFragmentActivity.className, "called miningLogs()", "call3");
                            ContainerFragmentActivity.this.miningLogs();
                            ContainerFragmentActivity.this.runOnUiThread(new C01961());
                        }
                    }
                }
            });
        }
    }

    public void onMoreFragment_request_isMe() {
        this.moreFragment.setIsMe(this.userProfileSettingData.isMe(FRIEND_EMAIL));
    }

    public void onFinish_from_moreFragment() {
        finish();
    }

    public void onFriendMap(Object obj) {
        this.logCat.log(className, "onFriendMaponFriendMaponFriendMaponFriendMaponFriendMap", "in");
        this.friendsMap = (HashMap) obj;
        Object[] keys = this.friendsMap.keySet().toArray();
        for (String key : keys) {
            this.logCat.log(className, "dynamic name", (String) this.friendsMap.get(key));
        }
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        if (FRIEND_EMAIL == null || FRIEND_EMAIL.equals("") || FRIEND_EMAIL.equals(pref.getString(PreferenceAction.MY_EMAIL))) {
            this.friendsMap.put(pref.getString(PreferenceAction.MY_EMAIL), pref.getString(PreferenceAction.MY_NAME));
        } else {
            this.friendsMap.put(FRIEND_EMAIL, FRIEND_NAME);
        }
        if (this.friendsMap.size() > 0) {
            this.logListFragment.setFriendMap(this.friendsMap);
        }
    }

    public void fragmentHome() {
        tabChange(0);
        showTopTabs();
        showTop();
        showManualInput();
        goFragment(0);
        this.logCat.log(className, "tabchang list size", this.listLogDM.size() + "");
        if (this.userProfileSettingData == null) {
            this.logCat.log(className, "is null", "userProfileSettingData is null");
        }
        if (FRIEND_EMAIL == null) {
            this.logCat.log(className, "is null", "FRIEND_EMAIL is null");
        }
    }

    public void onDataMiningProgressUpdate(final Object gubun, int p) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (DataMiningProgressListener.GET_DB_LIST.equals((String) gubun)) {
                }
                if (DataMiningProgressListener.GET_DATA_FROM_DEVICE.equals((String) gubun)) {
                }
                if (DataMiningProgressListener.GET_GRAPH_DATA_1.equals((String) gubun)) {
                }
                ContainerFragmentActivity containerFragmentActivity;
                if (DataMiningProgressListener.GET_GRAPH_DATA_2.equals((String) gubun)) {
                    containerFragmentActivity = ContainerFragmentActivity.this;
                    containerFragmentActivity.SET_PROGRESSBAR_VALUE += ContainerFragmentActivity.GLUCOSE_ONE_VALUE;
                    ContainerFragmentActivity.this.containerOrangeProgressBar.setProgress((double) ((int) ContainerFragmentActivity.this.SET_PROGRESSBAR_VALUE));
                } else {
                    containerFragmentActivity = ContainerFragmentActivity.this;
                    containerFragmentActivity.SET_PROGRESSBAR_VALUE += ContainerFragmentActivity.GLUCOSE_ONE_VALUE;
                    ContainerFragmentActivity.this.containerOrangeProgressBar.setProgress((double) ((int) ContainerFragmentActivity.this.SET_PROGRESSBAR_VALUE));
                }
            }
        });
    }

    public void onDelDeviceLog(LogDM logDM) {
        int OE = 0;
        if (logDM.blood_sugar_eat.equals("0")) {
            OE = GlucoseEvent.POST_MEAL_5;
        } else if (logDM.blood_sugar_eat.equals("1")) {
            OE = GlucoseEvent.PRE_MEAL_4;
        } else if (logDM.blood_sugar_eat.equals("2")) {
            OE = GlucoseEvent.CS_1;
        } else if (logDM.blood_sugar_eat.equals(LogDM.GLUCOSE_EAT_NONE)) {
        }
        OE += GlucoseEvent.MODIFY_8 + GlucoseEvent.DEL_9;
        this.logCat.log(className, "OE", OE + "");
        logDM.blood_sugar_eat_origin = String.valueOf(OE);
        DBAction dbActionLogUpdate = new DBAction(this.mContext);
        logDM.update_flag = "update";
        if (dbActionLogUpdate.updateLog(logDM)) {
            this.logCat.log(className, "OE", "update ok");
        } else {
            this.logCat.log(className, "OE", "update failed");
        }
        DBAction dbAction = new DBAction(this.mContext);
        dbAction.updateLog(logDM);
        miningLogs();
        this.logListFragment.setUserProfileSettingData(this.userProfileSettingData);
        this.logListFragment.setLogListApFromContainer(false, this.listLogDM);
        PreferenceAction prefEmail = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        ModGlucoseDM modGlucoseDM = new ModGlucoseDM();
        modGlucoseDM.email = prefEmail.getString(PreferenceAction.MY_EMAIL);
        modGlucoseDM.deviceid = dbAction.getOneDeviceId();
        modGlucoseDM.gdate = new Util().getServerDateFormat(logDM.input_date);
        modGlucoseDM.gvalue = logDM.blood_sugar_value;
        modGlucoseDM.gevent = logDM.blood_sugar_eat;
        modGlucoseDM.gtempeature = "0";
        modGlucoseDM.manualinput = "NO";
        modGlucoseDM.gmodevent = logDM.blood_sugar_eat_origin;
        modGlucoseDM.id = logDM._id;
        actionDefineWithObj(58, modGlucoseDM, logDM);
    }

    public void onModGlucose(Object obj) {
        this.logCat.log(className, "onModGlucose", "in");
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults[0] == 0) {
                    Intent intent = new Intent(this.mContext, DataTransActivity.class);
                    intent.putExtra(DataTransActivity.ACTION_DATA_CATEGORY, 0);
                    startActivityForResult(intent, INPUT_BLUETOOTH);
                    return;
                }
                Builder builder = new Builder(this);
                builder.setTitle(getResources().getString(C0213R.string.location_access_cancel_title));
                builder.setMessage(getResources().getString(C0213R.string.location_access_cancel_message));
                builder.setPositiveButton(17039370, null);
                builder.setOnDismissListener(new OnDismissListener() {
                    public void onDismiss(DialogInterface dialog) {
                    }
                });
                builder.show();
                return;
            default:
                return;
        }
    }
}
