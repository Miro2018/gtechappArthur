package com.accumed.gtech.router;

public interface AppStatusRouterListener {
    void onAppStatus(int i);
}
