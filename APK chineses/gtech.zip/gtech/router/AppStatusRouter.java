package com.accumed.gtech.router;

import android.content.Context;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.NetworkWatcher;
import com.accumed.gtech.util.PreferenceAction;

public class AppStatusRouter {
    public static final int FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o = 30;
    public static final int FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x = 14;
    public static final int FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o = 21;
    public static final int FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x = 5;
    public static final int FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o = 26;
    public static final int FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x = 10;
    public static final int FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o = 17;
    public static final int FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x = 1;
    public static final int FIRSTUSE_x = 0;
    private static final String className = "AppStatusRouter";
    private int device = 2;
    private int firstUse = 1;
    private LogCat logCat;
    private int login = 3;
    private Context mContext;
    private int network = 4;

    public AppStatusRouter(Context c) {
        this.mContext = c;
        this.logCat = new LogCat();
    }

    public int getAppStatus() {
        if (getFirstUse()) {
            int result = 0 + this.firstUse;
            if (getIsDevice()) {
                result += this.device * this.device;
            }
            if (getIsLogin()) {
                result += this.login * this.login;
            }
            if (getNetworkStatus()) {
                result += this.network * this.network;
            }
            this.logCat.log(className, "getAppStatus", result + "");
            return result;
        }
        this.logCat.log(className, "getAppStatus", 0 + "");
        return 0;
    }

    public boolean getFirstUse() {
        boolean result;
        PreferenceAction pref0 = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_AGREEMENT);
        PreferenceAction pref1 = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        PreferenceAction pref2 = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        this.logCat.log(className, "pref1", pref1.getString(PreferenceAction.MY_NAME));
        if (!pref0.getString(PreferenceAction.IS_AGREEMENT).equals("yes") || pref1.getString(PreferenceAction.MY_NAME).equals("") || pref1.getString(PreferenceAction.MY_NAME) == null || pref2.getString(PreferenceAction.MY_DATE_METHOD).equals("") || pref2.getString(PreferenceAction.MY_DATE_METHOD) == null) {
            result = false;
        } else {
            result = true;
        }
        this.logCat.log(className, "pref1", new Boolean(result).toString());
        return result;
    }

    public boolean getIsDevice() {
        return new DBAction(this.mContext).isDevice();
    }

    public boolean getIsLogin() {
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_IS_LOGIN);
        if (pref.getString(PreferenceAction.IS_LOGIN).equals("no") || pref.getString(PreferenceAction.IS_LOGIN).equals("") || pref.getString(PreferenceAction.IS_LOGIN) == null) {
            return false;
        }
        if (pref.getString(PreferenceAction.IS_LOGIN).equals("yes")) {
            return true;
        }
        return false;
    }

    public boolean getNetworkStatus() {
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_SYNC_SWITCH);
        if (pref.getString(PreferenceAction.SYNC_SWITCH) == null || pref.getString(PreferenceAction.SYNC_SWITCH).equals("no")) {
            return false;
        }
        return new NetworkWatcher(this.mContext).isCon();
    }

    public void setOnStatusListener(AppStatusRouterListener listener) {
        listener.onAppStatus(getAppStatus());
    }
}
