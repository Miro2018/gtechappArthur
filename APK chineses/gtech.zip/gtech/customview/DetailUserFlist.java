package com.accumed.gtech.customview;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;

public class DetailUserFlist extends LinearLayout {
    public TextView emailTv;
    Context mContext;
    public TextView nameTv;
    public Button requestBt;
    public ImageView userCircleIv;

    public DetailUserFlist(Context context) {
        super(context);
        this.mContext = context;
        create();
    }

    private void create() {
        ((LayoutInflater) this.mContext.getSystemService("layout_inflater")).inflate(C0213R.layout.detail_user_flist, this, true);
        this.userCircleIv = (ImageView) findViewById(C0213R.id.userCircleIv);
        this.nameTv = (TextView) findViewById(C0213R.id.nameTv);
        this.emailTv = (TextView) findViewById(C0213R.id.emailTv);
        this.requestBt = (Button) findViewById(C0213R.id.requestBt);
    }
}
