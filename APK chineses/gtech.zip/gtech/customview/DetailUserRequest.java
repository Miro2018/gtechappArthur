package com.accumed.gtech.customview;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.accumed.gtech.C0213R;

public class DetailUserRequest extends LinearLayout {
    public Button deniedBt;
    public TextView emailTv;
    Context mContext;
    public TextView nameEmailSpTv;
    public TextView nameTv;
    public Button requestBt;

    public DetailUserRequest(Context context) {
        super(context);
        this.mContext = context;
        create();
    }

    private void create() {
        ((LayoutInflater) this.mContext.getSystemService("layout_inflater")).inflate(C0213R.layout.detail_user_request, this, true);
        this.nameTv = (TextView) findViewById(C0213R.id.nameTv);
        this.emailTv = (TextView) findViewById(C0213R.id.emailTv);
        this.nameEmailSpTv = (TextView) findViewById(C0213R.id.emailTv);
        this.requestBt = (Button) findViewById(C0213R.id.requestBt);
        this.deniedBt = (Button) findViewById(C0213R.id.deniedBt);
    }
}
