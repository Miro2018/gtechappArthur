package com.accumed.gtech.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ClipDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.accumed.gtech.C0213R;

public class RoundProgressBar extends RelativeLayout {
    private double max = 100.0d;
    private ImageView progressDrawableImageView;
    private ImageView trackDrawableImageView;

    public int getMax() {
        return new Double(this.max).intValue();
    }

    public double getMaxDouble() {
        return this.max;
    }

    public void setMax(int max) {
        new Integer(max).doubleValue();
        this.max = (double) max;
    }

    public void setMax(double max) {
        this.max = max;
    }

    public RoundProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(C0213R.layout.round_progress, this);
        setup(context, attrs);
    }

    protected void setup(Context context, AttributeSet attrs) {
        TypedArray a = context.obtainStyledAttributes(attrs, C0213R.styleable.RoundProgress);
        String xmlns = "com.accumed.gtech.customview.RoundProgressBar";
        int bgResource = attrs.getAttributeResourceValue("com.accumed.gtech.customview.RoundProgressBar", "progressDrawable", 0);
        this.progressDrawableImageView = (ImageView) findViewById(C0213R.id.progress_drawable_image_view);
        this.progressDrawableImageView.setBackgroundResource(bgResource);
        int trackResource = attrs.getAttributeResourceValue("com.accumed.gtech.customview.RoundProgressBar", "track", 0);
        this.trackDrawableImageView = (ImageView) findViewById(C0213R.id.track_image_view);
        this.trackDrawableImageView.setBackgroundResource(trackResource);
        setProgress((double) attrs.getAttributeIntValue("com.accumed.gtech.customview.RoundProgressBar", "progress", 0));
        setMax(attrs.getAttributeIntValue("com.accumed.gtech.customview.RoundProgressBar", "max", 100));
        int numTicks = attrs.getAttributeIntValue("com.accumed.gtech.customview.RoundProgressBar", "numTicks", 0);
        a.recycle();
        addView(new ProgressBarOutline(context));
    }

    public void setProgress(Integer value) {
        setProgress((double) value.intValue());
    }

    public void setProgress(double value) {
        ((ClipDrawable) this.progressDrawableImageView.getBackground()).setLevel((int) Math.floor(10000.0d * (value / this.max)));
    }
}
