package com.accumed.gtech.customview;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import java.io.PrintWriter;
import java.io.StringWriter;

public class CustomViewPager extends ViewPager {
    private boolean enabled = true;

    public CustomViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public boolean onTouchEvent(MotionEvent event) {
        try {
            if (this.enabled) {
                return super.onTouchEvent(event);
            }
        } catch (Exception e) {
            e.printStackTrace(new PrintWriter(new StringWriter()));
        }
        return false;
    }

    public boolean onInterceptTouchEvent(MotionEvent event) {
        if (this.enabled) {
            return super.onInterceptTouchEvent(event);
        }
        return false;
    }

    public void setPagingEnabled() {
        this.enabled = true;
    }

    public void setPagingDisabled() {
        this.enabled = false;
    }
}
