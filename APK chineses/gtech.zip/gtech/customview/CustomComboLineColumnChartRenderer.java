package com.accumed.gtech.customview;

import android.content.Context;
import lecho.lib.hellocharts.provider.ColumnChartDataProvider;
import lecho.lib.hellocharts.provider.LineChartDataProvider;
import lecho.lib.hellocharts.renderer.ColumnChartRenderer;
import lecho.lib.hellocharts.renderer.ComboChartRenderer;
import lecho.lib.hellocharts.view.Chart;

public class CustomComboLineColumnChartRenderer extends ComboChartRenderer {
    private ColumnChartRenderer columnChartRenderer;
    private CustomLineChartRenderer lineChartRenderer;

    public CustomComboLineColumnChartRenderer(Context context, Chart chart, ColumnChartDataProvider columnChartDataProvider, LineChartDataProvider lineChartDataProvider) {
        this(context, chart, new ColumnChartRenderer(context, chart, columnChartDataProvider), new CustomLineChartRenderer(context, chart, lineChartDataProvider));
    }

    public CustomComboLineColumnChartRenderer(Context context, Chart chart, ColumnChartRenderer columnChartRenderer, LineChartDataProvider lineChartDataProvider) {
        this(context, chart, columnChartRenderer, new CustomLineChartRenderer(context, chart, lineChartDataProvider));
    }

    public CustomComboLineColumnChartRenderer(Context context, Chart chart, ColumnChartDataProvider columnChartDataProvider, CustomLineChartRenderer lineChartRenderer) {
        this(context, chart, new ColumnChartRenderer(context, chart, columnChartDataProvider), lineChartRenderer);
    }

    public CustomComboLineColumnChartRenderer(Context context, Chart chart, ColumnChartRenderer columnChartRenderer, CustomLineChartRenderer lineChartRenderer) {
        super(context, chart);
        this.columnChartRenderer = columnChartRenderer;
        this.lineChartRenderer = lineChartRenderer;
        this.renderers.add(this.columnChartRenderer);
        this.renderers.add(this.lineChartRenderer);
    }
}
