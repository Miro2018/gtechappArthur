package com.accumed.gtech.customview;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import com.accumed.gtech.C0213R;

public class MoreFooter extends LinearLayout {
    Context context;

    public MoreFooter(Context context) {
        super(context);
        this.context = context;
        create();
    }

    private void create() {
        ((LayoutInflater) this.context.getSystemService("layout_inflater")).inflate(C0213R.layout.more_footer, this, true);
    }
}
