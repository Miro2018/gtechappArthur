package com.accumed.gtech.customview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.accumed.gtech.C0213R;

public class CustomToast extends Toast {
    Context mContext;

    public CustomToast(Context context) {
        super(context);
        this.mContext = context;
    }

    public void showToast(String body, int duration) {
        View v = ((LayoutInflater) this.mContext.getSystemService("layout_inflater")).inflate(C0213R.layout.toast_layout, null);
        ((TextView) v.findViewById(C0213R.id.text)).setText(body);
        show(this, v, duration);
    }

    private void show(Toast toast, View v, int duration) {
        toast.setDuration(duration);
        toast.setView(v);
        toast.show();
    }
}
