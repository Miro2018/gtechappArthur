package com.accumed.gtech.customview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.view.View;
import lecho.lib.hellocharts.model.BubbleChartData;

public class ProgressBarOutline extends View {
    private Paint paint = new Paint();

    public ProgressBarOutline(Context context) {
        super(context);
    }

    public void onDraw(Canvas canvas) {
        this.paint.setColor(Color.argb(255, 75, 75, 75));
        this.paint.setStrokeWidth(3.0f);
        this.paint.setAntiAlias(true);
        this.paint.setStyle(Style.STROKE);
        this.paint.setARGB(255, 75, 75, 75);
        canvas.drawRoundRect(new RectF(BubbleChartData.DEFAULT_BUBBLE_SCALE, BubbleChartData.DEFAULT_BUBBLE_SCALE, (float) getWidth(), (float) getHeight()), (float) (getHeight() / 2), (float) (getHeight() / 2), this.paint);
    }
}
