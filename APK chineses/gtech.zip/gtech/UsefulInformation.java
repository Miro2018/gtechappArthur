package com.accumed.gtech;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.accumed.gtech.pinchzoom.GestureImageView;
import com.accumed.gtech.util.PreferenceAction;
import java.util.Locale;

public class UsefulInformation extends Activity {
    Button mBtnPrev;
    Context mContext;
    GestureImageView view;
    GestureImageView view2;

    class C02141 implements OnClickListener {
        C02141() {
        }

        public void onClick(View v) {
            UsefulInformation.this.finish();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.usefulinformation);
        this.mContext = getApplicationContext();
        this.mBtnPrev = (Button) findViewById(C0213R.id.usefulinfo_btn_prev);
        this.mBtnPrev.setOnClickListener(new C02141());
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
