package com.accumed.gtech.structure;

public interface UtilStrStructure {
    boolean isNullEmpty(String str);
}
