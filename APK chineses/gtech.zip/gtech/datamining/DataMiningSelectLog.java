package com.accumed.gtech.datamining;

import android.content.Context;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.fma.android.chart.type.GlucoseItem;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.GlucoseEvent;
import com.accumed.gtech.util.LogCat;
import java.util.ArrayList;
import java.util.Vector;

public class DataMiningSelectLog {
    static final String className = "DataMining";
    DataMiningProgressListener dataMiningProgressListener;
    LogCat logCat = new LogCat();
    Context mContext;

    public DataMiningSelectLog(Context c) {
        this.mContext = c;
    }

    public DataMiningSelectLog(Context c, DataMiningProgressListener l) {
        this.mContext = c;
        this.dataMiningProgressListener = l;
    }

    public ArrayList<LogDM> getLogList() {
        ArrayList<LogDM> list = new ArrayList();
        DBAction dbAction = new DBAction(this.mContext);
        String MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
        String DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
        return dbAction.selectLogList("SELECT * FROM log where blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE + " ORDER BY input_date DESC, seq DESC");
    }

    public ArrayList<LogDM> getLogList(String query) {
        ArrayList<LogDM> list = new ArrayList();
        return new DBAction(this.mContext).selectLogList(query);
    }

    public Vector<GlucoseItem> getGraphList(ArrayList<LogDM> logList) {
        int i;
        Vector<GlucoseItem> chartList = new Vector();
        this.logCat.log(className, "logList size", logList.size() + "");
        ArrayList<LogDM> allTimlineList = new ArrayList();
        ArrayList<LogDM> refinedTimeLineList = new ArrayList();
        allTimlineList = logList;
        ContainerFragmentActivity.GLUCOSE_COUNT = allTimlineList.size();
        this.logCat.log(className, "re_GLUCOSE_COUNT", ContainerFragmentActivity.GLUCOSE_COUNT + "");
        ContainerFragmentActivity.GLUCOSE_ONE_VALUE = ((float) ContainerFragmentActivity.PROGRESSBAR_AREA_PERCENT) / ((float) ContainerFragmentActivity.GLUCOSE_COUNT);
        this.logCat.log(className, "re_GLUCOSE_ONE_VALUE", ContainerFragmentActivity.GLUCOSE_ONE_VALUE + "");
        for (i = 0; i < allTimlineList.size(); i++) {
            if (((LogDM) allTimlineList.get(i)).category.equals("0")) {
                if (!((LogDM) allTimlineList.get(i)).blood_sugar_eat.equals("2")) {
                    refinedTimeLineList.add(allTimlineList.get(i));
                }
            } else if (((LogDM) allTimlineList.get(i)).category.equals("1")) {
                refinedTimeLineList.add(allTimlineList.get(i));
            }
            if (this.dataMiningProgressListener != null) {
                this.dataMiningProgressListener.onDataMiningProgressUpdate(DataMiningProgressListener.GET_GRAPH_DATA_1, (int) ContainerFragmentActivity.GLUCOSE_ONE_VALUE);
            }
        }
        ContainerFragmentActivity.GLUCOSE_COUNT = refinedTimeLineList.size();
        this.logCat.log(className, "re_GLUCOSE_COUNT", ContainerFragmentActivity.GLUCOSE_COUNT + "");
        ContainerFragmentActivity.GLUCOSE_ONE_VALUE = ((float) ContainerFragmentActivity.PROGRESSBAR_AREA_PERCENT) / ((float) ContainerFragmentActivity.GLUCOSE_COUNT);
        this.logCat.log(className, "re_GLUCOSE_ONE_VALUE", ContainerFragmentActivity.GLUCOSE_ONE_VALUE + "");
        i = 0;
        while (i < refinedTimeLineList.size()) {
            String date = ((LogDM) refinedTimeLineList.get(i)).input_date;
            this.logCat.log(className, "addGlucoseData date", date);
            if (date != null) {
                String insulinTypeStr;
                date = conversionStrDateTimeFormat(date);
                String getDate = date.substring(0, 8);
                String getTime = date.substring(8, 12);
                this.logCat.log(className, "addGlucoseData getDate", getDate);
                this.logCat.log(className, "addGlucoseData getTime", getTime);
                int eat = -1;
                if (((LogDM) refinedTimeLineList.get(i)).blood_sugar_eat != null) {
                    if (((LogDM) refinedTimeLineList.get(i)).blood_sugar_eat.equals("")) {
                        eat = 0;
                    } else {
                        eat = Integer.parseInt(((LogDM) refinedTimeLineList.get(i)).blood_sugar_eat);
                        if (eat == 0) {
                            eat = 2;
                        } else if (eat == 1) {
                            eat = 1;
                        } else if (eat == 3) {
                            eat = 3;
                        } else {
                            eat = 0;
                        }
                    }
                }
                int bloodValue = 0;
                if (!(((LogDM) refinedTimeLineList.get(i)).blood_sugar_value == null || ((LogDM) refinedTimeLineList.get(i)).blood_sugar_value.equals(""))) {
                    bloodValue = (int) Float.parseFloat(((LogDM) refinedTimeLineList.get(i)).blood_sugar_value);
                }
                int insulinType = 0;
                LogCat logCat = this.logCat;
                String str = className;
                String str2 = str;
                String str3 = "insulin_type";
                logCat.log(str2, str3, "::" + ((LogDM) refinedTimeLineList.get(i)).insulin_type + "::");
                try {
                    insulinTypeStr = ((LogDM) refinedTimeLineList.get(i)).insulin_type.trim();
                } catch (Exception e) {
                    insulinTypeStr = "";
                }
                if (insulinTypeStr != null) {
                    if (!insulinTypeStr.equals("")) {
                        insulinType = Integer.parseInt(insulinTypeStr) + 1;
                    }
                }
                float insulinValue = 0.0f;
                String insulinValueStr = ((LogDM) refinedTimeLineList.get(i)).insulin_value.trim();
                if (insulinValueStr != null) {
                    if (!insulinValueStr.equals("")) {
                        insulinValue = Float.parseFloat(insulinValueStr);
                    }
                }
                String insulinName = "";
                if (insulinType - 1 >= 0) {
                    insulinName = getInsulinName(String.valueOf(((LogDM) refinedTimeLineList.get(i)).insulin_name));
                }
                chartList.add(new GlucoseItem(getDate, getTime, eat, (float) bloodValue, insulinType, insulinValue, insulinName));
            }
            if (this.dataMiningProgressListener != null) {
                this.dataMiningProgressListener.onDataMiningProgressUpdate(DataMiningProgressListener.GET_GRAPH_DATA_2, (int) ContainerFragmentActivity.GLUCOSE_ONE_VALUE);
            }
            i++;
        }
        return chartList;
    }

    public String conversionStrDateTimeFormat(String date) {
        if (date == null) {
            return null;
        }
        return date.replaceAll("-", "").replaceAll(":", "").replaceAll("\\.", "").replaceAll("\\p{Space}", "");
    }

    public String getInsulinName(String no) {
        if (no == null || no.trim().equals("")) {
            return null;
        }
        switch (Integer.parseInt(no)) {
            case 0:
                return this.mContext.getString(C0213R.string.insulin_name_novorapid);
            case 1:
                return this.mContext.getString(C0213R.string.insulin_name_apidra);
            case 2:
                return this.mContext.getString(C0213R.string.insulin_name_humalog);
            case 3:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_r);
            case 4:
                return this.mContext.getString(C0213R.string.insulin_name_novorin_r);
            case 5:
                return this.mContext.getString(C0213R.string.insulin_name_insulatard);
            case 6:
                return this.mContext.getString(C0213R.string.insulin_name_lantus);
            case 7:
                return this.mContext.getString(C0213R.string.insulin_name_levemir);
            case 8:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_30);
            case 9:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_50);
            case 10:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_70);
            case 11:
                return this.mContext.getString(C0213R.string.insulin_name_mixtard);
            case 12:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_30);
            case 13:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_70);
            case 14:
                return this.mContext.getString(C0213R.string.insulin_name_humalogmix_25);
            case 15:
                return this.mContext.getString(C0213R.string.insulin_name_humalogmix_50);
            default:
                return null;
        }
    }
}
