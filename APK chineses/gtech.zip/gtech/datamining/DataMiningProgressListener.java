package com.accumed.gtech.datamining;

public interface DataMiningProgressListener {
    public static final String AP_SET = "AP_SET";
    public static final String GET_DATA_FROM_DEVICE = "GET_DATA_FROM_DEVICE";
    public static final String GET_DB_LIST = "GET_DB_LIST";
    public static final String GET_GRAPH_DATA_1 = "GET_GRAPH_DATA_1";
    public static final String GET_GRAPH_DATA_2 = "GET_GRAPH_DATA_2";

    void onDataMiningProgressUpdate(Object obj, int i);
}
