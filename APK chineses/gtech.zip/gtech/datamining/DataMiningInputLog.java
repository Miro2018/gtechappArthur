package com.accumed.gtech.datamining;

import android.content.Context;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.NotiThrDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.Util;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class DataMiningInputLog {
    static final String className = "DataMiningInputLog";
    DataMiningProgressListener dataMiningProgressListener;
    private String device_id;
    private ArrayList<LogDM> getDeviceLogList = new ArrayList();
    private LogCat logCat;
    private Context mContext;

    class C02591 extends Thread {
        C02591() {
        }

        public void run() {
            PreferenceAction pref = new PreferenceAction(DataMiningInputLog.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            NotiThrDM nDM = new NotiThrDM();
            nDM.email = pref.getString(PreferenceAction.MY_EMAIL);
            nDM.gubun = DataMiningInputLog.this.mContext.getString(C0213R.string.noti_glucose);
            nDM.gubun_num = "0";
            nDM.message = pref.getString(PreferenceAction.MY_NAME) + " " + nDM.gubun + " : " + ((LogDM) DataMiningInputLog.this.getDeviceLogList.get(DataMiningInputLog.this.getDeviceLogList.size() - 1)).blood_sugar_value;
            nDM.name = pref.getString(PreferenceAction.MY_NAME);
            new SDConnection(nDM).notiResult(DataMiningInputLog.this.mContext, ClassConstant.SUBDIR_SUPORT_NOTI);
        }
    }

    public DataMiningInputLog(Context c, ArrayList<LogDM> list, String deviceId) {
        this.mContext = c;
        this.getDeviceLogList = list;
        this.logCat = new LogCat();
        this.device_id = deviceId;
        sendNotification();
    }

    public DataMiningInputLog(Context c, ArrayList<LogDM> list, String deviceId, DataMiningProgressListener l) {
        this.mContext = c;
        this.getDeviceLogList = list;
        this.logCat = new LogCat();
        this.device_id = deviceId;
        this.dataMiningProgressListener = l;
        sendNotification();
    }

    private void thrNotification() {
        new C02591().start();
    }

    private void sendNotification() {
        ArrayList<LogDM> dbList = new DBAction(this.mContext).selectLogList("SELECT * FROM log where blood_sugar_type='0' ORDER BY input_date DESC, seq DESC");
        Collections.reverse(dbList);
        if (this.getDeviceLogList.size() != 0) {
            if (dbList.size() == 0 && this.getDeviceLogList.size() > 0) {
                thrNotification();
            } else if (this.getDeviceLogList.size() > 0 && dbList.size() > 0) {
                String s = ((LogDM) this.getDeviceLogList.get(this.getDeviceLogList.size() - 1)).input_date + ((LogDM) this.getDeviceLogList.get(this.getDeviceLogList.size() - 1)).blood_sugar_eat + ((LogDM) this.getDeviceLogList.get(this.getDeviceLogList.size() - 1)).blood_sugar_value;
                String s1 = ((LogDM) dbList.get(dbList.size() - 1)).input_date + ((LogDM) dbList.get(dbList.size() - 1)).blood_sugar_eat + ((LogDM) dbList.get(dbList.size() - 1)).blood_sugar_value;
                this.logCat.log(className, "s-----", s);
                this.logCat.log(className, "s-----1", s1);
                if (!s.equals(s1)) {
                    thrNotification();
                }
            }
        }
    }

    public ArrayList<LogDM> getList() {
        DataMiningSelectLog miningSelect = new DataMiningSelectLog(this.mContext);
        for (int i = 0; i < this.getDeviceLogList.size(); i++) {
            String q = "select * from log where input_date='" + ((LogDM) this.getDeviceLogList.get(i)).input_date + "' and category='" + ((LogDM) this.getDeviceLogList.get(i)).category + "' and blood_sugar_type='" + ((LogDM) this.getDeviceLogList.get(i)).blood_sugar_type + "' and blood_sugar_eat='" + ((LogDM) this.getDeviceLogList.get(i)).blood_sugar_eat + "' and blood_sugar_value='" + ((LogDM) this.getDeviceLogList.get(i)).blood_sugar_value + "'";
            DBAction dbAction = new DBAction(this.mContext);
            if (dbAction.getCount(q) == 0) {
                dbAction.insertLog((LogDM) this.getDeviceLogList.get(i));
            }
            this.dataMiningProgressListener.onDataMiningProgressUpdate(DataMiningProgressListener.GET_DB_LIST, i);
        }
        return miningSelect.getLogList();
    }

    private ArrayList<String> getDBTopFiveValueList() {
        Util util = new Util();
        ArrayList<String> resultList = new ArrayList();
        ArrayList<LogDM> tempList = new DataMiningSelectLog(this.mContext).getLogList("SELECT * FROM log WHERE device_id='" + this.device_id + "' and category = '" + 0 + "' ORDER BY input_date DESC, seq DESC LIMIT 0,5");
        for (int i = 0; i < tempList.size(); i++) {
            String YYYYMMDDHHNNVVVEE = ((LogDM) tempList.get(i)).input_date + util.vvv(((LogDM) tempList.get(i)).blood_sugar_value) + util.vvv(((LogDM) tempList.get(i)).blood_sugar_eat);
            resultList.add(YYYYMMDDHHNNVVVEE);
            this.logCat.log(className, "getDBTopFiveValueList YYYYMMDDHHNNVVVEE", YYYYMMDDHHNNVVVEE);
        }
        return resultList;
    }

    private ArrayList<String> getDeviceValueList() {
        Util util = new Util();
        ArrayList<String> resultList = new ArrayList();
        for (int i = 0; i < this.getDeviceLogList.size(); i++) {
            String YYYYMMDDHHNNVVVEE = ((LogDM) this.getDeviceLogList.get(i)).input_date + util.vvv(((LogDM) this.getDeviceLogList.get(i)).blood_sugar_value) + util.ee(((LogDM) this.getDeviceLogList.get(i)).blood_sugar_eat);
            resultList.add(YYYYMMDDHHNNVVVEE);
            this.logCat.log(className, "getDviceLogList YYYYMMDDHHNNVVVEE", YYYYMMDDHHNNVVVEE);
        }
        Collections.reverse(resultList);
        return resultList;
    }

    private ArrayList<LogDM> makeUpdateLogList(int indexNo) {
        this.logCat.log(className, "makeUpdateLogList()", indexNo + "");
        ArrayList<LogDM> resultList = new ArrayList();
        ArrayList arrayList = new ArrayList();
        ArrayList<LogDM> tempList = this.getDeviceLogList;
        Collections.reverse(tempList);
        for (int i = indexNo; i >= 0; i--) {
            resultList.add(tempList.get(i));
        }
        for (int h = 0; h < resultList.size(); h++) {
            this.logCat.log(className, "makeUpdateLogList", ((LogDM) resultList.get(h)).blood_sugar_value);
        }
        return resultList;
    }

    private int getUpdateIndexNo() {
        int updateIndexNo = 0;
        HashMap<Integer, ArrayList<String>> valueMap = makeMiningMap();
        if (valueMap.size() == 0) {
            updateIndexNo = 0;
        } else {
            ArrayList<String> top5ValueList = getDBTopFiveValueList();
            boolean compare = false;
            for (int mapSize = 0; mapSize < valueMap.size(); mapSize++) {
                if (compare) {
                    this.logCat.log(className, "compare if", (mapSize - 2) + "부터 0까지 없데이트 한다.");
                    this.logCat.log(className, "compare", "compare return");
                    return mapSize - 2;
                }
                compare = false;
                for (int i = 0; i < 5; i++) {
                    if (((ArrayList) valueMap.get(Integer.valueOf(mapSize))).size() == 4) {
                        this.logCat.log(className, "compare", "맵의 리스트가 4개 이하 임");
                        return valueMap.size() - 1;
                    }
                    try {
                        if (((String) top5ValueList.get(i)).equals(((ArrayList) valueMap.get(Integer.valueOf(mapSize))).get(i))) {
                            this.logCat.log(className, "compare", "동일 리스트 임");
                            compare = true;
                        } else {
                            this.logCat.log(className, "compare", "동일 리스트가 아님");
                            compare = false;
                        }
                    } catch (Exception e) {
                        compare = false;
                    }
                }
            }
        }
        this.logCat.log(className, "updateIndexNo", updateIndexNo + "");
        return updateIndexNo;
    }

    private HashMap<Integer, ArrayList<String>> makeMiningMap() {
        HashMap<Integer, ArrayList<String>> resultMap = new HashMap();
        ArrayList<String> deviceValueList = getDeviceValueList();
        for (int indexNo = 0; indexNo < deviceValueList.size(); indexNo++) {
            ArrayList<String> tempValueList = new ArrayList();
            for (int i = 0; i < 5; i++) {
                try {
                    tempValueList.add(deviceValueList.get(indexNo + i));
                } catch (Exception e) {
                }
            }
            resultMap.put(Integer.valueOf(indexNo), tempValueList);
        }
        for (Entry entry : resultMap.entrySet()) {
            this.logCat.log(className, "makeMiningMap", entry.getKey() + " : " + entry.getValue());
        }
        return resultMap;
    }
}
