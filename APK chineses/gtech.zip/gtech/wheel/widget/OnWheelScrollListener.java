package com.accumed.gtech.wheel.widget;

public interface OnWheelScrollListener {
    void onScrollingFinished(WheelView wheelView);

    void onScrollingStarted(WheelView wheelView);
}
