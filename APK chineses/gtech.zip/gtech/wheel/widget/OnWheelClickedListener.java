package com.accumed.gtech.wheel.widget;

public interface OnWheelClickedListener {
    void onItemClicked(WheelView wheelView, int i);
}
