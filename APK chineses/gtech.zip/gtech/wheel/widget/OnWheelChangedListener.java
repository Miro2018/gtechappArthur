package com.accumed.gtech.wheel.widget;

public interface OnWheelChangedListener {
    void onChanged(WheelView wheelView, int i, int i2);
}
