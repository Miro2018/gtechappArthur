package com.accumed.gtech.wheel.widget;

public interface WheelAdapter {
    String getItem(int i);

    int getItemsCount();

    int getMaximumLength();
}
