package com.accumed.gtech;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import com.accumed.gtech.util.LogCat;

public class DBStructure extends SQLiteOpenHelper {
    public static final String DB_NAME = "gtech.db";
    public static final String DB_TABLE_NAME_DEVICE = "device";
    public static final String DB_TABLE_NAME_FRINED_EVENTCOUNT = "friend_eventcount";
    public static final String DB_TABLE_NAME_LOG = "log";
    public static final String DB_TABLE_NAME_OTHERRECORD = "otherrecord";
    static final String className = "DBStructure";
    public int DBVERSION;
    LogCat logCat = new LogCat();

    public DBStructure(Context context, String name, CursorFactory factory, int DBversion) {
        super(context, name, factory, DBversion);
        this.DBVERSION = DBversion;
        this.logCat.log(className, "DBStructure constructure", "in");
        this.logCat.log(className, "DBStructure DBVERSION", this.DBVERSION + "");
    }

    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL("CREATE TABLE device (seq integer PRIMARY KEY AUTOINCREMENT, device_id text, _id text, update_date text);");
            this.logCat.log(className, "create table device", "onCreate ok");
        } catch (Exception e) {
            this.logCat.log(className, "create table device", "onCreate failed");
        }
        try {
            db.execSQL("CREATE TABLE log (seq integer primary key autoincrement, _id text, user_id text, update_flag text, device_id text, input_date text, system_date text, category text, blood_sugar_type text, blood_sugar_eat text, blood_sugar_value text, insulin_type text, insulin_name text, insulin_value text, note_type text, note_content text, note_picture text, note_picture_thumb text, targetemail text, blood_sugar_eat_origin text);");
            this.logCat.log(className, "create table log", "onCreate ok");
        } catch (Exception e2) {
            this.logCat.log(className, "create table log", "onCreate failed");
        }
        try {
            db.execSQL("create table if not exists otherrecord (seq integer primary key autoincrement, email text, odate text, weight text, bmi text, waist text, waistunit text, hba1c text, hba1cunit text, bloodpressure text, tc text, tg text, hdl text, ldl text, _id text, update_flag text, input_date text, system_date text);");
            this.logCat.log(className, "create table otherrecord", "ok");
        } catch (Exception e3) {
            this.logCat.log(className, "create table otherrecord", "failed");
        }
        try {
            db.execSQL("create table if not exists friend_eventcount (seq integer primary key autoincrement, email text, name text, eventcount text);");
            this.logCat.log(className, "create table friend_eventcount", "ok");
        } catch (Exception e4) {
            this.logCat.log(className, "create table friend_eventcount", "failed");
        }
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion > 0) {
            try {
                db.execSQL("alter table log add column blood_sugar_eat_origin text");
                this.logCat.log("sqlite_master()", "sqlite_master()_column update", "--alter ok");
            } catch (Exception e) {
                this.logCat.log("sqlite_master()", "sqlite_master()_column update blood_sugar_eat_origin", "--alter failed");
            }
        }
    }

    public int dbVersion() {
        return this.DBVERSION;
    }
}
