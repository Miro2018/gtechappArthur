package com.accumed.gtech.server.helper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.util.Log;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.util.BitmapUtil;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

public class ServerHelper {
    protected static final String ASIA_SERVER = "https://54.250.126.59";
    protected static final String ENCODING = "UTF-8";
    protected static final String EU_SERVER = "https://54.228.205.134";
    protected static final int TIMEOUT = 10000;
    protected static final String US_SERVER = "https://54.215.215.78";
    static final String className = "ServerHelper";
    LogCat logCat = new LogCat();
    private String mSurportServer;

    public String getEncode() {
        return ENCODING;
    }

    public HttpGet getHttpGet(Context context, String url, HashMap<String, String> parameter_map) {
        PreferenceAction prefServerCheck = new PreferenceAction(context, PreferenceAction.PREF_SELECT_SERVER);
        if (prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER) == 0) {
            url = ASIA_SERVER + url;
        } else if (prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER) == 1) {
            url = EU_SERVER + url;
        } else {
            url = US_SERVER + url;
        }
        List<NameValuePair> qparams = new ArrayList();
        if (parameter_map != null && parameter_map.size() > 0) {
            for (String key : parameter_map.keySet()) {
                qparams.add(new BasicNameValuePair(key, (String) parameter_map.get(key)));
            }
        }
        String encoded = URLEncodedUtils.format(qparams, ENCODING);
        HttpGet httpGet = new HttpGet(url + "?" + encoded);
        this.logCat.log(className, "getHttpGet", url + "?" + encoded);
        setLog("Type : GET");
        setLog("Encoding : UTF-8");
        setLog("URL : " + url);
        setLog("Params : " + encoded.toString());
        return httpGet;
    }

    public HttpGet getHttpGet(Context context, String url) {
        PreferenceAction prefServerCheck = new PreferenceAction(context, PreferenceAction.PREF_SELECT_SERVER);
        if (prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER) == 0) {
            url = ASIA_SERVER + url;
        } else if (prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER) == 1) {
            url = EU_SERVER + url;
        } else {
            url = US_SERVER + url;
        }
        HttpGet httpGet = new HttpGet(url);
        setLog("Type : GET");
        setLog("Encoding : UTF-8");
        setLog("URL : " + url);
        return httpGet;
    }

    public HttpPost getHttpPost(Context context, String url, HashMap<String, String> parameter_map, HashMap<String, String> attachedFileMap, String classNameFrom) throws UnsupportedEncodingException {
        PreferenceAction prefServerCheck = new PreferenceAction(context, PreferenceAction.PREF_SELECT_SERVER);
        this.mSurportServer = ClassConstant.ASIA_ADDRESS_SUPORT;
        if (url.equals(ClassConstant.SUBDIR_SUPORT_TIMELINE)) {
            url = "https://" + this.mSurportServer + url;
        } else {
            if (url.equals(ClassConstant.SUBDIR_SUPORT_MODINSULIN)) {
                url = "https://" + this.mSurportServer + url;
            } else {
                if (url.equals(ClassConstant.SUBDIR_SUPORT_DELNOTE)) {
                    url = "https://" + this.mSurportServer + url;
                } else {
                    if (url.equals(ClassConstant.SUBDIR_SUPORT_DELCOMMENT)) {
                        url = "https://" + this.mSurportServer + url;
                    } else {
                        if (url.equals(ClassConstant.SUBDIR_SUPORT_ADDGLUCOSES)) {
                            url = "https://" + this.mSurportServer + url;
                        } else {
                            if (url.equals(ClassConstant.SUBDIR_SUPORT_ADDINSULINS)) {
                                url = "https://" + this.mSurportServer + url;
                            } else {
                                if (url.equals(ClassConstant.SUBDIR_SUPORT_MODGLUCOSES)) {
                                    url = "https://" + this.mSurportServer + url;
                                } else {
                                    if (url.equals(ClassConstant.SUBDIR_SUPORT_MODINSULINS)) {
                                        url = "https://" + this.mSurportServer + url;
                                    } else {
                                        if (url.equals(ClassConstant.SUBDIR_SUPORT_ADDMOD_USERDEVICE)) {
                                            url = "https://" + this.mSurportServer + url;
                                        } else {
                                            if (url.equals(ClassConstant.SUBDIR_SUPORT_NOTI)) {
                                                url = "https://" + this.mSurportServer + url;
                                            } else {
                                                if (url.equals(ClassConstant.SUBDIR_SUPORT_NOTI_FRIENDS)) {
                                                    url = "https://" + this.mSurportServer + url;
                                                } else {
                                                    if (url.equals(ClassConstant.SUBDIR_SUPORT_FRIENDS)) {
                                                        url = "https://" + this.mSurportServer + url;
                                                    } else {
                                                        if (url.equals(ClassConstant.SUBDIR_SUPORT_VERSION)) {
                                                            url = "https://" + this.mSurportServer + url;
                                                        } else if (prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER) == 0) {
                                                            url = ASIA_SERVER + url;
                                                        } else if (prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER) == 1) {
                                                            url = EU_SERVER + url;
                                                        } else {
                                                            url = US_SERVER + url;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        this.logCat.log(className, "url", url);
        HttpPost httpPost = new HttpPost(url);
        if (attachedFileMap == null || attachedFileMap.size() <= 0) {
            this.logCat.log(className, "content-type", "default");
            List<NameValuePair> qparams = new ArrayList();
            if (parameter_map != null && parameter_map.size() > 0) {
                for (String key : parameter_map.keySet()) {
                    qparams.add(new BasicNameValuePair(key, (String) parameter_map.get(key)));
                }
            }
            this.logCat.log(className, "Params", qparams.toString());
            UrlEncodedFormEntity entityRequest = null;
            try {
                entityRequest = new UrlEncodedFormEntity(qparams, ENCODING);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            httpPost.setEntity(entityRequest);
        } else {
            this.logCat.log(className, "content-type", "multipart/form-data");
            this.logCat.log(className, "content-type attachedFileMap", attachedFileMap.size() + "");
            httpPost.setHeader(HttpHeaders.ACCEPT_CHARSET, ENCODING);
            httpPost.setHeader("ENCTYPE", "multipart/form-data");
            MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
            if (parameter_map != null && parameter_map.size() > 0) {
                for (String key2 : attachedFileMap.keySet()) {
                    String value = (String) attachedFileMap.get(key2);
                    if (!(value == null || value.equals(""))) {
                        reqEntity.addPart(key2, createFileBody(value));
                    }
                }
            }
            for (String key22 : parameter_map.keySet()) {
                try {
                    reqEntity.addPart(key22, new StringBody((String) parameter_map.get(key22), Charset.forName(ENCODING)));
                } catch (UnsupportedEncodingException e2) {
                    e2.printStackTrace();
                }
            }
            setLog("Params : " + reqEntity.toString());
            httpPost.setEntity(reqEntity);
        }
        return httpPost;
    }

    public HttpPost getHttpPostData(Context context, String url, String data) {
        PreferenceAction prefServerCheck = new PreferenceAction(context, PreferenceAction.PREF_SELECT_SERVER);
        if (prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER) == 0) {
            url = ASIA_SERVER + url;
        } else if (prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER) == 1) {
            url = EU_SERVER + url;
        } else {
            url = US_SERVER + url;
        }
        HttpPost httpPost = new HttpPost(url);
        try {
            httpPost.setEntity(new StringEntity(data, ENCODING));
            httpPost.setHeader(HttpHeaders.USER_AGENT, "Fiddler");
            httpPost.setHeader(HttpHeaders.HOST, ClassConstant.ADDRESS_V1_1_0_4);
            httpPost.setHeader("Content-type", "application/json; charset=utf-8");
            setLog("Params : " + data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return httpPost;
    }

    public FileBody createFileBody(String filePath) {
        File file = new File(filePath);
        String path = file.getPath();
        Log.d(getClass().getName(), "FileBody-FileName : " + file.getName());
        Bitmap bmp = BitmapUtil.getImageRotate(path);
        File smallFile = new File(filePath);
        try {
            FileOutputStream fos = new FileOutputStream(smallFile);
            bmp.compress(CompressFormat.JPEG, 100, fos);
            if (bmp != null) {
                bmp.recycle();
            }
            fos.flush();
            fos.close();
            file = smallFile;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return new FileBody(file);
    }

    private void setLog(String msg) {
        Log.d(getClass().getName(), msg);
    }

    public HttpClient getNewHttpClient() {
        try {
            KeyStore.getInstance(KeyStore.getDefaultType()).load(null, null);
            HttpParams params = new BasicHttpParams();
            HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
            HttpProtocolParams.setContentCharset(params, ENCODING);
            SchemeRegistry schReg = new SchemeRegistry();
            schReg.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
            schReg.register(new Scheme("https", new EasySSLSocketFactory(), 443));
            return new DefaultHttpClient(new ThreadSafeClientConnManager(params, schReg), params);
        } catch (Exception e) {
            return new DefaultHttpClient();
        }
    }
}
