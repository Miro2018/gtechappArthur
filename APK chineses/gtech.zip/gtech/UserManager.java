package com.accumed.gtech;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Html;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import com.accumed.gtech.customview.DetailUserFlist;
import com.accumed.gtech.customview.DetailUserHold;
import com.accumed.gtech.customview.DetailUserRequest;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.OnAddFriendListener;
import com.accumed.gtech.thread.OnChangestatusListener;
import com.accumed.gtech.thread.OnFriendListListener;
import com.accumed.gtech.thread.OnUserRequestListener;
import com.accumed.gtech.thread.ThrAddFriend;
import com.accumed.gtech.thread.ThrChangestatus;
import com.accumed.gtech.thread.ThrFriendList;
import com.accumed.gtech.thread.ThrUserRequest;
import com.accumed.gtech.thread.datamodel.AddFriendThrDM;
import com.accumed.gtech.thread.datamodel.ChangestatusThrDM;
import com.accumed.gtech.thread.datamodel.FriendListReturnDM;
import com.accumed.gtech.thread.datamodel.FriendListReturnDMSubDM;
import com.accumed.gtech.thread.datamodel.FriendListThrDM;
import com.accumed.gtech.thread.datamodel.NotiFriensRequestThrDM;
import com.accumed.gtech.thread.datamodel.UserRequestDM;
import com.accumed.gtech.thread.datamodel.UserRequestReturnDM;
import com.accumed.gtech.util.Anim;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

public class UserManager extends Activity implements OnUserRequestListener, OnFriendListListener, OnAddFriendListener, OnChangestatusListener {
    static final String className = "UserManager";
    final int ROW_HEIGHT = 28;
    LinearLayout detailFlistLy;
    LinearLayout detailFlistRequestLy;
    LinearLayout detailHoldFlistLy;
    String email_from_container = "";
    ArrayList<FriendListReturnDMSubDM> friendHoldList;
    ProgressBar friendHoldPgb;
    ArrayList<FriendListReturnDMSubDM> friendList;
    ProgressBar friendPgb;
    LogCat logCat;
    Context mContext;
    PullToRefreshScrollView mPullRefreshScrollView;
    ScrollView mScrollView;
    ArrayList<FriendListReturnDMSubDM> requestList;
    ProgressBar requestPgb;
    LinearLayout userManagerLy0;
    Button usermanager_btn_prev;
    Button usermanager_btn_search;
    EditText usermanager_edit_email;

    class C02231 implements OnRefreshListener<ScrollView> {
        C02231() {
        }

        public void onRefresh(PullToRefreshBase<ScrollView> pullToRefreshBase) {
            UserManager.this.listRemove();
            PreferenceAction pref = new PreferenceAction(UserManager.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            FriendListThrDM friendListThrDM = new FriendListThrDM();
            friendListThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
            new ThrFriendList(UserManager.this.mContext, friendListThrDM, UserManager.this, null, ClassConstant.SUBDIR_SUPORT_FRIENDS).start();
        }
    }

    class C02242 implements OnClickListener {
        C02242() {
        }

        public void onClick(View v) {
            UserManager.this.finish();
        }
    }

    class C02263 implements OnClickListener {

        class C02251 implements Runnable {
            C02251() {
            }

            public void run() {
                UserManager.this.requestPgb.setVisibility(0);
                UserManager.this.usermanager_edit_email.setText("");
            }
        }

        C02263() {
        }

        public void onClick(View arg0) {
            UserRequestDM dm = new UserRequestDM();
            dm.email = UserManager.this.usermanager_edit_email.getText().toString().trim();
            new ThrUserRequest(UserManager.this.mContext, dm, UserManager.this).start();
            UserManager.this.runOnUiThread(new C02251());
        }
    }

    class C02274 implements OnTouchListener {
        C02274() {
        }

        public boolean onTouch(View arg0, MotionEvent arg1) {
            ((InputMethodManager) UserManager.this.getSystemService("input_method")).hideSoftInputFromWindow(UserManager.this.usermanager_edit_email.getWindowToken(), 0);
            return false;
        }
    }

    class C02285 implements OnTouchListener {
        C02285() {
        }

        public boolean onTouch(View arg0, MotionEvent arg1) {
            ((InputMethodManager) UserManager.this.getSystemService("input_method")).hideSoftInputFromWindow(UserManager.this.usermanager_edit_email.getWindowToken(), 0);
            return false;
        }
    }

    class C02296 implements Runnable {
        C02296() {
        }

        public void run() {
            UserManager.this.detailFlistRequestLy.removeAllViews();
            UserManager.this.detailFlistLy.removeAllViews();
            UserManager.this.detailHoldFlistLy.removeAllViews();
        }
    }

    class C02307 implements Runnable {
        C02307() {
        }

        public void run() {
            UserManager.this.requestPgb.setVisibility(8);
        }
    }

    class C02338 implements Runnable {
        C02338() {
        }

        public void run() {
            Iterator it = UserManager.this.requestList.iterator();
            while (it.hasNext()) {
                final FriendListReturnDMSubDM dm = (FriendListReturnDMSubDM) it.next();
                DetailUserRequest detailView = new DetailUserRequest(UserManager.this.mContext);
                if (dm.name.equals("null")) {
                    detailView.nameTv.setVisibility(8);
                    detailView.nameEmailSpTv.setVisibility(8);
                } else {
                    detailView.nameTv.setVisibility(0);
                    detailView.nameEmailSpTv.setVisibility(0);
                }
                if (dm.status.equals("null") || dm.status.equals("")) {
                    detailView.requestBt.setVisibility(0);
                    detailView.deniedBt.setVisibility(8);
                } else if (dm.status.equals("add")) {
                    detailView.requestBt.setVisibility(8);
                    detailView.deniedBt.setVisibility(0);
                }
                detailView.nameTv.setText(dm.name);
                detailView.emailTv.setText(dm.friend);
                detailView.requestBt.setOnClickListener(new OnClickListener() {
                    public void onClick(View v) {
                        UserManager.this.logCat.log(UserManager.className, "onclick", dm.id);
                        PreferenceAction pref = new PreferenceAction(UserManager.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                        PreferenceAction notiPref = new PreferenceAction(UserManager.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                        NotiFriensRequestThrDM thrNotiDM = new NotiFriensRequestThrDM();
                        thrNotiDM.friend_email = dm.friend;
                        thrNotiDM.message = UserManager.this.mContext.getString(C0213R.string.noti_request_friend);
                        thrNotiDM.my_email = notiPref.getString(PreferenceAction.MY_EMAIL);
                        thrNotiDM.my_name = notiPref.getString(PreferenceAction.MY_NAME);
                        new RequestFriendThr(thrNotiDM).start();
                        AddFriendThrDM addFriendThrDM = new AddFriendThrDM();
                        addFriendThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
                        addFriendThrDM.friendemail = dm.friend;
                        new ThrAddFriend(UserManager.this.mContext, addFriendThrDM, UserManager.this, ClassConstant.SUBDIR_USER_ADDFRIEND).start();
                        UserManager.this.logCat.log(UserManager.className, "SUBDIR_USER_ADDFRIEND", "click");
                    }
                });
                detailView.deniedBt.setOnClickListener(new OnClickListener() {
                    public void onClick(View v) {
                        ChangestatusThrDM changeDm = new ChangestatusThrDM();
                        changeDm.id = dm.id;
                        changeDm.command = ChangestatusThrDM.USER_DENY;
                        new ThrChangestatus(UserManager.this.mContext, changeDm, UserManager.this, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
                    }
                });
                UserManager.this.detailFlistRequestLy.addView(detailView);
            }
        }
    }

    class C02349 implements Runnable {
        C02349() {
        }

        public void run() {
            new ShowAlert(UserManager.this).alert0(UserManager.this.getString(C0213R.string.alert_text_title), UserManager.this.getString(C0213R.string.message_text42), UserManager.this.getString(C0213R.string.alert_text_confirm));
        }
    }

    class RequestFriendThr extends Thread {
        NotiFriensRequestThrDM nDM;

        public RequestFriendThr(NotiFriensRequestThrDM d) {
            this.nDM = d;
        }

        public void run() {
            new SDConnection(this.nDM).notiFriendsRequestResult(UserManager.this.mContext, ClassConstant.SUBDIR_SUPORT_NOTI_FRIENDS);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        this.logCat.log(className, "code requestCode", requestCode + "");
        this.logCat.log(className, "code resultCode", resultCode + "");
        if (resultCode == ContainerFragmentActivity.USER_MANAGER_FINISH) {
            finish();
        }
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.logCat.log(className, "onNewIntent", intent.getStringExtra("PANDING"));
        this.logCat.log(className, "onNewIntent", intent.getStringExtra(PreferenceAction.FRIEND_EMAIL));
        this.logCat.log(className, "onNewIntent", intent.getStringExtra("FRIEND_NAME"));
        if (intent.getStringExtra("PANDING") != null) {
            if (intent.getStringExtra("GUBUN_NUM").equals(LogDM.GLUCOSE_EAT_NONE)) {
            }
            if (intent.getStringExtra(PreferenceAction.FRIEND_EMAIL) != null && intent.getStringExtra("FRIEND_NAME") != null) {
                this.logCat.log(className, "click", "in");
                userClick(intent.getStringExtra(PreferenceAction.FRIEND_EMAIL), intent.getStringExtra("FRIEND_NAME"));
            }
        }
    }

    public void onResume() {
        super.onResume();
        this.logCat.log(className, "onResume", getIntent().getStringExtra("PANDING"));
        if (getIntent() == null) {
            this.logCat.log(className, "getIntent", "null");
        }
        try {
            if (getIntent().getStringExtra("FINISH") != null) {
                finish();
            }
            this.logCat.log("className", "onCreate", getIntent().getStringExtra("FINISH"));
        } catch (Exception e) {
        }
        if (getIntent().getStringExtra("FRIEND_EMAIL_FROM_CONTAINER") != null) {
            this.email_from_container = getIntent().getStringExtra("FRIEND_EMAIL_FROM_CONTAINER");
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.usermanager);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.logCat.log(className, "onCreate", "in");
        try {
            if (getIntent().getStringExtra("FINISH") != null) {
                finish();
            }
            this.logCat.log("className", "onCreate", getIntent().getStringExtra("FINISH"));
        } catch (Exception e) {
        }
        this.logCat.log(className, "onNewIntent", getIntent().getStringExtra("PANDING"));
        this.logCat.log(className, "onNewIntent", getIntent().getStringExtra(PreferenceAction.FRIEND_EMAIL));
        this.logCat.log(className, "onNewIntent", getIntent().getStringExtra("FRIEND_NAME"));
        if (!((getIntent().getStringExtra("GUBUN_NUM") != null && getIntent().getStringExtra("GUBUN_NUM").equals(LogDM.GLUCOSE_EAT_NONE)) || getIntent().getStringExtra("PANDING") == null || getIntent().getStringExtra(PreferenceAction.FRIEND_EMAIL) == null || getIntent().getStringExtra("FRIEND_NAME") == null)) {
            this.logCat.log(className, "click", "in");
            userClick(getIntent().getStringExtra(PreferenceAction.FRIEND_EMAIL), getIntent().getStringExtra("FRIEND_NAME"));
        }
        this.detailFlistLy = (LinearLayout) findViewById(C0213R.id.detailFlistLy);
        this.detailFlistRequestLy = (LinearLayout) findViewById(C0213R.id.detailFlistRequestLy);
        this.detailHoldFlistLy = (LinearLayout) findViewById(C0213R.id.detailHoldFlistLy);
        this.mPullRefreshScrollView = (PullToRefreshScrollView) findViewById(C0213R.id.pull_refresh_scrollview);
        this.mPullRefreshScrollView.setOnRefreshListener(new C02231());
        this.mScrollView = (ScrollView) this.mPullRefreshScrollView.getRefreshableView();
        this.requestPgb = (ProgressBar) findViewById(C0213R.id.requestPgb);
        this.requestPgb.setVisibility(8);
        this.friendHoldPgb = (ProgressBar) findViewById(C0213R.id.friendHoldPgb);
        this.friendHoldPgb.setVisibility(8);
        this.usermanager_btn_prev = (Button) findViewById(C0213R.id.usermanager_btn_prev);
        this.usermanager_btn_prev.setOnClickListener(new C02242());
        this.usermanager_edit_email = (EditText) findViewById(C0213R.id.usermanager_edit_email);
        this.usermanager_btn_search = (Button) findViewById(C0213R.id.usermanager_btn_search);
        this.usermanager_btn_search.setOnClickListener(new C02263());
        this.userManagerLy0 = (LinearLayout) findViewById(C0213R.id.userManagerLy0);
        this.userManagerLy0.setOnTouchListener(new C02274());
        this.mPullRefreshScrollView.setOnTouchListener(new C02285());
        this.requestList = new ArrayList();
        this.friendPgb = (ProgressBar) findViewById(C0213R.id.friendPgb);
        this.friendList = new ArrayList();
        this.friendHoldList = new ArrayList();
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        FriendListThrDM friendListThrDM = new FriendListThrDM();
        friendListThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
        new ThrFriendList(this.mContext, friendListThrDM, this, null, ClassConstant.SUBDIR_SUPORT_FRIENDS).start();
        this.friendPgb.setVisibility(0);
    }

    void listRemove() {
        runOnUiThread(new C02296());
    }

    public void userClick(String fEmail, String fName) {
        startContainerUserClickActivity(fEmail, fName);
        finish();
    }

    private void startContainerUserClickActivity(String fEmail, String fName) {
        Intent intent = new Intent(this, ContainerFragmentActivity.class);
        intent.setFlags(131072);
        intent.putExtra(PreferenceAction.FRIEND_EMAIL, fEmail);
        intent.putExtra("FRIEND_NAME", fName);
        startActivity(intent);
    }

    public void onUserRequest(Object obj) {
        this.logCat.log(className, "onUserRequest", "in");
        UserRequestReturnDM dm = (UserRequestReturnDM) obj;
        runOnUiThread(new C02307());
        if (!dm.statusResult.equals("ok")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(UserManager.this).alert0(UserManager.this.getString(C0213R.string.alert_text_title), UserManager.this.getString(C0213R.string.message_text41), UserManager.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        } else if (dm.code.equals("200")) {
            this.requestList.clear();
            FriendListReturnDMSubDM friendListReturnDMSubDM = new FriendListReturnDMSubDM();
            friendListReturnDMSubDM.friend = dm.email;
            friendListReturnDMSubDM.name = dm.name;
            this.requestList.add(0, friendListReturnDMSubDM);
            runOnUiThread(new C02338());
        } else {
            runOnUiThread(new C02349());
        }
    }

    public void onFriendList(Object obj) {
        this.logCat.log(className, "onFriendList", "in");
        listRemove();
        FriendListReturnDM friendListReturnDM = new FriendListReturnDM();
        friendListReturnDM = (FriendListReturnDM) obj;
        if (friendListReturnDM.statusResult.equals("ok")) {
            if (friendListReturnDM.code.equals("200")) {
                this.logCat.log(className, "onFriendList sublist size", friendListReturnDM.subDMList.size() + "");
                try {
                    this.friendList.clear();
                    this.friendHoldList.clear();
                    this.requestList.clear();
                } catch (Exception e) {
                }
                final DBAction dbAction = new DBAction(this.mContext);
                for (int i = 0; i < friendListReturnDM.subDMList.size(); i++) {
                    if (((FriendListReturnDMSubDM) friendListReturnDM.subDMList.get(i)).status.equals("confirm")) {
                        this.friendList.add(friendListReturnDM.subDMList.get(i));
                    } else if (((FriendListReturnDMSubDM) friendListReturnDM.subDMList.get(i)).status.equals("waiting")) {
                        this.friendHoldList.add(friendListReturnDM.subDMList.get(i));
                    } else if (((FriendListReturnDMSubDM) friendListReturnDM.subDMList.get(i)).status.equals("add")) {
                        this.requestList.add(friendListReturnDM.subDMList.get(i));
                    }
                }
                final PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                FriendListReturnDMSubDM friendListReturnDMSubDM = new FriendListReturnDMSubDM();
                friendListReturnDMSubDM.name = pref.getString(PreferenceAction.MY_NAME) + " (" + getString(C0213R.string.usermanager_text_my) + ")";
                friendListReturnDMSubDM.friend = pref.getString(PreferenceAction.MY_EMAIL);
                this.friendList.add(0, friendListReturnDMSubDM);
                runOnUiThread(new Runnable() {
                    public void run() {
                        UserManager.this.logCat.log(UserManager.className, "friendList size", UserManager.this.friendList.size() + "");
                        Iterator it = UserManager.this.friendList.iterator();
                        while (it.hasNext()) {
                            final FriendListReturnDMSubDM dm = (FriendListReturnDMSubDM) it.next();
                            DetailUserFlist detailView = new DetailUserFlist(UserManager.this.mContext);
                            if (UserManager.this.email_from_container.equals(dm.friend)) {
                                detailView.userCircleIv.setImageResource(C0213R.drawable.btn_circle_selected);
                            } else if (UserManager.this.email_from_container.equals("") || UserManager.this.email_from_container == null) {
                                if (dm.friend.equals(new PreferenceAction(UserManager.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL))) {
                                    detailView.userCircleIv.setImageResource(C0213R.drawable.btn_circle_selected);
                                }
                            }
                            dbAction.insertFriendEventCount(dm);
                            detailView.setOnClickListener(new OnClickListener() {
                                public void onClick(View v) {
                                    UserManager.this.userClick(dm.friend, dm.name);
                                    PreferenceAction pref = new PreferenceAction(UserManager.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                                    FriendListThrDM friendListThrDM = new FriendListThrDM();
                                    friendListThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
                                    new ThrFriendList(UserManager.this.mContext, friendListThrDM, UserManager.this, null, ClassConstant.SUBDIR_SUPORT_FRIENDS).start();
                                }
                            });
                            if (dm.friend.equals(pref.getString(PreferenceAction.MY_EMAIL))) {
                                detailView.requestBt.setVisibility(8);
                                detailView.nameTv.setText(Html.fromHtml("<b>" + dm.name + "</b>"));
                                detailView.emailTv.setText(Html.fromHtml("<b>" + dm.friend + "</b>"));
                            } else {
                                detailView.requestBt.setVisibility(0);
                                detailView.nameTv.setText(dm.name);
                                detailView.emailTv.setText(dm.friend);
                            }
                            detailView.requestBt.setOnClickListener(new OnClickListener() {

                                class C02161 implements DialogInterface.OnClickListener {
                                    C02161() {
                                    }

                                    public void onClick(DialogInterface dialog, int id) {
                                        ChangestatusThrDM changeDM = new ChangestatusThrDM();
                                        changeDM.id = dm.id;
                                        changeDM.command = ChangestatusThrDM.USER_DEL;
                                        UserManager.this.logCat.log(UserManager.className, "dm.id", dm.id);
                                        new ThrChangestatus(UserManager.this.mContext, changeDM, UserManager.this, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
                                    }
                                }

                                class C02172 implements DialogInterface.OnClickListener {
                                    C02172() {
                                    }

                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.dismiss();
                                    }
                                }

                                public void onClick(View v) {
                                    String title = UserManager.this.mContext.getResources().getString(C0213R.string.alert_title);
                                    String btnOk = UserManager.this.mContext.getResources().getString(C0213R.string.btn_ok);
                                    String btnCancel = UserManager.this.mContext.getResources().getString(C0213R.string.btn_cancel);
                                    Builder alt_bld = new Builder(UserManager.this);
                                    alt_bld.setMessage(UserManager.this.mContext.getResources().getString(C0213R.string.alert_type22));
                                    alt_bld.setCancelable(false);
                                    alt_bld.setPositiveButton(btnOk, new C02161());
                                    alt_bld.setNegativeButton(btnCancel, new C02172());
                                    AlertDialog alert = alt_bld.create();
                                    alert.setTitle(title);
                                    alert.show();
                                }
                            });
                            UserManager.this.detailFlistLy.addView(detailView);
                            new Anim(UserManager.this.mContext).startAnimSlow(detailView, "in");
                        }
                        it = UserManager.this.friendHoldList.iterator();
                        while (it.hasNext()) {
                            dm = (FriendListReturnDMSubDM) it.next();
                            DetailUserHold detailView2 = new DetailUserHold(UserManager.this.mContext);
                            detailView2.nameTv.setText(dm.name);
                            detailView2.emailTv.setText(dm.friend);
                            UserManager.this.logCat.log(UserManager.className, "holdfriend", dm.friend);
                            detailView2.allowBt.setOnClickListener(new OnClickListener() {
                                public void onClick(View arg0) {
                                    UserManager.this.logCat.log(UserManager.className, "onclick2", dm.id);
                                    ChangestatusThrDM changeDm = new ChangestatusThrDM();
                                    changeDm.id = dm.id;
                                    changeDm.command = ChangestatusThrDM.USER_ALLOW;
                                    new ThrChangestatus(UserManager.this.mContext, changeDm, UserManager.this, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
                                }
                            });
                            detailView2.denyBt.setOnClickListener(new OnClickListener() {
                                public void onClick(View arg0) {
                                    UserManager.this.logCat.log(UserManager.className, "onclick2", dm.id);
                                    ChangestatusThrDM changeDm = new ChangestatusThrDM();
                                    changeDm.id = dm.id;
                                    changeDm.command = ChangestatusThrDM.USER_DEL;
                                    new ThrChangestatus(UserManager.this.mContext, changeDm, UserManager.this, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
                                }
                            });
                            UserManager.this.detailHoldFlistLy.addView(detailView2);
                        }
                        it = UserManager.this.requestList.iterator();
                        while (it.hasNext()) {
                            dm = (FriendListReturnDMSubDM) it.next();
                            DetailUserRequest detailView3 = new DetailUserRequest(UserManager.this.mContext);
                            if (dm.name.equals("null")) {
                                detailView3.nameTv.setVisibility(8);
                                detailView3.nameEmailSpTv.setVisibility(8);
                            } else {
                                detailView3.nameTv.setVisibility(0);
                                detailView3.nameEmailSpTv.setVisibility(0);
                            }
                            if (dm.status.equals("null") || dm.status.equals("")) {
                                detailView3.requestBt.setVisibility(0);
                                detailView3.deniedBt.setVisibility(8);
                            } else if (dm.status.equals("add")) {
                                detailView3.requestBt.setVisibility(8);
                                detailView3.deniedBt.setVisibility(0);
                            }
                            detailView3.nameTv.setText(dm.name);
                            detailView3.emailTv.setText(dm.friend);
                            detailView3.requestBt.setOnClickListener(new OnClickListener() {
                                public void onClick(View v) {
                                    UserManager.this.logCat.log(UserManager.className, "onclick", dm.id);
                                    PreferenceAction pref = new PreferenceAction(UserManager.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                                    NotiFriensRequestThrDM nDM = new NotiFriensRequestThrDM();
                                    nDM.my_email = pref.getString(PreferenceAction.MY_EMAIL);
                                    nDM.message = UserManager.this.mContext.getString(C0213R.string.noti_request_friend);
                                    nDM.friend_email = dm.friend;
                                    UserManager.this.logCat.log(UserManager.className, "notiresult", new SDConnection(nDM).notiFriendsRequestResult(UserManager.this.mContext, ClassConstant.SUBDIR_SUPORT_NOTI_FRIENDS));
                                    AddFriendThrDM addFriendThrDM = new AddFriendThrDM();
                                    addFriendThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
                                    addFriendThrDM.friendemail = dm.friend;
                                    new ThrAddFriend(UserManager.this.mContext, addFriendThrDM, UserManager.this, ClassConstant.SUBDIR_USER_ADDFRIEND).start();
                                    UserManager.this.logCat.log(UserManager.className, "request", "click");
                                }
                            });
                            detailView3.deniedBt.setOnClickListener(new OnClickListener() {
                                public void onClick(View v) {
                                    ChangestatusThrDM changeDm = new ChangestatusThrDM();
                                    changeDm.id = dm.id;
                                    changeDm.command = ChangestatusThrDM.USER_DENY;
                                    new ThrChangestatus(UserManager.this.mContext, changeDm, UserManager.this, ClassConstant.SUBDIR_USER_CHANGESTATUS).start();
                                }
                            });
                            UserManager.this.detailFlistRequestLy.addView(detailView3);
                        }
                    }
                });
            } else {
                runOnUiThread(new Runnable() {
                    public void run() {
                        new ShowAlert(UserManager.this).alert0(UserManager.this.getString(C0213R.string.alert_text_title), UserManager.this.getString(C0213R.string.message_text42), UserManager.this.getString(C0213R.string.alert_text_confirm));
                    }
                });
            }
        }
        runOnUiThread(new Runnable() {
            public void run() {
                UserManager.this.friendPgb.setVisibility(8);
                UserManager.this.friendHoldPgb.setVisibility(8);
                UserManager.this.mPullRefreshScrollView.onRefreshComplete();
            }
        });
    }

    public void onAddFriend(Object obj) {
        this.logCat.log(className, "onAddFriend", "in");
        listRemove();
        runOnUiThread(new Runnable() {
            public void run() {
                UserManager.this.friendPgb.setVisibility(0);
            }
        });
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        FriendListThrDM friendListThrDM = new FriendListThrDM();
        friendListThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
        new ThrFriendList(this.mContext, friendListThrDM, this, null, ClassConstant.SUBDIR_SUPORT_FRIENDS).start();
    }

    public void onChangestatus(Object obj) {
        this.logCat.log(className, "onChangestatus", "in");
        runOnUiThread(new Runnable() {
            public void run() {
                UserManager.this.friendPgb.setVisibility(0);
            }
        });
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        FriendListThrDM friendListThrDM = new FriendListThrDM();
        friendListThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
        new ThrFriendList(this.mContext, friendListThrDM, this, null, ClassConstant.SUBDIR_SUPORT_FRIENDS).start();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
