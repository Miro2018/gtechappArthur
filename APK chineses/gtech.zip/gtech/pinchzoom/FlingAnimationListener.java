package com.accumed.gtech.pinchzoom;

public interface FlingAnimationListener {
    void onComplete();

    void onMove(float f, float f2);
}
