package com.accumed.gtech.pinchzoom;

public interface Animation {
    boolean update(GestureImageView gestureImageView, long j);
}
