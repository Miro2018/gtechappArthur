package com.accumed.gtech.pinchzoom;

public interface ZoomAnimationListener {
    void onComplete();

    void onZoom(float f, float f2, float f3);
}
