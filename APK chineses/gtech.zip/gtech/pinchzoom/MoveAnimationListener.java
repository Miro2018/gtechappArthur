package com.accumed.gtech.pinchzoom;

public interface MoveAnimationListener {
    void onMove(float f, float f2);
}
