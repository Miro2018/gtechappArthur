package com.accumed.gtech.pinchzoom;

import android.graphics.PointF;
import android.view.MotionEvent;

public class VectorF {
    public float angle;
    public final PointF end = new PointF();
    public float length;
    public final PointF start = new PointF();

    public void calculateEndPoint() {
        this.end.x = (((float) Math.cos((double) this.angle)) * this.length) + this.start.x;
        this.end.y = (((float) Math.sin((double) this.angle)) * this.length) + this.start.y;
    }

    public void setStart(PointF p) {
        this.start.x = p.x;
        this.start.y = p.y;
    }

    public void setEnd(PointF p) {
        this.end.x = p.x;
        this.end.y = p.y;
    }

    public void set(MotionEvent event) {
        this.start.x = event.getX(0);
        this.start.y = event.getY(0);
        this.end.x = event.getX(1);
        this.end.y = event.getY(1);
    }

    public float calculateLength() {
        this.length = MathUtils.distance(this.start, this.end);
        return this.length;
    }

    public float calculateAngle() {
        this.angle = MathUtils.angle(this.start, this.end);
        return this.angle;
    }
}
