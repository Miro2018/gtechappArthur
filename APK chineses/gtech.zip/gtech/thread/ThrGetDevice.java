package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.GetDeviceThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrGetDevice extends Thread {
    final String className = "ThrGetDevice";
    GetDeviceThrDM getDeviceThrDM;
    LogCat logCat;
    Context mContext;
    OnGetDeviceListener onGetDeviceListener;

    public ThrGetDevice(Context context, GetDeviceThrDM dm, OnGetDeviceListener l) {
        this.onGetDeviceListener = l;
        this.getDeviceThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrGetDevice", "LoginThr", "in");
    }

    public void run() {
        String result = new SDConnection(this.getDeviceThrDM).getDeviceResult(this.mContext, ClassConstant.SUBDIR_GET_DEVICE);
        this.logCat.log("ThrGetDevice", "result", result);
        if (this.onGetDeviceListener != null) {
            this.onGetDeviceListener.onGetDevice(new MagicReturnDM().getDeviceReturnDM(result));
        }
    }
}
