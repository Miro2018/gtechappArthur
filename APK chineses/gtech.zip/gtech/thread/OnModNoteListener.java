package com.accumed.gtech.thread;

public interface OnModNoteListener {
    void onModNote(Object obj);
}
