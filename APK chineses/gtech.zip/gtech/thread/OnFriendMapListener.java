package com.accumed.gtech.thread;

public interface OnFriendMapListener {
    void onFriendMap(Object obj);
}
