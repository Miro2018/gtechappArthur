package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.AddNoteThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrAddNote extends Thread {
    AddNoteThrDM addNoteThrDM;
    final String className = "ThrAddNote";
    LogCat logCat;
    Context mContext;
    OnAddNoteListener onAddNoteListener;

    public ThrAddNote(Context context, AddNoteThrDM dm, OnAddNoteListener l) {
        this.onAddNoteListener = l;
        this.addNoteThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrAddNote", "ThrAddGlucose", "in");
    }

    public void run() {
        String result = new SDConnection(this.addNoteThrDM).getAddNoteResult(this.mContext, ClassConstant.SUBDIR_ADD_NOTE);
        this.logCat.log("ThrAddNote", "result", result);
        if (this.onAddNoteListener != null) {
            this.onAddNoteListener.onAddNote(new MagicReturnDM().addNoteReturnDM(result));
        }
    }
}
