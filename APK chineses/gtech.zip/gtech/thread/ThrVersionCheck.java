package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.util.LogCat;

public class ThrVersionCheck extends Thread {
    final String className = "ThrVersionCheck";
    LogCat logCat;
    Context mContext;
    OnVersionCheckListener onVersionCheckListener;

    public ThrVersionCheck(Context context, OnVersionCheckListener l) {
        this.onVersionCheckListener = l;
        this.logCat = new LogCat();
        this.mContext = context;
        this.logCat.log("ThrVersionCheck", "ThrVersionCheck", "in");
    }

    public void run() {
        String result = new SDConnection(null).getVersionResult(this.mContext, ClassConstant.SUBDIR_SUPORT_VERSION);
        this.logCat.log("ThrVersionCheck", "result", result);
        if (this.onVersionCheckListener != null) {
            this.onVersionCheckListener.onVersionCheck(result);
        }
    }
}
