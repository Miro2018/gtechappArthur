package com.accumed.gtech.thread;

public interface OnModGlucoseListener {
    void onModGlucose(Object obj);
}
