package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.fragments.OtherrecordFragment.OnOtherrecordListener;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.OtherrecordThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrModOtherrecord extends Thread {
    final String className = "ThrModOtherrecord";
    LogCat logCat;
    Context mContext;
    OnOtherrecordListener onOtherrecordListener;
    OtherrecordThrDM otherrecordThrDM;

    public ThrModOtherrecord(Context context, OtherrecordThrDM dm, OnOtherrecordListener l) {
        this.onOtherrecordListener = l;
        this.otherrecordThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrModOtherrecord", "ThrModOtherrecord", "in");
    }

    public void run() {
        String result = new SDConnection(this.otherrecordThrDM).getModOthersResult(this.mContext, ClassConstant.SUBDIR_MOD_OTHERS);
        this.logCat.log("ThrModOtherrecord", "result", result);
        if (this.onOtherrecordListener != null) {
            this.onOtherrecordListener.onUpdateDataSend(new MagicReturnDM().modOtherrecordReturnDM(result), this.otherrecordThrDM);
        }
    }
}
