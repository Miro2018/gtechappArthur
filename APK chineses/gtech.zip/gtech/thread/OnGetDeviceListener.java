package com.accumed.gtech.thread;

public interface OnGetDeviceListener {
    void onGetDevice(Object obj);
}
