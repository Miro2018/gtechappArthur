package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.FindPasswordThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrFindPassword extends Thread {
    final String className = "ThrFindPassword";
    FindPasswordThrDM findPasswordThrDM;
    LogCat logCat = new LogCat();
    Context mContext;
    String mSubDir;
    OnFindPasswordListener onFindPasswordListener;

    public ThrFindPassword(Context context, FindPasswordThrDM dm, OnFindPasswordListener l, String subDir) {
        this.onFindPasswordListener = l;
        this.findPasswordThrDM = dm;
        this.mSubDir = subDir;
        this.mContext = context;
        this.logCat.log("ThrFindPassword", "ThrFindPassword", "in");
    }

    public void run() {
        String result = new SDConnection(this.findPasswordThrDM).getFindPasswordResult(this.mContext, this.mSubDir);
        this.logCat.log("ThrFindPassword", "result", result);
        if (this.onFindPasswordListener != null) {
            this.onFindPasswordListener.onFindPassword(new MagicReturnDM().findPasswordReturnDM(result));
        }
    }
}
