package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.AddFriendThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrAddFriend extends Thread {
    AddFriendThrDM addFriendThrDM;
    final String className = "ThrAddFriend";
    LogCat logCat;
    Context mContext;
    String mSubDir;
    OnAddFriendListener onAddFriendListener;

    public ThrAddFriend(Context context, AddFriendThrDM dm, OnAddFriendListener l, String subDir) {
        this.onAddFriendListener = l;
        this.addFriendThrDM = dm;
        this.mSubDir = subDir;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrAddFriend", "ThrAddFriend", "in");
    }

    public void run() {
        String result = new SDConnection(this.addFriendThrDM).getAddFriendResult(this.mContext, this.mSubDir);
        this.logCat.log("ThrAddFriend", "result", result);
        if (this.onAddFriendListener != null) {
            this.onAddFriendListener.onAddFriend(new MagicReturnDM().addFriendReturnDM(result));
        }
    }
}
