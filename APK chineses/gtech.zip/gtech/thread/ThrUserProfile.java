package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.UserProfileThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrUserProfile extends Thread {
    final String className = "ThrFriendList";
    LogCat logCat;
    Context mContext;
    String mSubDir;
    OnUserProfileListener onUserProfileListener;
    UserProfileThrDM userProfileThrDM;

    public ThrUserProfile(Context context, UserProfileThrDM dm, OnUserProfileListener l, String subDir) {
        this.mContext = context;
        this.onUserProfileListener = l;
        this.userProfileThrDM = dm;
        this.logCat = new LogCat();
        this.mSubDir = subDir;
        this.logCat.log("ThrFriendList", "ThrUserProfile", "in");
    }

    public void run() {
        String result = new SDConnection(this.userProfileThrDM).getFriendListResult(this.mContext, this.mSubDir);
        this.logCat.log("ThrFriendList", "result", result);
        if (this.onUserProfileListener != null) {
            this.onUserProfileListener.onUserProfile(new MagicReturnDM().userProfileReturnDM(result));
        }
    }
}
