package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.ChangestatusThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrChangestatus extends Thread {
    ChangestatusThrDM changestatusThrDM;
    final String className = "ThrChangestatus";
    LogCat logCat;
    Context mContext;
    String mSubDir;
    OnChangestatusListener onChangestatusListener;

    public ThrChangestatus(Context context, ChangestatusThrDM dm, OnChangestatusListener l, String subDir) {
        this.onChangestatusListener = l;
        this.changestatusThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.mSubDir = subDir;
        this.logCat.log("ThrChangestatus", "ThrChangestatus", "in");
    }

    public void run() {
        String result = new SDConnection(this.changestatusThrDM).getChangestatusResult(this.mContext, this.mSubDir);
        this.logCat.log("ThrChangestatus", "result", result);
        if (this.onChangestatusListener != null) {
            this.onChangestatusListener.onChangestatus(new MagicReturnDM().changestatusReturnDM(result));
        }
    }
}
