package com.accumed.gtech.thread;

public interface OnChangestatusListener {
    void onChangestatus(Object obj);
}
