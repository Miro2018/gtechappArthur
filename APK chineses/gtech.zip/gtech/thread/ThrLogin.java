package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.LoginThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrLogin extends Thread {
    final String className = "ThrLogin";
    LogCat logCat;
    LoginThrDM loginTrDM;
    Context mContext;
    OnLoginListener onLoginListener;

    public ThrLogin(Context context, LoginThrDM dm, OnLoginListener l) {
        this.onLoginListener = l;
        this.loginTrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrLogin", "LoginThr", "in");
    }

    public void run() {
        String result = new SDConnection(this.loginTrDM).getLoginResult(this.mContext, ClassConstant.SUBDIR_LOGIN);
        this.logCat.log("ThrLogin", "result", result);
        if (this.onLoginListener != null) {
            this.onLoginListener.onLogin(new MagicReturnDM().loginReturnDM(result));
        }
    }
}
