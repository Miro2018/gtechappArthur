package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.DBStructure;
import com.accumed.gtech.datamodel.DeviceDM;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.GetDeviceThrDM;
import com.accumed.gtech.thread.datamodel.GetDeviceThrDMv1;
import com.accumed.gtech.thread.datamodel.ModUserThrDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;
import com.accumed.gtech.util.PreferenceAction;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SyncProfileDevice extends Thread {
    public static boolean SYNC_FAILD = false;
    public static int SYNC_FAILD_ADD_DEVICE = 2;
    public static int SYNC_FAILD_GETDEVICE = 1;
    public static int SYNC_FAILD_MODUSER = 0;
    public static boolean SYNC_OK = true;
    String className = "SyncProfileDevice";
    LogCat logCat = new LogCat();
    Context mContext;
    HashMap<String, Object> mSyncDM = new HashMap();
    MagicReturnDM magicReturnDM;
    OnSyncListener onSyncListener;

    public SyncProfileDevice(Context c, OnSyncListener l) {
        this.logCat.log(this.className, this.className, "in");
        this.mContext = c;
        this.onSyncListener = l;
        this.magicReturnDM = new MagicReturnDM();
    }

    public void run() {
        DBAction dbAction = new DBAction(this.mContext);
        ArrayList<DeviceDM> devList = dbAction.selectDevice();
        PreferenceAction preferenceAction = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        JSONObject j = new JSONObject();
        try {
            int i;
            j.put("email", preferenceAction.getString(PreferenceAction.MY_EMAIL));
            JSONArray jarr = new JSONArray();
            for (i = 0; i < devList.size(); i++) {
                JSONObject j1 = new JSONObject();
                j1.put("deviceid", ((DeviceDM) devList.get(i)).device_id);
                ArrayList<LogDM> lastValueList = new ArrayList();
                lastValueList = dbAction.selectLogList("select * from log where category='0' and manualinput='0' limit 0,5");
                j1.put("lastvalue", "");
                jarr.put(j1);
            }
            j.put(DBStructure.DB_TABLE_NAME_DEVICE, jarr);
            this.logCat.log(this.className, "dev_jstr", j.toString());
            GetDeviceThrDMv1 dm = new GetDeviceThrDMv1();
            dm.data = j.toString();
            String devResult = new SDConnection(dm).getDeviceResultV1(this.mContext, ClassConstant.SUBDIR_SUPORT_ADDMOD_USERDEVICE);
            this.logCat.log(this.className, "devicejons reulst", devResult);
            if (devResult != null) {
                JSONObject jSONObject = new JSONObject(devResult);
                if (jSONObject.getString("code").equals("200")) {
                    JSONArray rjArr = new JSONArray(jSONObject.getString("data"));
                    for (i = 0; i < rjArr.length(); i++) {
                        String devId = new JSONObject(rjArr.getString(i)).getString("deviceid");
                        if (dbAction.getCount("select * from device where device_id='" + devId + "'") == 0) {
                            dbAction.executeQuery("insert into device(device_id) values('" + devId + "')");
                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private ModUserThrDM modUserThrDM() {
        PreferenceAction prefProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        PreferenceAction prefSetting = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        ModUserThrDM dm = new ModUserThrDM();
        dm.MY_EMAIL = prefProfile.getString(PreferenceAction.MY_EMAIL);
        dm.MY_SERVER_ID = prefProfile.getString(PreferenceAction.MY_SERVER_ID);
        dm.MY_NAME = prefProfile.getString(PreferenceAction.MY_NAME);
        dm.MY_BIRTH = prefProfile.getString(PreferenceAction.MY_BIRTH);
        dm.MY_GENDER = prefProfile.getString(PreferenceAction.MY_GENDER);
        dm.MY_HEIGHT = prefProfile.getString(PreferenceAction.MY_HEIGHT);
        dm.MY_HEIGHT_UNIT = prefProfile.getString(PreferenceAction.MY_HEIGHT_UNIT);
        dm.MY_WEIGHT = prefProfile.getString(PreferenceAction.MY_WEIGHT);
        dm.MY_WEIGHT_UNIT = prefProfile.getString(PreferenceAction.MY_WEIGHT_UNIT);
        dm.MY_OCCOURDAY = prefProfile.getString(PreferenceAction.MY_OCCOURDAY);
        dm.MY_BLOOD_SUGAR_TYPE = prefProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_TYPE);
        dm.MY_BLOOD_SUGAR_UNIT = prefProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
        dm.MY_HIGH_BLOOD_SUGAR = prefProfile.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR);
        dm.MY_LOW_BLOOD_SUGAR = prefProfile.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR);
        dm.MY_DATE_METHOD = prefSetting.getString(PreferenceAction.MY_DATE_METHOD);
        dm.MY_TIME_METHOD = prefSetting.getString(PreferenceAction.MY_TIME_METHOD);
        dm.MY_LANGUAGE = prefSetting.getString(PreferenceAction.MY_LANGUAGE);
        this.logCat.log(this.className, "dm.MY_SERVER_ID", dm.MY_SERVER_ID);
        this.logCat.log(this.className, "dm.MY_EMAIL", dm.MY_EMAIL);
        this.logCat.log(this.className, "dm.MY_PASSWORD", dm.MY_PASSWORD);
        this.logCat.log(this.className, "dm.MY_NAME", dm.MY_NAME);
        this.logCat.log(this.className, "dm.MY_BIRTH", dm.MY_BIRTH);
        this.logCat.log(this.className, "dm.MY_GENDER", dm.MY_GENDER);
        this.logCat.log(this.className, "dm.MY_HEIGHT", dm.MY_HEIGHT);
        this.logCat.log(this.className, "dm.MY_HEIGHT_UNIT", dm.MY_HEIGHT_UNIT);
        this.logCat.log(this.className, "dm.MY_WEIGHT", dm.MY_WEIGHT);
        this.logCat.log(this.className, "dm.MY_WEIGHT_UNIT", dm.MY_WEIGHT_UNIT);
        this.logCat.log(this.className, "dm.MY_OCCOURDAY", dm.MY_OCCOURDAY);
        this.logCat.log(this.className, "dm.MY_BLOOD_SUGAR_TYPE", dm.MY_BLOOD_SUGAR_TYPE);
        this.logCat.log(this.className, "dm.MY_BLOOD_SUGAR_UNIT", dm.MY_BLOOD_SUGAR_UNIT);
        this.logCat.log(this.className, "dm.MY_HIGH_BLOOD_SUGAR", dm.MY_HIGH_BLOOD_SUGAR);
        this.logCat.log(this.className, "dm.MY_LOW_BLOOD_SUGAR", dm.MY_LOW_BLOOD_SUGAR);
        this.logCat.log(this.className, "dm.MY_DATE_METHOD", dm.MY_DATE_METHOD);
        this.logCat.log(this.className, "dm.MY_TIME_METHOD", dm.MY_TIME_METHOD);
        this.logCat.log(this.className, "dm.MY_LANGUAGE", dm.MY_LANGUAGE);
        return dm;
    }

    private GetDeviceThrDM getDeviceThrDM() {
        GetDeviceThrDM dm = new GetDeviceThrDM();
        dm.email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        return dm;
    }
}
