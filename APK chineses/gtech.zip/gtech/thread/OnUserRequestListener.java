package com.accumed.gtech.thread;

public interface OnUserRequestListener {
    void onUserRequest(Object obj);
}
