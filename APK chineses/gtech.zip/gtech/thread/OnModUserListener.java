package com.accumed.gtech.thread;

public interface OnModUserListener {
    void onModUser(Object obj);
}
