package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.FriendListThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrFriendList extends Thread {
    final String className = "ThrFriendList";
    FriendListThrDM friendListThrDM;
    LogCat logCat;
    Context mContext;
    String mSubDir;
    OnFriendListListener onFriendListListener;
    OnFriendMapListener onFriendMapListener;

    public ThrFriendList(Context context, FriendListThrDM dm, OnFriendListListener l1, OnFriendMapListener l2, String subDir) {
        this.onFriendListListener = l1;
        this.onFriendMapListener = l2;
        this.friendListThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.mSubDir = subDir;
        this.logCat.log("ThrFriendList", "ThrFriendList", "in");
    }

    public void run() {
        String result = new SDConnection(this.friendListThrDM).getFriendListResult(this.mContext, this.mSubDir);
        this.logCat.log("ThrFriendList", "result", result);
        if (this.onFriendListListener != null) {
            this.onFriendListListener.onFriendList(new MagicReturnDM().friendListReturnDM(result));
        }
        if (this.onFriendMapListener != null) {
            this.onFriendMapListener.onFriendMap(new MagicReturnDM().friendMapReturn(result));
        }
    }
}
