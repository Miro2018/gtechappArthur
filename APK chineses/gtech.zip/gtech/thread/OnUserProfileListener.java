package com.accumed.gtech.thread;

public interface OnUserProfileListener {
    void onUserProfile(Object obj);
}
