package com.accumed.gtech.thread.datamodel;

public class ModOtherrecordReturnDM {
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
