package com.accumed.gtech.thread.datamodel;

public class FriendListReturnDMSubDM {
    public String eventcount = "";
    public String friend = "";
    public String id = "";
    public String name = "";
    public String status = "";
}
