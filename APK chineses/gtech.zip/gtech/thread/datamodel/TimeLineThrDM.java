package com.accumed.gtech.thread.datamodel;

public class TimeLineThrDM {
    public String email = "";
    public String enddate = "";
    public String return_num = "";
    public String start_num = "";
    public String startdate = "";
}
