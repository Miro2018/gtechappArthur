package com.accumed.gtech.thread.datamodel;

public class ChangestatusReturnDM {
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
