package com.accumed.gtech.thread.datamodel;

import com.accumed.gtech.util.PreferenceAction;

public class AddUserThrDM {
    public String MY_BIRTH = "";
    public String MY_BLOOD_SUGAR_TYPE = "";
    public String MY_BLOOD_SUGAR_UNIT = "";
    public String MY_DATA_SAVE_PERIOD = PreferenceAction.MY_DATA_SAVE_PERIOD;
    public String MY_DATE_METHOD = PreferenceAction.MY_DATE_METHOD;
    public String MY_EMAIL = "";
    public String MY_GENDER = "";
    public String MY_HEIGHT = "";
    public String MY_HEIGHT_UNIT = "";
    public String MY_HIGH_BLOOD_SUGAR = "";
    public String MY_LANGUAGE = PreferenceAction.MY_LANGUAGE;
    public String MY_LOW_BLOOD_SUGAR = "";
    public String MY_NAME = "";
    public String MY_OCCOURDAY = "";
    public String MY_PASSWORD = "";
    public String MY_SERVER_CREATE_AT = "";
    public String MY_TIME_METHOD = PreferenceAction.MY_TIME_METHOD;
    public String MY_WEIGHT = "";
    public String MY_WEIGHT_UNIT = "";
}
