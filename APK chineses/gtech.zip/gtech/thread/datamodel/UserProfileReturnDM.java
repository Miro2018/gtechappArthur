package com.accumed.gtech.thread.datamodel;

public class UserProfileReturnDM {
    public String birth = "";
    public String code = "";
    public String created_at = "";
    public String datetype = "";
    public String diabetestype = "";
    public String diabeticsince = "";
    public String email = "";
    public String gender = "";
    public String glucoseunit = "";
    public String height = "";
    public String heightunit = "";
    public String hyper = "";
    public String hypo = "";
    public String id = "";
    public String language = "";
    public String name = "";
    public String photo1 = "";
    public String photo2 = "";
    public String statusResult = "";
    public String timetype = "";
    public String weight = "";
    public String weightunit = "";
}
