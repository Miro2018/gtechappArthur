package com.accumed.gtech.thread.datamodel;

public class AddG_I_ThrDM {
    public String data = "";
}
