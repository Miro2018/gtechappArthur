package com.accumed.gtech.thread.datamodel;

public class DeviceThrDM {
    public String email = "";
}
