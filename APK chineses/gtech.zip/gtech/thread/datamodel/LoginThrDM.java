package com.accumed.gtech.thread.datamodel;

public class LoginThrDM {
    public String email = "";
    public String password = "";
    public String registration_device = "android";
    public String registration_id = "";
}
