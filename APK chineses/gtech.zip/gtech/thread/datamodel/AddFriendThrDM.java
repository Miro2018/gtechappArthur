package com.accumed.gtech.thread.datamodel;

public class AddFriendThrDM {
    public String email = "";
    public String friendemail = "";
}
