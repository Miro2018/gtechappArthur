package com.accumed.gtech.thread.datamodel;

public class FriendListThrDM {
    public String email = "";
}
