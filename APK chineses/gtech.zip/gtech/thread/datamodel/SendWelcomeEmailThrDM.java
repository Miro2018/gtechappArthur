package com.accumed.gtech.thread.datamodel;

public class SendWelcomeEmailThrDM {
    public String email = "";
}
