package com.accumed.gtech.thread.datamodel;

public class UserRequestDM {
    public String email = "";
}
