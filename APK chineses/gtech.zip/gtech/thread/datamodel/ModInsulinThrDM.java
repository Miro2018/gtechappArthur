package com.accumed.gtech.thread.datamodel;

public class ModInsulinThrDM {
    public String id = "";
    public String idate = "";
    public String iproduct = "";
    public String itype = "";
    public String ivalue = "";
    public String manualinput = "";
}
