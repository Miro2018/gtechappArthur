package com.accumed.gtech.thread.datamodel;

public class AddInsulinReturnDM {
    public String code = "";
    public String id = "";
    public String result = "";
    public String statusResult = "";
}
