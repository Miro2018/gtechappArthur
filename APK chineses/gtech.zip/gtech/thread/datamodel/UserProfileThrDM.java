package com.accumed.gtech.thread.datamodel;

public class UserProfileThrDM {
    public String email = "";
}
