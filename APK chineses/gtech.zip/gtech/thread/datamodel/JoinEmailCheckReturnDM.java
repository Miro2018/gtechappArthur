package com.accumed.gtech.thread.datamodel;

public class JoinEmailCheckReturnDM {
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
