package com.accumed.gtech.thread.datamodel;

public class ModDeviceThrDM {
    public String deviceid = "";
    public String email = "";
    public String id = "";
    public String lastvalue = "";
}
