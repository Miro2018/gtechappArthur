package com.accumed.gtech.thread.datamodel;

public class AddMod_G_I_ThrDM {
    public String data = "";
}
