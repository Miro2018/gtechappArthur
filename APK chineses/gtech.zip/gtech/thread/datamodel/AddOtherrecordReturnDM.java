package com.accumed.gtech.thread.datamodel;

public class AddOtherrecordReturnDM {
    public String code = "";
    public String id = "";
    public String result = "";
    public String statusResult = "";
}
