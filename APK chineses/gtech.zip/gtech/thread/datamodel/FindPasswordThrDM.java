package com.accumed.gtech.thread.datamodel;

public class FindPasswordThrDM {
    public String email = "";
}
