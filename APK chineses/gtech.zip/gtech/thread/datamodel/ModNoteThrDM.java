package com.accumed.gtech.thread.datamodel;

public class ModNoteThrDM {
    public String email = "";
    public String id = "";
    public String imgs = "";
    public String ndate = "";
    public String ntype = "";
    public String nvalue = "";
    public String targetemail = "";
    public String thumb = "";
}
