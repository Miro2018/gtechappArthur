package com.accumed.gtech.thread.datamodel;

public class GetDeviceThrDMv1 {
    public String data = "";
}
