package com.accumed.gtech.thread.datamodel;

public class AddFriendReturnDM {
    public String code = "";
    public String friendid = "";
    public String result = "";
    public String statusResult = "";
    public String userid = "";
}
