package com.accumed.gtech.thread.datamodel;

public class DelOtherrecordReturnDM {
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
