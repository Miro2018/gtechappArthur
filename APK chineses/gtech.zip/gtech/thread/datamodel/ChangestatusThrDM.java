package com.accumed.gtech.thread.datamodel;

public class ChangestatusThrDM {
    public static String USER_ALLOW = "1";
    public static String USER_DEL = "0";
    public static String USER_DENY = "2";
    public String command = "";
    public String id = "";
}
