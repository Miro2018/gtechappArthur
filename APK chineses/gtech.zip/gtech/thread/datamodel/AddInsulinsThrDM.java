package com.accumed.gtech.thread.datamodel;

public class AddInsulinsThrDM {
    public String data = "";
}
