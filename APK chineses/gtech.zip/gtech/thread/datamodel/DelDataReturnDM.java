package com.accumed.gtech.thread.datamodel;

public class DelDataReturnDM {
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
