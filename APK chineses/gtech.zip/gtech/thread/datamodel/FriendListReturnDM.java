package com.accumed.gtech.thread.datamodel;

import java.util.ArrayList;

public class FriendListReturnDM {
    public String code = "";
    public String statusResult = "";
    public ArrayList<FriendListReturnDMSubDM> subDMList = new ArrayList();
}
