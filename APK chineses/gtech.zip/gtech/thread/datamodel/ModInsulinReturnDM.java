package com.accumed.gtech.thread.datamodel;

public class ModInsulinReturnDM {
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
