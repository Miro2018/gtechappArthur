package com.accumed.gtech.thread.datamodel;

public class ModGlucoseReturnDM {
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
