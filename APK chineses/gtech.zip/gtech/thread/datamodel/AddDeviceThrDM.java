package com.accumed.gtech.thread.datamodel;

public class AddDeviceThrDM {
    public String deviceid = "";
    public String email = "";
    public String lastvalue = "";
}
