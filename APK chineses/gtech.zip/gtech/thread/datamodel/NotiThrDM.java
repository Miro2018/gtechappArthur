package com.accumed.gtech.thread.datamodel;

public class NotiThrDM {
    public String email = "";
    public String gubun = "";
    public String gubun_num = "";
    public String message = "";
    public String name = "";
    public String targetemail = "";
}
