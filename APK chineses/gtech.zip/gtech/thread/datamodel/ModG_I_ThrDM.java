package com.accumed.gtech.thread.datamodel;

public class ModG_I_ThrDM {
    public String data = "";
}
