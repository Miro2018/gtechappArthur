package com.accumed.gtech.thread.datamodel;

public class ModGlucoseDM {
    public String blood_sugar_eat_origin = "";
    public String deviceid = "";
    public String email = "";
    public String gdate = "";
    public String gevent = "";
    public String gmodevent = "";
    public String gtempeature = "";
    public String gvalue = "";
    public String id = "";
    public String manualinput = "";
}
