package com.accumed.gtech.thread.datamodel;

public class ModNoteReturnDM {
    public String code = "";
    public String filename = "";
    public String result = "";
    public String statusResult = "";
    public String thumbnail = "";
}
