package com.accumed.gtech.thread.datamodel;

public class UserRequestReturnDM {
    public String code = "";
    public String created_at = "";
    public String email = "";
    public String id = "";
    public String name = "";
    public String statusResult = "";
}
