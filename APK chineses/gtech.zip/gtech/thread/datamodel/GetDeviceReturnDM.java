package com.accumed.gtech.thread.datamodel;

import java.util.ArrayList;

public class GetDeviceReturnDM {
    public String code = "";
    public ArrayList<GetDeviceReturnDMSubDM> deviceList = new ArrayList();
    public String statusResult = "";
}
