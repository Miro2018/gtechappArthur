package com.accumed.gtech.thread.datamodel;

public class GetDeviceThrDM {
    public String email = "";
}
