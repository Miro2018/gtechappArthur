package com.accumed.gtech.thread.datamodel;

import java.util.ArrayList;

public class AddG_I_ReturnDM {
    public ArrayList<String> clientSeqList = new ArrayList();
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
