package com.accumed.gtech.thread.datamodel;

public class DelDataThrDM {
    public String email = "";
    public String id = "";
    public String ntype = "";
}
