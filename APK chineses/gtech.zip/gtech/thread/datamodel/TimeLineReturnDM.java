package com.accumed.gtech.thread.datamodel;

import com.accumed.gtech.datamodel.LogDM;
import java.util.ArrayList;

public class TimeLineReturnDM {
    public String code = "";
    public String profile_birth = "";
    public String profile_created_at = "";
    public String profile_datetype = "";
    public String profile_diabetestype = "";
    public String profile_diabeticsince = "";
    public String profile_email = "";
    public String profile_gender = "";
    public String profile_glucoseunit = "";
    public String profile_height = "";
    public String profile_heightunit = "";
    public String profile_hyper = "";
    public String profile_hypo = "";
    public String profile_id = "";
    public String profile_language = "";
    public String profile_name = "";
    public String profile_photo1 = "";
    public String profile_photo2 = "";
    public String profile_timetype = "";
    public String profile_weight = "";
    public String profile_weightunit = "";
    public String statusResult = "";
    public ArrayList<TimeLineReturnDMSubDM> subDMList = new ArrayList();
    public ArrayList<LogDM> subLogDMList = new ArrayList();
}
