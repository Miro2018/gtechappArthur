package com.accumed.gtech.thread.datamodel;

public class GetDeviceReturnDMSubDM {
    public String deviceid = "";
    public String id = "";
    public String lastvalue = "";
}
