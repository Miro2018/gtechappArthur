package com.accumed.gtech.thread.datamodel;

public class AddDeviceReturnDM {
    public String code = "";
    public String id = "";
    public String result = "";
    public String statusResult = "";
}
