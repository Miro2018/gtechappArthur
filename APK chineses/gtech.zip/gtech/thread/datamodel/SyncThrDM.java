package com.accumed.gtech.thread.datamodel;

import android.content.Context;
import com.accumed.gtech.util.LogCat;
import java.util.HashMap;

public class SyncThrDM {
    static String className = "SyncThrDM";
    LogCat logCat = new LogCat();
    Context mContext;
    HashMap<String, Object> mSyncDM = new HashMap();

    public SyncThrDM(Context c) {
        this.mContext = c;
    }

    public HashMap<String, Object> getSyncDM() {
        return this.mSyncDM;
    }

    private ModUserThrDM getModUserDM() {
        return null;
    }

    private void geAddDeviceId() {
    }
}
