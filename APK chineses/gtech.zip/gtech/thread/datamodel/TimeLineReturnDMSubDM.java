package com.accumed.gtech.thread.datamodel;

public class TimeLineReturnDMSubDM {
    public String created_at = "";
    public String deviceid = "";
    public String email = "";
    public String gdate = "";
    public String gevent = "";
    public String gmodevent = "";
    public String gtempeature = "";
    public String gvalue = "";
    public String idate = "";
    public String iproduct = "";
    public String itype = "";
    public String ivalue = "";
    public String manualinput = "";
    public String ndate = "";
    public String ntype = "";
    public String nvalue = "";
    public String picture = "";
    public String targetemail = "";
    public String thumbnail = "";
    public String tid = "";
    public String tkind = "";
}
