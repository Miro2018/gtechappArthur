package com.accumed.gtech.thread.datamodel;

public class NotiFriensRequestThrDM {
    public String friend_email = "";
    public String message = "";
    public String my_email = "";
    public String my_name = "";
}
