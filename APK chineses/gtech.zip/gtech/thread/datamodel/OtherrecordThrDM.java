package com.accumed.gtech.thread.datamodel;

public class OtherrecordThrDM {
    public String _id = "";
    public String bloodpressure = "";
    public String bmi = "";
    public String email = "";
    public String hba1c = "";
    public String hba1cunit = "";
    public String hdl = "";
    public String input_date = "";
    public String ldl = "";
    public String odate = "";
    public String seq = "";
    public String system_date = "";
    public String tc = "";
    public String tg = "";
    public String update_flag = "";
    public String waist = "";
    public String waistunit = "";
    public String weight = "";
}
