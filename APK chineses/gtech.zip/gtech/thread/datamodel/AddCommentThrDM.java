package com.accumed.gtech.thread.datamodel;

public class AddCommentThrDM {
    public String email = "";
    public String imgs = "";
    public String ndate = "";
    public String ntype = "";
    public String nvalue = "";
    public String targetemail = "";
    public String thumb = "";
}
