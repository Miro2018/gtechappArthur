package com.accumed.gtech.thread.datamodel;

public class DelOtherrecordThrDM {
    public String email = "";
    public String id = "";
}
