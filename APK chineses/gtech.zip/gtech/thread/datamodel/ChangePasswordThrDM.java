package com.accumed.gtech.thread.datamodel;

public class ChangePasswordThrDM {
    public String email = "";
    public String newpassword = "";
    public String password = "";
}
