package com.accumed.gtech.thread.datamodel;

public class FindPasswordReturnDM {
    public String code = "";
    public String result = "";
    public String statusResult = "";
}
