package com.accumed.gtech.thread.datamodel;

public class AddGlucoseThrDM {
    public String deviceid = "";
    public String email = "";
    public String gdate = "";
    public String gevent = "";
    public String gmodevent = "";
    public String gtempeature = "";
    public String gvalue = "";
    public String manualinput = "";
}
