package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.SendWelcomeEmailThrDM;
import com.accumed.gtech.util.LogCat;

public class ThrSendWelcomeEmail extends Thread {
    final String className = "ThrModUser";
    LogCat logCat = new LogCat();
    Context mContext;
    SendWelcomeEmailThrDM sendWelcomeEmailThrDM;

    public ThrSendWelcomeEmail(Context context, SendWelcomeEmailThrDM dm) {
        this.sendWelcomeEmailThrDM = dm;
        this.mContext = context;
        this.logCat.log("ThrModUser", "ThrSendWelcomeEmail", "in");
    }

    public void run() {
        this.logCat.log("ThrModUser", "result", new SDConnection(this.sendWelcomeEmailThrDM).getSendWelcomeEmail(this.mContext, ClassConstant.SUBDIR_JOIN_COMPLETE_SEND_EMAIL));
    }
}
