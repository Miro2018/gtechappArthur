package com.accumed.gtech.thread;

public interface OnFindPasswordListener {
    void onFindPassword(Object obj);
}
