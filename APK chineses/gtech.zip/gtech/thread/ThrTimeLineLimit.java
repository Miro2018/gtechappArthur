package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.TimeLineReturnDM;
import com.accumed.gtech.thread.datamodel.TimeLineThrDM;
import com.accumed.gtech.thread.datamodel.UserProfileThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;
import java.util.ArrayList;

public class ThrTimeLineLimit extends Thread {
    final String className = "ThrTimeLineLimit";
    LogCat logCat;
    ArrayList<LogDM> logList;
    Context mContext;
    String mSubDir;
    OnTimeLineLimitListener onTimeLineLimitListener;
    TimeLineThrDM timeLineThrDM;
    String userEmail;

    public ThrTimeLineLimit(Context c, TimeLineThrDM dm, OnTimeLineLimitListener l, String subDir) {
        this.onTimeLineLimitListener = l;
        this.mContext = c;
        this.timeLineThrDM = dm;
        this.userEmail = this.timeLineThrDM.email;
        this.mSubDir = subDir;
        this.logList = new ArrayList();
        this.logCat = new LogCat();
        this.logCat.log("ThrTimeLineLimit", "ThrTimeLineLimit", "in");
    }

    public void run() {
        this.logList = new ArrayList();
        this.logCat.log("ThrTimeLineLimit", "0 / s_num / re_num", Integer.toString(0) + "/" + this.timeLineThrDM.start_num + " / " + this.timeLineThrDM.return_num);
        String result = new SDConnection(this.timeLineThrDM).suport_getTimeLineResult(this.mContext, this.mSubDir);
        this.logCat.log("ThrTimeLineLimit", "result", result);
        TimeLineReturnDM tiemLineReturnDM = new MagicReturnDM(this.mContext).suport_timeLineReturnDM(result);
        this.logCat.log("ThrTimeLineLimit", "tiemLineReturnDM", tiemLineReturnDM.code);
        this.logCat.log("ThrTimeLineLimit", "tiemLineReturnDM", tiemLineReturnDM.statusResult);
        UserProfileThrDM userProfileThrDM = new UserProfileThrDM();
        userProfileThrDM.email = this.userEmail;
        String pResult = new SDConnection(userProfileThrDM).getUserProfileResult(this.mContext, ClassConstant.SUBDIR_USER_PROFILE);
        if (this.onTimeLineLimitListener != null) {
            this.onTimeLineLimitListener.onTimeLineLimit_userprofile_suport(new MagicReturnDM().userProfileReturnDM(pResult));
            this.onTimeLineLimitListener.onTimeLineLimit(tiemLineReturnDM.subLogDMList);
        }
    }
}
