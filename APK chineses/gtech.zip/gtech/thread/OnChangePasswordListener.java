package com.accumed.gtech.thread;

public interface OnChangePasswordListener {
    void OnChangePassword(Object obj);
}
