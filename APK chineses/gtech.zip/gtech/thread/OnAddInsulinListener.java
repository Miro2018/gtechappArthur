package com.accumed.gtech.thread;

public interface OnAddInsulinListener {
    void onAddInsulin(Object obj);
}
