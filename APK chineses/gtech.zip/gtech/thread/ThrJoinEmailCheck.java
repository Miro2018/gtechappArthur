package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.JoinEmailCheckThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrJoinEmailCheck extends Thread {
    final String className = "ThrJoinEmailCheck";
    JoinEmailCheckThrDM joinEmailCheckThrDM;
    LogCat logCat;
    Context mContext;
    OnJoinEmailCheckListener onJoinEmailCheckListener;

    public ThrJoinEmailCheck(Context context, JoinEmailCheckThrDM dm, OnJoinEmailCheckListener l) {
        this.onJoinEmailCheckListener = l;
        this.joinEmailCheckThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrJoinEmailCheck", "LoginThr", "in");
    }

    public void run() {
        String result = new SDConnection(this.joinEmailCheckThrDM).getJoinEmailCheckResult(this.mContext, ClassConstant.SUBDIR_JOIN_EMAILCHECK);
        this.logCat.log("ThrJoinEmailCheck", "result", result);
        if (this.onJoinEmailCheckListener != null) {
            this.onJoinEmailCheckListener.onJoinEmailCheckListener(new MagicReturnDM().joinEmailCheckReturnDM(result));
        }
    }
}
