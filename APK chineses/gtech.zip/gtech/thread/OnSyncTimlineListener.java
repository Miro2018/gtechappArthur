package com.accumed.gtech.thread;

public interface OnSyncTimlineListener {
    public static final int SYNC_TIMELINE_FETCH = 2;
    public static final int SYNC_TIMELINE_FINISH = 1;
    public static final int SYNC_TIMELINE_START = 0;

    void onSyncTimeline(Object obj, Object obj2);
}
