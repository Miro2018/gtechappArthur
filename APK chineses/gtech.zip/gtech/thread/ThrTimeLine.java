package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.TimeLineReturnDM;
import com.accumed.gtech.thread.datamodel.TimeLineThrDM;
import com.accumed.gtech.thread.datamodel.UserProfileThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;
import java.util.ArrayList;

public class ThrTimeLine extends Thread {
    final String className = "ThrTimeLine";
    LogCat logCat;
    ArrayList<LogDM> logList;
    Context mContext;
    String mSubDir;
    OnTimeLineListener onTimeLineListener;
    TimeLineThrDM timeLineThrDM;
    String userEmail;

    public ThrTimeLine(Context context, TimeLineThrDM dm, OnTimeLineListener l, String subDir) {
        this.onTimeLineListener = l;
        this.timeLineThrDM = dm;
        this.userEmail = this.timeLineThrDM.email;
        this.mSubDir = subDir;
        this.mContext = context;
        this.logList = new ArrayList();
        this.logCat = new LogCat();
        this.logCat.log("ThrTimeLine", "timeLineThrDM", "in");
    }

    public void run() {
        this.logList = new ArrayList();
        this.logCat.log("ThrTimeLine", "0 / start_num / return_num", Integer.toString(0) + "/" + this.timeLineThrDM.start_num + " / " + this.timeLineThrDM.return_num);
        SDConnection conn = new SDConnection(this.timeLineThrDM);
        String result = conn.suport_getTimeLineResult(this.mContext, this.mSubDir);
        this.logCat.log("ThrTimeLine", "result", result);
        TimeLineReturnDM tiemLineReturnDM = new MagicReturnDM().suport_timeLineReturnDM(result);
        this.logCat.log("ThrTimeLine", "tiemLineReturnDM", tiemLineReturnDM.code);
        this.logCat.log("ThrTimeLine", "tiemLineReturnDM", tiemLineReturnDM.statusResult);
        int start_num = Integer.parseInt(this.timeLineThrDM.start_num);
        int i = 0;
        while (tiemLineReturnDM.code.equals("200") && tiemLineReturnDM.statusResult.equals("ok")) {
            this.logCat.log("ThrTimeLine", "while", "in");
            if (i > 0) {
                start_num = Integer.parseInt(this.timeLineThrDM.start_num) + Integer.parseInt(this.timeLineThrDM.return_num);
            } else if (i == 0) {
                start_num = Integer.parseInt(this.timeLineThrDM.start_num);
            }
            this.timeLineThrDM.start_num = Integer.toString(start_num);
            conn.setDataModel(this.timeLineThrDM);
            result = conn.suport_getTimeLineResult(this.mContext, this.mSubDir);
            tiemLineReturnDM = new MagicReturnDM().suport_timeLineReturnDM(result);
            this.logList.addAll(tiemLineReturnDM.subLogDMList);
            i++;
            this.logCat.log("ThrTimeLine", "i / start_num / return_num", Integer.toString(i) + "/" + Integer.toString(start_num) + " / " + Integer.parseInt(this.timeLineThrDM.return_num));
            this.logCat.log("ThrTimeLine", "result", result);
        }
        UserProfileThrDM userProfileThrDM = new UserProfileThrDM();
        userProfileThrDM.email = this.userEmail;
        String pResult = new SDConnection(userProfileThrDM).getUserProfileResult(this.mContext, ClassConstant.SUBDIR_USER_PROFILE);
        if (this.onTimeLineListener != null) {
            this.onTimeLineListener.onTimeLIne_userprofile_suport(new MagicReturnDM().userProfileReturnDM(pResult));
            this.onTimeLineListener.onTimeLine_suport(this.logList);
        }
    }
}
