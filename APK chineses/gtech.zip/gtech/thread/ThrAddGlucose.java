package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.AddGlucoseThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrAddGlucose extends Thread {
    AddGlucoseThrDM addGlucoseDM;
    final String className = "ThrAddGlucose";
    LogCat logCat;
    Context mContext;
    OnAddGlucoseListener onAddGlucoseListener;

    public ThrAddGlucose(Context context, AddGlucoseThrDM dm, OnAddGlucoseListener l) {
        this.onAddGlucoseListener = l;
        this.addGlucoseDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrAddGlucose", "ThrAddGlucose", "in");
    }

    public void run() {
        String result = new SDConnection(this.addGlucoseDM).getAddGlucoseResult(this.mContext, ClassConstant.SUBDIR_ADD_GLUCOSE);
        this.logCat.log("ThrAddGlucose", "result", result);
        if (this.onAddGlucoseListener != null) {
            this.onAddGlucoseListener.onAddGlucose(new MagicReturnDM().addGlucoseReturnDM(result));
        }
    }
}
