package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.fragments.OtherrecordFragment.OnOtherrecordListener;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.OtherrecordThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrAddOtherrecord extends Thread {
    final String className = "ThrAddOtherrecord";
    LogCat logCat;
    Context mContext;
    OnOtherrecordListener onOtherrecordListener;
    OtherrecordThrDM otherrecordThrDM;

    public ThrAddOtherrecord(Context context, OtherrecordThrDM dm, OnOtherrecordListener l) {
        this.onOtherrecordListener = l;
        this.otherrecordThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrAddOtherrecord", "ThrAddOtherrecord", "in");
    }

    public void run() {
        String result = new SDConnection(this.otherrecordThrDM).getAddOthersResult(this.mContext, ClassConstant.SUBDIR_ADD_OTHERS);
        this.logCat.log("ThrAddOtherrecord", "result", result);
        if (this.onOtherrecordListener != null) {
            this.onOtherrecordListener.onAddDataSend(new MagicReturnDM().otherrecordReturnDM(result), this.otherrecordThrDM);
        }
    }
}
