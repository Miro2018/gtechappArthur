package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.ModInsulinThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrModInsulin extends Thread {
    final String className = "ThrModInsulin";
    LogCat logCat;
    Context mContext;
    ModInsulinThrDM modInsulinThrDM;
    OnModInsulinListener onModInsulinListener;

    public ThrModInsulin(Context context, ModInsulinThrDM dm, OnModInsulinListener l) {
        this.onModInsulinListener = l;
        this.modInsulinThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrModInsulin", "ThrModInsulin", "in");
    }

    public void run() {
        String result = new SDConnection(this.modInsulinThrDM).getModInsulinResult(this.mContext, ClassConstant.SUBDIR_SUPORT_MODINSULIN);
        this.logCat.log("ThrModInsulin", "result", result);
        if (this.onModInsulinListener != null) {
            this.onModInsulinListener.onModInsulin(new MagicReturnDM().modInsulinReturnDM(result));
        }
    }
}
