package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.datamodel.AddMod_G_I_ThrDM;
import com.accumed.gtech.thread.datamodel.AddNoteReturnDM;
import com.accumed.gtech.thread.datamodel.AddNoteThrDM;
import com.accumed.gtech.thread.datamodel.ModNoteReturnDM;
import com.accumed.gtech.thread.datamodel.ModNoteThrDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.FileRename;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.Util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SyncAddMod extends Thread {
    int RETURN_NUM = 10;
    int SYNC = 0;
    String[] array_insulin_name_data;
    String[] array_insulin_type_data;
    final String className = "SyncAddMod";
    LogCat logCat = new LogCat();
    Context mContext;
    SyncOnAddModListener syncOnAddModListener;

    public SyncAddMod(Context c, SyncOnAddModListener l) {
        this.mContext = c;
        this.syncOnAddModListener = l;
        this.array_insulin_type_data = this.mContext.getResources().getStringArray(C0213R.array.array_insulin_type_data);
        this.array_insulin_name_data = this.mContext.getResources().getStringArray(C0213R.array.array_insulin_name_data);
    }

    public void run() {
        actionDefine(this.SYNC);
    }

    private void excuteAddValues() {
        if (this.syncOnAddModListener != null) {
            this.syncOnAddModListener.syncOnAddMod(0);
        }
        insertGlucoses();
        if (this.syncOnAddModListener != null) {
            this.syncOnAddModListener.syncOnAddMod(2);
        }
        insertInsulins();
        if (this.syncOnAddModListener != null) {
            this.syncOnAddModListener.syncOnAddMod(1);
        }
        updateGlucoses();
        if (this.syncOnAddModListener != null) {
            this.syncOnAddModListener.syncOnAddMod(3);
        }
        updateInsulins();
        if (this.syncOnAddModListener != null) {
            this.syncOnAddModListener.syncOnAddMod(5);
        }
        new_getNInsertValuesJson(getNInsertList(), getCInsertList());
        if (this.syncOnAddModListener != null) {
            this.syncOnAddModListener.syncOnAddMod(6);
        }
        new_getNUpdateValuesJson(getNUpdatetList());
        if (this.syncOnAddModListener != null) {
            this.syncOnAddModListener.syncOnAddMod(4);
        }
    }

    private ArrayList<LogDM> getGLimitedInsertList(int startNum, int returnNum) {
        DBAction dbAction = new DBAction(this.mContext);
        String sql = "select * from log where category = '0' and (update_flag ='insert' or update_flag='update') and _id = '' limit " + Integer.toString(startNum) + ", " + Integer.toString(returnNum);
        this.logCat.log("SyncAddMod", "__select_sql", sql);
        return dbAction.selectLogList(sql);
    }

    private int getGInsertTotalCount() {
        return new DBAction(this.mContext).getCount("select * from log where category = '0' and (update_flag ='insert' or update_flag='update') and _id = ''");
    }

    public void insertGlucoses() {
        String deviceId = new DBAction(this.mContext).getOneDeviceId();
        HashMap<String, String> client_sever_seqMap = new HashMap();
        String email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        int total = getGInsertTotalCount();
        this.logCat.log("SyncAddMod", "total", total + "");
        int loop = total / this.RETURN_NUM;
        if (total % this.RETURN_NUM > 0) {
            loop++;
        }
        if (total < 10) {
            loop = 1;
        }
        for (int i = 0; i < loop; i++) {
            this.logCat.log("SyncAddMod", "snum / renum", (this.RETURN_NUM * i) + "/" + this.RETURN_NUM);
            ArrayList<LogDM> logList = new ArrayList();
            logList = getGLimitedInsertList(this.RETURN_NUM * i, this.RETURN_NUM);
            this.logCat.log("SyncAddMod", "logList", logList.size() + "");
            try {
                JSONObject j = new JSONObject();
                j.put("email", email);
                JSONArray arr = new JSONArray();
                int a = 0;
                while (a < logList.size()) {
                    this.logCat.log("SyncAddMod", "a", a + "");
                    JSONObject j1 = new JSONObject();
                    if (((LogDM) logList.get(a)).device_id.equals("")) {
                        j1.put("deviceid", deviceId);
                    } else {
                        j1.put("deviceid", ((LogDM) logList.get(a)).device_id);
                    }
                    j1.put("gdate", new Util().getServerDateFormat(((LogDM) logList.get(a)).input_date));
                    j1.put("gvalue", ((LogDM) logList.get(a)).blood_sugar_value);
                    j1.put("gevent", ((LogDM) logList.get(a)).blood_sugar_eat);
                    j1.put("gtempeature", "0");
                    if (((LogDM) logList.get(a)).blood_sugar_eat_origin == null || ((LogDM) logList.get(a)).blood_sugar_eat_origin.equals("")) {
                        j1.put("gmodevent", "");
                    } else {
                        j1.put("gmodevent", ((LogDM) logList.get(a)).blood_sugar_eat_origin);
                        this.logCat.log("SyncAddMod", "j1.put", ((LogDM) logList.get(a)).blood_sugar_eat_origin);
                    }
                    if (((LogDM) logList.get(a)).blood_sugar_type.equals("0")) {
                        j1.put("manualinput", "NO");
                    } else {
                        j1.put("manualinput", "YES");
                    }
                    j1.put("client_seq", ((LogDM) logList.get(a)).seq);
                    arr.put(j1);
                    a++;
                }
                j.put("glucose", arr);
                AddMod_G_I_ThrDM dm = new AddMod_G_I_ThrDM();
                dm.data = j.toString();
                String result = new SDConnection(dm).getAddMod_G_I_Result(this.mContext, ClassConstant.SUBDIR_SUPORT_ADDGLUCOSES);
                this.logCat.log("SyncAddMod", "result_add", result);
                try {
                    JSONObject jSONObject = new JSONObject(result);
                    if (jSONObject.get("code").equals("200") && new JSONObject(jSONObject.getString("data")).get("result").equals("0")) {
                        JSONArray jSONArray = new JSONArray(jSONObject.getString("client_server_seq"));
                        for (int f = 0; f < jSONArray.length(); f++) {
                            this.logCat.log("SyncAddMod", "reJarr value", jSONArray.getString(f));
                            jSONObject = new JSONObject(jSONArray.getString(f));
                            client_sever_seqMap.put(jSONObject.getString("server_seq"), jSONObject.getString("client_seq"));
                        }
                    }
                } catch (Exception e) {
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        for (String _id : client_sever_seqMap.keySet()) {
            DBAction dbAction = new DBAction(this.mContext);
            String q = "update log set update_flag = null, _id='" + _id + "' where seq='" + ((String) client_sever_seqMap.get(_id)) + "'";
            this.logCat.log("SyncAddMod", "jjj", q);
            if (dbAction.executeQuery(q)) {
                this.logCat.log("SyncAddMod", "failed", q);
            }
        }
    }

    private ArrayList<LogDM> getILimitedInsertList(int startNum, int returnNum) {
        DBAction dbAction = new DBAction(this.mContext);
        String sql = "select * from log where category = '1' and (update_flag ='insert' or update_flag='update') and _id = '' limit " + Integer.toString(startNum) + ", " + Integer.toString(returnNum);
        this.logCat.log("SyncAddMod", "__select_sql", sql);
        return dbAction.selectLogList(sql);
    }

    private int getIInsertTotalCount() {
        return new DBAction(this.mContext).getCount("select * from log where category = '1' and (update_flag ='insert' or update_flag='update') and _id = ''");
    }

    public void insertInsulins() {
        HashMap<String, String> client_sever_seqMap = new HashMap();
        String email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        int total = getIInsertTotalCount();
        this.logCat.log("SyncAddMod", "total", total + "");
        int loop = total / this.RETURN_NUM;
        if (total % this.RETURN_NUM > 0) {
            loop++;
        }
        if (total < 10) {
            loop = 1;
        }
        for (int i = 0; i < loop; i++) {
            this.logCat.log("SyncAddMod", "snum / renum", (this.RETURN_NUM * i) + "/" + this.RETURN_NUM);
            ArrayList<LogDM> logList = new ArrayList();
            logList = getILimitedInsertList(this.RETURN_NUM * i, this.RETURN_NUM);
            this.logCat.log("SyncAddMod", "logList", logList.size() + "");
            try {
                JSONObject j = new JSONObject();
                j.put("email", email);
                JSONArray arr = new JSONArray();
                for (int a = 0; a < logList.size(); a++) {
                    this.logCat.log("SyncAddMod", "a", a + "");
                    JSONObject j1 = new JSONObject();
                    j1.put("idate", new Util().getServerDateFormat(((LogDM) logList.get(a)).input_date));
                    j1.put("ivalue", ((LogDM) logList.get(a)).insulin_value);
                    j1.put("itype", this.array_insulin_type_data[Integer.parseInt(((LogDM) logList.get(a)).insulin_type)]);
                    j1.put("iproduct", this.array_insulin_name_data[Integer.parseInt(((LogDM) logList.get(a)).insulin_name)]);
                    j1.put("manualinput", "YES");
                    j1.put("client_seq", ((LogDM) logList.get(a)).seq);
                    arr.put(j1);
                }
                j.put("insulin", arr);
                this.logCat.log("SyncAddMod", "jsonToStr", j.toString());
                AddMod_G_I_ThrDM dm = new AddMod_G_I_ThrDM();
                dm.data = j.toString();
                String result = new SDConnection(dm).getAddMod_G_I_Result(this.mContext, ClassConstant.SUBDIR_SUPORT_ADDINSULINS);
                this.logCat.log("SyncAddMod", "result_add", result);
                try {
                    JSONObject jSONObject = new JSONObject(result);
                    if (jSONObject.get("code").equals("200") && new JSONObject(jSONObject.getString("data")).get("result").equals("0")) {
                        JSONArray jSONArray = new JSONArray(jSONObject.getString("client_server_seq"));
                        for (int f = 0; f < jSONArray.length(); f++) {
                            this.logCat.log("SyncAddMod", "reJarr value", jSONArray.getString(f));
                            jSONObject = new JSONObject(jSONArray.getString(f));
                            client_sever_seqMap.put(jSONObject.getString("server_seq"), jSONObject.getString("client_seq"));
                        }
                    }
                } catch (Exception e) {
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        for (String _id : client_sever_seqMap.keySet()) {
            DBAction dbAction = new DBAction(this.mContext);
            String q = "update log set update_flag = null, _id='" + _id + "' where seq='" + ((String) client_sever_seqMap.get(_id)) + "'";
            this.logCat.log("SyncAddMod", "jjj", q);
            if (dbAction.executeQuery(q)) {
                this.logCat.log("SyncAddMod", "failed", q);
            }
        }
    }

    private int getGUpdateTotalCount() {
        return new DBAction(this.mContext).getCount("select * from log where category = '0' and update_flag ='update' and _id !='' ");
    }

    private ArrayList<LogDM> getGLimitedUpdateList(int startNum, int returnNum) {
        DBAction dbAction = new DBAction(this.mContext);
        String sql = "select * from log where category = '0' and update_flag='update' and _id != '' limit " + Integer.toString(startNum) + ", " + Integer.toString(returnNum);
        this.logCat.log("SyncAddMod", "__select_sql", sql);
        return dbAction.selectLogList(sql);
    }

    public void updateGlucoses() {
        String deviceId = new DBAction(this.mContext).getOneDeviceId();
        HashMap<String, String> client_sever_seqMap = new HashMap();
        String email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        int total = getGUpdateTotalCount();
        this.logCat.log("SyncAddMod", "total", total + "");
        int loop = total / this.RETURN_NUM;
        if (total % this.RETURN_NUM > 0) {
            loop++;
        }
        if (total < 10) {
            loop = 1;
        }
        for (int i = 0; i < loop; i++) {
            this.logCat.log("SyncAddMod", "snum / renum", (this.RETURN_NUM * i) + "/" + this.RETURN_NUM);
            ArrayList<LogDM> logList = new ArrayList();
            logList = getGLimitedUpdateList(this.RETURN_NUM * i, this.RETURN_NUM);
            this.logCat.log("SyncAddMod", "logList", logList.size() + "");
            try {
                JSONObject j = new JSONObject();
                j.put("email", email);
                JSONArray arr = new JSONArray();
                int a = 0;
                while (a < logList.size()) {
                    this.logCat.log("SyncAddMod", "a", a + "");
                    JSONObject j1 = new JSONObject();
                    j1.put("server_seq", ((LogDM) logList.get(a))._id);
                    if (((LogDM) logList.get(a)).device_id.equals("")) {
                        j1.put("deviceid", deviceId);
                    } else {
                        j1.put("deviceid", ((LogDM) logList.get(a)).device_id);
                    }
                    j1.put("gdate", new Util().getServerDateFormat(((LogDM) logList.get(a)).input_date));
                    j1.put("gvalue", ((LogDM) logList.get(a)).blood_sugar_value);
                    j1.put("gevent", ((LogDM) logList.get(a)).blood_sugar_eat);
                    j1.put("gtempeature", "0");
                    if (((LogDM) logList.get(a)).blood_sugar_eat_origin == null && ((LogDM) logList.get(a)).blood_sugar_eat_origin.equals("")) {
                        j1.put("gmodevent", "");
                    } else {
                        j1.put("gmodevent", ((LogDM) logList.get(a)).blood_sugar_eat_origin);
                        this.logCat.log("SyncAddMod", "j1.put", ((LogDM) logList.get(a)).blood_sugar_eat_origin);
                    }
                    if (((LogDM) logList.get(a)).blood_sugar_type.equals("0")) {
                        j1.put("manualinput", "NO");
                    } else {
                        j1.put("manualinput", "YES");
                    }
                    j1.put("client_seq", ((LogDM) logList.get(a)).seq);
                    arr.put(j1);
                    a++;
                }
                j.put("glucose", arr);
                this.logCat.log("SyncAddMod", "jsonToStr", j.toString());
                AddMod_G_I_ThrDM dm = new AddMod_G_I_ThrDM();
                dm.data = j.toString();
                String result = new SDConnection(dm).getAddMod_G_I_Result(this.mContext, ClassConstant.SUBDIR_SUPORT_MODGLUCOSES);
                this.logCat.log("SyncAddMod", "result_add", result);
                try {
                    JSONObject jSONObject = new JSONObject(result);
                    if (jSONObject.get("code").equals("200") && new JSONObject(jSONObject.getString("data")).get("result").equals("0")) {
                        JSONArray jSONArray = new JSONArray(jSONObject.getString("client_server_seq"));
                        for (int f = 0; f < jSONArray.length(); f++) {
                            this.logCat.log("SyncAddMod", "reJarr value", jSONArray.getString(f));
                            jSONObject = new JSONObject(jSONArray.getString(f));
                            client_sever_seqMap.put(jSONObject.getString("server_seq"), jSONObject.getString("client_seq"));
                        }
                    }
                } catch (Exception e) {
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        for (String _id : client_sever_seqMap.keySet()) {
            DBAction dbAction = new DBAction(this.mContext);
            String q = "update log set update_flag = null, _id='" + _id + "' where seq='" + ((String) client_sever_seqMap.get(_id)) + "'";
            this.logCat.log("SyncAddMod", "jjj", q);
            if (dbAction.executeQuery(q)) {
                this.logCat.log("SyncAddMod", "failed", q);
            }
        }
    }

    private int getIUpdateTotalCount() {
        return new DBAction(this.mContext).getCount("select * from log where category = '1' and update_flag ='update' and _id !=''");
    }

    private ArrayList<LogDM> getILimitedUpdateList(int startNum, int returnNum) {
        DBAction dbAction = new DBAction(this.mContext);
        String sql = "select * from log where category = '1' and update_flag='update' and _id != '' limit " + Integer.toString(startNum) + ", " + Integer.toString(returnNum);
        this.logCat.log("SyncAddMod", "getILimitedUpdateList() getILimitedUpdateList __select_sql", sql);
        return dbAction.selectLogList(sql);
    }

    public void updateInsulins() {
        HashMap<String, String> client_sever_seqMap = new HashMap();
        String email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        int total = getIUpdateTotalCount();
        this.logCat.log("SyncAddMod", "updateInsulins() total", total + "");
        int loop = total / this.RETURN_NUM;
        if (total % this.RETURN_NUM > 0) {
            loop++;
        }
        if (total < 10) {
            loop = 1;
        }
        for (int i = 0; i < loop; i++) {
            this.logCat.log("SyncAddMod", "snum / renum", (this.RETURN_NUM * i) + "/" + this.RETURN_NUM);
            ArrayList<LogDM> logList = new ArrayList();
            logList = getILimitedUpdateList(this.RETURN_NUM * i, this.RETURN_NUM);
            this.logCat.log("SyncAddMod", "logList", logList.size() + "");
            try {
                JSONObject j = new JSONObject();
                j.put("email", email);
                JSONArray arr = new JSONArray();
                for (int a = 0; a < logList.size(); a++) {
                    this.logCat.log("SyncAddMod", "a", a + "");
                    JSONObject j1 = new JSONObject();
                    j1.put("server_seq", ((LogDM) logList.get(a))._id);
                    j1.put("idate", new Util().getServerDateFormat(((LogDM) logList.get(a)).input_date));
                    j1.put("itype", this.array_insulin_type_data[Integer.parseInt(((LogDM) logList.get(a)).insulin_type)]);
                    j1.put("iproduct", this.array_insulin_name_data[Integer.parseInt(((LogDM) logList.get(a)).insulin_name)]);
                    j1.put("ivalue", ((LogDM) logList.get(a)).insulin_value);
                    j1.put("manualinput", "YES");
                    j1.put("client_seq", ((LogDM) logList.get(a)).seq);
                    arr.put(j1);
                }
                j.put("insulin", arr);
                this.logCat.log("SyncAddMod", "jsonToStr", j.toString());
                AddMod_G_I_ThrDM dm = new AddMod_G_I_ThrDM();
                dm.data = j.toString();
                String result = new SDConnection(dm).getAddMod_G_I_Result(this.mContext, ClassConstant.SUBDIR_SUPORT_MODINSULINS);
                this.logCat.log("SyncAddMod", "result_add", result);
                try {
                    JSONObject jSONObject = new JSONObject(result);
                    if (jSONObject.get("code").equals("200") && new JSONObject(jSONObject.getString("data")).get("result").equals("0")) {
                        JSONArray jSONArray = new JSONArray(jSONObject.getString("client_server_seq"));
                        for (int f = 0; f < jSONArray.length(); f++) {
                            this.logCat.log("SyncAddMod", "reJarr value", jSONArray.getString(f));
                            jSONObject = new JSONObject(jSONArray.getString(f));
                            client_sever_seqMap.put(jSONObject.getString("server_seq"), jSONObject.getString("client_seq"));
                        }
                    }
                } catch (Exception e) {
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        for (String _id : client_sever_seqMap.keySet()) {
            DBAction dbAction = new DBAction(this.mContext);
            String q = "update log set update_flag = null, _id='" + _id + "' where seq='" + ((String) client_sever_seqMap.get(_id)) + "'";
            this.logCat.log("SyncAddMod", "jjj", q);
            if (dbAction.executeQuery(q)) {
                this.logCat.log("SyncAddMod", "failed", q);
            }
        }
    }

    private ArrayList<LogDM> getNInsertList() {
        return new DBAction(this.mContext).selectLogList("select * from log where category = '2' and (update_flag ='insert' or update_flag='update') and _id = '' ");
    }

    private void new_getNInsertValuesJson(ArrayList<LogDM> noteList, ArrayList<LogDM> arrayList) {
        String email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        Iterator it = noteList.iterator();
        while (it.hasNext()) {
            LogDM logDM = (LogDM) it.next();
            AddNoteThrDM tDM = new AddNoteThrDM();
            tDM.email = email;
            tDM.ndate = new Util().getServerDateFormat(logDM.input_date);
            tDM.ntype = new Util().getServerNoteType(logDM.note_type);
            tDM.nvalue = logDM.note_content;
            if (!(logDM.note_picture.equals("") || logDM.note_picture.equals("null") || logDM.note_picture.equals("temp.jpg"))) {
                tDM.imgs = ClassConstant.DIR_IMG + logDM.note_picture;
                tDM.thumb = ClassConstant.DIR_IMG_THUMB + logDM.note_picture_thumb;
            }
            String result = new SDConnection(tDM).getAddNoteResult(this.mContext, ClassConstant.SUBDIR_ADD_NOTE);
            AddNoteReturnDM dm = new AddNoteReturnDM();
            dm = new MagicReturnDM().addNoteReturnDM(result);
            if (!dm.code.equals("200")) {
                this.logCat.log("SyncAddMod", "onAddNote()", "login failed 1");
            } else if (dm.result.equals("0")) {
                String sql;
                DBAction dbAction = new DBAction(this.mContext);
                this.logCat.log("SyncAddMod", "onAddNote() id", dm.id);
                this.logCat.log("SyncAddMod", "img name0", dm.filename);
                this.logCat.log("SyncAddMod", "img name1", dm.thumbnail);
                if (dm.filename.equals("null") || dm.filename.equals("") || dm.filename.equals("temp.jpg")) {
                    sql = "update log set user_id='" + email + "', _id= '" + dm.id + "', update_flag = null where system_date = '" + logDM.system_date + "'";
                } else {
                    FileRename fileRename = new FileRename();
                    if (fileRename.rename(ClassConstant.DIR_IMG, logDM.note_picture, dm.filename).booleanValue()) {
                        this.logCat.log("SyncAddMod", "rename img", "ok");
                    } else {
                        this.logCat.log("SyncAddMod", "rename img", "no");
                    }
                    if (fileRename.rename(ClassConstant.DIR_IMG_THUMB, logDM.note_picture_thumb, dm.thumbnail).booleanValue()) {
                        this.logCat.log("SyncAddMod", "rename thumbimg", "ok");
                    } else {
                        this.logCat.log("SyncAddMod", "rename thumbimg", "no");
                    }
                    sql = "update log set user_id='" + email + "', _id= '" + dm.id + "', note_picture='" + dm.filename + "', note_picture_thumb= '" + dm.thumbnail + "', update_flag = null where system_date = '" + logDM.system_date + "'";
                }
                this.logCat.log("SyncAddMod", "sql", sql);
                if (dbAction.executeQuery(sql)) {
                    this.logCat.log("SyncAddMod", "dbUpdate", "ok");
                } else {
                    this.logCat.log("SyncAddMod", "dbUpdate", "failed");
                }
            } else {
                this.logCat.log("SyncAddMod", "onAddNote()", "login failed 0");
            }
        }
    }

    private ArrayList<LogDM> getNUpdatetList() {
        return new DBAction(this.mContext).selectLogList("select * from log where category = '2' and update_flag='update' and _id != '' ");
    }

    private void new_getNUpdateValuesJson(ArrayList<LogDM> noteList) {
        String email = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        Iterator it = noteList.iterator();
        while (it.hasNext()) {
            LogDM logDM = (LogDM) it.next();
            ModNoteThrDM tDM = new ModNoteThrDM();
            tDM.id = logDM._id;
            tDM.email = email;
            tDM.ndate = new Util().getServerDateFormat(logDM.input_date);
            tDM.ntype = new Util().getServerNoteType(logDM.note_type);
            tDM.nvalue = logDM.note_content;
            if (!(logDM.note_picture.equals("") || logDM.note_picture.equals("null") || logDM.note_picture.equals("temp.jpg"))) {
                tDM.imgs = ClassConstant.DIR_IMG + logDM.note_picture;
                tDM.thumb = ClassConstant.DIR_IMG_THUMB + logDM.note_picture_thumb;
            }
            String result = new SDConnection(tDM).getModNoteResult(this.mContext, ClassConstant.SUBDIR_MOD_NOTE);
            this.logCat.log("SyncAddMod", "result", result);
            ModNoteReturnDM dm = new ModNoteReturnDM();
            dm = new MagicReturnDM().modNoteReturnDM(result);
            if (!dm.code.equals("200")) {
                this.logCat.log("SyncAddMod", "onModNote()", " failed 1");
            } else if (dm.result.equals("0")) {
                String sql;
                DBAction dbAction = new DBAction(this.mContext);
                this.logCat.log("SyncAddMod", "img name0", dm.filename);
                this.logCat.log("SyncAddMod", "img name1", dm.thumbnail);
                if (dm.filename.equals("null") || dm.filename.equals("")) {
                    sql = "update log set user_id='" + email + "', update_flag = null where system_date = '" + logDM.system_date + "'";
                } else {
                    FileRename fileRename = new FileRename();
                    if (fileRename.rename(ClassConstant.DIR_IMG, logDM.note_picture, dm.filename).booleanValue()) {
                        this.logCat.log("SyncAddMod", "rename img", "ok");
                    } else {
                        this.logCat.log("SyncAddMod", "rename img", "no");
                    }
                    if (fileRename.rename(ClassConstant.DIR_IMG_THUMB, logDM.note_picture_thumb, dm.thumbnail).booleanValue()) {
                        this.logCat.log("SyncAddMod", "rename thumbimg", "ok");
                    } else {
                        this.logCat.log("SyncAddMod", "rename thumbimg", "no");
                    }
                    sql = "update log set user_id='" + email + "', note_picture='" + dm.filename + "', note_picture_thumb= '" + dm.thumbnail + "', update_flag = null where system_date = '" + logDM.system_date + "'";
                }
                this.logCat.log("SyncAddMod", "sql", sql);
                if (dbAction.executeQuery(sql)) {
                    this.logCat.log("SyncAddMod", "dbUpdate", "ok");
                } else {
                    this.logCat.log("SyncAddMod", "dbUpdate", "failed");
                }
            } else {
                this.logCat.log("SyncAddMod", "onModNote()", " failed 0");
            }
        }
    }

    private ArrayList<LogDM> getCInsertList() {
        return new DBAction(this.mContext).selectLogList("select * from log where category = '3' and (update_flag ='insert' or update_flag='update') and _id = '' ");
    }

    private void actionDefine(int gubun) {
        switch (new AppStatusRouter(this.mContext).getAppStatus()) {
            case 0:
                this.logCat.log("SyncAddMod", "actionDefine()", "FIRSTUSE_x");
                return;
            case 1:
                this.logCat.log("SyncAddMod", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                return;
            case 5:
                this.logCat.log("SyncAddMod", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                return;
            case 10:
                this.logCat.log("SyncAddMod", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                return;
            case 14:
                this.logCat.log("SyncAddMod", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                return;
            case 17:
                this.logCat.log("SyncAddMod", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                return;
            case 26:
                this.logCat.log("SyncAddMod", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                return;
            case 30:
                this.logCat.log("SyncAddMod", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                excuteAddValues();
                return;
            default:
                return;
        }
    }
}
