package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.ChangePasswordThrDM;
import com.accumed.gtech.util.LogCat;

public class ThrChangePassword extends Thread {
    ChangePasswordThrDM changePasswordThrDM;
    final String className = "ThrChangePassword";
    LogCat logCat;
    Context mContext;
    OnChangePasswordListener onChangePasswordListener;

    public ThrChangePassword(Context context, ChangePasswordThrDM dm, OnChangePasswordListener l) {
        this.onChangePasswordListener = l;
        this.changePasswordThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrChangePassword", "ThrChangePassword", "in");
    }

    public void run() {
        this.logCat.log("ThrChangePassword", "result", new SDConnection(this.changePasswordThrDM).getChangePasswordResult(this.mContext, ClassConstant.SUBDIR_CHANGE_PASSWORD));
        if (this.onChangePasswordListener != null) {
            this.onChangePasswordListener.OnChangePassword(null);
        }
    }
}
