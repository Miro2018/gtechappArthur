package com.accumed.gtech.thread;

public interface OnAddFriendListener {
    void onAddFriend(Object obj);
}
