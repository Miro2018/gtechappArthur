package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.DelDataThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrDelData extends Thread {
    final String className = "ThrDelData";
    DelDataThrDM delThrDM;
    LogCat logCat;
    Context mContext;
    String mSubDir;
    OnDelDataServerListener onDelDataServerListener;

    public ThrDelData(Context context, DelDataThrDM dm, OnDelDataServerListener l, String subDir) {
        this.onDelDataServerListener = l;
        this.delThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.mSubDir = subDir;
        this.logCat.log("ThrDelData", "ThrDelData", "in");
    }

    public void run() {
        String result = new SDConnection(this.delThrDM).getDelDataResult(this.mContext, this.mSubDir);
        this.logCat.log("ThrDelData", "result", result);
        if (this.onDelDataServerListener != null) {
            this.onDelDataServerListener.onDelDataServer(new MagicReturnDM().delDataReturnDM(result));
        }
    }
}
