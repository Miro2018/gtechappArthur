package com.accumed.gtech.thread;

public interface OnJoinEmailCheckListener {
    void onJoinEmailCheckListener(Object obj);
}
