package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.AddUserThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrAddUser extends Thread {
    AddUserThrDM addUserThrDM;
    final String className = "ThrAddUser";
    LogCat logCat;
    Context mContext;
    OnAddUserListener onAddUserListener;

    public ThrAddUser(Context context, AddUserThrDM dm, OnAddUserListener l) {
        this.onAddUserListener = l;
        this.addUserThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrAddUser", "AddUserThr", "in");
    }

    public void run() {
        String result = new SDConnection(this.addUserThrDM).getAddUserResult(this.mContext, ClassConstant.SUBDIR_JOIN_ADDUSER);
        this.logCat.log("ThrAddUser", "result", result);
        if (this.onAddUserListener != null) {
            this.onAddUserListener.onAddUser(new MagicReturnDM().addUserReturnDM(result));
        }
    }
}
