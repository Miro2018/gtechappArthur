package com.accumed.gtech.thread;

public interface OnAddNoteListener {
    void onAddNote(Object obj);
}
