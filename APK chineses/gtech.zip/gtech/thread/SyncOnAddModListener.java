package com.accumed.gtech.thread;

public interface SyncOnAddModListener {
    public static final int ADD_MOD_FINISHE = 4;
    public static final int GLUCOSES_INSERT = 0;
    public static final int GLUCOSES_UPDATE = 1;
    public static final int INSULINS_INSERT = 2;
    public static final int INSULINS_UPDATE = 3;
    public static final int NOTE_INSERT = 5;
    public static final int NOTE_UPDATE = 6;

    void syncOnAddMod(int i);
}
