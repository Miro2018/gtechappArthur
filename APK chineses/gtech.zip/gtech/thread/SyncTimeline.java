package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.TimeLineReturnDM;
import com.accumed.gtech.thread.datamodel.TimeLineThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;
import java.util.ArrayList;

public class SyncTimeline extends Thread {
    final String className = "SyncTimeline";
    LogCat logCat;
    ArrayList<LogDM> logList;
    Context mContext;
    String mSubDir;
    OnSyncTimlineListener onSyncTimlineListener;
    TimeLineThrDM timeLineThrDM;
    String userEmail;

    public SyncTimeline(Context c, TimeLineThrDM dm, OnSyncTimlineListener l, String subDir) {
        this.mContext = c;
        this.onSyncTimlineListener = l;
        this.timeLineThrDM = dm;
        this.userEmail = this.timeLineThrDM.email;
        this.mSubDir = subDir;
        this.logList = new ArrayList();
        this.logCat = new LogCat();
        this.logCat.log("SyncTimeline", "timeLineThrDM", "in");
    }

    public void run() {
        this.logList = new ArrayList();
        this.logCat.log("SyncTimeline", "0 / start_num / return_num", Integer.toString(0) + "/" + this.timeLineThrDM.start_num + " / " + this.timeLineThrDM.return_num);
        SDConnection conn = new SDConnection(this.timeLineThrDM);
        String result = conn.suport_getTimeLineResult(this.mContext, this.mSubDir);
        this.logCat.log("SyncTimeline", "result", result);
        TimeLineReturnDM tiemLineReturnDM = new MagicReturnDM(this.mContext).suport_sync_timeLineReturnDM(result);
        this.logCat.log("SyncTimeline", "tiemLineReturnDM", tiemLineReturnDM.code);
        this.logCat.log("SyncTimeline", "tiemLineReturnDM", tiemLineReturnDM.statusResult);
        int start_num = Integer.parseInt(this.timeLineThrDM.start_num);
        int i = 0;
        while (tiemLineReturnDM.code.equals("200") && tiemLineReturnDM.statusResult.equals("ok") && tiemLineReturnDM.subLogDMList.size() != 0) {
            this.logCat.log("SyncTimeline", "while sync", "in");
            start_num = Integer.parseInt(this.timeLineThrDM.start_num) + Integer.parseInt(this.timeLineThrDM.return_num);
            this.timeLineThrDM.start_num = Integer.toString(start_num);
            conn.setDataModel(this.timeLineThrDM);
            result = conn.suport_getTimeLineResult(this.mContext, this.mSubDir);
            tiemLineReturnDM = new MagicReturnDM(this.mContext).suport_sync_timeLineReturnDM(result);
            this.logList.addAll(tiemLineReturnDM.subLogDMList);
            i++;
            this.logCat.log("SyncTimeline", "i / start_num / return_num", Integer.toString(i) + "/" + Integer.toString(start_num) + " / " + Integer.parseInt(this.timeLineThrDM.return_num));
            this.logCat.log("SyncTimeline", "result", result);
            this.logCat.log("SyncTimeline", "tiemLineReturnDM.subLogDMList.size() != 0", tiemLineReturnDM.subLogDMList.size() + "");
            if (this.onSyncTimlineListener != null) {
                this.onSyncTimlineListener.onSyncTimeline(Integer.valueOf(2), Integer.valueOf(i));
            }
        }
        if (this.onSyncTimlineListener != null) {
            this.onSyncTimlineListener.onSyncTimeline(Integer.valueOf(1), Integer.valueOf(0));
        }
    }
}
