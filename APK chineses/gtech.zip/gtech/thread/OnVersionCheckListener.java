package com.accumed.gtech.thread;

public interface OnVersionCheckListener {
    void onVersionCheck(Object obj);
}
