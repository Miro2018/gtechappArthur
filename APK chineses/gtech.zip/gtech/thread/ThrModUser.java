package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.ModUserThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrModUser extends Thread {
    final String className = "ThrModUser";
    LogCat logCat;
    Context mContext;
    ModUserThrDM modUserThrDM;
    OnModUserListener onModUserListener;

    public ThrModUser(Context context, ModUserThrDM dm, OnModUserListener l) {
        this.onModUserListener = l;
        this.modUserThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrModUser", "LoginThr", "in");
    }

    public void run() {
        String result = new SDConnection(this.modUserThrDM).getModUserResult(this.mContext, ClassConstant.SUBDIR_JOIN_MODUSER);
        this.logCat.log("ThrModUser", "result", result);
        if (this.onModUserListener != null) {
            this.onModUserListener.onModUser(new MagicReturnDM().modUserReturnDM(result));
        }
    }
}
