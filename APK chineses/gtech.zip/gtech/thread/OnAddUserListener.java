package com.accumed.gtech.thread;

public interface OnAddUserListener {
    void onAddUser(Object obj);
}
