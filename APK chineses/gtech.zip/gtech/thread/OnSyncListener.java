package com.accumed.gtech.thread;

public interface OnSyncListener {
    void onSync(boolean z, int i);
}
