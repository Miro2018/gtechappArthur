package com.accumed.gtech.thread;

public interface OnLoginListener {
    void onLogin(Object obj);
}
