package com.accumed.gtech.thread;

public interface OnTimeLineLimitListener {
    void onTimeLineLimit(Object obj);

    void onTimeLineLimit_userprofile_suport(Object obj);
}
