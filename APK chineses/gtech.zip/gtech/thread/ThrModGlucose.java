package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.ModGlucoseDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrModGlucose extends Thread {
    final String className = "ThrModGlucose";
    LogCat logCat;
    Context mContext;
    ModGlucoseDM modGlucoseDM;
    OnModGlucoseListener onModGlucoseListener;

    public ThrModGlucose(Context context, ModGlucoseDM dm, OnModGlucoseListener l) {
        this.onModGlucoseListener = l;
        this.modGlucoseDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrModGlucose", "ThrModGlucose", "in");
    }

    public void run() {
        String result = new SDConnection(this.modGlucoseDM).getModGlucoseResult(this.mContext, ClassConstant.SUBDIR_MOD_GLUCOSE);
        this.logCat.log("ThrModGlucose", "result", result);
        if (this.onModGlucoseListener != null) {
            this.onModGlucoseListener.onModGlucose(new MagicReturnDM().modGlucoseReturnDM(result));
        }
    }
}
