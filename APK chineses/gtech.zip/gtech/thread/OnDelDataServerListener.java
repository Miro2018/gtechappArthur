package com.accumed.gtech.thread;

public interface OnDelDataServerListener {
    void onDelDataServer(Object obj);
}
