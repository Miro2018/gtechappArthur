package com.accumed.gtech.thread;

public interface OnAddGlucoseListener {
    void onAddGlucose(Object obj);
}
