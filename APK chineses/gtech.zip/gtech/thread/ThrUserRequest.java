package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.UserRequestDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrUserRequest extends Thread {
    final String className = "ThrUserRequest";
    LogCat logCat;
    Context mContext;
    OnUserRequestListener onUserRequestListener;
    UserRequestDM userRequestDM;

    public ThrUserRequest(Context context, UserRequestDM dm, OnUserRequestListener l) {
        this.onUserRequestListener = l;
        this.userRequestDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrUserRequest", "LoginThr", "in");
    }

    public void run() {
        String result = new SDConnection(this.userRequestDM).getUserRequestResult(this.mContext, ClassConstant.SUBDIR_USER_FINDBYEMAIL);
        this.logCat.log("ThrUserRequest", "result", result);
        if (this.onUserRequestListener != null) {
            this.onUserRequestListener.onUserRequest(new MagicReturnDM().userRequestReturnaDM(result));
        }
    }
}
