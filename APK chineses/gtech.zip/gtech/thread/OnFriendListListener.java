package com.accumed.gtech.thread;

public interface OnFriendListListener {
    void onFriendList(Object obj);
}
