package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.fragments.OtherrecordFragment.OnOtherrecordListener;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.OtherrecordThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrDelOtherrecord extends Thread {
    final String className = "ThrDelOtherrecord";
    LogCat logCat;
    Context mContext;
    OnOtherrecordListener onOtherrecordListener;
    OtherrecordThrDM otherrecordThrDM;

    public ThrDelOtherrecord(Context context, OtherrecordThrDM dm, OnOtherrecordListener l) {
        this.onOtherrecordListener = l;
        this.otherrecordThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrDelOtherrecord", "ThrDelOtherrecord", "in");
    }

    public void run() {
        String result = new SDConnection(this.otherrecordThrDM).getDelOthersResult(this.mContext, ClassConstant.SUBDIR_DEL_OTHERS);
        this.logCat.log("ThrDelOtherrecord", "result", result);
        if (this.onOtherrecordListener != null) {
            this.onOtherrecordListener.onDelDataSend(new MagicReturnDM().delOtherrecordReturnDM(result), this.otherrecordThrDM);
        }
    }
}
