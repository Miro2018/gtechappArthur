package com.accumed.gtech.thread;

public interface OnTimeLineListener {
    void onTimeLIne_userprofile_suport(Object obj);

    void onTimeLine(Object obj);

    void onTimeLine_suport(Object obj);
}
