package com.accumed.gtech.thread;

public interface OnModInsulinListener {
    void onModInsulin(Object obj);
}
