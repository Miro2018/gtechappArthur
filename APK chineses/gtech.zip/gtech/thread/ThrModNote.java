package com.accumed.gtech.thread;

import android.content.Context;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.thread.datamodel.ModNoteThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;

public class ThrModNote extends Thread {
    final String className = "ThrModNote";
    LogCat logCat;
    Context mContext;
    ModNoteThrDM modNoteThrDM;
    OnModNoteListener onModNoteListener;

    public ThrModNote(Context context, ModNoteThrDM dm, OnModNoteListener l) {
        this.onModNoteListener = l;
        this.modNoteThrDM = dm;
        this.mContext = context;
        this.logCat = new LogCat();
        this.logCat.log("ThrModNote", "ThrModNote", "in");
    }

    public void run() {
        String result = new SDConnection(this.modNoteThrDM).getModNoteResult(this.mContext, ClassConstant.SUBDIR_MOD_NOTE);
        this.logCat.log("ThrModNote", "result", result);
        if (this.onModNoteListener != null) {
            this.onModNoteListener.onModNote(new MagicReturnDM().modNoteReturnDM(result));
        }
    }
}
