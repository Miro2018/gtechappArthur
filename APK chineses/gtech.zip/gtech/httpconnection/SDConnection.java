package com.accumed.gtech.httpconnection;

import android.content.Context;
import com.accumed.gtech.DBStructure;
import com.accumed.gtech.server.helper.ServerHelper;
import com.accumed.gtech.thread.datamodel.AddDeviceThrDM;
import com.accumed.gtech.thread.datamodel.AddFriendThrDM;
import com.accumed.gtech.thread.datamodel.AddGlucoseThrDM;
import com.accumed.gtech.thread.datamodel.AddInsulinDM;
import com.accumed.gtech.thread.datamodel.AddMod_G_I_ThrDM;
import com.accumed.gtech.thread.datamodel.AddNoteThrDM;
import com.accumed.gtech.thread.datamodel.AddUserThrDM;
import com.accumed.gtech.thread.datamodel.ChangePasswordThrDM;
import com.accumed.gtech.thread.datamodel.ChangestatusThrDM;
import com.accumed.gtech.thread.datamodel.DelDataThrDM;
import com.accumed.gtech.thread.datamodel.FindPasswordThrDM;
import com.accumed.gtech.thread.datamodel.FriendListThrDM;
import com.accumed.gtech.thread.datamodel.GetDeviceThrDM;
import com.accumed.gtech.thread.datamodel.GetDeviceThrDMv1;
import com.accumed.gtech.thread.datamodel.JoinEmailCheckThrDM;
import com.accumed.gtech.thread.datamodel.LoginThrDM;
import com.accumed.gtech.thread.datamodel.ModDeviceThrDM;
import com.accumed.gtech.thread.datamodel.ModGlucoseDM;
import com.accumed.gtech.thread.datamodel.ModInsulinThrDM;
import com.accumed.gtech.thread.datamodel.ModNoteThrDM;
import com.accumed.gtech.thread.datamodel.ModUserThrDM;
import com.accumed.gtech.thread.datamodel.NotiFriensRequestThrDM;
import com.accumed.gtech.thread.datamodel.NotiThrDM;
import com.accumed.gtech.thread.datamodel.OtherrecordThrDM;
import com.accumed.gtech.thread.datamodel.SendWelcomeEmailThrDM;
import com.accumed.gtech.thread.datamodel.TimeLineThrDM;
import com.accumed.gtech.thread.datamodel.UserProfileThrDM;
import com.accumed.gtech.thread.datamodel.UserRequestDM;
import com.accumed.gtech.util.LogCat;
import com.google.android.gcm.GCMConstants;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;

public class SDConnection {
    final String className = "SDConnection";
    LogCat logCat = new LogCat();
    private Object objDM;

    public SDConnection(Object dm) {
        this.objDM = dm;
    }

    public void setDataModel(Object obj) {
        this.objDM = obj;
    }

    public String getLoginResult(Context context, String subDir) {
        LoginThrDM loginTrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", loginTrDM.email);
        this.logCat.log("SDConnection", "-- email", loginTrDM.email);
        parameter_map.put("password", loginTrDM.password);
        this.logCat.log("SDConnection", "-- password", loginTrDM.password);
        parameter_map.put(GCMConstants.EXTRA_REGISTRATION_ID, loginTrDM.registration_id);
        this.logCat.log("SDConnection", "-- registration_id", loginTrDM.registration_id);
        parameter_map.put("registration_device", loginTrDM.registration_device);
        this.logCat.log("SDConnection", "-- registration_device", loginTrDM.registration_device);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getUserProfileResult(Context context, String subDir) {
        UserProfileThrDM userProfileThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", userProfileThrDM.email);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getAddUserResult(Context context, String subDir) {
        AddUserThrDM addUserThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", addUserThrDM.MY_EMAIL);
        parameter_map.put("password", addUserThrDM.MY_PASSWORD);
        parameter_map.put("name", addUserThrDM.MY_NAME);
        parameter_map.put(DBStructure.DB_TABLE_NAME_DEVICE, addUserThrDM.MY_NAME);
        parameter_map.put("birth", addUserThrDM.MY_BIRTH);
        parameter_map.put("gender", addUserThrDM.MY_GENDER);
        parameter_map.put("height", addUserThrDM.MY_HEIGHT);
        parameter_map.put("heightunit", addUserThrDM.MY_HEIGHT_UNIT);
        parameter_map.put("weight", addUserThrDM.MY_WEIGHT);
        parameter_map.put("weightunit", addUserThrDM.MY_WEIGHT_UNIT);
        parameter_map.put("diabeticsince", addUserThrDM.MY_OCCOURDAY);
        parameter_map.put("diabetestype", addUserThrDM.MY_BLOOD_SUGAR_TYPE);
        parameter_map.put("glucoseunit", addUserThrDM.MY_BLOOD_SUGAR_UNIT);
        parameter_map.put("hypo", addUserThrDM.MY_LOW_BLOOD_SUGAR);
        parameter_map.put("hyper", addUserThrDM.MY_HIGH_BLOOD_SUGAR);
        parameter_map.put("datetype", addUserThrDM.MY_DATE_METHOD);
        parameter_map.put("timetype", addUserThrDM.MY_TIME_METHOD);
        parameter_map.put("language", addUserThrDM.MY_LANGUAGE);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getChangePasswordResult(Context context, String subDir) {
        ChangePasswordThrDM changePasswordThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", changePasswordThrDM.email);
        parameter_map.put("password", changePasswordThrDM.password);
        parameter_map.put("newpassword", changePasswordThrDM.newpassword);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getJoinEmailCheckResult(Context context, String subDir) {
        JoinEmailCheckThrDM joinEmailCheckThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        this.logCat.log("SDConnection", "joinEmailCheckThrDM email", joinEmailCheckThrDM.email);
        parameter_map.put("email", joinEmailCheckThrDM.email);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getModUserResult(Context context, String subDir) {
        ModUserThrDM modUserThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("birth", modUserThrDM.MY_BIRTH);
        parameter_map.put("hyper", modUserThrDM.MY_HIGH_BLOOD_SUGAR);
        parameter_map.put("weight", modUserThrDM.MY_WEIGHT);
        parameter_map.put("heightunit", modUserThrDM.MY_HEIGHT_UNIT);
        parameter_map.put("weightunit", modUserThrDM.MY_WEIGHT_UNIT);
        parameter_map.put("diabetestype", modUserThrDM.MY_BLOOD_SUGAR_TYPE);
        parameter_map.put("hypo", modUserThrDM.MY_LOW_BLOOD_SUGAR);
        parameter_map.put("diabeticsince", modUserThrDM.MY_OCCOURDAY);
        parameter_map.put("id", modUserThrDM.MY_SERVER_ID);
        parameter_map.put("height", modUserThrDM.MY_HEIGHT);
        parameter_map.put("email", modUserThrDM.MY_EMAIL);
        parameter_map.put("name", modUserThrDM.MY_NAME);
        parameter_map.put("gender", modUserThrDM.MY_GENDER);
        parameter_map.put("language", modUserThrDM.MY_LANGUAGE);
        parameter_map.put("datetype", modUserThrDM.MY_DATE_METHOD);
        parameter_map.put("glucoseunit", modUserThrDM.MY_BLOOD_SUGAR_UNIT);
        parameter_map.put("timetype", modUserThrDM.MY_TIME_METHOD);
        this.logCat.log("SDConnection", "getModUserResult() birth", modUserThrDM.MY_BIRTH);
        this.logCat.log("SDConnection", "getModUserResult() hyper", modUserThrDM.MY_HIGH_BLOOD_SUGAR);
        this.logCat.log("SDConnection", "getModUserResult() weight", modUserThrDM.MY_WEIGHT);
        this.logCat.log("SDConnection", "getModUserResult() heightunit", modUserThrDM.MY_HEIGHT_UNIT);
        this.logCat.log("SDConnection", "getModUserResult() weightunit", modUserThrDM.MY_WEIGHT_UNIT);
        this.logCat.log("SDConnection", "getModUserResult() diabetestype", modUserThrDM.MY_BLOOD_SUGAR_TYPE);
        this.logCat.log("SDConnection", "getModUserResult() hypo", modUserThrDM.MY_LOW_BLOOD_SUGAR);
        this.logCat.log("SDConnection", "diabeticsince", modUserThrDM.MY_OCCOURDAY);
        this.logCat.log("SDConnection", "getModUserResult() id", modUserThrDM.MY_SERVER_ID);
        this.logCat.log("SDConnection", "getModUserResult() height", modUserThrDM.MY_HEIGHT);
        this.logCat.log("SDConnection", "getModUserResult() email", modUserThrDM.MY_EMAIL);
        this.logCat.log("SDConnection", "getModUserResult() name", modUserThrDM.MY_NAME);
        this.logCat.log("SDConnection", "getModUserResult() gender", modUserThrDM.MY_GENDER);
        this.logCat.log("SDConnection", "getModUserResult() language", modUserThrDM.MY_LANGUAGE);
        this.logCat.log("SDConnection", "getModUserResult() datetype", modUserThrDM.MY_DATE_METHOD);
        this.logCat.log("SDConnection", "getModUserResult() glucoseunit", modUserThrDM.MY_BLOOD_SUGAR_UNIT);
        this.logCat.log("SDConnection", "getModUserResult() timetype", modUserThrDM.MY_TIME_METHOD);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getDeviceResult(Context context, String subDir) {
        String result = "";
        GetDeviceThrDM getDeviceThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", getDeviceThrDM.email);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getSendWelcomeEmail(Context context, String subDir) {
        String result = "";
        SendWelcomeEmailThrDM sendWelcomeEmailThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", sendWelcomeEmailThrDM.email);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getDeviceResultV1(Context context, String subDir) {
        String result = "";
        GetDeviceThrDMv1 getDeviceThrDMv1 = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("data", getDeviceThrDMv1.data);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getAddDeviceResult(Context context, String subDir) {
        String result = "";
        AddDeviceThrDM addDeviceThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", addDeviceThrDM.email);
        parameter_map.put("deviceid", addDeviceThrDM.deviceid);
        parameter_map.put("lastvalue", addDeviceThrDM.lastvalue);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getModDeviceResult(Context context, String subDir) {
        String result = "";
        ModDeviceThrDM modDeviceThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", modDeviceThrDM.email);
        parameter_map.put("deviceid", modDeviceThrDM.deviceid);
        parameter_map.put("lastvalue", modDeviceThrDM.lastvalue);
        parameter_map.put("id", modDeviceThrDM.id);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getAddGlucoseResult(Context context, String subDir) {
        String result = "";
        AddGlucoseThrDM addGlucoseDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", addGlucoseDM.email);
        parameter_map.put("deviceid", addGlucoseDM.deviceid);
        parameter_map.put("gdate", addGlucoseDM.gdate);
        parameter_map.put("gvalue", addGlucoseDM.gvalue);
        parameter_map.put("gevent", addGlucoseDM.gevent);
        parameter_map.put("gmodevent", addGlucoseDM.gmodevent);
        parameter_map.put("gtempeature", addGlucoseDM.gtempeature);
        parameter_map.put("manualinput", addGlucoseDM.manualinput);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getAddMod_G_I_Result(Context context, String subDir) {
        String result = "";
        AddMod_G_I_ThrDM dm = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("data", dm.data);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String notiResult(Context context, String subDir) {
        String result = "";
        NotiThrDM dm = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", dm.email);
        parameter_map.put("targetemail", dm.targetemail);
        parameter_map.put("gubun", dm.gubun);
        parameter_map.put("gubun_num", dm.gubun_num);
        parameter_map.put("message", dm.message);
        parameter_map.put("name", dm.name);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String notiFriendsRequestResult(Context context, String subDir) {
        String result = "";
        NotiFriensRequestThrDM dm = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("my_email", dm.my_email);
        parameter_map.put("my_name", dm.my_name);
        parameter_map.put("friend_email", dm.friend_email);
        parameter_map.put("message", dm.message);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getModGlucoseResult(Context context, String subDir) {
        String result = "";
        ModGlucoseDM modGlucoseDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", modGlucoseDM.email.trim());
        parameter_map.put("deviceid", modGlucoseDM.deviceid);
        parameter_map.put("gdate", modGlucoseDM.gdate);
        parameter_map.put("gvalue", modGlucoseDM.gvalue);
        parameter_map.put("gevent", modGlucoseDM.gevent);
        parameter_map.put("gtempeature", modGlucoseDM.gtempeature);
        parameter_map.put("manualinput", modGlucoseDM.manualinput);
        parameter_map.put("id", modGlucoseDM.id);
        parameter_map.put("gmodevent", modGlucoseDM.gmodevent);
        this.logCat.log("SDConnection", "getModGlucoseResult() email", modGlucoseDM.email);
        this.logCat.log("SDConnection", "getModGlucoseResult() deviceid", modGlucoseDM.deviceid);
        this.logCat.log("SDConnection", "getModGlucoseResult() gdate", modGlucoseDM.gdate);
        this.logCat.log("SDConnection", "getModGlucoseResult() gvalue", modGlucoseDM.gvalue);
        this.logCat.log("SDConnection", "getModGlucoseResult() gevent", modGlucoseDM.gevent);
        this.logCat.log("SDConnection", "getModGlucoseResult() gmodevent", modGlucoseDM.gmodevent);
        this.logCat.log("SDConnection", "getModGlucoseResult() gtempeature", modGlucoseDM.gtempeature);
        this.logCat.log("SDConnection", "getModGlucoseResult() manualinput", modGlucoseDM.manualinput);
        this.logCat.log("SDConnection", "getModGlucoseResult() id", modGlucoseDM.id);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getAddInsulinResult(Context context, String subDir) {
        String result = "";
        AddInsulinDM addInsulinDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", addInsulinDM.email);
        parameter_map.put("idate", addInsulinDM.idate);
        parameter_map.put("itype", addInsulinDM.itype);
        parameter_map.put("iproduct", addInsulinDM.iproduct);
        parameter_map.put("ivalue", addInsulinDM.ivalue);
        parameter_map.put("manualinput", addInsulinDM.manualinput);
        this.logCat.log("SDConnection", "getAddInsulinResult() addInsulinDM.email", addInsulinDM.email);
        this.logCat.log("SDConnection", "getAddInsulinResult() addInsulinDM.idate", addInsulinDM.idate);
        this.logCat.log("SDConnection", "getAddInsulinResult() addInsulinDM.itype", addInsulinDM.itype);
        this.logCat.log("SDConnection", "getAddInsulinResult() addInsulinDM.email", addInsulinDM.email);
        this.logCat.log("SDConnection", "getAddInsulinResult() addInsulinDM.iproduct", addInsulinDM.iproduct);
        this.logCat.log("SDConnection", "getAddInsulinResult() addInsulinDM.ivalue", addInsulinDM.ivalue);
        this.logCat.log("SDConnection", "getAddInsulinResult() addInsulinDM.manualinput", addInsulinDM.manualinput);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getModInsulinResult(Context context, String subDir) {
        String result = "";
        ModInsulinThrDM modInsulinThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("idate", modInsulinThrDM.idate);
        parameter_map.put("itype", modInsulinThrDM.itype);
        parameter_map.put("iproduct", modInsulinThrDM.iproduct);
        parameter_map.put("ivalue", modInsulinThrDM.ivalue);
        parameter_map.put("manualinput", modInsulinThrDM.manualinput);
        parameter_map.put("id", modInsulinThrDM.id);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getAddNoteResult(Context context, String subDir) {
        String result = "";
        AddNoteThrDM addNoteThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", addNoteThrDM.email);
        parameter_map.put("ndate", addNoteThrDM.ndate);
        parameter_map.put("ntype", addNoteThrDM.ntype);
        parameter_map.put("nvalue", addNoteThrDM.nvalue);
        if (addNoteThrDM.ntype.toLowerCase().equals("note")) {
            this.logCat.log("SDConnection", "getAddNoteResult() note", "in");
        } else if (addNoteThrDM.ntype.toLowerCase().equals("comment")) {
            this.logCat.log("SDConnection", "getAddNoteResult() comment", "in");
            if (!(addNoteThrDM.targetemail == null || addNoteThrDM.targetemail.equals(""))) {
                this.logCat.log("SDConnection", "getAddNoteResult() comment", "in1");
                parameter_map.put("targetemail", addNoteThrDM.targetemail);
            }
        }
        if (!(addNoteThrDM.imgs == null || addNoteThrDM.imgs.trim().equals("") || addNoteThrDM.thumb == null || addNoteThrDM.thumb.trim().equals(""))) {
            attachFile_map.put("imgs", addNoteThrDM.imgs);
            attachFile_map.put("thumb", addNoteThrDM.thumb);
            this.logCat.log("SDConnection", "note imgs", addNoteThrDM.imgs);
            this.logCat.log("SDConnection", "note thumb", addNoteThrDM.thumb);
        }
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getModNoteResult(Context context, String subDir) {
        String result = "";
        ModNoteThrDM modNoteThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", modNoteThrDM.email);
        parameter_map.put("ndate", modNoteThrDM.ndate);
        parameter_map.put("ntype", modNoteThrDM.ntype);
        parameter_map.put("nvalue", modNoteThrDM.nvalue);
        parameter_map.put("id", modNoteThrDM.id);
        if (modNoteThrDM.ntype.toLowerCase().equals("note")) {
            this.logCat.log("SDConnection", "getModNoteResult() note", "in");
        } else if (modNoteThrDM.ntype.toLowerCase().equals("comment")) {
            this.logCat.log("SDConnection", "getModNoteResult() comment", "in");
            if (!(modNoteThrDM.targetemail == null && modNoteThrDM.targetemail.equals(""))) {
                parameter_map.put("targetemail", modNoteThrDM.targetemail);
            }
        }
        if (modNoteThrDM.imgs == null || modNoteThrDM.imgs.trim().equals("") || modNoteThrDM.thumb == null || modNoteThrDM.thumb.trim().equals("")) {
            parameter_map.put("imgs", "");
            parameter_map.put("thumb", "");
        } else {
            attachFile_map.put("imgs", modNoteThrDM.imgs);
            attachFile_map.put("thumb", modNoteThrDM.thumb);
            this.logCat.log("SDConnection", "note imgs", modNoteThrDM.imgs);
            this.logCat.log("SDConnection", "note thumb", modNoteThrDM.thumb);
        }
        this.logCat.log("SDConnection", "modNoteThrDM.email", modNoteThrDM.email);
        this.logCat.log("SDConnection", "modNoteThrDM.ndate", modNoteThrDM.ndate);
        this.logCat.log("SDConnection", "modNoteThrDM.ntype", modNoteThrDM.ntype);
        this.logCat.log("SDConnection", "modNoteThrDM.nvalue", modNoteThrDM.nvalue);
        this.logCat.log("SDConnection", "modNoteThrDM.email", modNoteThrDM.email);
        this.logCat.log("SDConnection", "modNoteThrDM.id", modNoteThrDM.id);
        this.logCat.log("SDConnection", "modNoteThrDM.targetemail", modNoteThrDM.targetemail);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getDelDataResult(Context context, String subDir) {
        DelDataThrDM delDataThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", delDataThrDM.email);
        parameter_map.put("id", delDataThrDM.id);
        parameter_map.put("ntype", delDataThrDM.ntype);
        this.logCat.log("SDConnection", "getDelDataResult email", delDataThrDM.email);
        this.logCat.log("SDConnection", "getDelDataResult id", delDataThrDM.id);
        this.logCat.log("SDConnection", "getDelDataResult ntype", delDataThrDM.ntype);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getFindPasswordResult(Context context, String subDir) {
        FindPasswordThrDM findPasswordThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", findPasswordThrDM.email);
        this.logCat.log("SDConnection", "getFindPasswordResult email", findPasswordThrDM.email);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getUserRequestResult(Context context, String subDir) {
        UserRequestDM userRequestDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", userRequestDM.email);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getFriendListResult(Context context, String subDir) {
        FriendListThrDM friendListThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", friendListThrDM.email);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getAddFriendResult(Context context, String subDir) {
        String result = "";
        AddFriendThrDM addFriendThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", addFriendThrDM.email);
        parameter_map.put("friendemail", addFriendThrDM.friendemail);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getChangestatusResult(Context context, String subDir) {
        String result = "";
        ChangestatusThrDM changestatusThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("id", changestatusThrDM.id);
        parameter_map.put("command", changestatusThrDM.command);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String suport_getTimeLineResult(Context context, String subDir) {
        TimeLineThrDM timeLineThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", timeLineThrDM.email);
        parameter_map.put("startdate", timeLineThrDM.startdate);
        parameter_map.put("enddate", timeLineThrDM.enddate);
        parameter_map.put("start_num", timeLineThrDM.start_num);
        parameter_map.put("return_num", timeLineThrDM.return_num);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getAddOthersResult(Context context, String subDir) {
        OtherrecordThrDM otherrecordThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("email", otherrecordThrDM.email);
        parameter_map.put("odate", otherrecordThrDM.odate);
        parameter_map.put("bmi", otherrecordThrDM.bmi);
        parameter_map.put("waist", otherrecordThrDM.waist);
        parameter_map.put("waistunit", otherrecordThrDM.waistunit);
        parameter_map.put("hba1c", otherrecordThrDM.hba1c);
        parameter_map.put("hba1cunit", otherrecordThrDM.hba1cunit);
        parameter_map.put("bloodpressure", otherrecordThrDM.bloodpressure);
        parameter_map.put("tc", otherrecordThrDM.tc);
        parameter_map.put("tg", otherrecordThrDM.tg);
        parameter_map.put("hdl", otherrecordThrDM.hdl);
        parameter_map.put("ldl", otherrecordThrDM.ldl);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getModOthersResult(Context context, String subDir) {
        OtherrecordThrDM otherrecordThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("id", otherrecordThrDM._id);
        parameter_map.put("odate", otherrecordThrDM.odate);
        parameter_map.put("bmi", otherrecordThrDM.bmi);
        parameter_map.put("waist", otherrecordThrDM.waist);
        parameter_map.put("waistunit", otherrecordThrDM.waistunit);
        parameter_map.put("hba1c", otherrecordThrDM.hba1c);
        parameter_map.put("hba1cunit", otherrecordThrDM.hba1cunit);
        parameter_map.put("bloodpressure", otherrecordThrDM.bloodpressure);
        parameter_map.put("tc", otherrecordThrDM.tc);
        parameter_map.put("tg", otherrecordThrDM.tg);
        parameter_map.put("hdl", otherrecordThrDM.hdl);
        parameter_map.put("ldl", otherrecordThrDM.ldl);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getDelOthersResult(Context context, String subDir) {
        OtherrecordThrDM otherrecordThrDM = this.objDM;
        HashMap<String, String> parameter_map = new HashMap();
        HashMap<String, String> attachFile_map = new HashMap();
        parameter_map.put("id", otherrecordThrDM._id);
        parameter_map.put("email", otherrecordThrDM.email);
        return getResultStr(context, parameter_map, attachFile_map, subDir);
    }

    public String getVersionResult(Context context, String subDir) {
        String result = getResultStr(context, null, null, subDir);
        this.logCat.log("SDConnection", "version_result", "result:" + result);
        return result;
    }

    private String getResultStr(Context context, HashMap<String, String> paramMap, HashMap<String, String> attachFileMap, String subDir) {
        String result = null;
        HttpClient client = new ServerHelper().getNewHttpClient();
        try {
            HttpPost httpPost = new ServerHelper().getHttpPost(context, subDir, paramMap, attachFileMap, "SDConnection");
            this.logCat.log("SDConnection", "version_result", "className:SDConnection");
            InputStream is = null;
            HttpEntity resEntity = client.execute(httpPost).getEntity();
            if (resEntity != null) {
                is = resEntity.getContent();
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, new ServerHelper().getEncode()));
            StringBuilder builder = new StringBuilder();
            while (true) {
                String str = reader.readLine();
                if (str == null) {
                    break;
                }
                builder.append(str + "\n");
                this.logCat.log("SDConnection", "version_result", "str:" + str);
            }
            result = builder.toString().trim();
            if (client != null) {
                client.getConnectionManager().shutdown();
            }
        } catch (Exception e) {
            e.printStackTrace();
            client.getConnectionManager().shutdown();
            return result;
        } finally {
            if (client != null) {
                client.getConnectionManager().shutdown();
            }
        }
        client.getConnectionManager().shutdown();
        return result;
    }
}
