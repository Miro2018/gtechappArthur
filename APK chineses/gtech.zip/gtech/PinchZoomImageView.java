package com.accumed.gtech;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ProgressBar;
import com.accumed.gtech.pinchzoom.GestureImageView;
import com.accumed.gtech.util.ImageDownloader;
import com.accumed.gtech.util.ImageDownloaderListener;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import java.util.Locale;

public class PinchZoomImageView extends Activity implements ImageDownloaderListener {
    final String className = "PinchZoomImageView";
    ImageDownloader imgDownloader;
    LogCat logCat = new LogCat();
    Context mContext;
    ProgressBar f12p;
    GestureImageView view;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.pinch_zoom);
        this.mContext = getApplicationContext();
        this.f12p = new ProgressBar(getApplicationContext());
        this.imgDownloader = new ImageDownloader(this);
        if (getIntent().getStringExtra("fname") != null) {
            try {
                String fname = ClassConstant.DIR_IMG + getIntent().getStringExtra("fname");
                this.logCat.log("PinchZoomImageView", "fname", fname);
                Options options = new Options();
                options.inSampleSize = 1;
                Bitmap bm = BitmapFactory.decodeFile(fname, options);
                LayoutParams params = new LayoutParams(-1, -1);
                this.view = new GestureImageView(this);
                this.view.setImageBitmap(bm);
                this.view.setLayoutParams(params);
                ((ViewGroup) findViewById(C0213R.id.layout)).addView(this.view);
                return;
            } catch (Exception e) {
                return;
            }
        }
        try {
            this.logCat.log("PinchZoomImageView", "d", "in");
            fname = getIntent().getStringExtra("fname_friend");
            this.logCat.log("PinchZoomImageView", "fname", fname);
            this.f12p.setVisibility(0);
            params = new LayoutParams(-1, -1);
            params.gravity = 16;
            params.gravity = 1;
            LayoutParams paramsP = new LayoutParams(50, 50);
            paramsP.gravity = 16;
            paramsP.gravity = 1;
            ViewGroup layout = (ViewGroup) findViewById(C0213R.id.layout);
            ImageView iv = new ImageView(getApplicationContext());
            iv.setLayoutParams(params);
            this.f12p.setLayoutParams(paramsP);
            layout.addView(this.f12p);
            layout.addView(iv);
            this.imgDownloader.download("https://54.250.126.59/img/" + fname, iv);
        } catch (Exception e2) {
        }
    }

    public void onImageDown(Object obj) {
        this.logCat.log("PinchZoomImageView", "onImageDown", "in");
        if (((Integer) obj).intValue() == 0 && this.f12p != null) {
            this.f12p.setVisibility(8);
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
