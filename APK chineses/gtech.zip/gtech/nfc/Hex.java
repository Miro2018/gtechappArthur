package com.accumed.gtech.nfc;

import android.support.v4.internal.view.SupportMenu;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.ContainerFragmentActivity;

public final class Hex {
    private static final String HEXCHARS = "0123456789abcdefABCDEF";
    private static final boolean LEFT = true;
    private static final String PRINTABLE = " .,:;'`\"<>()[]{}?/\\!@#$%^&*_-=+|~0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final boolean RIGHT = false;

    private Hex() {
    }

    public static String byteToHexString(byte b) {
        int n = b & 255;
        return ((n < 16 ? "0" : "") + Integer.toHexString(n)).toUpperCase();
    }

    public static String shortToHexString(short s) {
        int n = s & SupportMenu.USER_MASK;
        String result = (n < 4096 ? "0" : "") + (n < 256 ? "0" : "") + (n < 16 ? "0" : "") + Integer.toHexString(s);
        if (result.length() > 4) {
            result = result.substring(result.length() - 4, result.length());
        }
        return result.toUpperCase();
    }

    public static String intToHexString(int n) {
        return ((n < 268435456 ? "0" : "") + (n < 16777216 ? "0" : "") + (n < 1048576 ? "0" : "") + (n < 65536 ? "0" : "") + (n < 4096 ? "0" : "") + (n < 256 ? "0" : "") + (n < 16 ? "0" : "") + Integer.toHexString(n)).toUpperCase();
    }

    public static String bytesToHexString(byte[] text) {
        return bytesToHexString(text, 1000);
    }

    public static String bytesToHexString(byte[] text, int numRow) {
        if (text == null) {
            return "NULL";
        }
        return bytesToHexString(text, 0, text.length, numRow);
    }

    public static String toHexString(byte[] text) {
        return bytesToHexString(text, 0, text.length, 1000);
    }

    public static String toHexString(byte[] text, int numRow) {
        return bytesToHexString(text, 0, text.length, numRow);
    }

    public static String bytesToHexString(byte[] text, int offset, int length, int numRow) {
        if (text == null) {
            return "NULL";
        }
        StringBuffer result = new StringBuffer();
        int i = 0;
        while (i < length) {
            if (i != 0 && i % numRow == 0) {
                result.append("\n");
            }
            result.append(byteToHexString(text[offset + i]));
            i++;
        }
        return result.toString();
    }

    public static String bytesToHexString(byte[] text, int offset, int length) {
        return bytesToHexString(text, offset, length, 1000);
    }

    public static byte hexStringToByte(String text) throws NumberFormatException {
        byte[] bytes = hexStringToBytes(text);
        if (bytes.length == 1) {
            return bytes[0];
        }
        throw new NumberFormatException();
    }

    public static short hexStringToShort(String text) throws NumberFormatException {
        byte[] bytes = hexStringToBytes(text);
        if (bytes.length == 2) {
            return (short) (((bytes[0] & 255) << 8) | (bytes[1] & 255));
        }
        throw new NumberFormatException();
    }

    public static int hexStringToInt(String text) throws NumberFormatException {
        byte[] bytes = hexStringToBytes(text);
        if (bytes.length == 4) {
            return ((((bytes[0] & 255) << 24) | ((bytes[1] & 255) << 16)) | ((bytes[2] & 255) << 8)) | (bytes[3] & 255);
        }
        throw new NumberFormatException();
    }

    public static byte[] hexStringToBytes(String text) throws NumberFormatException {
        if (text == null) {
            return null;
        }
        int i;
        StringBuffer hexText = new StringBuffer();
        for (i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (!Character.isWhitespace(c)) {
                if (HEXCHARS.indexOf(c) < 0) {
                    throw new NumberFormatException();
                }
                hexText.append(c);
            }
        }
        if (hexText.length() % 2 != 0) {
            hexText.insert(0, "0");
        }
        byte[] result = new byte[(hexText.length() / 2)];
        for (i = 0; i < hexText.length(); i += 2) {
            result[i / 2] = (byte) (((hexDigitToInt(hexText.charAt(i)) & 255) << 4) | (hexDigitToInt(hexText.charAt(i + 1)) & 255));
        }
        return result;
    }

    static int hexDigitToInt(char c) throws NumberFormatException {
        switch (c) {
            case '0':
                return 0;
            case '1':
                return 1;
            case '2':
                return 2;
            case '3':
                return 3;
            case '4':
                return 4;
            case '5':
                return 5;
            case '6':
                return 6;
            case '7':
                return 7;
            case '8':
                return 8;
            case '9':
                return 9;
            case 'A':
            case 'a':
                return 10;
            case 'B':
            case 'b':
                return 11;
            case 'C':
            case 'c':
                return 12;
            case 'D':
            case 'd':
                return 13;
            case 'E':
            case ContainerFragmentActivity.USER_BTN /*101*/:
                return 14;
            case ClassConstant.GLUCOSE_mgdl_LOW /*70*/:
            case 'f':
                return 15;
            default:
                throw new NumberFormatException();
        }
    }

    private static String pad(String txt, int width, char padChar, boolean left) {
        StringBuffer result = new StringBuffer();
        int txtLength = txt.length();
        if (txtLength >= width) {
            return txt;
        }
        int padLength = width - txtLength;
        for (int i = 0; i < padLength; i++) {
            result.append(padChar);
        }
        if (left) {
            return result.toString() + txt;
        }
        return txt + result.toString();
    }

    public static String bytesToSpacedHexString(byte[] data) {
        StringBuffer result = new StringBuffer();
        int i = 0;
        while (i < data.length) {
            result.append(byteToHexString(data[i]));
            result.append(i < data.length + -1 ? " " : "");
            i++;
        }
        return result.toString().toUpperCase();
    }

    private static String[] bytesToSpacedHexStrings(byte[] data, int columns, int padWidth) {
        byte[][] src = split(data, columns);
        String[] result = new String[src.length];
        for (int j = 0; j < src.length; j++) {
            result[j] = bytesToSpacedHexString(src[j]);
            result[j] = pad(result[j], padWidth, TokenParser.SP, false);
        }
        return result;
    }

    public static String bytesToASCIIString(byte[] data) {
        StringBuffer result = new StringBuffer();
        for (byte b : data) {
            char c = (char) b;
            if (PRINTABLE.indexOf(c) < 0) {
                c = '.';
            }
            result.append(Character.toString(c));
        }
        return result.toString();
    }

    static String[] bytesToASCIIStrings(byte[] data, int columns, int padWidth) {
        byte[][] src = split(data, columns);
        String[] result = new String[src.length];
        for (int j = 0; j < src.length; j++) {
            result[j] = bytesToASCIIString(src[j]);
        }
        return result;
    }

    public static byte[][] split(byte[] src, int width) {
        int i;
        int rows = src.length / width;
        int rest = src.length % width;
        if (rest > 0) {
            i = 1;
        } else {
            i = 0;
        }
        byte[][] dest = new byte[(i + rows)][];
        int k = 0;
        for (int j = 0; j < rows; j++) {
            dest[j] = new byte[width];
            System.arraycopy(src, k, dest[j], 0, width);
            k += width;
        }
        if (rest > 0) {
            dest[rows] = new byte[rest];
            System.arraycopy(src, k, dest[rows], 0, rest);
        }
        return dest;
    }

    public static String bytesToPrettyString(byte[] data) {
        return bytesToPrettyString(data, 16, LEFT, 4, null, LEFT);
    }

    public static String bytesToPrettyString(byte[] data, int columns, boolean useIndex, int indexPadWidth, String altIndex, boolean useASCII) {
        StringBuffer result = new StringBuffer();
        String[] hexStrings = bytesToSpacedHexStrings(data, columns, columns * 3);
        String[] asciiStrings = bytesToASCIIStrings(data, columns, columns);
        int j = 0;
        while (j < hexStrings.length) {
            if (useIndex) {
                result.append(pad(Integer.toHexString(j * columns).toUpperCase(), indexPadWidth, '0', LEFT) + ": ");
            } else {
                result.append(pad(j == 0 ? altIndex : "", indexPadWidth, TokenParser.SP, LEFT) + " ");
            }
            result.append(hexStrings[j]);
            if (useASCII) {
                result.append(" " + asciiStrings[j]);
            }
            result.append("\n");
            j++;
        }
        return result.toString();
    }
}
