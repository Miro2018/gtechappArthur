package com.accumed.gtech.nfc;

public class nfc {
}
