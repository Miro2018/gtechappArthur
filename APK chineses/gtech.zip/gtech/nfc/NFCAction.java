package com.accumed.gtech.nfc;

public class NFCAction {
}
