package com.accumed.gtech;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import com.accumed.gtech.util.PreferenceAction;
import java.util.Locale;

public class MoveFriend extends Activity {
    Context mContext;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.mContext = getApplicationContext();
        startActivity(new Intent(this, ContainerFragmentActivity.class));
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
