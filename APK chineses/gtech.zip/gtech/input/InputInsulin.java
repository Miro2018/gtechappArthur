package com.accumed.gtech.input;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.adapter.InsulinListAdapter;
import com.accumed.gtech.adapter.WheelAdapter;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.datamodel.AddInsulinDM;
import com.accumed.gtech.thread.datamodel.AddInsulinReturnDM;
import com.accumed.gtech.thread.datamodel.NotiThrDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MagicReturnDM;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.util.Util;
import com.accumed.gtech.wheel.widget.OnWheelChangedListener;
import com.accumed.gtech.wheel.widget.OnWheelScrollListener;
import com.accumed.gtech.wheel.widget.WheelView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class InputInsulin extends Activity implements OnClickListener {
    static final int INSULIN_INPUT = 0;
    boolean INPUT;
    String[] array_insulin_name_data;
    String[] array_insulin_type_data;
    private OnCheckedChangeListener chboxCheckedChangeListener = new C03434();
    final String className = "InputInsulin";
    int indexNum;
    Handler insertH = new C03401();
    private LinearLayout insulinLy0;
    private WheelView insulinName;
    private String[][] insulinNames;
    private WheelView insulinType;
    private boolean isDefaultChecked;
    LogCat logCat = new LogCat();
    private InsulinListAdapter mAdapter;
    int mAppStatus;
    private ArrayList<LogDM> mArr;
    private Button mBtnAdd;
    private Button mBtnCancel;
    private Button mBtnComplete;
    private CheckBox mChboxDefaultChecker;
    Context mContext;
    private String mDate;
    private OnDateSetListener mDateSetListener = new C03412();
    private int mDay;
    private EditText mEditValue;
    private int mHour;
    private ListView mListview;
    private int mMinute;
    private int mMonth;
    private String mName;
    private WheelAdapter mNameAdapter;
    private String mRealName;
    private ArrayList<String> mRealNameArr;
    private String mTime;
    private OnTimeSetListener mTimeSetListener = new C03423();
    private TextView mTvDate;
    private TextView mTvTime;
    private String mType;
    private WheelAdapter mTypeAdapter;
    private String mValue;
    private int mYear;
    private int[][] name = new int[][]{new int[]{C0213R.string.insulin_name_novorapid, C0213R.string.insulin_name_apidra, C0213R.string.insulin_name_humalog}, new int[]{C0213R.string.insulin_name_humulin_r, C0213R.string.insulin_name_novorin_r}, new int[]{C0213R.string.insulin_name_novorin_n, C0213R.string.insulin_name_humulin_n, C0213R.string.insulin_name_insulatard}, new int[]{C0213R.string.insulin_name_lantus, C0213R.string.insulin_name_levemir, C0213R.string.insulin_name_toujeo, C0213R.string.insulin_name_tresiba}, new int[]{C0213R.string.insulin_name_novomix_30, C0213R.string.insulin_name_novomix_50, C0213R.string.insulin_name_novomix_70, C0213R.string.insulin_name_mixtard, C0213R.string.insulin_name_humulin_30, C0213R.string.insulin_name_humulin_70, C0213R.string.insulin_name_humalogmix_25, C0213R.string.insulin_name_humalogmix_50}};
    private PreferenceAction prefSetting;
    private boolean scrolling = false;
    ProgressBar sendProgressBar;
    int sendSize = 0;
    private int[] type = new int[]{C0213R.string.insulin_type_rapid, C0213R.string.insulin_type_short, C0213R.string.insulin_type_nph, C0213R.string.insulin_type_long, C0213R.string.insulin_type_mix};
    Util util;

    class C03401 extends Handler {

        class C03391 implements Runnable {
            C03391() {
            }

            public void run() {
                InputInsulin.this.sendProgressBar.setVisibility(8);
            }
        }

        C03401() {
        }

        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                InputInsulin.this.sendProgressBar.post(new C03391());
                InputInsulin.this.setResult(-1);
                InputInsulin.this.finish();
            }
        }
    }

    class C03412 implements OnDateSetListener {
        C03412() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            InputInsulin.this.mYear = year;
            InputInsulin.this.mMonth = monthOfYear + 1;
            InputInsulin.this.mDay = dayOfMonth;
            InputInsulin.this.mDate = InputInsulin.this.pad(InputInsulin.this.mYear) + InputInsulin.this.pad(InputInsulin.this.mMonth) + InputInsulin.this.pad(InputInsulin.this.mDay);
            InputInsulin.this.mTvDate.setTextColor(Color.parseColor("#000000"));
            InputInsulin.this.mTvDate.setText(InputInsulin.this.pad(InputInsulin.this.mYear) + "." + InputInsulin.this.pad(InputInsulin.this.mMonth) + "." + InputInsulin.this.pad(InputInsulin.this.mDay));
        }
    }

    class C03423 implements OnTimeSetListener {
        C03423() {
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            InputInsulin.this.mHour = hourOfDay;
            InputInsulin.this.mMinute = minute;
            InputInsulin.this.mTime = InputInsulin.this.pad(InputInsulin.this.mHour) + InputInsulin.this.pad(InputInsulin.this.mMinute);
            InputInsulin.this.mTvTime.setTextColor(Color.parseColor("#000000"));
            InputInsulin.this.mTvTime.setText(InputInsulin.this.pad(InputInsulin.this.mHour) + ":" + InputInsulin.this.pad(InputInsulin.this.mMinute));
        }
    }

    class C03434 implements OnCheckedChangeListener {
        C03434() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            switch (buttonView.getId()) {
                case C0213R.id.insulin_chbox_default:
                    if (isChecked) {
                        InputInsulin.this.mChboxDefaultChecker.setButtonDrawable(C0213R.drawable.btn_chbox_on);
                        Toast.makeText(InputInsulin.this.mContext, InputInsulin.this.getString(C0213R.string.insulin_default_checked), 0).show();
                        InputInsulin.this.prefSetting.putString(PreferenceAction.PREF_INSULIN_TYPE, "" + InputInsulin.this.insulinType.getCurrentItem());
                        InputInsulin.this.prefSetting.putString(PreferenceAction.PREF_INSULIN_NAME, "" + InputInsulin.this.insulinName.getCurrentItem());
                        InputInsulin.this.logCat.log("InputInsulin", PreferenceAction.PREF_INSULIN_TYPE, "" + InputInsulin.this.insulinType.getCurrentItem());
                        InputInsulin.this.logCat.log("InputInsulin", PreferenceAction.PREF_INSULIN_NAME, "" + InputInsulin.this.insulinName.getCurrentItem());
                        return;
                    }
                    InputInsulin.this.mChboxDefaultChecker.setButtonDrawable(C0213R.drawable.btn_chbox_off);
                    Toast.makeText(InputInsulin.this.mContext, InputInsulin.this.getString(C0213R.string.insulin_default_unchecked), 0).show();
                    InputInsulin.this.prefSetting.putString(PreferenceAction.PREF_INSULIN_TYPE, null);
                    InputInsulin.this.prefSetting.putString(PreferenceAction.PREF_INSULIN_NAME, null);
                    return;
                default:
                    return;
            }
        }
    }

    class C03445 implements OnTouchListener {
        C03445() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) InputInsulin.this.getSystemService("input_method")).hideSoftInputFromWindow(InputInsulin.this.mEditValue.getWindowToken(), 0);
            return false;
        }
    }

    class C03456 implements OnWheelChangedListener {
        C03456() {
        }

        public void onChanged(WheelView wheel, int oldValue, int newValue) {
            if (!InputInsulin.this.scrolling) {
                InputInsulin.this.updateType(newValue);
            }
        }
    }

    class C03467 implements OnWheelScrollListener {
        C03467() {
        }

        public void onScrollingStarted(WheelView wheel) {
            InputInsulin.this.scrolling = true;
        }

        public void onScrollingFinished(WheelView wheel) {
            InputInsulin.this.scrolling = false;
            InputInsulin.this.updateType(InputInsulin.this.insulinType.getCurrentItem());
        }
    }

    class C03478 implements OnWheelChangedListener {
        C03478() {
        }

        public void onChanged(WheelView wheel, int oldValue, int newValue) {
            if (!InputInsulin.this.scrolling) {
                InputInsulin.this.updateType(newValue);
            }
        }
    }

    class C03489 implements OnWheelScrollListener {
        C03489() {
        }

        public void onScrollingStarted(WheelView wheel) {
            InputInsulin.this.scrolling = true;
        }

        public void onScrollingFinished(WheelView wheel) {
            InputInsulin.this.scrolling = false;
            InputInsulin.this.updateType(InputInsulin.this.insulinType.getCurrentItem());
        }
    }

    class InsertThr extends Thread {
        InsertThr() {
        }

        public void run() {
            if (!InputInsulin.this.INPUT) {
                InputInsulin.this.INPUT = true;
                Message msg;
                if (InputInsulin.this.mArr == null || InputInsulin.this.mArr.size() <= 0) {
                    msg = Message.obtain();
                    msg.what = 0;
                    InputInsulin.this.insertH.handleMessage(msg);
                    return;
                }
                int i;
                for (i = 0; i < InputInsulin.this.mArr.size(); i++) {
                    LogDM dm = (LogDM) InputInsulin.this.mArr.get(i);
                    InputInsulin.this.logCat.log("InputInsulin", "dat.insulin", dm.input_date);
                    InputInsulin.this.logCat.log("InputInsulin", "dat.insulin", dm.insulin_name);
                    InputInsulin.this.logCat.log("InputInsulin", "dat.insulin", dm.insulin_type);
                    InputInsulin.this.logCat.log("InputInsulin", "dat.insulin", dm.insulin_value);
                }
                PreferenceAction prefEmail = new PreferenceAction(InputInsulin.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                DBAction dbAction = new DBAction(InputInsulin.this.mContext);
                for (i = 0; i < InputInsulin.this.mArr.size(); i++) {
                    InputInsulin.this.indexNum = i;
                    if (dbAction.insertLog((LogDM) InputInsulin.this.mArr.get(i))) {
                        AddInsulinDM addInsulinDM = new AddInsulinDM();
                        addInsulinDM.email = prefEmail.getString(PreferenceAction.MY_EMAIL);
                        addInsulinDM.itype = InputInsulin.this.array_insulin_type_data[Integer.parseInt(((LogDM) InputInsulin.this.mArr.get(i)).insulin_type)];
                        addInsulinDM.iproduct = InputInsulin.this.array_insulin_name_data[Integer.parseInt(((LogDM) InputInsulin.this.mArr.get(i)).insulin_name)];
                        addInsulinDM.idate = new Util().getServerDateFormat(((LogDM) InputInsulin.this.mArr.get(i)).input_date);
                        addInsulinDM.ivalue = ((LogDM) InputInsulin.this.mArr.get(i)).insulin_value;
                        addInsulinDM.manualinput = "YES";
                        InputInsulin.this.logCat.log("InputInsulin", "send addInsulinDM.email", addInsulinDM.email);
                        InputInsulin.this.logCat.log("InputInsulin", "send addInsulinDM.itype", addInsulinDM.itype);
                        InputInsulin.this.logCat.log("InputInsulin", "send addInsulinDM.idate", addInsulinDM.idate);
                        InputInsulin.this.logCat.log("InputInsulin", "send addInsulinDM.ivalue", addInsulinDM.ivalue);
                        InputInsulin.this.logCat.log("InputInsulin", "send addInsulinDM.iproduct", addInsulinDM.iproduct);
                        InputInsulin.this.logCat.log("InputInsulin", "send addInsulinDM.manualinput", addInsulinDM.manualinput);
                        InputInsulin.this.actionDefine(0, addInsulinDM);
                    } else {
                        InputInsulin.this.logCat.log("InputInsulin", "inslulin input", "failed");
                    }
                }
                msg = Message.obtain();
                msg.what = 0;
                InputInsulin.this.insertH.handleMessage(msg);
            }
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
        if (this.mEditValue != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditValue.getWindowToken(), 0);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.input_insulin);
        this.mContext = getApplicationContext();
        this.util = new Util();
        this.array_insulin_type_data = getResources().getStringArray(C0213R.array.array_insulin_type_data);
        this.array_insulin_name_data = getResources().getStringArray(C0213R.array.array_insulin_name_data);
        init();
    }

    private void init() {
        this.insulinLy0 = (LinearLayout) findViewById(C0213R.id.insulinLy0);
        this.mBtnCancel = (Button) findViewById(C0213R.id.insulin_btn_cancel);
        this.mBtnComplete = (Button) findViewById(C0213R.id.insulin_btn_complete);
        this.mTvTime = (TextView) findViewById(C0213R.id.insulin_tv_time);
        this.mEditValue = (EditText) findViewById(C0213R.id.insulin_edit_value);
        this.mBtnAdd = (Button) findViewById(C0213R.id.insulin_btn_add);
        this.mTvDate = (TextView) findViewById(C0213R.id.insulin_tv_date);
        this.sendProgressBar = (ProgressBar) findViewById(C0213R.id.sendProgressBar);
        this.sendProgressBar.setVisibility(8);
        this.mChboxDefaultChecker = (CheckBox) findViewById(C0213R.id.insulin_chbox_default);
        this.mChboxDefaultChecker.setOnCheckedChangeListener(this.chboxCheckedChangeListener);
        this.mBtnCancel.setOnClickListener(this);
        this.mBtnComplete.setOnClickListener(this);
        this.mTvDate.setOnClickListener(this);
        this.mTvTime.setOnClickListener(this);
        this.mBtnAdd.setOnClickListener(this);
        this.insulinLy0.setOnTouchListener(new C03445());
        setWheelData();
        notifyAdapter();
        setDefaultDate();
        setEditTextPosition();
    }

    private void setDefaultDate() {
        Calendar c = Calendar.getInstance();
        this.mYear = c.get(1);
        this.mMonth = c.get(2) + 1;
        this.mDay = c.get(5);
        this.mHour = c.get(10);
        this.mMinute = c.get(12);
        if (c.get(9) == 1) {
            this.mHour += 12;
        }
        this.mDate = pad(this.mYear) + pad(this.mMonth) + pad(this.mDay);
        this.mTvDate.setTextColor(Color.parseColor("#000000"));
        this.mTvDate.setText(pad(this.mYear) + "." + pad(this.mMonth) + "." + pad(this.mDay));
        this.mTime = pad(this.mHour) + pad(this.mMinute);
        this.mTvTime.setTextColor(Color.parseColor("#000000"));
        this.mTvTime.setText(pad(this.mHour) + ":" + pad(this.mMinute));
    }

    public void onClick(View v) {
        if (v.getId() == C0213R.id.insulin_btn_cancel) {
            finish();
        } else if (v.getId() == C0213R.id.insulin_btn_complete) {
            insert();
        } else if (v.getId() == C0213R.id.insulin_tv_date) {
            showDatePicker();
        } else if (v.getId() == C0213R.id.insulin_tv_time) {
            showTimePicker();
        } else if (v.getId() == C0213R.id.insulin_btn_add) {
            add();
        }
    }

    private void showDatePicker() {
        DatePickerDialog datePicker = new DatePickerDialog(this, this.mDateSetListener, this.mYear, this.mMonth - 1, this.mDay);
        datePicker.setButton(-1, getResources().getString(C0213R.string.btn_set), datePicker);
        datePicker.setButton(-2, getResources().getString(C0213R.string.btn_cancel), datePicker);
        datePicker.show();
    }

    private void showTimePicker() {
        TimePickerDialog timePicker = new TimePickerDialog(this, this.mTimeSetListener, this.mHour, this.mMinute, false);
        timePicker.setButton(-1, getResources().getString(C0213R.string.btn_set), timePicker);
        timePicker.setButton(-2, getResources().getString(C0213R.string.btn_cancel), timePicker);
        timePicker.show();
    }

    private void add() {
        if (this.mEditValue != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditValue.getWindowToken(), 0);
        }
        this.mValue = this.mEditValue.getText().toString().trim();
        if (this.mDate == null || this.mDate.trim().equals("") || this.mTime == null || this.mTime.trim().equals("")) {
            new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_type04), getString(C0213R.string.alert_text_confirm));
        } else if (this.mValue == null || this.mValue.trim().equals("")) {
            new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_type05), getString(C0213R.string.alert_text_confirm));
        } else if (this.mValue.substring(0, 1).equals(".")) {
            new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_type05), getString(C0213R.string.alert_text_confirm));
            this.mEditValue.setText("");
        } else {
            int position_type = this.insulinType.getCurrentItem();
            int position_name = this.insulinName.getCurrentItem();
            this.mType = String.valueOf(position_type);
            int n = 0;
            for (int i = 0; i < position_type; i++) {
                n += this.insulinNames[i].length;
            }
            if (position_type == 2) {
                if (position_name == 0 || position_name == 1) {
                    this.mName = String.valueOf((n + position_name) + 11);
                } else {
                    this.mName = String.valueOf((n + position_name) - 2);
                }
            } else if (position_type == 3) {
                if (position_name == 2 || position_name == 3) {
                    this.mName = String.valueOf((n + position_name) + 8);
                } else {
                    this.mName = String.valueOf((n + position_name) - 2);
                }
            } else if (position_type >= 4) {
                this.mName = String.valueOf((n + position_name) - 4);
            } else {
                this.mName = String.valueOf(n + position_name);
            }
            this.mRealName = this.insulinNames[position_type][position_name];
            this.mRealNameArr.add(this.mRealName);
            String system_date = new SimpleDateFormat("yyyyMMddHHmmss").format(Long.valueOf(System.currentTimeMillis()));
            LogDM data = new LogDM();
            data._id = "";
            data.input_date = this.mDate + this.mTime + "00000";
            data.system_date = system_date;
            data.category = "1";
            data.update_flag = "insert";
            data.insulin_type = this.mType;
            data.insulin_name = this.mName;
            data.insulin_value = this.mValue;
            this.mArr.add(data);
            notifyAdapter();
            this.mEditValue.setText("");
        }
    }

    private void notifyAdapter() {
        if (this.mAdapter == null) {
            this.mArr = new ArrayList();
            this.mRealNameArr = new ArrayList();
            this.mAdapter = new InsulinListAdapter(this, this.mArr, this.mRealNameArr);
            this.mListview = (ListView) findViewById(C0213R.id.insulin_lv_listview);
            this.mListview.setAdapter(this.mAdapter);
            return;
        }
        this.mAdapter.notifyDataSetChanged();
    }

    void inputAlert() {
        new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_type05), getString(C0213R.string.alert_text_confirm));
    }

    private void insert() {
        if (this.mArr.size() == 0) {
            inputAlert();
            return;
        }
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        this.sendProgressBar.setVisibility(0);
        new InsertThr().start();
    }

    private boolean validationCheck(LogDM data) {
        String date = data.input_date;
        String name = data.insulin_name;
        String type = data.insulin_type;
        String value = data.insulin_value;
        if (date == null || date.trim().equals("") || name == null || name.trim().equals("") || type == null || type.trim().equals("") || value == null || value.trim().equals("")) {
            return false;
        }
        return true;
    }

    private String pad(int c) {
        if (c < 10) {
            return "0" + String.valueOf(c);
        }
        return String.valueOf(c);
    }

    public void setWheelData() {
        boolean isSaved;
        r3 = new String[5][];
        r3[0] = new String[]{getInsulinName(C0213R.string.insulin_name_novorapid), getInsulinName(C0213R.string.insulin_name_apidra), getInsulinName(C0213R.string.insulin_name_humalog)};
        r3[1] = new String[]{getInsulinName(C0213R.string.insulin_name_novorin_r), getInsulinName(C0213R.string.insulin_name_humulin_r)};
        r3[2] = new String[]{getInsulinName(C0213R.string.insulin_name_novorin_n), getInsulinName(C0213R.string.insulin_name_humulin_n), getInsulinName(C0213R.string.insulin_name_insulatard)};
        r3[3] = new String[]{getInsulinName(C0213R.string.insulin_name_lantus), getInsulinName(C0213R.string.insulin_name_levemir), getInsulinName(C0213R.string.insulin_name_toujeo), getInsulinName(C0213R.string.insulin_name_tresiba)};
        r3[4] = new String[]{getInsulinName(C0213R.string.insulin_name_novomix_30), getInsulinName(C0213R.string.insulin_name_novomix_50), getInsulinName(C0213R.string.insulin_name_novomix_70), getInsulinName(C0213R.string.insulin_name_mixtard), getInsulinName(C0213R.string.insulin_name_humulin_30), getInsulinName(C0213R.string.insulin_name_humulin_70), getInsulinName(C0213R.string.insulin_name_humalogmix_25), getInsulinName(C0213R.string.insulin_name_humalogmix_50)};
        this.insulinNames = r3;
        this.mTypeAdapter = new WheelAdapter(this, this.type);
        this.insulinType = (WheelView) findViewById(C0213R.id.insulin_wheel_type);
        this.insulinType.setVisibleItems(3);
        this.insulinType.setViewAdapter(this.mTypeAdapter);
        this.insulinType.addChangingListener(new C03456());
        this.insulinType.addScrollingListener(new C03467());
        this.insulinName = (WheelView) findViewById(C0213R.id.insulin_wheel_name);
        this.insulinName.setVisibleItems(3);
        this.insulinType.addChangingListener(new C03478());
        this.insulinType.addScrollingListener(new C03489());
        this.prefSetting = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        String position_type = this.prefSetting.getString(PreferenceAction.PREF_INSULIN_TYPE);
        String position_name = this.prefSetting.getString(PreferenceAction.PREF_INSULIN_NAME);
        if (position_type == "" || position_name == "") {
            isSaved = false;
        } else {
            isSaved = true;
        }
        this.logCat.log("InputInsulin", "position_type", "" + position_type);
        this.logCat.log("InputInsulin", "position_name", "" + position_name);
        if (isSaved) {
            this.isDefaultChecked = true;
            updateDefault(Integer.valueOf(position_type).intValue(), Integer.valueOf(position_name).intValue());
            return;
        }
        this.isDefaultChecked = false;
        this.mChboxDefaultChecker.setChecked(this.isDefaultChecked);
        this.insulinType.setCurrentItem(1);
        this.insulinType.setCurrentItem(0);
    }

    private void updateType(int index) {
        this.insulinType.setColorPosition(index);
        this.insulinType.initResourcesIfNecessary();
        this.insulinName.setColorPosition(index);
        this.insulinName.initResourcesIfNecessary();
        this.mNameAdapter = new WheelAdapter(this, this.name[index]);
        this.insulinName.setViewAdapter(this.mNameAdapter);
        this.insulinName.setCurrentItem(0);
    }

    private void updateDefault(int typeIdx, int nameIdx) {
        this.insulinType.setCurrentItem(typeIdx);
        this.insulinType.setColorPosition(typeIdx);
        this.insulinType.initResourcesIfNecessary();
        this.insulinName.setColorPosition(typeIdx);
        this.insulinName.initResourcesIfNecessary();
        this.mNameAdapter = new WheelAdapter(this, this.name[typeIdx]);
        this.insulinName.setViewAdapter(this.mNameAdapter);
        this.insulinName.setCurrentItem(nameIdx);
    }

    private String getInsulinName(int resId) {
        return getString(resId);
    }

    private void setEditTextPosition() {
        if (this.mEditValue != null) {
            String str = this.mEditValue.getText().toString();
            if (str != null && !str.trim().equals("")) {
                this.mEditValue.setSelection(str.length());
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    private void actionDefine(int gubun, AddInsulinDM addInsulinDM) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_x");
                if (gubun == 0) {
                    setResult(-1);
                    finish();
                    return;
                }
                return;
            case 1:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 5:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == 0) {
                    setResult(-1);
                    finish();
                    return;
                }
                return;
            case 10:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == 0) {
                    setResult(-1);
                    finish();
                    return;
                }
                return;
            case 14:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == 0) {
                    setResult(-1);
                    finish();
                    return;
                }
                return;
            case 17:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == 0) {
                    setResult(-1);
                    finish();
                    return;
                }
                return;
            case 21:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == 0) {
                    setResult(-1);
                    finish();
                    return;
                }
                return;
            case 26:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    setResult(-1);
                    finish();
                    return;
                }
                return;
            case 30:
                this.logCat.log("InputInsulin", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    String jsonResult = new SDConnection(addInsulinDM).getAddInsulinResult(this.mContext, ClassConstant.SUBDIR_ADD_INSULIN);
                    AddInsulinReturnDM addInsulinReturnDM = new AddInsulinReturnDM();
                    sendResultAction(new MagicReturnDM().addInsulinReturnDM(jsonResult));
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void sendResultAction(AddInsulinReturnDM dm) {
        this.logCat.log("InputInsulin", "onAddInsulin", "in");
        if (!dm.statusResult.equals("ok")) {
            this.logCat.log("InputInsulin", "onAddInsulin()", "failed 2");
        } else if (!dm.code.equals("200")) {
            this.logCat.log("InputInsulin", "onAddInsulin()", "failed 1");
        } else if (dm.result.equals("0")) {
            final PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            this.logCat.log("InputInsulin", "onAddInsulin() id", dm.id);
            if (new DBAction(this.mContext).executeQuery("update log set user_id='" + pref.getString(PreferenceAction.MY_EMAIL) + "', _id= '" + dm.id + "', update_flag = null where system_date='" + ((LogDM) this.mArr.get(this.indexNum)).system_date + "'")) {
                this.logCat.log("InputInsulin", "dbUpdate", "ok");
            } else {
                this.logCat.log("InputInsulin", "dbUpdate", "failed");
            }
            setResult(-1);
            new Thread() {
                public void run() {
                    for (int i = 0; i < InputInsulin.this.mArr.size(); i++) {
                        NotiThrDM nDM = new NotiThrDM();
                        nDM.email = pref.getString(PreferenceAction.MY_EMAIL);
                        nDM.gubun = InputInsulin.this.getString(C0213R.string.noti_insulins);
                        nDM.gubun_num = "1";
                        nDM.message = pref.getString(PreferenceAction.MY_NAME) + " " + nDM.gubun + " : " + ((LogDM) InputInsulin.this.mArr.get(i)).insulin_value;
                        nDM.name = pref.getString(PreferenceAction.MY_NAME);
                        new SDConnection(nDM).notiResult(InputInsulin.this.mContext, ClassConstant.SUBDIR_SUPORT_NOTI);
                    }
                }
            }.start();
            finish();
        } else {
            this.logCat.log("InputInsulin", "onAddInsulin()", "failed 0");
        }
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
