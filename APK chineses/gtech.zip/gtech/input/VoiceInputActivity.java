package com.accumed.gtech.input;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.adapter.VoiceListAdapter;
import com.accumed.gtech.util.PreferenceAction;
import java.util.ArrayList;
import java.util.Locale;

public class VoiceInputActivity extends Activity {
    private static final int VOICE_RECOGNITION_REQUEST_CODE = 3000;
    private Button mBtnExit;
    Context mContext;
    private ListView mList;
    private ArrayList<String> matches;

    class C03751 implements OnClickListener {
        C03751() {
        }

        public void onClick(View v) {
            VoiceInputActivity.this.setResult(0);
            VoiceInputActivity.this.finish();
        }
    }

    class C03762 implements OnItemClickListener {
        C03762() {
        }

        public void onItemClick(AdapterView<?> adapterView, View v, int position, long id) {
            Intent intent = VoiceInputActivity.this.getIntent();
            intent.putExtra("searchKeyword", (String) VoiceInputActivity.this.matches.get(position));
            VoiceInputActivity.this.setResult(-1, intent);
            VoiceInputActivity.this.finish();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.voice_input);
        this.mContext = getApplicationContext();
        this.mList = (ListView) findViewById(C0213R.id.list);
        this.mBtnExit = (Button) findViewById(C0213R.id.btn_speak_exit);
        this.mBtnExit.setOnClickListener(new C03751());
        startVoiceRecognitionActivity();
    }

    private void startVoiceRecognitionActivity() {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        intent.putExtra("android.speech.extra.PROMPT", "Speech recognition demo");
        startActivityForResult(intent, VOICE_RECOGNITION_REQUEST_CODE);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == VOICE_RECOGNITION_REQUEST_CODE && resultCode == -1) {
            this.matches = data.getStringArrayListExtra("android.speech.extra.RESULTS");
            if (this.matches.size() > 0) {
                this.mBtnExit.setVisibility(0);
                this.mList.setAdapter(new VoiceListAdapter(this, this.matches));
                this.mList.setOnItemClickListener(new C03762());
            } else {
                setResult(0);
                finish();
            }
        } else {
            setResult(0);
            finish();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void onResume() {
        overridePendingTransition(0, 0);
        super.onResume();
    }

    public void onPause() {
        overridePendingTransition(0, 0);
        super.onPause();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
