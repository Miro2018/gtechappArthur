package com.accumed.gtech.input;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.adapter.WheelAdapter;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.OnModInsulinListener;
import com.accumed.gtech.thread.ThrModInsulin;
import com.accumed.gtech.thread.datamodel.ModInsulinReturnDM;
import com.accumed.gtech.thread.datamodel.ModInsulinThrDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.util.Util;
import com.accumed.gtech.wheel.widget.OnWheelChangedListener;
import com.accumed.gtech.wheel.widget.OnWheelScrollListener;
import com.accumed.gtech.wheel.widget.WheelView;
import java.util.Locale;

public class ModifyInsulin extends Activity implements OnClickListener, OnModInsulinListener {
    static final int MODIFY_INSULIN = 0;
    static final String className = "ModifyInsulin";
    String[] array_insulin_name_data;
    String[] array_insulin_type_data;
    private LogDM data;
    String inputDate;
    private LinearLayout insulinModyLy0;
    private WheelView insulinName;
    private String[][] insulinNames;
    private WheelView insulinType;
    private LogCat logCat;
    int mAppStatus;
    private Button mBtnCancel;
    private Button mBtnComplete;
    private Context mContext;
    private String mDate;
    private OnDateSetListener mDateSetListener = new C03652();
    private int mDay;
    private EditText mEditValue;
    private int mHour;
    private int mMinute;
    private int mMonth;
    private String mName;
    private WheelAdapter mNameAdapter;
    int mSeq;
    private String mTime;
    private OnTimeSetListener mTimeSetListener = new C03663();
    private TextView mTvDate;
    private TextView mTvTime;
    private String mType;
    private WheelAdapter mTypeAdapter;
    private String mValue;
    private int mYear;
    private int[][] name;
    int position;
    private boolean scrolling = false;
    ProgressBar sendProgressBar;
    private int[] type = new int[]{C0213R.string.insulin_type_rapid, C0213R.string.insulin_type_short, C0213R.string.insulin_type_nph, C0213R.string.insulin_type_long, C0213R.string.insulin_type_mix};

    class C03641 implements OnTouchListener {
        C03641() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) ModifyInsulin.this.getSystemService("input_method")).hideSoftInputFromWindow(ModifyInsulin.this.mEditValue.getWindowToken(), 0);
            return false;
        }
    }

    class C03652 implements OnDateSetListener {
        C03652() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            ModifyInsulin.this.mYear = year;
            ModifyInsulin.this.mMonth = monthOfYear + 1;
            ModifyInsulin.this.mDay = dayOfMonth;
            ModifyInsulin.this.mDate = ModifyInsulin.this.pad(ModifyInsulin.this.mYear) + ModifyInsulin.this.pad(ModifyInsulin.this.mMonth) + ModifyInsulin.this.pad(ModifyInsulin.this.mDay);
            ModifyInsulin.this.mTvDate.setTextColor(Color.parseColor("#000000"));
            ModifyInsulin.this.mTvDate.setText(ModifyInsulin.this.pad(ModifyInsulin.this.mYear) + "." + ModifyInsulin.this.pad(ModifyInsulin.this.mMonth) + "." + ModifyInsulin.this.pad(ModifyInsulin.this.mDay));
        }
    }

    class C03663 implements OnTimeSetListener {
        C03663() {
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            ModifyInsulin.this.mHour = hourOfDay;
            ModifyInsulin.this.mMinute = minute;
            ModifyInsulin.this.mTime = ModifyInsulin.this.pad(ModifyInsulin.this.mHour) + ModifyInsulin.this.pad(ModifyInsulin.this.mMinute);
            ModifyInsulin.this.mTvTime.setTextColor(Color.parseColor("#000000"));
            ModifyInsulin.this.mTvTime.setText(ModifyInsulin.this.pad(ModifyInsulin.this.mHour) + ":" + ModifyInsulin.this.pad(ModifyInsulin.this.mMinute));
        }
    }

    class C03674 implements Runnable {
        C03674() {
        }

        public void run() {
            ModifyInsulin.this.sendProgressBar.setVisibility(0);
        }
    }

    class C03685 implements OnWheelChangedListener {
        C03685() {
        }

        public void onChanged(WheelView wheel, int oldValue, int newValue) {
            if (!ModifyInsulin.this.scrolling) {
                ModifyInsulin.this.updateType(newValue);
            }
        }
    }

    class C03696 implements OnWheelScrollListener {
        C03696() {
        }

        public void onScrollingStarted(WheelView wheel) {
            ModifyInsulin.this.scrolling = true;
        }

        public void onScrollingFinished(WheelView wheel) {
            ModifyInsulin.this.scrolling = false;
            ModifyInsulin.this.updateType(ModifyInsulin.this.insulinType.getCurrentItem());
        }
    }

    public ModifyInsulin() {
        r0 = new int[5][];
        r0[1] = new int[]{C0213R.string.insulin_name_humulin_r};
        r0[2] = new int[]{C0213R.string.insulin_name_novorin_r, C0213R.string.insulin_name_insulatard};
        r0[3] = new int[]{C0213R.string.insulin_name_lantus, C0213R.string.insulin_name_levemir};
        r0[4] = new int[]{C0213R.string.insulin_name_novomix_30, C0213R.string.insulin_name_novomix_50, C0213R.string.insulin_name_novomix_70, C0213R.string.insulin_name_mixtard, C0213R.string.insulin_name_humulin_30, C0213R.string.insulin_name_humulin_70, C0213R.string.insulin_name_humalogmix_25, C0213R.string.insulin_name_humalogmix_50};
        this.name = r0;
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
        if (this.mEditValue != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditValue.getWindowToken(), 0);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.modify_insulin);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.data = (LogDM) getIntent().getSerializableExtra("MODIFY_INSULIN_LOGDM");
        this.logCat.log(className, "_id", this.data._id);
        this.array_insulin_type_data = getResources().getStringArray(C0213R.array.array_insulin_type_data);
        this.array_insulin_name_data = getResources().getStringArray(C0213R.array.array_insulin_name_data);
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        init();
    }

    private void init() {
        this.insulinModyLy0 = (LinearLayout) findViewById(C0213R.id.insulinModyLy0);
        this.mBtnCancel = (Button) findViewById(C0213R.id.insulin_btn_cancel);
        this.mBtnComplete = (Button) findViewById(C0213R.id.insulin_btn_complete);
        this.mTvDate = (TextView) findViewById(C0213R.id.insulin_tv_date);
        this.mTvTime = (TextView) findViewById(C0213R.id.insulin_tv_time);
        this.mEditValue = (EditText) findViewById(C0213R.id.insulin_edit_value);
        this.sendProgressBar = (ProgressBar) findViewById(C0213R.id.sendProgressBar);
        this.sendProgressBar.setVisibility(8);
        this.mBtnCancel.setOnClickListener(this);
        this.mBtnComplete.setOnClickListener(this);
        this.mTvDate.setOnClickListener(this);
        this.mTvTime.setOnClickListener(this);
        this.insulinModyLy0.setOnTouchListener(new C03641());
        setWheelData();
        setData();
        setEditTextPosition();
    }

    public String conversionStrDateTimeFormat(String date) {
        if (date == null) {
            return null;
        }
        return date.replaceAll("-", "").replaceAll(":", "").replaceAll("\\.", "").replaceAll("\\p{Space}", "");
    }

    private void setData() {
        this.mSeq = Integer.parseInt(this.data.seq);
        String strDate = this.data.input_date;
        this.mDate = strDate.substring(0, 8);
        this.mTime = strDate.substring(8);
        this.mType = this.data.insulin_type;
        this.mName = this.data.insulin_name;
        this.mValue = this.data.insulin_value;
        if (!(strDate == null || strDate.trim().equals(""))) {
            strDate = conversionStrDateTimeFormat(strDate);
            this.mYear = Integer.parseInt(strDate.substring(0, 4));
            this.mMonth = Integer.parseInt(strDate.substring(4, 6));
            this.mDay = Integer.parseInt(strDate.substring(6, 8));
            this.mHour = Integer.parseInt(strDate.substring(8, 10));
            this.mMinute = Integer.parseInt(strDate.substring(10, 12));
            this.mDate = pad(this.mYear) + pad(this.mMonth) + pad(this.mDay);
            this.mTvDate.setTextColor(Color.parseColor("#000000"));
            this.mTvDate.setText(pad(this.mYear) + "." + pad(this.mMonth) + "." + pad(this.mDay));
            this.mTime = pad(this.mHour) + pad(this.mMinute);
            this.mTvTime.setTextColor(Color.parseColor("#000000"));
            this.mTvTime.setText(pad(this.mHour) + ":" + pad(this.mMinute));
        }
        int n = 0;
        if (!(this.mType == null || this.mType.trim().equals(""))) {
            this.insulinType.setCurrentItem(Integer.parseInt(this.mType));
            for (int i = 0; i < Integer.parseInt(this.mType); i++) {
                n += this.insulinNames[i].length;
            }
        }
        if (!(this.mName == null || this.mName.trim().equals(""))) {
            this.insulinName.setCurrentItem(Integer.parseInt(this.mName) - n);
        }
        if (this.mValue != null && !this.mValue.trim().equals("")) {
            this.mEditValue.setText(this.mValue);
        }
    }

    public void onClick(View v) {
        if (v.getId() == C0213R.id.insulin_btn_cancel) {
            finish();
        } else if (v.getId() == C0213R.id.insulin_btn_complete) {
            update();
        } else if (v.getId() == C0213R.id.insulin_tv_date) {
            showDatePicker();
        } else if (v.getId() == C0213R.id.insulin_tv_time) {
            showTimePicker();
        }
    }

    private void showDatePicker() {
        new DatePickerDialog(this, this.mDateSetListener, this.mYear, this.mMonth - 1, this.mDay).show();
    }

    private void showTimePicker() {
        new TimePickerDialog(this, this.mTimeSetListener, this.mHour, this.mMinute, false).show();
    }

    void inputAlert() {
        new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_type05), getString(C0213R.string.alert_text_confirm));
    }

    private void update() {
        if (this.mEditValue.getText().toString().trim().equals("")) {
            inputAlert();
            return;
        }
        this.sendProgressBar.post(new C03674());
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        int position_type = this.insulinType.getCurrentItem();
        int position_name = this.insulinName.getCurrentItem();
        this.mType = String.valueOf(position_type);
        int n = 0;
        for (int i = 0; i < position_type; i++) {
            n += this.insulinNames[i].length;
        }
        this.mName = String.valueOf(n + position_name);
        this.mValue = this.mEditValue.getText().toString().trim();
        this.position = getIntent().getIntExtra("position", -1);
        LogDM dm = new LogDM();
        dm.seq = this.data.seq;
        dm._id = this.data._id;
        dm.user_id = this.data.user_id;
        dm.update_flag = this.data.update_flag;
        dm.device_id = this.data.device_id;
        dm.input_date = this.data.input_date;
        dm.system_date = this.data.system_date;
        dm.category = this.data.category;
        dm.blood_sugar_type = this.data.blood_sugar_type;
        dm.blood_sugar_eat = this.data.blood_sugar_eat;
        dm.blood_sugar_value = this.data.blood_sugar_value;
        dm.insulin_type = this.data.insulin_type;
        dm.insulin_name = this.data.insulin_name;
        dm.insulin_value = this.data.insulin_value;
        dm.note_type = this.data.note_type;
        dm.note_content = this.data.note_content;
        dm.note_picture = this.data.note_picture;
        dm.note_picture_thumb = this.data.note_picture_thumb;
        dm.input_date = this.mDate + this.mTime + "00000";
        dm.insulin_name = this.mName;
        dm.insulin_type = this.mType;
        dm.insulin_value = this.mValue;
        dm.update_flag = "update";
        if (new DBAction(this.mContext).updateLog(dm)) {
            this.logCat.log(className, "modi", "ok");
            ModInsulinThrDM modInsulinThrDM = new ModInsulinThrDM();
            modInsulinThrDM.idate = new Util().getServerDateFormat(dm.input_date);
            modInsulinThrDM.itype = this.array_insulin_type_data[Integer.parseInt(dm.insulin_type)];
            modInsulinThrDM.iproduct = this.array_insulin_name_data[Integer.parseInt(dm.insulin_name)];
            modInsulinThrDM.ivalue = dm.insulin_value;
            modInsulinThrDM.manualinput = "YES";
            modInsulinThrDM.id = dm._id;
            setResult(-1);
            actionDefine(0, modInsulinThrDM);
            return;
        }
        this.logCat.log(className, "modi", "false");
        this.sendProgressBar.setVisibility(8);
    }

    private void actionDefine(int gubun, ModInsulinThrDM dm) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                finish();
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                finish();
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                finish();
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                finish();
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                finish();
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                finish();
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                finish();
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                finish();
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    new ThrModInsulin(getApplicationContext(), dm, this).start();
                    return;
                }
                return;
            default:
                return;
        }
    }

    private String pad(int c) {
        if (c < 10) {
            return "0" + String.valueOf(c);
        }
        return String.valueOf(c);
    }

    public void setWheelData() {
        r0 = new String[5][];
        r0[0] = new String[]{getInsulinName(C0213R.string.insulin_name_novorapid), getInsulinName(C0213R.string.insulin_name_apidra), getInsulinName(C0213R.string.insulin_name_humalog)};
        r0[1] = new String[]{getInsulinName(C0213R.string.insulin_name_humulin_r)};
        r0[2] = new String[]{getInsulinName(C0213R.string.insulin_name_novorin_r), getInsulinName(C0213R.string.insulin_name_insulatard)};
        r0[3] = new String[]{getInsulinName(C0213R.string.insulin_name_lantus), getInsulinName(C0213R.string.insulin_name_levemir)};
        r0[4] = new String[]{getInsulinName(C0213R.string.insulin_name_novomix_30), getInsulinName(C0213R.string.insulin_name_novomix_50), getInsulinName(C0213R.string.insulin_name_novomix_70), getInsulinName(C0213R.string.insulin_name_mixtard), getInsulinName(C0213R.string.insulin_name_humulin_30), getInsulinName(C0213R.string.insulin_name_humulin_70), getInsulinName(C0213R.string.insulin_name_humalogmix_25), getInsulinName(C0213R.string.insulin_name_humalogmix_50)};
        this.insulinNames = r0;
        this.mTypeAdapter = new WheelAdapter(this, this.type);
        this.insulinType = (WheelView) findViewById(C0213R.id.insulin_wheel_type);
        this.insulinType.setVisibleItems(3);
        this.insulinType.setViewAdapter(this.mTypeAdapter);
        this.insulinType.addChangingListener(new C03685());
        this.insulinType.addScrollingListener(new C03696());
        this.insulinName = (WheelView) findViewById(C0213R.id.insulin_wheel_name);
        this.insulinName.setVisibleItems(3);
        this.insulinType.setCurrentItem(1);
        this.insulinType.setCurrentItem(0);
    }

    private void updateType(int index) {
        this.insulinType.setColorPosition(index);
        this.insulinType.initResourcesIfNecessary();
        this.insulinName.setColorPosition(index);
        this.insulinName.initResourcesIfNecessary();
        this.mType = String.valueOf(index);
        this.mNameAdapter = new WheelAdapter(this, this.name[index]);
        this.insulinName.setViewAdapter(this.mNameAdapter);
        this.insulinName.setCurrentItem(0);
    }

    private String getInsulinName(int resId) {
        return getString(resId);
    }

    private void setEditTextPosition() {
        if (this.mEditValue != null) {
            String str = this.mEditValue.getText().toString();
            if (str != null && !str.trim().equals("")) {
                this.mEditValue.setSelection(str.length());
            }
        }
    }

    public void onModInsulin(Object obj) {
        this.logCat.log(className, "onModInsulin()", "in");
        ModInsulinReturnDM dm = (ModInsulinReturnDM) obj;
        if (!dm.statusResult.equals("ok")) {
            this.logCat.log(className, "onModInsulin()", "failed 2");
        } else if (!dm.code.equals("200")) {
            this.logCat.log(className, "onModInsulin()", "failed 1");
        } else if (dm.result.equals("0")) {
            if (new DBAction(this.mContext).executeQuery("update log set update_flag = null where system_date = '" + this.data.system_date + "'")) {
                this.logCat.log(className, "dbUpdate", "ok");
            } else {
                this.logCat.log(className, "dbUpdate", "failed");
            }
            finish();
        } else {
            this.logCat.log(className, "onModInsulin()", "failed 0");
        }
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
