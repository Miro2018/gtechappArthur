package com.accumed.gtech.input;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Images.Media;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.OnAddNoteListener;
import com.accumed.gtech.thread.ThrAddNote;
import com.accumed.gtech.thread.datamodel.AddNoteReturnDM;
import com.accumed.gtech.thread.datamodel.AddNoteThrDM;
import com.accumed.gtech.thread.datamodel.NotiThrDM;
import com.accumed.gtech.util.Anim;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.FileRename;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MakeSaveImgDir;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.util.Util;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.UUID;

@SuppressLint({"SdCardPath"})
public class InputComment extends Activity implements OnClickListener, OnAddNoteListener {
    static final int INPUT_NOTE = 0;
    static final int MAX_IMAGE_WIDTH = 1024;
    static final int MAX_THUMB_IMAGE_WIDTH = 120;
    private static final int PICK_FROM_ALBUM = 1;
    private static final int PICK_FROM_CAMERA = 3;
    private static final int VOICE_RECOGNITION_REQUEST_CODE = 3000;
    static final String className = "InputComment";
    static Bitmap photo;
    private String FRIEND_EMAIL;
    private String IMG_NAME = "temp.jpg";
    private Anim anim;
    boolean availableCaptureUri;
    private Uri captureUri;
    private LogDM data;
    private String imgPath = "";
    private String imgPullPath = "";
    ProgressBar inputProgressBar;
    private boolean isMe;
    LogCat logCat;
    int mAppStatus;
    private Button mBtnCancel;
    private Button mBtnComplete;
    Context mContext;
    private String mDate;
    private OnDateSetListener mDateSetListener = new C03252();
    private int mDay;
    private EditText mEditMemo;
    private int mHour;
    private ImageButton mIbtnAttach;
    private ImageButton mIbtnVoice;
    private ImageView mIvPicture;
    private LinearLayout mLLAttach;
    private LinearLayout mLLVoice;
    private String mMemo;
    private int mMinute;
    private int mMonth;
    private String mTime;
    private OnTimeSetListener mTimeSetListener = new C03263();
    private TextView mTvAttach;
    private TextView mTvDate;
    private TextView mTvTime;
    private TextView mTvVoice;
    private String mVoice;
    private int mYear;
    String memo = "";
    private LinearLayout noteLy0;
    String reUseImgName;
    String reUseThumbName;
    private ImageView removeImageIv;
    private ImageView rotateIv;
    private Uri thumbUri;
    Util util;

    class C03241 implements OnTouchListener {
        C03241() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) InputComment.this.getSystemService("input_method")).hideSoftInputFromWindow(InputComment.this.mEditMemo.getWindowToken(), 0);
            return false;
        }
    }

    class C03252 implements OnDateSetListener {
        C03252() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            InputComment.this.mYear = year;
            InputComment.this.mMonth = monthOfYear + 1;
            InputComment.this.mDay = dayOfMonth;
            InputComment.this.mDate = InputComment.this.pad(InputComment.this.mYear) + InputComment.this.pad(InputComment.this.mMonth) + InputComment.this.pad(InputComment.this.mDay);
            InputComment.this.mTvDate.setTextColor(Color.parseColor("#000000"));
            InputComment.this.mTvDate.setText(InputComment.this.pad(InputComment.this.mYear) + "." + InputComment.this.pad(InputComment.this.mMonth) + "." + InputComment.this.pad(InputComment.this.mDay));
        }
    }

    class C03263 implements OnTimeSetListener {
        C03263() {
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            InputComment.this.mHour = hourOfDay;
            InputComment.this.mMinute = minute;
            InputComment.this.mTime = InputComment.this.pad(InputComment.this.mHour) + InputComment.this.pad(InputComment.this.mMinute);
            InputComment.this.mTvTime.setTextColor(Color.parseColor("#000000"));
            InputComment.this.mTvTime.setText(InputComment.this.pad(InputComment.this.mHour) + ":" + InputComment.this.pad(InputComment.this.mMinute));
        }
    }

    class C03274 implements Runnable {
        C03274() {
        }

        public void run() {
            InputComment.this.inputProgressBar.setVisibility(8);
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onPause() {
        super.onPause();
        if (this.mEditMemo != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditMemo.getWindowToken(), 0);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.input_comment);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.util = new Util();
        this.anim = new Anim(this.mContext);
        try {
            this.FRIEND_EMAIL = getIntent().getStringExtra(PreferenceAction.FRIEND_EMAIL);
        } catch (Exception e) {
        }
        String myEmail = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_EMAIL);
        if (this.FRIEND_EMAIL == null || this.FRIEND_EMAIL.equals(myEmail)) {
            this.isMe = true;
        } else {
            this.isMe = false;
        }
        this.logCat.log(className, "isMe", new Boolean(this.isMe).toString());
        this.logCat.log(className, PreferenceAction.FRIEND_EMAIL, this.FRIEND_EMAIL);
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        MakeSaveImgDir makeSaveImgDir = new MakeSaveImgDir();
        init();
    }

    private void init() {
        this.noteLy0 = (LinearLayout) findViewById(C0213R.id.noteLy0);
        this.mBtnCancel = (Button) findViewById(C0213R.id.note_btn_cancel);
        this.mBtnComplete = (Button) findViewById(C0213R.id.note_btn_complete);
        this.mTvDate = (TextView) findViewById(C0213R.id.note_tv_date);
        this.mTvTime = (TextView) findViewById(C0213R.id.note_tv_time);
        this.mIvPicture = (ImageView) findViewById(C0213R.id.note_iv_picture);
        this.mEditMemo = (EditText) findViewById(C0213R.id.note_edit_memo);
        this.mLLVoice = (LinearLayout) findViewById(C0213R.id.note_ll_voice);
        this.mLLAttach = (LinearLayout) findViewById(C0213R.id.note_ll_attach_picture);
        this.mIbtnVoice = (ImageButton) findViewById(C0213R.id.note_ibtn_voice);
        this.mIbtnAttach = (ImageButton) findViewById(C0213R.id.note_ibtn_attach_picture);
        this.mTvVoice = (TextView) findViewById(C0213R.id.note_tv_voice);
        this.mTvAttach = (TextView) findViewById(C0213R.id.note_tv_attach_picture);
        this.rotateIv = (ImageView) findViewById(C0213R.id.rotateIv);
        this.removeImageIv = (ImageView) findViewById(C0213R.id.removeImageIv);
        this.inputProgressBar = (ProgressBar) findViewById(C0213R.id.inputProgressBar);
        this.inputProgressBar.setVisibility(8);
        this.mBtnCancel.setOnClickListener(this);
        this.mBtnComplete.setOnClickListener(this);
        this.mTvDate.setOnClickListener(this);
        this.mTvTime.setOnClickListener(this);
        this.mLLVoice.setOnClickListener(this);
        this.mLLAttach.setOnClickListener(this);
        this.mIbtnVoice.setClickable(false);
        this.mIbtnAttach.setClickable(false);
        this.mTvVoice.setClickable(false);
        this.mTvAttach.setClickable(false);
        this.rotateIv.setOnClickListener(this);
        this.removeImageIv.setOnClickListener(this);
        this.rotateIv.setVisibility(8);
        this.removeImageIv.setVisibility(8);
        this.noteLy0.setOnTouchListener(new C03241());
        setDefaultDate();
        setEditTextPosition();
    }

    private void setDefaultDate() {
        Calendar c = Calendar.getInstance();
        this.mYear = c.get(1);
        this.mMonth = c.get(2) + 1;
        this.mDay = c.get(5);
        this.mHour = c.get(10);
        this.mMinute = c.get(12);
        if (c.get(9) == 1) {
            this.mHour += 12;
        }
        this.mDate = pad(this.mYear) + pad(this.mMonth) + pad(this.mDay);
        this.mTvDate.setTextColor(Color.parseColor("#000000"));
        this.mTvDate.setText(pad(this.mYear) + "." + pad(this.mMonth) + "." + pad(this.mDay));
        this.mTime = pad(this.mHour) + pad(this.mMinute);
        this.mTvTime.setTextColor(Color.parseColor("#000000"));
        this.mTvTime.setText(pad(this.mHour) + ":" + pad(this.mMinute));
    }

    public void onClick(View v) {
        if (v.getId() == C0213R.id.note_btn_cancel) {
            delCaptureUriFile();
            finish();
        } else if (v.getId() == C0213R.id.note_btn_complete) {
            insert();
        } else if (v.getId() == C0213R.id.note_tv_date) {
            showDatePicker();
        } else if (v.getId() == C0213R.id.note_tv_time) {
            showTimePicker();
        } else if (v.getId() == C0213R.id.note_ll_voice) {
            showInputVoiceView();
        } else if (v.getId() == C0213R.id.note_ll_attach_picture) {
            showAttachView();
        } else if (v.getId() == C0213R.id.rotateIv) {
            photo = GetRotatedBitmap(photo, 90);
            saveBitmapToFileCache(photo, this.imgPullPath);
            this.captureUri = Uri.fromFile(new File(this.imgPullPath));
            this.mIvPicture.setImageBitmap(photo);
            this.anim.startAnim(this.mIvPicture, "in");
        } else if (v.getId() == C0213R.id.removeImageIv) {
            this.rotateIv.setVisibility(8);
            photo = null;
            delCaptureUriFile();
            this.mIvPicture.setImageBitmap(photo);
            this.removeImageIv.setVisibility(8);
            this.rotateIv.setVisibility(8);
        }
    }

    private void showDatePicker() {
        DatePickerDialog datePicker = new DatePickerDialog(this, this.mDateSetListener, this.mYear, this.mMonth - 1, this.mDay);
        datePicker.setButton(-1, getResources().getString(C0213R.string.btn_set), datePicker);
        datePicker.setButton(-2, getResources().getString(C0213R.string.btn_cancel), datePicker);
        datePicker.show();
    }

    private void showTimePicker() {
        TimePickerDialog timePicker = new TimePickerDialog(this, this.mTimeSetListener, this.mHour, this.mMinute, false);
        timePicker.setButton(-1, getResources().getString(C0213R.string.btn_set), timePicker);
        timePicker.setButton(-2, getResources().getString(C0213R.string.btn_cancel), timePicker);
        timePicker.show();
    }

    @SuppressLint({"SimpleDateFormat"})
    private void insert() {
        this.inputProgressBar.setVisibility(0);
        this.logCat.log(className, "friend_email--", this.FRIEND_EMAIL);
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        if (this.mEditMemo != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditMemo.getWindowToken(), 0);
        }
        this.mMemo = this.mEditMemo.getText().toString().trim();
        if (this.mDate == null || this.mTime == null || this.mDate.trim().equals("") || this.mTime.trim().equals("")) {
            this.inputProgressBar.setVisibility(8);
            return;
        }
        String system_date = new SimpleDateFormat("yyyyMMddHHmmss").format(Long.valueOf(System.currentTimeMillis()));
        this.data = new LogDM();
        this.data._id = "";
        this.data.input_date = this.mDate + this.mTime + "00000";
        this.data.system_date = system_date;
        this.data.category = LogDM.GLUCOSE_EAT_FASTING;
        this.data.note_content = this.mMemo;
        this.data.update_flag = "insert";
        this.logCat.log(className, "input_date data", this.data.input_date);
        PreferenceAction pref = new PreferenceAction(this, PreferenceAction.PREF_NAME_MY_PROFILE);
        if (this.isMe) {
            this.data.user_id = pref.getString(PreferenceAction.MY_EMAIL);
            this.data.targetemail = pref.getString(PreferenceAction.MY_EMAIL);
        } else {
            this.data.user_id = this.FRIEND_EMAIL;
            this.data.targetemail = pref.getString(PreferenceAction.MY_EMAIL);
        }
        ArrayList<LogDM> logDMList = new ArrayList();
        logDMList.add(this.data);
        if (!this.IMG_NAME.equals("temp.jpg")) {
            String thumb_imgName = "thumb_" + this.IMG_NAME;
            String thumb_imgPullPath = this.imgPath + "thumb/" + thumb_imgName;
            this.logCat.log(className, "thumb_imgPullPath", thumb_imgPullPath);
            photo = resizeBitmapImage(photo, MAX_THUMB_IMAGE_WIDTH);
            saveBitmapToFileCache(photo, thumb_imgPullPath);
            this.thumbUri = Uri.fromFile(new File(thumb_imgPullPath));
            this.data.note_picture_thumb = thumb_imgName;
        }
        this.data.note_picture = this.IMG_NAME;
        DBAction dbAction = new DBAction(this.mContext);
        AddNoteThrDM addNoteThrDM = new AddNoteThrDM();
        addNoteThrDM.ndate = new Util().getServerDateFormat(this.data.input_date);
        addNoteThrDM.ntype = "comment";
        addNoteThrDM.nvalue = this.data.note_content;
        addNoteThrDM.targetemail = this.data.targetemail;
        addNoteThrDM.email = this.data.user_id;
        if (!this.data.note_picture.equals("temp.jpg")) {
            addNoteThrDM.imgs = ClassConstant.DIR_IMG + this.data.note_picture;
            addNoteThrDM.thumb = ClassConstant.DIR_IMG_THUMB + this.data.note_picture_thumb;
            this.reUseImgName = this.data.note_picture;
            this.reUseThumbName = this.data.note_picture_thumb;
        }
        this.logCat.log(className, "email-- addNoteThrDM.email", addNoteThrDM.email);
        this.logCat.log(className, "email-- addNoteThrDM.targetemail", addNoteThrDM.targetemail);
        if (this.mAppStatus == 14 || this.mAppStatus == 5 || this.mAppStatus == 10 || this.mAppStatus == 1) {
            new ShowAlert(this).alert0(getString(C0213R.string.alert_title), getString(C0213R.string.alert_text_message), getString(C0213R.string.btn_ok));
            this.inputProgressBar.setVisibility(8);
            return;
        }
        this.logCat.log(className, "network none", "in");
        this.logCat.log(className, "ddd femail", this.FRIEND_EMAIL);
        this.logCat.log(className, "ddd user_id", this.data.targetemail);
        if (this.FRIEND_EMAIL == null || this.data.targetemail.equals(this.FRIEND_EMAIL)) {
            this.logCat.log(className, "is my", "ok");
            if (dbAction.insertLogList(logDMList)) {
                this.logCat.log(className, "comment input", "ok");
                photo = null;
                setResult(-1);
                actionDefine(0, addNoteThrDM);
                finish();
                return;
            }
            this.logCat.log(className, "inputComment input", "false");
            this.inputProgressBar.post(new C03274());
            return;
        }
        this.logCat.log(className, "is my", "no");
        setResult(-1);
        actionDefine(0, addNoteThrDM);
    }

    private String pad(int c) {
        if (c < 10) {
            return "0" + String.valueOf(c);
        }
        return String.valueOf(c);
    }

    private void showInputVoiceView() {
        startActivityForResult(new Intent(this, VoiceInputActivity.class), VOICE_RECOGNITION_REQUEST_CODE);
    }

    private void showAttachView() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        View view = View.inflate(this, C0213R.layout.item_picture, null);
        TextView mTvItem02 = (TextView) view.findViewById(C0213R.id.note_tv_album);
        ((TextView) view.findViewById(C0213R.id.note_tv_camera)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
                InputComment.this.doTakePhotoAction();
            }
        });
        mTvItem02.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
                InputComment.this.doTakeAlbumAction();
            }
        });
        dialog.setContentView(view);
        dialog.show();
    }

    private void doTakePhotoAction() {
        delCaptureUriFile();
        this.imgPullPath = doMakeUniqueFileName(Environment.getExternalStorageDirectory().getAbsolutePath() + "/data/com.gluconavii/", this.IMG_NAME);
        this.captureUri = Uri.fromFile(new File(this.imgPullPath));
        this.logCat.log(className, "captureUri", this.captureUri.toString());
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        intent.putExtra("output", this.captureUri);
        startActivityForResult(intent, 3);
    }

    private void doTakeAlbumAction() {
        delCaptureUriFile();
        Intent intent = new Intent("android.intent.action.PICK");
        intent.setType("vnd.android.cursor.dir/image");
        startActivityForResult(intent, 1);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != 0) {
            switch (requestCode) {
                case 1:
                    this.captureUri = data.getData();
                    try {
                        photo = Media.getBitmap(this.mContext.getContentResolver(), this.captureUri);
                        this.imgPullPath = doMakeUniqueFileName(Environment.getExternalStorageDirectory().getAbsolutePath() + "/data/com.gluconavii/", this.IMG_NAME);
                        saveBitmapToFileCache(photo, this.imgPullPath);
                        this.captureUri = Uri.fromFile(new File(this.imgPullPath));
                        photo = uriToBitmap(this.captureUri, 13);
                        this.removeImageIv.setVisibility(0);
                        this.rotateIv.setVisibility(0);
                        this.mIvPicture.setImageBitmap(photo);
                        return;
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                        photo = null;
                        return;
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        photo = null;
                        return;
                    }
                case 3:
                    if (this.captureUri == null) {
                        new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_try_again), getString(C0213R.string.alert_text_confirm));
                        return;
                    }
                    photo = uriToBitmap(this.captureUri, 3);
                    saveBitmapToFileCache(photo, this.imgPullPath);
                    this.captureUri = Uri.fromFile(new File(this.imgPullPath));
                    this.removeImageIv.setVisibility(0);
                    this.rotateIv.setVisibility(0);
                    this.mIvPicture.setImageBitmap(photo);
                    return;
                case VOICE_RECOGNITION_REQUEST_CODE /*3000*/:
                    this.mVoice = data.getStringExtra("searchKeyword");
                    this.mEditMemo.setText(this.mEditMemo.getText().toString().trim() + " " + this.mVoice);
                    setEditTextPosition();
                    return;
                default:
                    return;
            }
        }
    }

    private void setEditTextPosition() {
        if (this.mEditMemo != null) {
            String str = this.mEditMemo.getText().toString();
            if (str != null && !str.trim().equals("")) {
                this.mEditMemo.setSelection(str.length());
            }
        }
    }

    public synchronized Bitmap GetRotatedBitmap(Bitmap bitmap, int degrees) {
        if (!(degrees == 0 || bitmap == null)) {
            Matrix m = new Matrix();
            m.setRotate((float) degrees, ((float) bitmap.getWidth()) / PullToRefreshBase.DEFAULT_FRICTION, ((float) bitmap.getHeight()) / PullToRefreshBase.DEFAULT_FRICTION);
            try {
                Bitmap b2 = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
                if (bitmap != b2) {
                    bitmap.recycle();
                    bitmap = b2;
                }
            } catch (OutOfMemoryError e) {
            }
        }
        return bitmap;
    }

    boolean checkBitmapWidth(Uri uri, int ratio) {
        Options options = new Options();
        options.inJustDecodeBounds = true;
        options.inSampleSize = ratio;
        BitmapFactory.decodeFile(uri.getPath().toString(), options);
        if (options.outWidth > ClassConstant.INPUT_GLUCOSE_MGDL_MAX) {
            return false;
        }
        return true;
    }

    Bitmap uriToBitmap(Uri uri, int ratio) {
        Options options = new Options();
        options.inSampleSize = ratio;
        return BitmapFactory.decodeFile(uri.getPath().toString(), options);
    }

    public Bitmap resizeBitmapImage(Bitmap source, int maxResolution) {
        int width = source.getWidth();
        int height = source.getHeight();
        int newWidth = width;
        int newHeight = height;
        if (width > height) {
            if (maxResolution < width) {
                newHeight = (int) (((float) height) * (((float) maxResolution) / ((float) width)));
                newWidth = maxResolution;
            }
        } else if (maxResolution < height) {
            newWidth = (int) (((float) width) * (((float) maxResolution) / ((float) height)));
            newHeight = maxResolution;
        }
        return Bitmap.createScaledBitmap(source, newWidth, newHeight, true);
    }

    private void saveBitmapToFileCache(Bitmap bitmap, String strFilePath) {
        Exception e;
        Throwable th;
        this.logCat.log(className, "strFilePath", strFilePath);
        File fileCacheItem = new File(strFilePath);
        OutputStream out = null;
        try {
            fileCacheItem.createNewFile();
            OutputStream out2 = new FileOutputStream(fileCacheItem);
            try {
                bitmap.compress(CompressFormat.JPEG, 100, out2);
                try {
                    out2.close();
                    out = out2;
                } catch (IOException e2) {
                    e2.printStackTrace();
                    out = out2;
                }
            } catch (Exception e3) {
                e = e3;
                out = out2;
                try {
                    e.printStackTrace();
                    try {
                        out.close();
                    } catch (IOException e22) {
                        e22.printStackTrace();
                    }
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        out.close();
                    } catch (IOException e222) {
                        e222.printStackTrace();
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                out = out2;
                out.close();
                throw th;
            }
        } catch (Exception e4) {
            e = e4;
            e.printStackTrace();
            out.close();
        }
    }

    private void delCaptureUriFile() {
        File f;
        try {
            f = new File(this.captureUri.getPath().toString());
            if (f.exists()) {
                f.delete();
            }
        } catch (Exception e) {
        }
        try {
            f = new File(this.thumbUri.getPath().toString());
            if (f.exists()) {
                f.delete();
            }
        } catch (Exception e2) {
        }
    }

    private String doMakeUniqueFileName(String path, String fileName) {
        String extension = fileName.substring(fileName.lastIndexOf("."));
        String uniqueFileName = null;
        boolean flag = true;
        while (flag) {
            uniqueFileName = getUniqueFileName();
            this.IMG_NAME = uniqueFileName + extension;
            this.imgPath = path;
            flag = doCheckFileExists(path + uniqueFileName + extension);
        }
        return path + uniqueFileName + extension;
    }

    private static boolean doCheckFileExists(String fullPath) {
        return new File(fullPath).exists();
    }

    private static String getUniqueFileName() {
        return UUID.randomUUID().toString();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case 4:
                delCaptureUriFile();
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void actionDefine(int gubun, AddNoteThrDM addNoteThrDM) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                setResult(-1);
                finish();
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                setResult(-1);
                finish();
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                setResult(-1);
                finish();
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                setResult(-1);
                finish();
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                setResult(-1);
                finish();
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                setResult(-1);
                finish();
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                setResult(-1);
                finish();
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    new ThrAddNote(getApplicationContext(), addNoteThrDM, this).start();
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    new ThrAddNote(getApplicationContext(), addNoteThrDM, this).start();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void onAddNote(Object obj) {
        this.logCat.log(className, "onAddNote", "in");
        AddNoteReturnDM dm = (AddNoteReturnDM) obj;
        if (!dm.statusResult.equals("ok")) {
            this.logCat.log(className, "onAddNote()", "login failed 2");
        } else if (!dm.code.equals("200")) {
            this.logCat.log(className, "onAddNote()", "login failed 1");
        } else if (dm.result.equals("0")) {
            FileRename fileRename = new FileRename();
            if (fileRename.rename(ClassConstant.DIR_IMG, this.reUseImgName, dm.filename).booleanValue()) {
                this.logCat.log(className, "rename img", "ok");
            } else {
                this.logCat.log(className, "rename img", "no");
            }
            if (fileRename.rename(ClassConstant.DIR_IMG_THUMB, this.reUseThumbName, dm.thumbnail).booleanValue()) {
                this.logCat.log(className, "rename thumbimg", "ok");
            } else {
                this.logCat.log(className, "rename thumbimg", "no");
            }
            this.logCat.log(className, "onAddNote() id", dm.id);
            if (new DBAction(this.mContext).executeQuery("update log set _id= '" + dm.id + "', note_picture='" + dm.filename + "', note_picture_thumb= '" + dm.thumbnail + "', update_flag = null where system_date = '" + this.data.system_date + "'")) {
                this.logCat.log(className, "dbUpdate", "ok");
            } else {
                this.logCat.log(className, "dbUpdate", "failed");
            }
            setResult(-1);
            final PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            new Thread() {
                public void run() {
                    NotiThrDM nDM = new NotiThrDM();
                    nDM.email = InputComment.this.data.user_id;
                    nDM.targetemail = InputComment.this.data.targetemail;
                    InputComment.this.logCat.log(InputComment.className, "nDM.email", nDM.email);
                    InputComment.this.logCat.log(InputComment.className, "nDM.targetemail", nDM.targetemail);
                    nDM.gubun = InputComment.this.getString(C0213R.string.noti_comment);
                    nDM.gubun_num = LogDM.GLUCOSE_EAT_FASTING;
                    nDM.message = pref.getString(PreferenceAction.MY_NAME) + " " + nDM.gubun + " : " + InputComment.this.mEditMemo.getText().toString();
                    nDM.name = pref.getString(PreferenceAction.MY_NAME);
                    InputComment.this.logCat.log(InputComment.className, "result", new SDConnection(nDM).notiResult(InputComment.this.mContext, ClassConstant.SUBDIR_SUPORT_NOTI));
                }
            }.start();
            finish();
        } else {
            this.logCat.log(className, "onAddNote()", "login failed 0");
        }
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
