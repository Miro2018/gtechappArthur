package com.accumed.gtech.input;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Images.Media;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.OnModNoteListener;
import com.accumed.gtech.thread.ThrModNote;
import com.accumed.gtech.thread.datamodel.ModNoteReturnDM;
import com.accumed.gtech.thread.datamodel.ModNoteThrDM;
import com.accumed.gtech.util.Anim;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.FileRename;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.MakeSaveImgDir;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.util.Util;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.UUID;

@SuppressLint({"SdCardPath"})
public class ModifyNote extends Activity implements OnClickListener, OnModNoteListener {
    static final int MAX_IMAGE_WIDTH = 1024;
    static final int MAX_THUMB_IMAGE_WIDTH = 120;
    static final int MODIFY_NOTE = 0;
    private static final int PICK_FROM_ALBUM = 1;
    private static final int PICK_FROM_CAMERA = 3;
    private static final int VOICE_RECOGNITION_REQUEST_CODE = 3000;
    static final String className = "ModifyNote";
    private static int mIntType = -1;
    static Bitmap photo;
    private String IMG_NAME = "temp.jpg";
    private Anim anim;
    boolean availableCaptureUri;
    private Uri captureUri;
    private LogDM data;
    private String imgPath = "";
    private String imgPullPath = "";
    ProgressBar inputProgressBar;
    LogCat logCat;
    int mAppStatus;
    private Button mBtnCancel;
    private Button mBtnComplete;
    Context mContext;
    private String mDate;
    private OnDateSetListener mDateSetListener = new C03712();
    private int mDay;
    private EditText mEditMemo;
    private int mHour;
    private ImageButton mIbtnAttach;
    private ImageButton mIbtnEat;
    private ImageButton mIbtnNote;
    private ImageButton mIbtnSports;
    private ImageButton mIbtnVoice;
    private ImageView mIvPicture;
    private LinearLayout mLLAttach;
    private LinearLayout mLLEat;
    private LinearLayout mLLNote;
    private LinearLayout mLLSports;
    private LinearLayout mLLVoice;
    private String mMemo;
    private int mMinute;
    private int mMonth;
    private String mTime;
    private OnTimeSetListener mTimeSetListener = new C03723();
    private TextView mTvAttach;
    private TextView mTvDate;
    private TextView mTvEat;
    private TextView mTvNote;
    private TextView mTvSports;
    private TextView mTvTime;
    private TextView mTvVoice;
    private String mType;
    private String mVoice;
    private int mYear;
    String memo = "";
    private LinearLayout noteLy0;
    String reUseImgName;
    String reUseThumbName;
    private ImageView removeImageIv;
    private ImageView rotateIv;
    private Uri thumbUri;
    Util util;

    class C03701 implements OnTouchListener {
        C03701() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) ModifyNote.this.getSystemService("input_method")).hideSoftInputFromWindow(ModifyNote.this.mEditMemo.getWindowToken(), 0);
            return false;
        }
    }

    class C03712 implements OnDateSetListener {
        C03712() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            ModifyNote.this.mYear = year;
            ModifyNote.this.mMonth = monthOfYear + 1;
            ModifyNote.this.mDay = dayOfMonth;
            ModifyNote.this.mDate = ModifyNote.this.pad(ModifyNote.this.mYear) + ModifyNote.this.pad(ModifyNote.this.mMonth) + ModifyNote.this.pad(ModifyNote.this.mDay);
            ModifyNote.this.mTvDate.setTextColor(Color.parseColor("#000000"));
            ModifyNote.this.mTvDate.setText(ModifyNote.this.pad(ModifyNote.this.mYear) + "." + ModifyNote.this.pad(ModifyNote.this.mMonth) + "." + ModifyNote.this.pad(ModifyNote.this.mDay));
        }
    }

    class C03723 implements OnTimeSetListener {
        C03723() {
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            ModifyNote.this.mHour = hourOfDay;
            ModifyNote.this.mMinute = minute;
            ModifyNote.this.mTime = ModifyNote.this.pad(ModifyNote.this.mHour) + ModifyNote.this.pad(ModifyNote.this.mMinute);
            ModifyNote.this.mTvTime.setTextColor(Color.parseColor("#000000"));
            ModifyNote.this.mTvTime.setText(ModifyNote.this.pad(ModifyNote.this.mHour) + ":" + ModifyNote.this.pad(ModifyNote.this.mMinute));
        }
    }

    public void onDestroy() {
        super.onDestroy();
        mIntType = -1;
    }

    public void onPause() {
        super.onPause();
        if (this.mEditMemo != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditMemo.getWindowToken(), 0);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.modify_note);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.util = new Util();
        this.anim = new Anim(this.mContext);
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        this.data = (LogDM) getIntent().getSerializableExtra("MODIFY_NOTE_LOGDM");
        MakeSaveImgDir makeSaveImgDir = new MakeSaveImgDir();
        init();
    }

    private void init() {
        this.noteLy0 = (LinearLayout) findViewById(C0213R.id.noteLy0);
        this.mBtnCancel = (Button) findViewById(C0213R.id.note_btn_cancel);
        this.mBtnComplete = (Button) findViewById(C0213R.id.note_btn_complete);
        this.mTvDate = (TextView) findViewById(C0213R.id.note_tv_date);
        this.mTvTime = (TextView) findViewById(C0213R.id.note_tv_time);
        this.mIvPicture = (ImageView) findViewById(C0213R.id.note_iv_picture);
        this.mEditMemo = (EditText) findViewById(C0213R.id.note_edit_memo);
        this.mLLVoice = (LinearLayout) findViewById(C0213R.id.note_ll_voice);
        this.mLLAttach = (LinearLayout) findViewById(C0213R.id.note_ll_attach_picture);
        this.mLLEat = (LinearLayout) findViewById(C0213R.id.note_ll_eat);
        this.mLLSports = (LinearLayout) findViewById(C0213R.id.note_ll_sports);
        this.mLLNote = (LinearLayout) findViewById(C0213R.id.note_ll_note);
        this.mIbtnVoice = (ImageButton) findViewById(C0213R.id.note_ibtn_voice);
        this.mIbtnAttach = (ImageButton) findViewById(C0213R.id.note_ibtn_attach_picture);
        this.mIbtnEat = (ImageButton) findViewById(C0213R.id.note_ibtn_eat);
        this.mIbtnSports = (ImageButton) findViewById(C0213R.id.note_ibtn_sports);
        this.mIbtnNote = (ImageButton) findViewById(C0213R.id.note_ibtn_note);
        this.mTvVoice = (TextView) findViewById(C0213R.id.note_tv_voice);
        this.mTvAttach = (TextView) findViewById(C0213R.id.note_tv_attach_picture);
        this.mTvEat = (TextView) findViewById(C0213R.id.note_tv_eat);
        this.mTvSports = (TextView) findViewById(C0213R.id.note_tv_sports);
        this.mTvNote = (TextView) findViewById(C0213R.id.note_tv_note);
        this.rotateIv = (ImageView) findViewById(C0213R.id.rotateIv);
        this.removeImageIv = (ImageView) findViewById(C0213R.id.removeImageIv);
        this.inputProgressBar = (ProgressBar) findViewById(C0213R.id.inputProgressBar);
        this.inputProgressBar.setVisibility(8);
        this.mBtnCancel.setOnClickListener(this);
        this.mBtnComplete.setOnClickListener(this);
        this.mTvDate.setOnClickListener(this);
        this.mTvTime.setOnClickListener(this);
        this.mLLVoice.setOnClickListener(this);
        this.mLLAttach.setOnClickListener(this);
        this.mLLEat.setOnClickListener(this);
        this.mLLSports.setOnClickListener(this);
        this.mLLNote.setOnClickListener(this);
        this.mIbtnVoice.setClickable(false);
        this.mIbtnAttach.setClickable(false);
        this.mIbtnEat.setClickable(false);
        this.mIbtnSports.setClickable(false);
        this.mIbtnNote.setClickable(false);
        this.mTvVoice.setClickable(false);
        this.mTvAttach.setClickable(false);
        this.mTvEat.setClickable(false);
        this.mTvSports.setClickable(false);
        this.mTvNote.setClickable(false);
        this.rotateIv.setOnClickListener(this);
        this.removeImageIv.setOnClickListener(this);
        this.rotateIv.setVisibility(8);
        this.removeImageIv.setVisibility(8);
        this.noteLy0.setOnTouchListener(new C03701());
        setType(mIntType);
        setDefaultDate();
        setEditTextPosition();
    }

    private void setDefaultDate() {
        String strDate = this.data.input_date;
        if (!(strDate == null || strDate.trim().equals(""))) {
            strDate = conversionStrDateTimeFormat(strDate);
            this.mYear = Integer.parseInt(strDate.substring(0, 4));
            this.mMonth = Integer.parseInt(strDate.substring(4, 6));
            this.mDay = Integer.parseInt(strDate.substring(6, 8));
            this.mHour = Integer.parseInt(strDate.substring(8, 10));
            this.mMinute = Integer.parseInt(strDate.substring(10, 12));
            this.mDate = pad(this.mYear) + pad(this.mMonth) + pad(this.mDay);
            this.mTvDate.setTextColor(Color.parseColor("#000000"));
            this.mTvDate.setText(pad(this.mYear) + "." + pad(this.mMonth) + "." + pad(this.mDay));
            this.mTime = pad(this.mHour) + pad(this.mMinute);
            this.mTvTime.setTextColor(Color.parseColor("#000000"));
            this.mTvTime.setText(pad(this.mHour) + ":" + pad(this.mMinute));
        }
        this.mEditMemo.setText(this.data.note_content);
        setType(Integer.parseInt(this.data.note_type));
        this.logCat.log(className, "note_picture--", this.data.note_picture);
        this.logCat.log(className, "note_picture_thumb--", this.data.note_picture_thumb);
        try {
            if (this.data.note_picture.equals("") || this.data.note_picture.equals("temp.jpg") || this.data.note_picture.equals("null") || this.data.note_picture == null) {
                this.logCat.log(className, "gone", "in");
                this.rotateIv.setVisibility(8);
                this.removeImageIv.setVisibility(8);
                return;
            }
            this.removeImageIv.setVisibility(0);
            this.mIvPicture.setImageBitmap(Media.getBitmap(getContentResolver(), Uri.fromFile(new File(ClassConstant.DIR_IMG_THUMB + this.data.note_picture_thumb))));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public String conversionStrDateTimeFormat(String date) {
        if (date == null) {
            return null;
        }
        return date.replaceAll("-", "").replaceAll(":", "").replaceAll("\\.", "").replaceAll("\\p{Space}", "");
    }

    public void onClick(View v) {
        if (v.getId() == C0213R.id.note_btn_cancel) {
            delCaptureUriFile();
            finish();
        } else if (v.getId() == C0213R.id.note_btn_complete) {
            insert();
        } else if (v.getId() == C0213R.id.note_tv_date) {
            showDatePicker();
        } else if (v.getId() == C0213R.id.note_tv_time) {
            showTimePicker();
        } else if (v.getId() == C0213R.id.note_ll_eat) {
            setType(0);
        } else if (v.getId() == C0213R.id.note_ll_sports) {
            setType(1);
        } else if (v.getId() == C0213R.id.note_ll_note) {
            setType(2);
        } else if (v.getId() == C0213R.id.note_ll_voice) {
            showInputVoiceView();
        } else if (v.getId() == C0213R.id.note_ll_attach_picture) {
            showAttachView();
        } else if (v.getId() == C0213R.id.rotateIv) {
            this.logCat.log(className, "photo", "rotate in");
            photo = GetRotatedBitmap(photo, 90);
            saveBitmapToFileCache(photo, this.imgPullPath);
            this.captureUri = Uri.fromFile(new File(this.imgPullPath));
            this.mIvPicture.setImageBitmap(photo);
            this.anim.startAnim(this.mIvPicture, "in");
            this.logCat.log(className, "roatate imgPullPath", this.imgPullPath);
        } else if (v.getId() == C0213R.id.removeImageIv) {
            this.logCat.log(className, "delete IMG_NAME", this.IMG_NAME);
            if (this.IMG_NAME.equals("temp.jpg")) {
                new File(ClassConstant.DIR_IMG + this.data.note_picture).delete();
                new File(ClassConstant.DIR_IMG_THUMB + this.data.note_picture_thumb).delete();
            } else {
                new File(ClassConstant.DIR_IMG + this.IMG_NAME).delete();
                new File(ClassConstant.DIR_IMG_THUMB + this.IMG_NAME).delete();
            }
            this.data.note_picture = "";
            this.data.note_picture_thumb = "";
            this.rotateIv.setVisibility(8);
            photo = null;
            delCaptureUriFile();
            this.mIvPicture.setImageBitmap(photo);
            this.removeImageIv.setVisibility(8);
            this.rotateIv.setVisibility(8);
        }
    }

    private void showDatePicker() {
        new DatePickerDialog(this, this.mDateSetListener, this.mYear, this.mMonth - 1, this.mDay).show();
    }

    private void showTimePicker() {
        new TimePickerDialog(this, this.mTimeSetListener, this.mHour, this.mMinute, false).show();
    }

    private void setType(int type) {
        if (type == 0) {
            this.mLLEat.setBackgroundResource(C0213R.drawable.bg_type_on);
            this.mLLSports.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLNote.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 1) {
            this.mLLEat.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLSports.setBackgroundResource(C0213R.drawable.bg_type_on);
            this.mLLNote.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 2) {
            this.mLLEat.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLSports.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLNote.setBackgroundResource(C0213R.drawable.bg_type_on);
        } else {
            this.mLLEat.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLSports.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLNote.setBackgroundResource(C0213R.drawable.bg_type_off);
        }
        this.mType = Integer.toString(type);
    }

    @SuppressLint({"SimpleDateFormat"})
    private void insert() {
        this.inputProgressBar.setVisibility(0);
        LogDM dm = new LogDM();
        if (this.mEditMemo != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditMemo.getWindowToken(), 0);
        }
        this.mMemo = this.mEditMemo.getText().toString().trim();
        if (this.mDate == null || this.mTime == null || this.mDate.trim().equals("") || this.mTime.trim().equals("")) {
            new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_type04), getString(C0213R.string.alert_text_confirm));
            return;
        }
        dm.seq = this.data.seq;
        dm._id = this.data._id;
        dm.user_id = this.data.user_id;
        dm.update_flag = this.data.update_flag;
        dm.device_id = this.data.device_id;
        dm.input_date = this.data.input_date;
        dm.system_date = this.data.system_date;
        dm.category = this.data.category;
        dm.blood_sugar_type = this.data.blood_sugar_type;
        dm.blood_sugar_eat = this.data.blood_sugar_eat;
        dm.blood_sugar_value = this.data.blood_sugar_value;
        dm.insulin_type = this.data.insulin_type;
        dm.insulin_name = this.data.insulin_name;
        dm.insulin_value = this.data.insulin_value;
        dm.note_type = this.data.note_type;
        dm.note_content = this.data.note_content;
        dm.note_picture = this.data.note_picture;
        dm.note_picture_thumb = this.data.note_picture_thumb;
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss");
        dm.input_date = this.mDate + this.mTime + "00000";
        dm.note_content = this.mMemo;
        dm.note_type = this.mType;
        dm.update_flag = "update";
        if (!(this.IMG_NAME.equals("temp.jpg") || this.IMG_NAME.equals("") || this.IMG_NAME == null)) {
            this.logCat.log(className, "photo IMG_NAME ", this.IMG_NAME);
            if (photo != null) {
                this.logCat.log(className, "photo", "not null");
                String thumb_imgName = "thumb_" + this.IMG_NAME;
                String thumb_imgPullPath = this.imgPath + "thumb/" + thumb_imgName;
                this.logCat.log(className, "thumb_imgPullPath", thumb_imgPullPath);
                photo = resizeBitmapImage(photo, MAX_THUMB_IMAGE_WIDTH);
                saveBitmapToFileCache(photo, thumb_imgPullPath);
                this.thumbUri = Uri.fromFile(new File(thumb_imgPullPath));
                dm.note_picture_thumb = thumb_imgName;
                dm.note_picture = this.IMG_NAME;
            } else {
                this.logCat.log(className, "photo", "null");
                dm.note_picture_thumb = "";
                dm.note_picture = "";
            }
        }
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        ModNoteThrDM modNoteThrDM = new ModNoteThrDM();
        modNoteThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
        modNoteThrDM.id = dm._id;
        modNoteThrDM.ndate = new Util().getServerDateFormat(dm.input_date);
        modNoteThrDM.ntype = new Util().getServerNoteType(dm.note_type);
        modNoteThrDM.nvalue = dm.note_content;
        if (!(dm.note_picture.equals("temp.jpg") || dm.note_picture.equals("") || dm.note_picture.equals("null"))) {
            this.logCat.log(className, "photo", "in10");
            modNoteThrDM.imgs = ClassConstant.DIR_IMG + dm.note_picture;
            modNoteThrDM.thumb = ClassConstant.DIR_IMG_THUMB + dm.note_picture_thumb;
            this.reUseImgName = dm.note_picture;
            this.reUseThumbName = dm.note_picture_thumb;
        }
        this.logCat.log(className, "photo", "in11");
        this.logCat.log(className, "modNoteThrDM.imgs", modNoteThrDM.imgs);
        this.logCat.log(className, "modNoteThrDM.thumb", modNoteThrDM.thumb);
        if (new DBAction(this.mContext).updateLog(dm)) {
            this.logCat.log(className, "note update", "ok");
            photo = null;
            setResult(-1);
            actionDefine(0, modNoteThrDM);
            return;
        }
        this.logCat.log(className, "note update", "failed");
    }

    private String pad(int c) {
        if (c < 10) {
            return "0" + String.valueOf(c);
        }
        return String.valueOf(c);
    }

    private void showInputVoiceView() {
        startActivityForResult(new Intent(this, VoiceInputActivity.class), VOICE_RECOGNITION_REQUEST_CODE);
    }

    private void showAttachView() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        View view = View.inflate(this, C0213R.layout.item_picture, null);
        TextView mTvItem02 = (TextView) view.findViewById(C0213R.id.note_tv_album);
        ((TextView) view.findViewById(C0213R.id.note_tv_camera)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
                ModifyNote.this.doTakePhotoAction();
            }
        });
        mTvItem02.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
                ModifyNote.this.doTakeAlbumAction();
            }
        });
        dialog.setContentView(view);
        dialog.show();
    }

    private void doTakePhotoAction() {
        delCaptureUriFile();
        this.imgPullPath = doMakeUniqueFileName(Environment.getExternalStorageDirectory().getAbsolutePath() + "/data/com.gluconavii/", this.IMG_NAME);
        this.captureUri = Uri.fromFile(new File(this.imgPullPath));
        this.logCat.log(className, "captureUri", this.captureUri.toString());
        this.logCat.log(className, "IMG_NAME doTakePhotoAction()", this.IMG_NAME);
        Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
        intent.putExtra("output", this.captureUri);
        startActivityForResult(intent, 3);
    }

    private void doTakeAlbumAction() {
        delCaptureUriFile();
        Intent intent = new Intent("android.intent.action.PICK");
        intent.setType("vnd.android.cursor.dir/image");
        startActivityForResult(intent, 1);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != 0) {
            switch (requestCode) {
                case 1:
                    this.captureUri = data.getData();
                    try {
                        this.logCat.log(className, "photo", "PICK_FROM_ALBUM");
                        photo = Media.getBitmap(this.mContext.getContentResolver(), this.captureUri);
                        this.imgPullPath = doMakeUniqueFileName(Environment.getExternalStorageDirectory().getAbsolutePath() + "/data/com.gluconavii/", this.IMG_NAME);
                        saveBitmapToFileCache(photo, this.imgPullPath);
                        this.captureUri = Uri.fromFile(new File(this.imgPullPath));
                        photo = uriToBitmap(this.captureUri, 16);
                        this.removeImageIv.setVisibility(0);
                        this.rotateIv.setVisibility(0);
                        this.mIvPicture.setImageBitmap(photo);
                        return;
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                        photo = null;
                        return;
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        photo = null;
                        return;
                    }
                case 3:
                    if (this.captureUri == null) {
                        new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_try_again), getString(C0213R.string.alert_text_confirm));
                        return;
                    }
                    this.logCat.log(className, "photo", "PICK_FROM_CAMERA");
                    photo = uriToBitmap(this.captureUri, 3);
                    saveBitmapToFileCache(photo, this.imgPullPath);
                    this.captureUri = Uri.fromFile(new File(this.imgPullPath));
                    this.removeImageIv.setVisibility(0);
                    this.rotateIv.setVisibility(0);
                    this.mIvPicture.setImageBitmap(photo);
                    return;
                case VOICE_RECOGNITION_REQUEST_CODE /*3000*/:
                    this.mVoice = data.getStringExtra("searchKeyword");
                    this.mEditMemo.setText(this.mEditMemo.getText().toString().trim() + " " + this.mVoice);
                    setEditTextPosition();
                    return;
                default:
                    return;
            }
        }
    }

    private void setEditTextPosition() {
        if (this.mEditMemo != null) {
            String str = this.mEditMemo.getText().toString();
            if (str != null && !str.trim().equals("")) {
                this.mEditMemo.setSelection(str.length());
            }
        }
    }

    public synchronized Bitmap GetRotatedBitmap(Bitmap bitmap, int degrees) {
        if (!(degrees == 0 || bitmap == null)) {
            Matrix m = new Matrix();
            m.setRotate((float) degrees, ((float) bitmap.getWidth()) / PullToRefreshBase.DEFAULT_FRICTION, ((float) bitmap.getHeight()) / PullToRefreshBase.DEFAULT_FRICTION);
            try {
                Bitmap b2 = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
                if (bitmap != b2) {
                    bitmap.recycle();
                    bitmap = b2;
                }
            } catch (OutOfMemoryError e) {
            }
        }
        return bitmap;
    }

    public Bitmap uriToBitmap(Uri uri, int ratio) {
        Options options = new Options();
        options.inSampleSize = ratio;
        Bitmap bt = null;
        try {
            bt = BitmapFactory.decodeFile(uri.getPath().toString(), options);
        } catch (Exception e) {
            this.logCat.log(className, "bt", e.toString());
        }
        return bt;
    }

    public Bitmap resizeBitmapImage(Bitmap source, int maxResolution) {
        int width = source.getWidth();
        int height = source.getHeight();
        int newWidth = width;
        int newHeight = height;
        if (width > height) {
            if (maxResolution < width) {
                newHeight = (int) (((float) height) * (((float) maxResolution) / ((float) width)));
                newWidth = maxResolution;
            }
        } else if (maxResolution < height) {
            newWidth = (int) (((float) width) * (((float) maxResolution) / ((float) height)));
            newHeight = maxResolution;
        }
        return Bitmap.createScaledBitmap(source, newWidth, newHeight, true);
    }

    private void saveBitmapToFileCache(Bitmap bitmap, String strFilePath) {
        Exception e;
        Throwable th;
        this.logCat.log(className, "strFilePath", strFilePath);
        File fileCacheItem = new File(strFilePath);
        OutputStream out = null;
        try {
            fileCacheItem.createNewFile();
            OutputStream out2 = new FileOutputStream(fileCacheItem);
            try {
                bitmap.compress(CompressFormat.JPEG, 100, out2);
                try {
                    out2.close();
                    out = out2;
                } catch (IOException e2) {
                    e2.printStackTrace();
                    out = out2;
                }
            } catch (Exception e3) {
                e = e3;
                out = out2;
                try {
                    e.printStackTrace();
                    try {
                        out.close();
                    } catch (IOException e22) {
                        e22.printStackTrace();
                    }
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        out.close();
                    } catch (IOException e222) {
                        e222.printStackTrace();
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                out = out2;
                out.close();
                throw th;
            }
        } catch (Exception e4) {
            e = e4;
            e.printStackTrace();
            out.close();
        }
    }

    private void delCaptureUriFile() {
        File f;
        try {
            f = new File(this.captureUri.getPath().toString());
            if (f.exists()) {
                f.delete();
            }
        } catch (Exception e) {
        }
        try {
            f = new File(this.thumbUri.getPath().toString());
            if (f.exists()) {
                f.delete();
            }
        } catch (Exception e2) {
        }
    }

    private String doMakeUniqueFileName(String path, String fileName) {
        String extension = fileName.substring(fileName.lastIndexOf("."));
        String uniqueFileName = null;
        boolean flag = true;
        while (flag) {
            uniqueFileName = getUniqueFileName();
            this.IMG_NAME = uniqueFileName + extension;
            this.imgPath = path;
            flag = doCheckFileExists(path + uniqueFileName + extension);
        }
        return path + uniqueFileName + extension;
    }

    private static boolean doCheckFileExists(String fullPath) {
        return new File(fullPath).exists();
    }

    private static String getUniqueFileName() {
        return UUID.randomUUID().toString();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case 4:
                delCaptureUriFile();
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void actionDefine(int gubun, ModNoteThrDM modNoteThrDM) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                finish();
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                finish();
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                finish();
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                finish();
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                finish();
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                finish();
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                finish();
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                finish();
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    new ThrModNote(getApplicationContext(), modNoteThrDM, this).start();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void onModNote(Object obj) {
        this.logCat.log(className, "onModNote", "in");
        ModNoteReturnDM dm = (ModNoteReturnDM) obj;
        if (!dm.statusResult.equals("ok")) {
            this.logCat.log(className, "onModNote", "failed 2");
        } else if (!dm.code.equals("200")) {
            this.logCat.log(className, "onModNote", "failed 1");
        } else if (dm.result.equals("0")) {
            DBAction dbAction = new DBAction(this.mContext);
            this.logCat.log(className, "onModNote() img", dm.filename);
            this.logCat.log(className, "onModNote() img thumb", dm.thumbnail);
            FileRename fileRename = new FileRename();
            if (fileRename.rename(ClassConstant.DIR_IMG, this.reUseImgName, dm.filename).booleanValue()) {
                this.logCat.log(className, "rename img", "ok");
            } else {
                this.logCat.log(className, "rename img", "no");
            }
            if (fileRename.rename(ClassConstant.DIR_IMG_THUMB, this.reUseThumbName, dm.thumbnail).booleanValue()) {
                this.logCat.log(className, "rename thumbimg", "ok");
            } else {
                this.logCat.log(className, "rename thumbimg", "no");
            }
            String sql = "update log set update_flag = null, note_picture = '" + dm.filename + "', note_picture_thumb = '" + dm.thumbnail + "' where system_date = '" + this.data.system_date + "'";
            this.logCat.log(className, "sql", sql);
            if (dbAction.executeQuery(sql)) {
                this.logCat.log(className, "dbUpdate", "ok");
            } else {
                this.logCat.log(className, "dbUpdate", "failed");
            }
            finish();
        } else {
            this.logCat.log(className, "onModNote", "failed 0");
        }
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
