package com.accumed.gtech.input;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.DBStructure;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.httpconnection.SDConnection;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.OnAddGlucoseListener;
import com.accumed.gtech.thread.ThrAddGlucose;
import com.accumed.gtech.thread.datamodel.AddGlucoseReturnDM;
import com.accumed.gtech.thread.datamodel.AddGlucoseThrDM;
import com.accumed.gtech.thread.datamodel.NotiThrDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.util.Util;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class InputGlucose extends Activity implements OnClickListener, OnAddGlucoseListener {
    static final String className = "InputGlucose";
    final int GLUCOSE_INPUT = 0;
    private LinearLayout bloodLy0;
    String[] getBloodSugarUnitTypeArr;
    private ProgressBar inputProgressBar;
    LogCat logCat;
    LogDM logDM;
    int mAppStatus;
    private String mBloodSugar;
    private Button mBtnCancel;
    private Button mBtnComplete;
    Context mContext;
    private String mDate;
    private OnDateSetListener mDateSetListener = new C03311();
    private int mDay;
    private String mEat;
    private String mEat_origin;
    private EditText mEditBloodSugar;
    private int mHour;
    private ImageView mIbtnAfter;
    private ImageView mIbtnBefore;
    private ImageView mIbtnCs;
    private ImageView mIbtnFasting;
    private int mIntEat;
    private LinearLayout mLLAfter;
    private LinearLayout mLLBefore;
    private LinearLayout mLLCs;
    private LinearLayout mLLFasting;
    private int mMinute;
    private int mMonth;
    private String mTime;
    private OnTimeSetListener mTimeSetListener = new C03322();
    private TextView mTvAfter;
    private TextView mTvBefore;
    private TextView mTvCs;
    private TextView mTvDate;
    private TextView mTvFasting;
    private TextView mTvTime;
    private TextView mTvUnit;
    private int mYear;
    String mg_dl;
    String mmol_l;
    private String sugarUnit;
    UserProfileSettingData userProfileSettingData;
    Util util;

    class C03311 implements OnDateSetListener {
        C03311() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            InputGlucose.this.mYear = year;
            InputGlucose.this.mMonth = monthOfYear + 1;
            InputGlucose.this.mDay = dayOfMonth;
            InputGlucose.this.mDate = InputGlucose.this.pad(InputGlucose.this.mYear) + InputGlucose.this.pad(InputGlucose.this.mMonth) + InputGlucose.this.pad(InputGlucose.this.mDay);
            InputGlucose.this.mTvDate.setTextColor(Color.parseColor("#000000"));
            InputGlucose.this.mTvDate.setText(InputGlucose.this.pad(InputGlucose.this.mYear) + "." + InputGlucose.this.pad(InputGlucose.this.mMonth) + "." + InputGlucose.this.pad(InputGlucose.this.mDay));
        }
    }

    class C03322 implements OnTimeSetListener {
        C03322() {
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            InputGlucose.this.mHour = hourOfDay;
            InputGlucose.this.mMinute = minute;
            InputGlucose.this.mTime = InputGlucose.this.pad(InputGlucose.this.mHour) + InputGlucose.this.pad(InputGlucose.this.mMinute);
            InputGlucose.this.mTvTime.setTextColor(Color.parseColor("#000000"));
            InputGlucose.this.mTvTime.setText(InputGlucose.this.pad(InputGlucose.this.mHour) + ":" + InputGlucose.this.pad(InputGlucose.this.mMinute));
        }
    }

    class C03333 implements OnTouchListener {
        C03333() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) InputGlucose.this.getSystemService("input_method")).hideSoftInputFromWindow(InputGlucose.this.mEditBloodSugar.getWindowToken(), 0);
            return false;
        }
    }

    class C03344 implements Runnable {
        C03344() {
        }

        public void run() {
            InputGlucose.this.inputProgressBar.setVisibility(0);
        }
    }

    class C03355 implements Runnable {
        C03355() {
        }

        public void run() {
            InputGlucose.this.inputProgressBar.setVisibility(8);
        }
    }

    class C03366 implements Runnable {
        C03366() {
        }

        public void run() {
            InputGlucose.this.inputProgressBar.setVisibility(8);
        }
    }

    class C03377 implements Runnable {
        C03377() {
        }

        public void run() {
            InputGlucose.this.inputProgressBar.setVisibility(8);
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
        if (this.mEditBloodSugar != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditBloodSugar.getWindowToken(), 0);
        }
    }

    public void onCreate(Bundle savedInsetance) {
        super.onCreate(savedInsetance);
        setContentView(C0213R.layout.input_glucose);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.util = new Util();
        this.logDM = new LogDM();
        this.userProfileSettingData = new UserProfileSettingData(this.mContext);
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        init();
        this.getBloodSugarUnitTypeArr = getResources().getStringArray(C0213R.array.array_bloodsugar_unit_data);
        this.mg_dl = this.getBloodSugarUnitTypeArr[0];
        this.mmol_l = this.getBloodSugarUnitTypeArr[1];
    }

    private void init() {
        this.bloodLy0 = (LinearLayout) findViewById(C0213R.id.bloodLy0);
        this.mBtnCancel = (Button) findViewById(C0213R.id.blood_sugar_btn_cancel);
        this.mBtnComplete = (Button) findViewById(C0213R.id.blood_sugar_btn_complete);
        this.mTvDate = (TextView) findViewById(C0213R.id.blood_sugar_tv_date);
        this.mTvTime = (TextView) findViewById(C0213R.id.blood_sugar_tv_time);
        this.mEditBloodSugar = (EditText) findViewById(C0213R.id.blood_sugar_edit_value);
        this.mLLAfter = (LinearLayout) findViewById(C0213R.id.blood_sugar_ll_after);
        this.mLLBefore = (LinearLayout) findViewById(C0213R.id.blood_sugar_ll_before);
        this.mLLFasting = (LinearLayout) findViewById(C0213R.id.blood_sugar_ll_fasting);
        this.mLLCs = (LinearLayout) findViewById(C0213R.id.blood_sugar_ll_cs);
        this.mIbtnAfter = (ImageView) findViewById(C0213R.id.blood_sugar_ibtn_after);
        this.mIbtnBefore = (ImageView) findViewById(C0213R.id.blood_sugar_ibtn_before);
        this.mIbtnFasting = (ImageView) findViewById(C0213R.id.blood_sugar_ibtn_fasting);
        this.mIbtnCs = (ImageView) findViewById(C0213R.id.blood_sugar_ibtn_cs);
        this.mTvAfter = (TextView) findViewById(C0213R.id.blood_sugar_tv_after);
        this.mTvBefore = (TextView) findViewById(C0213R.id.blood_sugar_tv_before);
        this.mTvFasting = (TextView) findViewById(C0213R.id.blood_sugar_tv_fasting);
        this.mTvCs = (TextView) findViewById(C0213R.id.blood_sugar_tv_cs);
        this.mTvUnit = (TextView) findViewById(C0213R.id.blood_sugar_tv_unit);
        this.inputProgressBar = (ProgressBar) findViewById(C0213R.id.inputProgressBar);
        this.inputProgressBar.setVisibility(8);
        this.mBtnCancel.setOnClickListener(this);
        this.mBtnComplete.setOnClickListener(this);
        this.mTvDate.setOnClickListener(this);
        this.mTvTime.setOnClickListener(this);
        this.mLLAfter.setOnClickListener(this);
        this.mLLBefore.setOnClickListener(this);
        this.mLLFasting.setOnClickListener(this);
        this.mLLCs.setOnClickListener(this);
        this.mIbtnAfter.setClickable(false);
        this.mIbtnBefore.setClickable(false);
        this.mIbtnFasting.setClickable(false);
        this.mIbtnCs.setClickable(false);
        this.mTvAfter.setClickable(false);
        this.mTvBefore.setClickable(false);
        this.mTvFasting.setClickable(false);
        this.mTvCs.setClickable(false);
        this.bloodLy0.setOnTouchListener(new C03333());
        this.sugarUnit = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
        String[] getBloodSugarUnitTypeArr = getResources().getStringArray(C0213R.array.array_bloodsugar_unit_data);
        if (this.sugarUnit.equals(getBloodSugarUnitTypeArr[0])) {
            this.mTvUnit.setText(getBloodSugarUnitTypeArr[0]);
        } else if (this.sugarUnit.equals(getBloodSugarUnitTypeArr[1])) {
            this.mTvUnit.setText(getBloodSugarUnitTypeArr[1]);
        }
        setType(4);
        setDefaultDate();
        setEditTextPosition();
    }

    private void setDefaultDate() {
        Calendar c = Calendar.getInstance();
        this.mYear = c.get(1);
        this.mMonth = c.get(2) + 1;
        this.mDay = c.get(5);
        this.mHour = c.get(10);
        this.mMinute = c.get(12);
        if (c.get(9) == 1) {
            this.mHour += 12;
        }
        this.mDate = pad(this.mYear) + pad(this.mMonth) + pad(this.mDay);
        this.mTvDate.setTextColor(Color.parseColor("#000000"));
        this.mTvDate.setText(pad(this.mYear) + "." + pad(this.mMonth) + "." + pad(this.mDay));
        this.mTime = pad(this.mHour) + pad(this.mMinute);
        this.mTvTime.setTextColor(Color.parseColor("#000000"));
        this.mTvTime.setText(pad(this.mHour) + ":" + pad(this.mMinute));
    }

    public void onClick(View v) {
        if (v.getId() == C0213R.id.blood_sugar_btn_cancel) {
            finish();
        } else if (v.getId() == C0213R.id.blood_sugar_btn_complete) {
            input();
        } else if (v.getId() == C0213R.id.blood_sugar_tv_date) {
            showDatePicker();
        } else if (v.getId() == C0213R.id.blood_sugar_tv_time) {
            showTimePicker();
        } else if (v.getId() == C0213R.id.blood_sugar_ll_after) {
            setType(0);
        } else if (v.getId() == C0213R.id.blood_sugar_ll_before) {
            setType(1);
        } else if (v.getId() == C0213R.id.blood_sugar_ll_fasting) {
            setType(3);
        } else if (v.getId() == C0213R.id.blood_sugar_ll_cs) {
            setType(2);
        }
    }

    private void showDatePicker() {
        DatePickerDialog datePicker = new DatePickerDialog(this, this.mDateSetListener, this.mYear, this.mMonth - 1, this.mDay);
        datePicker.setButton(-1, getResources().getString(C0213R.string.btn_set), datePicker);
        datePicker.setButton(-2, getResources().getString(C0213R.string.btn_cancel), datePicker);
        datePicker.show();
    }

    private void showTimePicker() {
        TimePickerDialog timePicker = new TimePickerDialog(this, this.mTimeSetListener, this.mHour, this.mMinute, false);
        timePicker.setButton(-1, getResources().getString(C0213R.string.btn_set), timePicker);
        timePicker.setButton(-2, getResources().getString(C0213R.string.btn_cancel), timePicker);
        timePicker.show();
    }

    private void setType(int type) {
        if (this.mIntEat == type) {
            type = 4;
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 0) {
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_on);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 1) {
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_on);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 3) {
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_on);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 2) {
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_on);
        } else if (this.mIntEat == type) {
            type = 4;
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else {
            type = 4;
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        }
        this.mIntEat = type;
    }

    private void inputOverAlert(String msg) {
        new ShowAlert(this).alert0(getString(C0213R.string.alert_title), msg, getString(C0213R.string.btn_ok));
    }

    void inputAlert() {
        new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_type07), getString(C0213R.string.alert_text_confirm));
    }

    private void input() {
        this.mBloodSugar = this.mEditBloodSugar.getText().toString().trim();
        if (this.mBloodSugar == null || this.mBloodSugar.equals("")) {
            inputAlert();
            return;
        }
        this.inputProgressBar.post(new C03344());
        if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mg_dl)) {
            if (this.mBloodSugar.matches(".*\\..*")) {
                this.mBloodSugar = String.format("%d", new Object[]{Integer.valueOf((int) Float.parseFloat(this.mBloodSugar))});
            }
            if (Integer.parseInt(this.mBloodSugar) < 10 || Integer.parseInt(this.mBloodSugar) > ClassConstant.INPUT_GLUCOSE_MGDL_MAX) {
                inputOverAlert(getString(C0213R.string.message_text34));
                this.inputProgressBar.post(new C03355());
                return;
            }
        } else if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mmol_l) && (Float.parseFloat(this.mBloodSugar) < ClassConstant.INPUT_GLUCOSE_MMOL_MIN || Float.parseFloat(this.mBloodSugar) > ClassConstant.INPUT_GLUCOSE_MMOL_MAX)) {
            inputOverAlert(getString(C0213R.string.message_text35));
            this.inputProgressBar.post(new C03366());
            return;
        }
        this.mEat = String.valueOf(this.mIntEat);
        if (this.mEat.equals("0")) {
            this.mEat_origin = "32";
        } else if (this.mEat.equals("1")) {
            this.mEat_origin = "16";
        } else if (this.mEat.equals("2")) {
            this.mEat_origin = "2";
        } else if (this.mEat.equals(LogDM.GLUCOSE_EAT_FASTING)) {
            this.mEat_origin = "64";
        } else {
            this.mEat_origin = "0";
        }
        this.sugarUnit = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
        if (this.sugarUnit.equals(getResources().getStringArray(C0213R.array.array_bloodsugar_unit_data)[1])) {
            this.mBloodSugar = String.valueOf(Math.round(Double.valueOf(Double.parseDouble(String.format("%.0f", new Object[]{Double.valueOf(Double.parseDouble(this.mBloodSugar) * 18.01d)}))).doubleValue()));
        }
        this.logDM.system_date = new SimpleDateFormat("yyyyMMddHHmmss").format(Long.valueOf(System.currentTimeMillis()));
        this.logDM.category = "0";
        this.logDM.blood_sugar_type = "1";
        this.logDM.blood_sugar_eat = this.mEat;
        this.logDM.blood_sugar_eat_origin = this.mEat_origin;
        this.logDM.blood_sugar_value = this.mBloodSugar;
        this.logDM.update_flag = "insert";
        DBAction dbAction = new DBAction(this.mContext);
        String VVV;
        if (Integer.parseInt(this.mBloodSugar) < 100) {
            VVV = "0" + this.logDM.blood_sugar_value;
        } else {
            VVV = this.logDM.blood_sugar_value;
        }
        String EE;
        if (Integer.parseInt(this.mEat) < 10) {
            EE = "0" + this.logDM.blood_sugar_eat;
        } else {
            EE = this.logDM.blood_sugar_eat;
        }
        this.logDM.input_date = this.mDate + this.mTime + "00000";
        this.logCat.log_d(className, "NDEFTAGTest", "dbAction.getOneDeviceId @input()");
        this.logDM.device_id = dbAction.getOneDeviceId();
        ArrayList<LogDM> logDMList = new ArrayList();
        logDMList.add(this.logDM);
        PreferenceAction prefEmail = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        AddGlucoseThrDM addGlucoseDM = new AddGlucoseThrDM();
        addGlucoseDM.email = prefEmail.getString(PreferenceAction.MY_EMAIL);
        addGlucoseDM.deviceid = dbAction.getOneDeviceId();
        addGlucoseDM.gdate = new Util().getServerDateFormat(this.logDM.input_date);
        addGlucoseDM.gvalue = this.logDM.blood_sugar_value;
        addGlucoseDM.gevent = this.logDM.blood_sugar_eat;
        addGlucoseDM.gmodevent = this.logDM.blood_sugar_eat_origin;
        addGlucoseDM.gtempeature = "0";
        addGlucoseDM.manualinput = "YES";
        if (dbAction.insertLogList(logDMList)) {
            this.logCat.log(className, "inputGlucse input", "ok");
            setResult(-1);
            actionDefine(0, addGlucoseDM);
            return;
        }
        this.logCat.log(className, "inputGlucse input", "false");
        this.inputProgressBar.post(new C03377());
    }

    private String pad(int c) {
        if (c < 10) {
            return "0" + String.valueOf(c);
        }
        return String.valueOf(c);
    }

    private void setEditTextPosition() {
        if (this.mEditBloodSugar != null) {
            String str = this.mEditBloodSugar.getText().toString();
            if (str != null && !str.trim().equals("")) {
                this.mEditBloodSugar.setSelection(str.length());
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    private void actionDefine(int gubun, AddGlucoseThrDM addGlucoseDM) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    new ThrAddGlucose(this.mContext, addGlucoseDM, this).start();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void onAddGlucose(Object obj) {
        this.logCat.log(className, "onAddGlucose", "in");
        AddGlucoseReturnDM dm = (AddGlucoseReturnDM) obj;
        if (!dm.statusResult.equals("ok")) {
            this.logCat.log(className, "onAddGlucose", "failed 2");
        } else if (!dm.code.equals("200")) {
            this.logCat.log(className, "onAddGlucose", "failed 1");
        } else if (dm.result.equals("0")) {
            this.logCat.log(className, "onAddGlucose", "onAddGlucose");
            final PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            this.logCat.log(className, "onAddGlucose() id", dm.id);
            DBAction dbAction = new DBAction(this.mContext);
            this.logCat.log(className, "onAddGlucose() lastSeq", dbAction.getLastSeq(DBStructure.DB_TABLE_NAME_LOG, "insert") + "");
            if (dbAction.executeQuery("update log set user_id='" + pref.getString(PreferenceAction.MY_EMAIL) + "', _id= '" + dm.id + "', update_flag = null where system_date = '" + this.logDM.system_date + "'")) {
                this.logCat.log(className, "dbUpdate", "ok");
            } else {
                this.logCat.log(className, "dbUpdate", "failed");
            }
            new Thread() {
                public void run() {
                    NotiThrDM nDM = new NotiThrDM();
                    nDM.email = pref.getString(PreferenceAction.MY_EMAIL);
                    nDM.gubun = InputGlucose.this.getString(C0213R.string.noti_glucose);
                    nDM.gubun_num = "0";
                    nDM.message = pref.getString(PreferenceAction.MY_NAME) + " " + nDM.gubun + " : " + InputGlucose.this.mEditBloodSugar.getText().toString();
                    nDM.name = pref.getString(PreferenceAction.MY_NAME);
                    new SDConnection(nDM).notiResult(InputGlucose.this.mContext, ClassConstant.SUBDIR_SUPORT_NOTI);
                }
            }.start();
            finish();
        } else {
            this.logCat.log(className, "onAddGlucose", "failed 0");
        }
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
