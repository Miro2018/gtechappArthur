package com.accumed.gtech.input;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.OnModGlucoseListener;
import com.accumed.gtech.thread.ThrModGlucose;
import com.accumed.gtech.thread.datamodel.ModGlucoseDM;
import com.accumed.gtech.thread.datamodel.ModGlucoseReturnDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.accumed.gtech.util.Util;
import java.util.Calendar;
import java.util.Locale;

public class ModifyGlucose extends Activity implements OnClickListener, OnModGlucoseListener {
    static final int GLUCOSE_MODIFY = 0;
    static final String className = "ModifyGlucose";
    private LinearLayout bloodLy0;
    String[] getBloodSugarUnitTypeArr;
    LogCat logCat;
    private LogDM logDM;
    int mAppStatus = 0;
    private String mBloodSugar;
    private Button mBtnCancel;
    private Button mBtnComplete;
    Context mContext;
    private String mDate;
    private OnDateSetListener mDateSetListener = new C03611();
    private int mDay;
    private String mEat;
    private String mEat_origin;
    private EditText mEditBloodSugar;
    private int mHour;
    private ImageView mIbtnAfter;
    private ImageView mIbtnBefore;
    private ImageView mIbtnCs;
    private ImageView mIbtnFasting;
    private int mIntEat;
    private LinearLayout mLLAfter;
    private LinearLayout mLLBefore;
    private LinearLayout mLLCs;
    private LinearLayout mLLFasting;
    private int mMinute;
    private int mMonth;
    private String mTime;
    private OnTimeSetListener mTimeSetListener = new C03622();
    private TextView mTvAfter;
    private TextView mTvBefore;
    private TextView mTvCs;
    private TextView mTvDate;
    private TextView mTvFasting;
    private TextView mTvTime;
    private TextView mTvUnit;
    private int mYear;
    String mg_dl;
    String mmol_l;
    private ProgressBar sendProgressBar;
    UserProfileSettingData userProfileSettingData;
    Util util;

    class C03611 implements OnDateSetListener {
        C03611() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            ModifyGlucose.this.mYear = year;
            ModifyGlucose.this.mMonth = monthOfYear + 1;
            ModifyGlucose.this.mDay = dayOfMonth;
            ModifyGlucose.this.mDate = ModifyGlucose.this.pad(ModifyGlucose.this.mYear) + ModifyGlucose.this.pad(ModifyGlucose.this.mMonth) + ModifyGlucose.this.pad(ModifyGlucose.this.mDay);
            ModifyGlucose.this.mTvDate.setTextColor(Color.parseColor("#000000"));
            ModifyGlucose.this.mTvDate.setText(ModifyGlucose.this.pad(ModifyGlucose.this.mYear) + "." + ModifyGlucose.this.pad(ModifyGlucose.this.mMonth) + "." + ModifyGlucose.this.pad(ModifyGlucose.this.mDay));
        }
    }

    class C03622 implements OnTimeSetListener {
        C03622() {
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            ModifyGlucose.this.mHour = hourOfDay;
            ModifyGlucose.this.mMinute = minute;
            ModifyGlucose.this.mTime = ModifyGlucose.this.pad(ModifyGlucose.this.mHour) + ModifyGlucose.this.pad(ModifyGlucose.this.mMinute);
            ModifyGlucose.this.mTvTime.setTextColor(Color.parseColor("#000000"));
            ModifyGlucose.this.mTvTime.setText(ModifyGlucose.this.pad(ModifyGlucose.this.mHour) + ":" + ModifyGlucose.this.pad(ModifyGlucose.this.mMinute));
        }
    }

    class C03633 implements OnTouchListener {
        C03633() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) ModifyGlucose.this.getSystemService("input_method")).hideSoftInputFromWindow(ModifyGlucose.this.mEditBloodSugar.getWindowToken(), 0);
            return false;
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
        if (this.mEditBloodSugar != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditBloodSugar.getWindowToken(), 0);
        }
    }

    public void onCreate(Bundle savedInsetance) {
        super.onCreate(savedInsetance);
        setContentView(C0213R.layout.modify_glucose);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.userProfileSettingData = new UserProfileSettingData(this.mContext);
        this.util = new Util();
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        init();
        this.logDM = (LogDM) getIntent().getSerializableExtra("MODIFY_GLUCOSE_LOGDM");
        this.logCat.log(className, "---", this.logDM.seq);
        this.getBloodSugarUnitTypeArr = getResources().getStringArray(C0213R.array.array_bloodsugar_unit_data);
        this.mg_dl = this.getBloodSugarUnitTypeArr[0];
        this.mmol_l = this.getBloodSugarUnitTypeArr[1];
        getDataUiSet();
    }

    private void getDataUiSet() {
        Util util = new Util();
        String date = Util.conversionStrDateTimeFormat(this.logDM.input_date);
        this.mYear = Integer.parseInt(date.substring(0, 4));
        this.mMonth = Integer.parseInt(date.substring(4, 6));
        this.mDay = Integer.parseInt(date.substring(6, 8));
        this.mHour = Integer.parseInt(date.substring(8, 10));
        this.mMinute = Integer.parseInt(date.substring(10, 12));
        this.mDate = pad(this.mYear) + pad(this.mMonth) + pad(this.mDay);
        this.mTvDate.setTextColor(Color.parseColor("#000000"));
        this.mTvDate.setText(pad(this.mYear) + "." + pad(this.mMonth) + "." + pad(this.mDay));
        this.mTime = pad(this.mHour) + pad(this.mMinute);
        this.mTvTime.setTextColor(Color.parseColor("#000000"));
        this.mTvTime.setText(pad(this.mHour) + ":" + pad(this.mMinute));
        this.logCat.log(className, "userProfileSettingData.MY_BLOOD_SUGAR_UNIT", this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT);
        if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mg/dL")) {
            this.mEditBloodSugar.setText(this.logDM.blood_sugar_value);
        } else if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mmol/L")) {
            this.mEditBloodSugar.setText(util.mgdlToMmolL(this.logDM.blood_sugar_value));
        }
        if (this.logDM.blood_sugar_eat_origin.equals("") || this.logDM.blood_sugar_eat_origin == null) {
            if (this.logDM.blood_sugar_eat.equals("0")) {
                setType(0);
            } else if (this.logDM.blood_sugar_eat.equals("1")) {
                setType(1);
            } else if (this.logDM.blood_sugar_eat.equals("2")) {
                setType(2);
            } else if (this.logDM.blood_sugar_eat.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                setType(3);
            } else if (this.logDM.blood_sugar_eat.equals(LogDM.GLUCOSE_EAT_NONE)) {
                setType(4);
            }
        } else if (this.logDM.blood_sugar_eat_origin.equals("32")) {
            setType(0);
        } else if (this.logDM.blood_sugar_eat_origin.equals("16")) {
            setType(1);
        } else if (this.logDM.blood_sugar_eat_origin.equals("64")) {
            setType(3);
        } else if (this.logDM.blood_sugar_eat_origin.equals("2")) {
            setType(2);
        } else if (this.logDM.blood_sugar_eat_origin.equals("0")) {
            setType(4);
        }
    }

    private void init() {
        this.bloodLy0 = (LinearLayout) findViewById(C0213R.id.bloodLy0);
        this.mBtnCancel = (Button) findViewById(C0213R.id.blood_sugar_btn_cancel);
        this.mBtnComplete = (Button) findViewById(C0213R.id.blood_sugar_btn_complete);
        this.mTvDate = (TextView) findViewById(C0213R.id.blood_sugar_tv_date);
        this.mTvTime = (TextView) findViewById(C0213R.id.blood_sugar_tv_time);
        this.mEditBloodSugar = (EditText) findViewById(C0213R.id.blood_sugar_edit_value);
        this.mLLAfter = (LinearLayout) findViewById(C0213R.id.blood_sugar_ll_after);
        this.mLLBefore = (LinearLayout) findViewById(C0213R.id.blood_sugar_ll_before);
        this.mLLFasting = (LinearLayout) findViewById(C0213R.id.blood_sugar_ll_fasting);
        this.mLLCs = (LinearLayout) findViewById(C0213R.id.blood_sugar_ll_cs);
        this.mIbtnAfter = (ImageView) findViewById(C0213R.id.blood_sugar_ibtn_after);
        this.mIbtnBefore = (ImageView) findViewById(C0213R.id.blood_sugar_ibtn_before);
        this.mIbtnFasting = (ImageView) findViewById(C0213R.id.blood_sugar_ibtn_fasting);
        this.mIbtnCs = (ImageView) findViewById(C0213R.id.blood_sugar_ibtn_cs);
        this.mTvAfter = (TextView) findViewById(C0213R.id.blood_sugar_tv_after);
        this.mTvBefore = (TextView) findViewById(C0213R.id.blood_sugar_tv_before);
        this.mTvFasting = (TextView) findViewById(C0213R.id.blood_sugar_tv_fasting);
        this.mTvCs = (TextView) findViewById(C0213R.id.blood_sugar_tv_cs);
        this.mTvUnit = (TextView) findViewById(C0213R.id.blood_sugar_tv_unit);
        this.sendProgressBar = (ProgressBar) findViewById(C0213R.id.sendProgressBar);
        this.sendProgressBar.setVisibility(8);
        this.mBtnCancel.setOnClickListener(this);
        this.mBtnComplete.setOnClickListener(this);
        this.mTvDate.setOnClickListener(this);
        this.mTvTime.setOnClickListener(this);
        this.mLLAfter.setOnClickListener(this);
        this.mLLBefore.setOnClickListener(this);
        this.mLLFasting.setOnClickListener(this);
        this.mLLCs.setOnClickListener(this);
        this.mIbtnAfter.setClickable(false);
        this.mIbtnBefore.setClickable(false);
        this.mIbtnFasting.setClickable(false);
        this.mIbtnCs.setClickable(false);
        this.mTvAfter.setClickable(false);
        this.mTvBefore.setClickable(false);
        this.mTvFasting.setClickable(false);
        this.mTvCs.setClickable(false);
        this.bloodLy0.setOnTouchListener(new C03633());
        if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mg_dl)) {
            this.mTvUnit.setText(this.getBloodSugarUnitTypeArr[0]);
        } else if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mmol_l)) {
            this.mTvUnit.setText(this.getBloodSugarUnitTypeArr[1]);
        }
        setType(4);
        setDefaultDate();
        setEditTextPosition();
    }

    private void setDefaultDate() {
        Calendar c = Calendar.getInstance();
        this.mYear = c.get(1);
        this.mMonth = c.get(2) + 1;
        this.mDay = c.get(5);
        this.mHour = c.get(10);
        this.mMinute = c.get(12);
        if (c.get(9) == 1) {
            this.mHour += 12;
        }
        this.mDate = pad(this.mYear) + pad(this.mMonth) + pad(this.mDay);
        this.mTvDate.setTextColor(Color.parseColor("#000000"));
        this.mTvDate.setText(pad(this.mYear) + "." + pad(this.mMonth) + "." + pad(this.mDay));
        this.mTime = pad(this.mHour) + pad(this.mMinute);
        this.mTvTime.setTextColor(Color.parseColor("#000000"));
        this.mTvTime.setText(pad(this.mHour) + ":" + pad(this.mMinute));
    }

    public void onClick(View v) {
        if (v.getId() == C0213R.id.blood_sugar_btn_cancel) {
            finish();
        } else if (v.getId() == C0213R.id.blood_sugar_btn_complete) {
            input();
        } else if (v.getId() == C0213R.id.blood_sugar_tv_date) {
            showDatePicker();
        } else if (v.getId() == C0213R.id.blood_sugar_tv_time) {
            showTimePicker();
        } else if (v.getId() == C0213R.id.blood_sugar_ll_after) {
            setType(0);
        } else if (v.getId() == C0213R.id.blood_sugar_ll_before) {
            setType(1);
        } else if (v.getId() == C0213R.id.blood_sugar_ll_fasting) {
            setType(3);
        } else if (v.getId() == C0213R.id.blood_sugar_ll_cs) {
            setType(2);
        }
    }

    private void showDatePicker() {
        new DatePickerDialog(this, this.mDateSetListener, this.mYear, this.mMonth - 1, this.mDay).show();
    }

    private void showTimePicker() {
        new TimePickerDialog(this, this.mTimeSetListener, this.mHour, this.mMinute, false).show();
    }

    private void setType(int type) {
        if (this.mIntEat == type) {
            type = 4;
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 0) {
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_on);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 1) {
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_on);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 3) {
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_on);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else if (type == 2) {
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLFasting.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_on);
        } else if (this.mIntEat == type) {
            type = 4;
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        } else {
            type = 4;
            this.mLLAfter.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLBefore.setBackgroundResource(C0213R.drawable.bg_type_off);
            this.mLLCs.setBackgroundResource(C0213R.drawable.bg_type_off);
        }
        this.mIntEat = type;
    }

    private void inputOverAlert(String msg) {
        new ShowAlert(this).alert0(getString(C0213R.string.alert_title), msg, getString(C0213R.string.btn_ok));
    }

    void inputAlert() {
        new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.alert_type07), getString(C0213R.string.alert_text_confirm));
    }

    private void input() {
        this.mBloodSugar = this.mEditBloodSugar.getText().toString().trim();
        if (this.mBloodSugar.equals("")) {
            inputAlert();
            return;
        }
        this.sendProgressBar.setVisibility(0);
        LogDM dm = new LogDM();
        if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mg_dl)) {
            if (Integer.parseInt(this.mBloodSugar) <= 10 || Integer.parseInt(this.mBloodSugar) >= ClassConstant.INPUT_GLUCOSE_MGDL_MAX) {
                this.logCat.log(className, "modi", "mg_dl");
                inputOverAlert(getString(C0213R.string.message_text34));
                this.sendProgressBar.setVisibility(8);
                return;
            }
        } else if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mmol_l) && (((float) Integer.parseInt(this.util.mmolLToMgdl(this.mBloodSugar))) <= ClassConstant.INPUT_GLUCOSE_MMOL_MIN || ((float) Integer.parseInt(this.util.mmolLToMgdl(this.mBloodSugar))) >= ClassConstant.INPUT_GLUCOSE_MMOL_MAX)) {
            this.logCat.log(className, "modi", "mmol_l");
            inputOverAlert(getString(C0213R.string.message_text35));
            this.sendProgressBar.setVisibility(8);
            return;
        }
        this.mEat = String.valueOf(this.mIntEat);
        if (this.mEat.equals("0")) {
            this.mEat_origin = "32";
        } else if (this.mEat.equals("1")) {
            this.mEat_origin = "16";
        } else if (this.mEat.equals("2")) {
            this.mEat_origin = "2";
        } else if (this.mEat.equals(LogDM.GLUCOSE_EAT_FASTING)) {
            this.mEat_origin = "64";
        } else if (this.mEat.equals(LogDM.GLUCOSE_EAT_NONE)) {
            this.mEat_origin = "0";
        }
        if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals(this.mmol_l)) {
            this.mBloodSugar = this.util.mmolLToMgdl(this.mBloodSugar);
        }
        dm.seq = this.logDM.seq;
        dm._id = this.logDM._id;
        dm.user_id = this.logDM.user_id;
        dm.update_flag = this.logDM.update_flag;
        dm.device_id = this.logDM.device_id;
        dm.input_date = this.logDM.input_date;
        dm.system_date = this.logDM.system_date;
        dm.category = this.logDM.category;
        dm.blood_sugar_type = this.logDM.blood_sugar_type;
        dm.blood_sugar_eat = this.logDM.blood_sugar_eat;
        dm.blood_sugar_eat_origin = this.logDM.blood_sugar_eat_origin;
        dm.blood_sugar_value = this.logDM.blood_sugar_value;
        dm.insulin_type = this.logDM.insulin_type;
        dm.insulin_name = this.logDM.insulin_name;
        dm.insulin_value = this.logDM.insulin_value;
        dm.note_type = this.logDM.note_type;
        dm.note_content = this.logDM.note_content;
        dm.note_picture = this.logDM.note_picture;
        dm.note_picture_thumb = this.logDM.note_picture_thumb;
        dm.category = "0";
        dm.blood_sugar_type = "1";
        dm.blood_sugar_eat = this.mEat;
        dm.blood_sugar_eat_origin = this.mEat_origin;
        dm.blood_sugar_value = this.mBloodSugar;
        dm.update_flag = "update";
        String perfectDate = this.mDate + this.mTime + "00000";
        dm.input_date = perfectDate;
        this.logCat.log(className, "hey logDM.input_date", dm.input_date);
        this.logCat.log(className, "hey YYYYMMDDHHNN", perfectDate);
        DBAction dbAction = new DBAction(this.mContext);
        PreferenceAction prefEmail = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        ModGlucoseDM modGlucoseDM = new ModGlucoseDM();
        modGlucoseDM.email = prefEmail.getString(PreferenceAction.MY_EMAIL);
        modGlucoseDM.deviceid = dbAction.getOneDeviceId();
        modGlucoseDM.gdate = new Util().getServerDateFormat(dm.input_date);
        modGlucoseDM.gvalue = dm.blood_sugar_value;
        modGlucoseDM.gevent = dm.blood_sugar_eat;
        modGlucoseDM.gtempeature = "0";
        modGlucoseDM.manualinput = "YES";
        modGlucoseDM.gmodevent = dm.blood_sugar_eat_origin;
        modGlucoseDM.id = dm._id;
        this.logCat.log(className, "send email", modGlucoseDM.email);
        this.logCat.log(className, "send deviceid", modGlucoseDM.deviceid);
        this.logCat.log(className, "send gdate", modGlucoseDM.gdate);
        this.logCat.log(className, "send gvalue", modGlucoseDM.gvalue);
        this.logCat.log(className, "send gevent", modGlucoseDM.gevent);
        this.logCat.log(className, "send gtempeature", modGlucoseDM.gtempeature);
        this.logCat.log(className, "send manualinput", modGlucoseDM.manualinput);
        this.logCat.log(className, "send id", modGlucoseDM.id);
        if (dbAction.updateLog(dm)) {
            this.logCat.log(className, "modityGlucose input", "ok");
            this.sendProgressBar.setVisibility(8);
            setResult(-1);
            actionDefine(0, modGlucoseDM);
            return;
        }
        this.logCat.log(className, "modityGlucose input", "false");
        this.sendProgressBar.setVisibility(8);
    }

    private String getGoodDate(String dateStr) {
        return dateStr.replace(" ", "").replace("-", "").replace(":", "").replace(".", "").substring(0, 12) + Calendar.getInstance().get(14) + "00";
    }

    private String pad(int c) {
        if (c < 10) {
            return "0" + String.valueOf(c);
        }
        return String.valueOf(c);
    }

    private void setEditTextPosition() {
        if (this.mEditBloodSugar != null) {
            String str = this.mEditBloodSugar.getText().toString();
            if (str != null && !str.trim().equals("")) {
                this.mEditBloodSugar.setSelection(str.length());
            }
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    private void actionDefine(int gubun, ModGlucoseDM modGlucoseDM) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    finish();
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == 0) {
                    new ThrModGlucose(getApplicationContext(), modGlucoseDM, this).start();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void onModGlucose(Object obj) {
        this.logCat.log(className, "onModGlucose", "in");
        ModGlucoseReturnDM dm = (ModGlucoseReturnDM) obj;
        if (!dm.statusResult.equals("ok")) {
            this.logCat.log(className, "onModGlucose", "failed 2");
        } else if (!dm.code.equals("200")) {
            this.logCat.log(className, "onModGlucose", "failed 1");
        } else if (dm.result.equals("0")) {
            if (new DBAction(this.mContext).executeQuery("update log set update_flag = null where system_date='" + this.logDM.system_date + "'")) {
                this.logCat.log(className, "dbUpdate", "ok");
            } else {
                this.logCat.log(className, "dbUpdate", "failed");
            }
            finish();
        } else {
            this.logCat.log(className, "onModGlucose", "failed 0");
        }
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
