package com.accumed.gtech.settings;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.util.LanguageChange;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import java.util.Locale;

public class Setting extends Activity implements OnClickListener {
    static final String className = "Setting";
    private OnItemSelectedListener dateMethodSelectedListener = new C04622();
    private OnItemSelectedListener languageSelectedListener = new C04644();
    LogCat logCat = new LogCat();
    private Button mBtnClear;
    private Button mBtnComplete;
    private Button mBtnPrev;
    Context mContext;
    private int mDateMethod;
    private int mLanguage;
    private int mPeriod;
    private LinearLayout mSettingLocation;
    private LinearLayout mSettingServer;
    private Spinner mSpDateMethod;
    private Spinner mSpLanguage;
    private Spinner mSpLocation;
    private Spinner mSpPeriod;
    private Spinner mSpServer;
    private Spinner mSpTimeMethod;
    private int mTimeMethod;
    private OnItemSelectedListener periodSelectedListener = new C04655();
    private LinearLayout settingLy0;
    private OnItemSelectedListener timeMethodSelectedListener = new C04633();

    class C04611 implements OnTouchListener {
        C04611() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) Setting.this.getSystemService("input_method")).hideSoftInputFromWindow(Setting.this.mSpDateMethod.getWindowToken(), 0);
            return false;
        }
    }

    class C04622 implements OnItemSelectedListener {
        C04622() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            Setting.this.mDateMethod = position;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04633 implements OnItemSelectedListener {
        C04633() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            Setting.this.mTimeMethod = position;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04644 implements OnItemSelectedListener {
        C04644() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            Setting.this.mLanguage = position;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04655 implements OnItemSelectedListener {
        C04655() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            Setting.this.mPeriod = position;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04666 implements DialogInterface.OnClickListener {
        C04666() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Setting.this.setResult(-1);
            Setting.this.finish();
        }
    }

    class C04677 implements DialogInterface.OnClickListener {
        C04677() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.setting);
        this.mContext = getApplicationContext();
        init();
    }

    private void init() {
        this.settingLy0 = (LinearLayout) findViewById(C0213R.id.settingLy0);
        this.mBtnPrev = (Button) findViewById(C0213R.id.setting_btn_prev);
        this.mBtnPrev.setOnClickListener(this);
        this.mBtnComplete = (Button) findViewById(C0213R.id.setting_btn_complete);
        this.mBtnComplete.setOnClickListener(this);
        this.mBtnClear = (Button) findViewById(C0213R.id.setting_btn_clear);
        this.mBtnClear.setOnClickListener(this);
        this.mSpDateMethod = (Spinner) findViewById(C0213R.id.setting_sp_date_method);
        this.mSpTimeMethod = (Spinner) findViewById(C0213R.id.setting_sp_time_method);
        this.mSpLanguage = (Spinner) findViewById(C0213R.id.setting_sp_language);
        this.mSpPeriod = (Spinner) findViewById(C0213R.id.setting_sp_period);
        this.mSpLocation = (Spinner) findViewById(C0213R.id.setting_sp_location);
        this.mSpServer = (Spinner) findViewById(C0213R.id.setting_sp_server);
        this.mSettingLocation = (LinearLayout) findViewById(C0213R.id.setting_location);
        this.mSettingServer = (LinearLayout) findViewById(C0213R.id.setting_server);
        this.mSettingLocation.setVisibility(8);
        this.mSettingServer.setVisibility(8);
        String[] dateMethodArray = getResources().getStringArray(C0213R.array.array_date_method);
        String[] timeMethodArray = getResources().getStringArray(C0213R.array.array_time_method);
        String[] periodArray = getResources().getStringArray(C0213R.array.array_save_period);
        String[] locationArray = getResources().getStringArray(C0213R.array.array_location_select);
        String[] serverArray = getResources().getStringArray(C0213R.array.array_server_select);
        String[] languageArray = getResources().getStringArray(C0213R.array.array_language);
        String[] languageArrayData = getResources().getStringArray(C0213R.array.array_language_data);
        String sysLang = new LanguageChange(this.mContext).getSystemLanguage();
        this.logCat.log(className, "langPromptSelectNum sysLang", sysLang + "");
        int langPromptSelectNum = 0;
        for (int i = 0; i < languageArrayData.length; i++) {
            if (languageArrayData[i].equals(sysLang)) {
                langPromptSelectNum = i;
            }
        }
        this.logCat.log(className, "langPromptSelectNum", langPromptSelectNum + "");
        ArrayAdapter<String> dateMethodAdapter = new ArrayAdapter(this, 17367048, dateMethodArray);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter(this, 17367048, timeMethodArray);
        ArrayAdapter<String> languageAdapter = new ArrayAdapter(this, 17367048, languageArray);
        ArrayAdapter<String> periodAdapter = new ArrayAdapter(this, 17367048, periodArray);
        ArrayAdapter<String> locationAdapter = new ArrayAdapter(this, C0213R.layout.spinner_item, locationArray);
        arrayAdapter = new ArrayAdapter(this, C0213R.layout.spinner_item, serverArray);
        dateMethodAdapter.setDropDownViewResource(17367049);
        arrayAdapter.setDropDownViewResource(17367049);
        languageAdapter.setDropDownViewResource(17367049);
        periodAdapter.setDropDownViewResource(17367049);
        locationAdapter.setDropDownViewResource(17367049);
        arrayAdapter.setDropDownViewResource(17367049);
        this.mSpDateMethod.setAdapter(dateMethodAdapter);
        this.mSpTimeMethod.setAdapter(arrayAdapter);
        this.mSpLanguage.setAdapter(languageAdapter);
        this.mSpLanguage.setSelection(langPromptSelectNum);
        this.mSpPeriod.setAdapter(periodAdapter);
        this.mSpLocation.setAdapter(locationAdapter);
        this.mSpServer.setAdapter(arrayAdapter);
        this.mSpDateMethod.setPrompt(getString(C0213R.string.prompt_date_method));
        this.mSpTimeMethod.setPrompt(getString(C0213R.string.prompt_time_method));
        this.mSpLanguage.setPrompt(getString(C0213R.string.prompt_language));
        this.mSpPeriod.setPrompt(getString(C0213R.string.prompt_period));
        this.mSpLocation.setPrompt(getString(C0213R.string.prompt_location));
        this.mSpServer.setPrompt(getString(C0213R.string.prompt_server));
        this.mSpLocation.setEnabled(false);
        this.mSpServer.setEnabled(false);
        this.mSpDateMethod.setOnItemSelectedListener(this.dateMethodSelectedListener);
        this.mSpTimeMethod.setOnItemSelectedListener(this.timeMethodSelectedListener);
        this.mSpLanguage.setOnItemSelectedListener(this.languageSelectedListener);
        this.mSpPeriod.setOnItemSelectedListener(this.periodSelectedListener);
        PreferenceAction preferenceAction = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_LOCATION);
        preferenceAction = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_SERVER);
        if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_LOCATION) == 0) {
            this.mSpLocation.setSelection(0);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_LOCATION) == 1) {
            this.mSpLocation.setSelection(1);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_LOCATION) == 2) {
            this.mSpLocation.setSelection(2);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_LOCATION) == 3) {
            this.mSpLocation.setSelection(3);
        } else {
            this.mSpLocation.setSelection(4);
        }
        if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_SERVER) == 0) {
            this.mSpServer.setSelection(0);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_SERVER) == 1) {
            this.mSpServer.setSelection(1);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_SERVER) == 2) {
            this.mSpServer.setSelection(2);
        } else {
            this.mSpServer.setSelection(3);
        }
        this.settingLy0.setOnTouchListener(new C04611());
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0213R.id.setting_btn_prev:
                finish();
                return;
            case C0213R.id.setting_btn_complete:
                settingFinish();
                return;
            default:
                return;
        }
    }

    private void settingFinish() {
        String[] dateMethodArr = getResources().getStringArray(C0213R.array.array_date_method_data);
        String[] timeMethodArr = getResources().getStringArray(C0213R.array.array_time_method_data);
        String[] languageMethodArr = getResources().getStringArray(C0213R.array.array_language_data);
        int[] periodMethodArr = getResources().getIntArray(C0213R.array.array_save_period_data);
        String dateMethodValue = dateMethodArr[this.mDateMethod];
        String timeMethodValue = timeMethodArr[this.mTimeMethod];
        String laguageMethodValue = languageMethodArr[this.mLanguage];
        String periodMethodValue = Integer.toString(periodMethodArr[this.mPeriod]);
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        pref.putString(PreferenceAction.MY_DATE_METHOD, dateMethodValue);
        pref.putString(PreferenceAction.MY_TIME_METHOD, timeMethodValue);
        pref.putString(PreferenceAction.MY_LANGUAGE, laguageMethodValue);
        pref.putString(PreferenceAction.MY_DATA_SAVE_PERIOD, periodMethodValue);
        this.logCat.log(className, PreferenceAction.MY_DATE_METHOD, pref.getString(PreferenceAction.MY_DATE_METHOD));
        this.logCat.log(className, PreferenceAction.MY_TIME_METHOD, pref.getString(PreferenceAction.MY_TIME_METHOD));
        this.logCat.log(className, PreferenceAction.MY_LANGUAGE, pref.getString(PreferenceAction.MY_LANGUAGE));
        this.logCat.log(className, PreferenceAction.MY_DATA_SAVE_PERIOD, pref.getString(PreferenceAction.MY_DATA_SAVE_PERIOD));
        Locale locale = new Locale(laguageMethodValue);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        Intent intent = new Intent(this, ContainerFragmentActivity.class);
        intent.setFlags(67108864);
        intent.putExtra(ClassConstant.LOCALE_ALTER, ClassConstant.LOCALE_ALTER);
        startActivity(intent);
        pakageRestart();
    }

    public void onBackPressed() {
        this.logCat.log(className, "onBackPressed", "in");
        new Builder(this).setTitle(getString(C0213R.string.alert_text_title)).setMessage(getString(C0213R.string.alert_text_finish)).setNegativeButton(getString(C0213R.string.alert_text_cancel), new C04677()).setPositiveButton(getString(C0213R.string.alert_text_confirm), new C04666()).show();
    }

    void pakageRestart() {
        ContainerFragmentActivity.containerFragmentActivity.finish();
        startActivity(new Intent(this, ContainerFragmentActivity.class));
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
