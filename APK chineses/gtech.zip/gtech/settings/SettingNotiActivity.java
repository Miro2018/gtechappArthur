package com.accumed.gtech.settings;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Switch;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import java.util.Locale;

public class SettingNotiActivity extends Activity {
    static final String className = "SettingNotiActivity";
    LogCat logControl;
    Context mContext;
    Button settingNotiBtnPrev;
    Switch switchNone;
    Switch switchPopupMessage;
    Switch switchSound;
    Switch switchVibration;

    class C04775 implements OnClickListener {
        C04775() {
        }

        public void onClick(View arg0) {
            SettingNotiActivity.this.finish();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0213R.layout.setting_noti);
        this.mContext = getApplicationContext();
        this.logControl = new LogCat();
        this.switchSound = (Switch) findViewById(C0213R.id.switchSound);
        this.switchVibration = (Switch) findViewById(C0213R.id.switchVibration);
        this.switchPopupMessage = (Switch) findViewById(C0213R.id.switchPopupMessage);
        this.switchNone = (Switch) findViewById(C0213R.id.switchNone);
        this.settingNotiBtnPrev = (Button) findViewById(C0213R.id.settingNotiBtnPrev);
        final PreferenceAction pref = new PreferenceAction(getApplicationContext(), PreferenceAction.PREF_NAME_NOTIFICATION_IS_USE);
        String notiDefaultSettng = pref.getString(PreferenceAction.NOTIFICATION_IS_DEFAULT_SETTING);
        if (notiDefaultSettng.equals("no")) {
            this.logControl.log(className, "notiDefaultSettng", "NO");
            pref.putString(PreferenceAction.NOTIFICATION_IS_DEFAULT_SETTING, "yes");
            pref.putString(PreferenceAction.NOTIFICATION_IS_USE_SOUND, "yes");
            pref.putString(PreferenceAction.NOTIFICATION_IS_USE_VIBRATION, "yes");
            pref.putString(PreferenceAction.NOTIFICATION_POPUPMESSAGE_IS_USE, "yes");
            pref.putString(PreferenceAction.NOTIFICATION_IS_USE_NONE, "yes");
            this.switchSound.setChecked(true);
            this.switchVibration.setChecked(true);
            this.switchPopupMessage.setChecked(true);
            this.switchNone.setChecked(false);
        } else if (notiDefaultSettng.equals("yes") || notiDefaultSettng.equals("") || notiDefaultSettng == null) {
            this.logControl.log(className, "notiDefaultSettng", "yes");
            String useSound = pref.getString(PreferenceAction.NOTIFICATION_IS_USE_SOUND);
            String useVibration = pref.getString(PreferenceAction.NOTIFICATION_IS_USE_VIBRATION);
            String usePopupMessage = pref.getString(PreferenceAction.NOTIFICATION_POPUPMESSAGE_IS_USE);
            String useNone = pref.getString(PreferenceAction.NOTIFICATION_IS_USE_NONE);
            this.logControl.log(className, "notiDefaultSettng useSound", useSound);
            this.logControl.log(className, "notiDefaultSettng useVibration", useVibration);
            this.logControl.log(className, "notiDefaultSettng useNone", useNone);
            if (useSound.equals("no")) {
                this.switchSound.setChecked(false);
            } else if (useSound.equals("yes") || useSound.equals("") || useSound == null) {
                this.switchSound.setChecked(true);
            }
            if (useVibration.equals("no")) {
                this.switchVibration.setChecked(false);
            } else if (useVibration.equals("yes") || useVibration.equals("") || useVibration == null) {
                this.switchVibration.setChecked(true);
            }
            if (usePopupMessage.equals("no")) {
                this.switchPopupMessage.setChecked(false);
            } else if (usePopupMessage == null || usePopupMessage.equals("")) {
                this.switchPopupMessage.setChecked(false);
            } else if (usePopupMessage.equals("yes")) {
                this.switchPopupMessage.setChecked(true);
            }
            if (useNone.equals("no")) {
                this.switchNone.setChecked(true);
            } else if (useNone.equals("yes") || useNone.equals("") || useNone == null) {
                this.switchNone.setChecked(false);
            }
        }
        this.switchSound.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                if (arg1) {
                    pref.putString(PreferenceAction.NOTIFICATION_IS_USE_SOUND, "yes");
                    pref.putString(PreferenceAction.NOTIFICATION_IS_USE_NONE, "yes");
                    SettingNotiActivity.this.switchNone.setChecked(false);
                    return;
                }
                pref.putString(PreferenceAction.NOTIFICATION_IS_USE_SOUND, "no");
            }
        });
        this.switchVibration.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                if (arg1) {
                    pref.putString(PreferenceAction.NOTIFICATION_IS_USE_VIBRATION, "yes");
                    pref.putString(PreferenceAction.NOTIFICATION_IS_USE_NONE, "yes");
                    SettingNotiActivity.this.switchNone.setChecked(false);
                    return;
                }
                pref.putString(PreferenceAction.NOTIFICATION_IS_USE_VIBRATION, "no");
            }
        });
        this.switchPopupMessage.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                if (arg1) {
                    pref.putString(PreferenceAction.NOTIFICATION_POPUPMESSAGE_IS_USE, "yes");
                    pref.putString(PreferenceAction.NOTIFICATION_IS_USE_NONE, "yes");
                    SettingNotiActivity.this.switchNone.setChecked(false);
                    return;
                }
                pref.putString(PreferenceAction.NOTIFICATION_POPUPMESSAGE_IS_USE, "no");
            }
        });
        this.switchNone.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
                if (arg1) {
                    pref.putString(PreferenceAction.NOTIFICATION_IS_USE_NONE, "no");
                    SettingNotiActivity.this.switchSound.setChecked(false);
                    SettingNotiActivity.this.switchVibration.setChecked(false);
                    SettingNotiActivity.this.switchPopupMessage.setChecked(false);
                    return;
                }
                pref.putString(PreferenceAction.NOTIFICATION_IS_USE_NONE, "yes");
            }
        });
        this.settingNotiBtnPrev.setOnClickListener(new C04775());
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
