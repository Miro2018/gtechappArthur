package com.accumed.gtech.settings;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.intro.ChangePassword;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.OnModUserListener;
import com.accumed.gtech.thread.ThrModUser;
import com.accumed.gtech.thread.datamodel.ModUserThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.Util;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ProfileModify extends Activity implements OnClickListener, OnCheckedChangeListener, OnFocusChangeListener, OnModUserListener {
    static int MODIFY_PROFILE = 0;
    static final String className = "ProfileActivity";
    private OnDateSetListener birthdayPickerListener = new C04565();
    private OnItemSelectedListener bodyUnitSelectedListener = new C04587();
    private OnItemSelectedListener bsTypeSelectedListener = new C04598();
    private OnItemSelectedListener bsUnitSelectedListener = new C04609();
    ProgressBar btProgressBar;
    private OnTouchListener focusTouchListener = new C04543();
    LogCat logCat;
    int mAppStatus;
    private int mBirthDate;
    private String mBirthDay;
    private int mBirthMonth;
    private int mBirthYear;
    private String mBloodSugarHigh;
    private String mBloodSugarLow;
    private String mBloodSugarType;
    private int mBloodSugarUnit;
    private int mBodyUnit;
    private Button mBtnNext;
    Context mContext;
    private EditText mEdit;
    private EditText mEditBloodSugarHigh;
    private EditText mEditBloodSugarLow;
    private EditText mEditHeight;
    private EditText mEditName;
    private EditText mEditWeight;
    private String mGender;
    private String mGenderValue;
    private String mHeight;
    private String mName;
    private int mOccurDate;
    private String mOccurDay;
    private int mOccurMonth;
    private int mOccurYear;
    private RadioButton mRbtnFemale;
    private RadioButton mRbtnMale;
    private Spinner mSpBloodSugarType;
    private Spinner mSpBloodSugarUnit;
    private Spinner mSpBodyUnit;
    private TextView mTvBirthDay;
    private TextView mTvOccurDay;
    private TextView mTvUnit_BloodSugar01;
    private TextView mTvUnit_BloodSugar02;
    private TextView mTvUnit_Height;
    private TextView mTvUnit_Weight;
    private String mWeight;
    private OnDateSetListener occurdayPickerListener = new C04576();
    PreferenceAction pref;
    private LinearLayout profileLy0;
    private TextView profile_tv_email_value;
    TextView profile_tv_password_value;
    private Util util;

    class C04521 implements OnClickListener {
        C04521() {
        }

        public void onClick(View arg0) {
            if (ProfileModify.this.profile_tv_password_value.getText() != null && !ProfileModify.this.profile_tv_password_value.getText().toString().equals("")) {
                ProfileModify.this.startActivity(new Intent(ProfileModify.this, ChangePassword.class));
            }
        }
    }

    class C04532 implements OnTouchListener {
        C04532() {
        }

        public boolean onTouch(View arg0, MotionEvent arg1) {
            ((InputMethodManager) ProfileModify.this.getSystemService("input_method")).hideSoftInputFromWindow(ProfileModify.this.mEditName.getWindowToken(), 0);
            return false;
        }
    }

    class C04543 implements OnTouchListener {
        C04543() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == 0) {
                ((EditText) v).setCursorVisible(true);
                ((EditText) v).setSelectAllOnFocus(true);
            }
            return false;
        }
    }

    class C04565 implements OnDateSetListener {
        C04565() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            ProfileModify.this.mBirthYear = year;
            ProfileModify.this.mBirthMonth = monthOfYear + 1;
            ProfileModify.this.mBirthDate = dayOfMonth;
            ProfileModify.this.mBirthDay = ProfileModify.this.convertDateValue(ProfileModify.this.mBirthYear) + ProfileModify.this.convertDateValue(ProfileModify.this.mBirthMonth) + ProfileModify.this.convertDateValue(ProfileModify.this.mBirthDate);
            ProfileModify.this.mTvBirthDay.setText(ProfileModify.this.convertDateValue(ProfileModify.this.mBirthYear) + "." + ProfileModify.this.convertDateValue(ProfileModify.this.mBirthMonth) + "." + ProfileModify.this.convertDateValue(ProfileModify.this.mBirthDate));
            ProfileModify.this.setCursorOff();
        }
    }

    class C04576 implements OnDateSetListener {
        C04576() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            ProfileModify.this.mOccurYear = year;
            ProfileModify.this.mOccurMonth = monthOfYear + 1;
            ProfileModify.this.mOccurDate = dayOfMonth;
            ProfileModify.this.mOccurDay = ProfileModify.this.convertDateValue(ProfileModify.this.mOccurYear) + ProfileModify.this.convertDateValue(ProfileModify.this.mOccurMonth) + ProfileModify.this.convertDateValue(ProfileModify.this.mOccurDate);
            ProfileModify.this.mTvOccurDay.setText(ProfileModify.this.convertDateValue(ProfileModify.this.mOccurYear) + "." + ProfileModify.this.convertDateValue(ProfileModify.this.mOccurMonth) + "." + ProfileModify.this.convertDateValue(ProfileModify.this.mOccurDate));
            ProfileModify.this.setCursorOff();
        }
    }

    class C04587 implements OnItemSelectedListener {
        C04587() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            ProfileModify.this.logCat.log(ProfileModify.className, "mBodyUnit--position", ProfileModify.this.mBodyUnit + "/" + position);
            if (ProfileModify.this.mBodyUnit != position) {
                ProfileModify.this.setCalValue2(position);
            }
            if (position == 0) {
                ProfileModify.this.mTvUnit_Weight.setText(ProfileModify.this.getString(C0213R.string.unit_weight_ko));
                ProfileModify.this.mTvUnit_Height.setText(ProfileModify.this.getString(C0213R.string.unit_height_ko));
            } else if (position == 1) {
                ProfileModify.this.mTvUnit_Weight.setText(ProfileModify.this.getString(C0213R.string.unit_weight_en));
                ProfileModify.this.mTvUnit_Height.setText(ProfileModify.this.getString(C0213R.string.unit_height_en));
            }
            ProfileModify.this.setCursorOff();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04598 implements OnItemSelectedListener {
        C04598() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            ProfileModify.this.mBloodSugarType = ProfileModify.this.getResources().getStringArray(C0213R.array.array_bloodsugar_type_data)[position];
            ProfileModify.this.setCursorOff();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04609 implements OnItemSelectedListener {
        C04609() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            if (ProfileModify.this.mBloodSugarUnit != position) {
                ProfileModify.this.setCalValue(position, 1);
            }
            ProfileModify.this.setCursorOff();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public void onResume() {
        super.onResume();
        try {
            this.profile_tv_password_value.setText(new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).getString(PreferenceAction.MY_PASSWORD));
        } catch (Exception e) {
        }
    }

    public void onPause() {
        super.onPause();
        if (this.mEdit != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEdit.getWindowToken(), 0);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.profile);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.util = new Util();
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        init();
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        this.mEditName.setText(pref.getString(PreferenceAction.MY_NAME));
        this.mTvBirthDay.setText(new Util().mobileProfileDateFormat(pref.getString(PreferenceAction.MY_BIRTH)));
        this.logCat.log(className, "body unit", pref.getString(PreferenceAction.MY_HEIGHT_UNIT));
        if (pref.getString(PreferenceAction.MY_GENDER).toLowerCase().equals("male")) {
            this.mRbtnFemale.setChecked(false);
            this.mRbtnMale.setChecked(true);
        } else {
            this.mRbtnFemale.setChecked(true);
            this.mRbtnMale.setChecked(false);
        }
        if (pref.getString(PreferenceAction.MY_HEIGHT_UNIT).equals(getString(C0213R.string.unit_height_ko))) {
            this.mBodyUnit = 0;
            this.mSpBodyUnit.setSelection(this.mBodyUnit);
            this.mEditHeight.setText(pref.getString(PreferenceAction.MY_HEIGHT));
            this.mEditWeight.setText(pref.getString(PreferenceAction.MY_WEIGHT));
        } else {
            this.mBodyUnit = 1;
            this.mSpBodyUnit.setSelection(this.mBodyUnit);
            this.mEditHeight.setText(pref.getString(PreferenceAction.MY_HEIGHT));
            this.mEditWeight.setText(pref.getString(PreferenceAction.MY_WEIGHT));
        }
        this.mTvOccurDay.setText(new Util().mobileProfileDateFormat(pref.getString(PreferenceAction.MY_OCCOURDAY)));
        if (pref.getString(PreferenceAction.MY_BLOOD_SUGAR_TYPE).equals("Insulin-dependent")) {
            this.mSpBloodSugarType.setSelection(0);
        } else {
            this.mSpBloodSugarType.setSelection(1);
        }
        if (pref.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT).equals("mg/dL")) {
            this.mBloodSugarUnit = 0;
            this.mSpBloodSugarUnit.setSelection(this.mBloodSugarUnit);
            this.mEditBloodSugarHigh.setText(pref.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR));
            this.mEditBloodSugarLow.setText(pref.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR));
            setCalValue(0, 0);
        } else {
            this.mBloodSugarUnit = 1;
            this.mSpBloodSugarUnit.setSelection(this.mBloodSugarUnit);
            this.mEditBloodSugarHigh.setText(pref.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR));
            this.mEditBloodSugarLow.setText(pref.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR));
            setCalValue(1, 1);
        }
        try {
            this.mBirthDay = pref.getString(PreferenceAction.MY_BIRTH).substring(0, 10).replaceAll("-", "");
            this.mOccurDay = pref.getString(PreferenceAction.MY_OCCOURDAY).substring(0, 10).replaceAll("-", "");
        } catch (Exception e) {
            this.mBirthDay = "";
            this.mOccurDay = "";
        }
    }

    private void init() {
        this.profileLy0 = (LinearLayout) findViewById(C0213R.id.profileLy0);
        this.mEditName = (EditText) findViewById(C0213R.id.profile_edit_name);
        this.profile_tv_email_value = (TextView) findViewById(C0213R.id.profile_tv_email_value);
        this.mTvBirthDay = (TextView) findViewById(C0213R.id.profile_tv_birth);
        this.mRbtnMale = (RadioButton) findViewById(C0213R.id.profile_rbtn_male);
        this.mRbtnFemale = (RadioButton) findViewById(C0213R.id.profile_rbtn_female);
        this.mSpBodyUnit = (Spinner) findViewById(C0213R.id.profile_sp_body_unit);
        this.mEditWeight = (EditText) findViewById(C0213R.id.profile_edit_weight);
        this.mEditHeight = (EditText) findViewById(C0213R.id.profile_edit_height);
        this.mTvOccurDay = (TextView) findViewById(C0213R.id.profile_tv_occur);
        this.mSpBloodSugarType = (Spinner) findViewById(C0213R.id.profile_sp_blood_sugar_type);
        this.mSpBloodSugarUnit = (Spinner) findViewById(C0213R.id.profile_sp_blood_sugar_unit);
        this.mEditBloodSugarHigh = (EditText) findViewById(C0213R.id.profile_edit_high_blood_sugar);
        this.mEditBloodSugarLow = (EditText) findViewById(C0213R.id.profile_edit_low_blood_sugar);
        this.mTvUnit_Weight = (TextView) findViewById(C0213R.id.profile_tv_unit_weight);
        this.mTvUnit_Height = (TextView) findViewById(C0213R.id.profile_tv_unit_height);
        this.mTvUnit_BloodSugar01 = (TextView) findViewById(C0213R.id.profile_tv_unit_bloodsugar01);
        this.mTvUnit_BloodSugar02 = (TextView) findViewById(C0213R.id.profile_tv_unit_bloodsugar02);
        this.btProgressBar = (ProgressBar) findViewById(C0213R.id.btProgressBar);
        this.profile_tv_password_value = (TextView) findViewById(C0213R.id.profile_tv_password_value);
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        this.profile_tv_password_value.setText(pref.getString(PreferenceAction.MY_PASSWORD));
        this.profile_tv_password_value.setOnClickListener(new C04521());
        this.mTvBirthDay.setOnClickListener(this);
        this.mTvOccurDay.setOnClickListener(this);
        this.mRbtnMale.setOnCheckedChangeListener(this);
        this.mRbtnFemale.setOnCheckedChangeListener(this);
        String[] bodyUnitArray = getResources().getStringArray(C0213R.array.array_body_unit);
        String[] bloodSugarTypeArray = getResources().getStringArray(C0213R.array.array_bloodsugar_type);
        String[] bloodSugarUnitArray = getResources().getStringArray(C0213R.array.array_bloodsugar_unit);
        ArrayAdapter<String> bodyUnitAdapter = new ArrayAdapter(this, C0213R.layout.item_spinner, bodyUnitArray);
        ArrayAdapter<String> bloodSugarTypeAdapter = new ArrayAdapter(this, 17367048, bloodSugarTypeArray);
        ArrayAdapter<String> bloodSugarUnitAdapter = new ArrayAdapter(this, C0213R.layout.item_spinner, bloodSugarUnitArray);
        bodyUnitAdapter.setDropDownViewResource(17367049);
        bloodSugarTypeAdapter.setDropDownViewResource(17367049);
        bloodSugarUnitAdapter.setDropDownViewResource(17367049);
        this.mSpBodyUnit.setAdapter(bodyUnitAdapter);
        this.mSpBloodSugarType.setAdapter(bloodSugarTypeAdapter);
        this.mSpBloodSugarUnit.setAdapter(bloodSugarUnitAdapter);
        this.mSpBodyUnit.setPrompt(getString(C0213R.string.prompt_body_unit));
        this.mSpBloodSugarType.setPrompt(getString(C0213R.string.prompt_bloodsugar_type));
        this.mSpBloodSugarUnit.setPrompt(getString(C0213R.string.prompt_bloodsugar_unit));
        this.mSpBodyUnit.setOnItemSelectedListener(this.bodyUnitSelectedListener);
        this.mSpBloodSugarType.setOnItemSelectedListener(this.bsTypeSelectedListener);
        this.mSpBloodSugarUnit.setOnItemSelectedListener(this.bsUnitSelectedListener);
        this.mEditName.setOnTouchListener(this.focusTouchListener);
        this.mEditWeight.setOnTouchListener(this.focusTouchListener);
        this.mEditHeight.setOnTouchListener(this.focusTouchListener);
        this.mEditBloodSugarHigh.setOnTouchListener(this.focusTouchListener);
        this.mEditBloodSugarLow.setOnTouchListener(this.focusTouchListener);
        setBaseOnEditorAction(this.mEditName);
        setBaseOnEditorAction(this.mEditWeight);
        this.mEditName.setOnFocusChangeListener(this);
        this.mEditWeight.setOnFocusChangeListener(this);
        this.mEditHeight.setOnFocusChangeListener(this);
        this.mEditBloodSugarHigh.setOnFocusChangeListener(this);
        this.mEditBloodSugarLow.setOnFocusChangeListener(this);
        this.mBtnNext = (Button) findViewById(C0213R.id.profile_btn_next);
        this.mBtnNext.setText(C0213R.string.btn_complete);
        this.mBtnNext.setOnClickListener(this);
        this.mBtnNext.setVisibility(0);
        this.profileLy0.setOnTouchListener(new C04532());
        this.profile_tv_email_value.setText(pref.getString(PreferenceAction.MY_EMAIL));
    }

    public void setBaseOnEditorAction(final EditText edit) {
        edit.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId != 6 && (event == null || event.getKeyCode() != 66)) {
                    return false;
                }
                edit.setSelectAllOnFocus(true);
                ((InputMethodManager) ProfileModify.this.getSystemService("input_method")).hideSoftInputFromWindow(edit.getWindowToken(), 0);
                return true;
            }
        });
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0213R.id.profile_btn_next:
                goSetting();
                return;
            case C0213R.id.profile_tv_birth:
                showBirthDayPicker();
                return;
            case C0213R.id.profile_tv_occur:
                showOccurDayPicker();
                return;
            default:
                return;
        }
    }

    private void goSetting() {
        this.logCat.log(className, "goSetting()", "in");
        this.mName = this.mEditName.getText().toString();
        if (this.mName == null || this.mName.trim().equals("")) {
            this.logCat.log(className, "goSetting()", "in1");
        } else if (this.mBirthDay == null || this.mBirthDay.trim().equals("")) {
            this.logCat.log(className, "goSetting()", "in2");
        } else {
            String mBloodSugarUnitValue;
            String mBodyUnitHeightValue;
            String mBodyUnitWeightValue;
            this.logCat.log(className, "goSetting()", "in3");
            String weight = this.mEditWeight.getText().toString();
            String height = this.mEditHeight.getText().toString();
            String bloodsugarHigh = this.mEditBloodSugarHigh.getText().toString().trim();
            String bloodsugarLow = this.mEditBloodSugarLow.getText().toString().trim();
            if (weight == null || weight.trim().equals("")) {
                this.mWeight = "0";
            } else {
                this.mWeight = weight;
            }
            if (height == null || height.trim().equals("")) {
                this.mHeight = "0";
            } else {
                this.mHeight = height;
            }
            String[] sugarUnitValueArr = getResources().getStringArray(C0213R.array.array_bloodsugar_unit_data);
            if (this.mBloodSugarUnit == 1) {
                setCalValue(0, 0);
                this.mBloodSugarUnit = 1;
                mBloodSugarUnitValue = sugarUnitValueArr[1];
            } else {
                mBloodSugarUnitValue = sugarUnitValueArr[0];
            }
            String[] mBodyUnitHeightValueArr = getResources().getStringArray(C0213R.array.array_body_height_data);
            if (this.mBodyUnit == 0) {
                mBodyUnitHeightValue = mBodyUnitHeightValueArr[0];
            } else {
                mBodyUnitHeightValue = mBodyUnitHeightValueArr[1];
            }
            String[] mBodyUnitWeightValueArr = getResources().getStringArray(C0213R.array.array_body_weight_data);
            if (this.mBodyUnit == 0) {
                mBodyUnitWeightValue = mBodyUnitWeightValueArr[0];
            } else {
                mBodyUnitWeightValue = mBodyUnitWeightValueArr[1];
            }
            if (!mBloodSugarUnitValue.equals("mg/dL") && mBloodSugarUnitValue.equals("mmol/L")) {
                this.logCat.log(className, "bloodsugarHigh", bloodsugarHigh);
                this.logCat.log(className, "bloodsugarLow", bloodsugarLow);
                bloodsugarHigh = this.util.mmolLToMgdl(bloodsugarHigh);
                bloodsugarLow = this.util.mmolLToMgdl(bloodsugarLow);
            }
            PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            pref.putString(PreferenceAction.MY_NAME, this.mName);
            pref.putString(PreferenceAction.MY_BIRTH, changeDateStr(this.mBirthDay));
            pref.putString(PreferenceAction.MY_GENDER, this.mGenderValue);
            pref.putString(PreferenceAction.MY_WEIGHT_UNIT, mBodyUnitWeightValue);
            pref.putString(PreferenceAction.MY_HEIGHT_UNIT, mBodyUnitHeightValue);
            pref.putString(PreferenceAction.MY_WEIGHT, this.mWeight);
            pref.putString(PreferenceAction.MY_HEIGHT, this.mHeight);
            pref.putString(PreferenceAction.MY_OCCOURDAY, changeDateStr(this.mOccurDay));
            pref.putString(PreferenceAction.MY_BLOOD_SUGAR_TYPE, this.mBloodSugarType);
            pref.putString(PreferenceAction.MY_BLOOD_SUGAR_UNIT, mBloodSugarUnitValue);
            pref.putString(PreferenceAction.MY_HIGH_BLOOD_SUGAR, bloodsugarHigh);
            pref.putString(PreferenceAction.MY_LOW_BLOOD_SUGAR, bloodsugarLow);
            pref.putString(PreferenceAction.MY_GCM_STR, new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_GCM).getString(PreferenceAction.GCM_REGISTRED_ID));
            this.logCat.log(className, PreferenceAction.MY_NAME, pref.getString(PreferenceAction.MY_NAME));
            this.logCat.log(className, PreferenceAction.MY_BIRTH, pref.getString(PreferenceAction.MY_BIRTH));
            this.logCat.log(className, PreferenceAction.MY_GENDER, pref.getString(PreferenceAction.MY_GENDER));
            this.logCat.log(className, PreferenceAction.MY_WEIGHT_UNIT, pref.getString(PreferenceAction.MY_WEIGHT_UNIT));
            this.logCat.log(className, PreferenceAction.MY_HEIGHT_UNIT, pref.getString(PreferenceAction.MY_HEIGHT_UNIT));
            this.logCat.log(className, PreferenceAction.MY_WEIGHT, pref.getString(PreferenceAction.MY_WEIGHT));
            this.logCat.log(className, PreferenceAction.MY_HEIGHT, pref.getString(PreferenceAction.MY_HEIGHT));
            this.logCat.log(className, PreferenceAction.MY_OCCOURDAY, pref.getString(PreferenceAction.MY_OCCOURDAY));
            this.logCat.log(className, PreferenceAction.MY_BLOOD_SUGAR_TYPE, pref.getString(PreferenceAction.MY_BLOOD_SUGAR_TYPE));
            this.logCat.log(className, PreferenceAction.MY_BLOOD_SUGAR_UNIT, pref.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT));
            this.logCat.log(className, PreferenceAction.MY_HIGH_BLOOD_SUGAR, pref.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR));
            this.logCat.log(className, PreferenceAction.MY_LOW_BLOOD_SUGAR, pref.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR));
            this.logCat.log(className, PreferenceAction.MY_GCM_STR, pref.getString(PreferenceAction.MY_GCM_STR));
            setResult(10);
            actionDefine(MODIFY_PROFILE);
            Toast.makeText(this.mContext, getString(C0213R.string.setting_restart), 0).show();
        }
    }

    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            String[] genderArr = getResources().getStringArray(C0213R.array.array_gender_unit_data);
            if (buttonView.getId() == C0213R.id.profile_rbtn_male) {
                this.mGender = getString(C0213R.string.profile_male);
                this.mGenderValue = genderArr[0];
            } else if (buttonView.getId() == C0213R.id.profile_rbtn_female) {
                this.mGender = getString(C0213R.string.profile_female);
                this.mGenderValue = genderArr[1];
            }
        }
    }

    private void showBirthDayPicker() {
        if (this.mBirthYear == 0) {
            this.mBirthYear = 1980;
        }
        if (this.mBirthMonth == 0) {
            this.mBirthMonth = 1;
        }
        if (this.mBirthDate == 0) {
            this.mBirthDate = 1;
        }
        new DatePickerDialog(this, this.birthdayPickerListener, this.mBirthYear, this.mBirthMonth - 1, this.mBirthDate).show();
    }

    private void showOccurDayPicker() {
        if (this.mOccurYear == 0) {
            this.mOccurYear = getYear();
        }
        if (this.mOccurMonth == 0) {
            this.mOccurMonth = getMonth();
        }
        if (this.mOccurDate == 0) {
            this.mOccurDate = getDay();
        }
        new DatePickerDialog(this, this.occurdayPickerListener, this.mOccurYear, this.mOccurMonth - 1, this.mOccurDate).show();
    }

    private void setCursorOff() {
        this.mEditName.setCursorVisible(false);
        this.mEditWeight.setCursorVisible(false);
        this.mEditHeight.setCursorVisible(false);
        this.mEditBloodSugarHigh.setCursorVisible(false);
        this.mEditBloodSugarLow.setCursorVisible(false);
    }

    public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus) {
            ((EditText) v).setCursorVisible(true);
            ((EditText) v).setSelectAllOnFocus(true);
            this.mEdit = (EditText) v;
        }
    }

    private void setCalValue(int type, int inputType) {
        this.mBloodSugarHigh = this.mEditBloodSugarHigh.getText().toString();
        this.mBloodSugarLow = this.mEditBloodSugarLow.getText().toString();
        if (type == 0) {
            if (this.mBloodSugarHigh == null || this.mBloodSugarHigh.trim().equals("")) {
                this.mBloodSugarHigh = Integer.toString(200);
            }
            if (this.mBloodSugarLow == null || this.mBloodSugarLow.trim().equals("")) {
                this.mBloodSugarHigh = Integer.toString(70);
            }
            String H = this.util.mmolLToMgdl(this.mBloodSugarHigh);
            String L = this.util.mmolLToMgdl(this.mBloodSugarLow);
            this.mBloodSugarHigh = String.valueOf(H);
            this.mBloodSugarLow = String.valueOf(L);
        } else if (type == 1) {
            if (this.mBloodSugarHigh == null || this.mBloodSugarHigh.trim().equals("")) {
                this.mBloodSugarHigh = Float.toString(ClassConstant.GLUCOSE_mmoll_HIGHT);
            }
            if (this.mBloodSugarLow == null || this.mBloodSugarLow.trim().equals("")) {
                this.mBloodSugarLow = Float.toString(ClassConstant.GLUCOSE_mmoll_LOW);
            }
            double val01 = Double.parseDouble(this.mBloodSugarHigh) / 18.010000228881836d;
            double val02 = Double.parseDouble(this.mBloodSugarLow) / 18.010000228881836d;
            DecimalFormat df = new DecimalFormat("###,##0.0");
            this.mBloodSugarHigh = df.format(val01);
            this.mBloodSugarLow = df.format(val02);
            this.mBloodSugarHigh = this.mBloodSugarHigh.replaceAll(",", "\\.");
            this.mBloodSugarLow = this.mBloodSugarLow.replaceAll(",", "\\.");
        }
        if (type == 0) {
            this.mTvUnit_BloodSugar01.setText(getString(C0213R.string.unit_blood_sugar_ko));
            this.mTvUnit_BloodSugar02.setText(getString(C0213R.string.unit_blood_sugar_ko));
        } else if (type == 1) {
            this.mTvUnit_BloodSugar01.setText(getString(C0213R.string.unit_blood_sugar_en));
            this.mTvUnit_BloodSugar02.setText(getString(C0213R.string.unit_blood_sugar_en));
        }
        this.mBloodSugarUnit = type;
        if (inputType != 0) {
            this.mEditBloodSugarHigh.setText(this.mBloodSugarHigh);
            this.mEditBloodSugarLow.setText(this.mBloodSugarLow);
            if (type == 0) {
                this.mTvUnit_BloodSugar01.setText(getString(C0213R.string.unit_blood_sugar_ko));
                this.mTvUnit_BloodSugar02.setText(getString(C0213R.string.unit_blood_sugar_ko));
            } else if (type == 1) {
                this.mTvUnit_BloodSugar01.setText(getString(C0213R.string.unit_blood_sugar_en));
                this.mTvUnit_BloodSugar02.setText(getString(C0213R.string.unit_blood_sugar_en));
            }
        }
    }

    private void setCalValue2(int type) {
        this.logCat.log(className, "setCalValue2 type", type + "");
        this.mHeight = this.mEditHeight.getText().toString().trim();
        this.mWeight = this.mEditWeight.getText().toString().trim();
        if (type == 0) {
            if (this.mHeight == null || this.mHeight.trim().equals("") || this.mHeight.trim().equals("0.0")) {
                this.mHeight = "0";
            }
            if (this.mWeight == null || this.mWeight.trim().equals("") || this.mWeight.trim().equals("0.0")) {
                this.mWeight = "0";
            }
            int val02 = (int) roundOff(Double.parseDouble(this.mWeight) * 0.45359d, 0);
            this.mHeight = String.valueOf((int) roundOff(Double.parseDouble(this.mHeight) * 30.48d, 0));
            this.mWeight = String.valueOf(val02);
        } else if (type == 1) {
            if (this.mHeight == null || this.mHeight.trim().equals("")) {
                this.mHeight = "0";
            }
            if (this.mWeight == null || this.mWeight.trim().equals("")) {
                this.mWeight = "0";
            }
            double val01 = roundOff(Double.parseDouble(this.mHeight) / 30.48d, 2);
            double val022 = roundOff(Double.parseDouble(this.mWeight) / 0.45359d, 2);
            String strVal01 = String.valueOf(val01);
            String strVal02 = String.valueOf(val022);
            String[] strArray01 = strVal01.split("\\.");
            String[] strArray02 = strVal02.split("\\.");
            if (strArray01 != null && strArray01.length == 2 && strArray01[1].length() > 2) {
                strVal01 = strArray01[0] + "." + strArray01[1].substring(0, 2);
            }
            if (strArray02 != null && strArray02.length == 2 && strArray02[1].length() > 2) {
                strVal02 = strArray02[0] + "." + strArray02[1].substring(0, 2);
            }
            this.mHeight = strVal01;
            this.mWeight = strVal02;
        }
        if (type == 0) {
            this.mTvUnit_Height.setText(getString(C0213R.string.unit_height_ko));
            this.mTvUnit_Weight.setText(getString(C0213R.string.unit_weight_ko));
        } else if (type == 1) {
            this.mTvUnit_Height.setText(getString(C0213R.string.unit_height_en));
            this.mTvUnit_Weight.setText(getString(C0213R.string.unit_weight_en));
        }
        this.mBodyUnit = type;
        this.mEditHeight.setText(this.mHeight);
        this.mEditWeight.setText(this.mWeight);
    }

    public static double roundOff(double num, int point) {
        return Math.floor((Math.pow(10.0d, (double) point) * num) + 0.5d) / Math.pow(10.0d, (double) point);
    }

    public int getYear() {
        return Integer.parseInt(new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime()));
    }

    public int getMonth() {
        return Integer.parseInt(new SimpleDateFormat("MM").format(Calendar.getInstance().getTime()));
    }

    public int getDay() {
        return Integer.parseInt(new SimpleDateFormat("dd").format(Calendar.getInstance().getTime()));
    }

    public String convertDateValue(int value) {
        if (value > 9) {
            return String.valueOf(value);
        }
        return String.valueOf(addZero(value));
    }

    public String addZero(int value) {
        if (value < 10) {
            return "0" + String.valueOf(value);
        }
        return String.valueOf(value);
    }

    public void onBackPressed() {
        this.logCat.log(className, "onBackPressed", "in");
        finish();
    }

    private String changeDateStr(String str) {
        String y = str.substring(0, 4);
        String m = str.substring(4, 6);
        return y + "-" + m + "-" + str.substring(6, 8) + " 00:00:00.000";
    }

    void pakageRestart() {
        ContainerFragmentActivity.containerFragmentActivity.finish();
        startActivity(new Intent(this, ContainerFragmentActivity.class));
        finish();
    }

    private void actionDefine(int gubun) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                if (gubun == MODIFY_PROFILE) {
                    pakageRestart();
                    return;
                }
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == MODIFY_PROFILE) {
                    pakageRestart();
                    return;
                }
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == MODIFY_PROFILE) {
                    pakageRestart();
                    return;
                }
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == MODIFY_PROFILE) {
                    pakageRestart();
                    return;
                }
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == MODIFY_PROFILE) {
                    pakageRestart();
                    return;
                }
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == MODIFY_PROFILE) {
                    pakageRestart();
                    return;
                }
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == MODIFY_PROFILE) {
                    pakageRestart();
                    return;
                }
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == MODIFY_PROFILE) {
                    pakageRestart();
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == MODIFY_PROFILE) {
                    this.btProgressBar.setVisibility(0);
                    new ThrModUser(getApplicationContext(), modUserThrDM(), this).start();
                    pakageRestart();
                    return;
                }
                return;
            default:
                return;
        }
    }

    private ModUserThrDM modUserThrDM() {
        PreferenceAction prefProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        PreferenceAction prefSetting = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        ModUserThrDM dm = new ModUserThrDM();
        dm.MY_EMAIL = prefProfile.getString(PreferenceAction.MY_EMAIL);
        dm.MY_SERVER_ID = prefProfile.getString(PreferenceAction.MY_SERVER_ID);
        dm.MY_NAME = prefProfile.getString(PreferenceAction.MY_NAME);
        dm.MY_BIRTH = prefProfile.getString(PreferenceAction.MY_BIRTH);
        dm.MY_GENDER = prefProfile.getString(PreferenceAction.MY_GENDER);
        dm.MY_HEIGHT = prefProfile.getString(PreferenceAction.MY_HEIGHT);
        dm.MY_HEIGHT_UNIT = prefProfile.getString(PreferenceAction.MY_HEIGHT_UNIT);
        dm.MY_WEIGHT = prefProfile.getString(PreferenceAction.MY_WEIGHT);
        dm.MY_WEIGHT_UNIT = prefProfile.getString(PreferenceAction.MY_WEIGHT_UNIT);
        dm.MY_OCCOURDAY = prefProfile.getString(PreferenceAction.MY_OCCOURDAY);
        dm.MY_BLOOD_SUGAR_TYPE = prefProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_TYPE);
        dm.MY_BLOOD_SUGAR_UNIT = prefProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
        dm.MY_HIGH_BLOOD_SUGAR = prefProfile.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR);
        dm.MY_LOW_BLOOD_SUGAR = prefProfile.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR);
        dm.MY_DATE_METHOD = prefSetting.getString(PreferenceAction.MY_DATE_METHOD);
        dm.MY_TIME_METHOD = prefSetting.getString(PreferenceAction.MY_TIME_METHOD);
        dm.MY_LANGUAGE = prefSetting.getString(PreferenceAction.MY_LANGUAGE);
        return dm;
    }

    public void onModUser(Object obj) {
        this.logCat.log(className, "onModUser", "in");
        this.btProgressBar.post(new Runnable() {
            public void run() {
                ProfileModify.this.btProgressBar.setVisibility(8);
                ProfileModify.this.finish();
            }
        });
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
