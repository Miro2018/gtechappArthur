package com.accumed.gtech.settings;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.OnModUserListener;
import com.accumed.gtech.thread.ThrModUser;
import com.accumed.gtech.thread.datamodel.ModUserReturnDM;
import com.accumed.gtech.thread.datamodel.ModUserThrDM;
import com.accumed.gtech.util.LanguageChange;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import java.util.Locale;

public class SettingModify extends Activity implements OnClickListener, OnModUserListener {
    static int MODIFY_SETTINT = 0;
    static final String className = "SettingModify";
    String[] dateMethodArr;
    private OnItemSelectedListener dateMethodSelectedListener = new C04692();
    ProgressBar inputProgress;
    String[] languageMethodArr;
    private OnItemSelectedListener languageSelectedListener = new C04714();
    LogCat logCat = new LogCat();
    int mAppStatus;
    private Button mBtnClear;
    private Button mBtnComplete;
    private Button mBtnPrev;
    Context mContext;
    private int mDateMethod;
    private int mLanguage;
    private int mPeriod;
    private LinearLayout mSettingLocation;
    private LinearLayout mSettingServer;
    private Spinner mSpDateMethod;
    private Spinner mSpLanguage;
    private Spinner mSpLocation;
    private Spinner mSpPeriod;
    private Spinner mSpServer;
    private Spinner mSpTimeMethod;
    private int mTimeMethod;
    int[] periodMethodArr;
    private OnItemSelectedListener periodSelectedListener = new C04725();
    private LinearLayout settingLy0;
    String[] timeMethodArr;
    private OnItemSelectedListener timeMethodSelectedListener = new C04703();

    class C04681 implements OnTouchListener {
        C04681() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) SettingModify.this.getSystemService("input_method")).hideSoftInputFromWindow(SettingModify.this.mSpDateMethod.getWindowToken(), 0);
            return false;
        }
    }

    class C04692 implements OnItemSelectedListener {
        C04692() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            SettingModify.this.mDateMethod = position;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04703 implements OnItemSelectedListener {
        C04703() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            SettingModify.this.mTimeMethod = position;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04714 implements OnItemSelectedListener {
        C04714() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            SettingModify.this.mLanguage = position;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04725 implements OnItemSelectedListener {
        C04725() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            SettingModify.this.mPeriod = position;
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onCreate(Bundle savedInstanceState) {
        int i;
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.setting);
        this.mContext = getApplicationContext();
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        init();
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        this.logCat.log(className, "setting pref", pref.getString(PreferenceAction.MY_DATE_METHOD));
        this.logCat.log(className, "setting pref", pref.getString(PreferenceAction.MY_TIME_METHOD));
        this.logCat.log(className, "setting pref language", pref.getString(PreferenceAction.MY_LANGUAGE));
        this.logCat.log(className, "setting pref", pref.getString(PreferenceAction.MY_DATA_SAVE_PERIOD));
        this.dateMethodArr = getResources().getStringArray(C0213R.array.array_date_method_data);
        this.timeMethodArr = getResources().getStringArray(C0213R.array.array_time_method_data);
        this.languageMethodArr = getResources().getStringArray(C0213R.array.array_language_data);
        this.periodMethodArr = getResources().getIntArray(C0213R.array.array_save_period_data);
        for (i = 0; i < this.dateMethodArr.length; i++) {
            if (this.dateMethodArr[i].equals(pref.getString(PreferenceAction.MY_DATE_METHOD))) {
                this.mDateMethod = i;
            }
        }
        for (i = 0; i < this.timeMethodArr.length; i++) {
            if (this.timeMethodArr[i].equals(pref.getString(PreferenceAction.MY_TIME_METHOD))) {
                this.mTimeMethod = i;
            }
        }
        for (i = 0; i < this.languageMethodArr.length; i++) {
            if (this.languageMethodArr[i].equals(pref.getString(PreferenceAction.MY_LANGUAGE))) {
                this.mLanguage = i;
            }
        }
        for (i = 0; i < this.periodMethodArr.length; i++) {
            this.logCat.log(className, "periodMethodArr", this.periodMethodArr[i] + "");
            this.logCat.log(className, "periodMethodArr--", pref.getString(PreferenceAction.MY_DATA_SAVE_PERIOD));
            if (this.periodMethodArr[i] == Integer.parseInt(pref.getString(PreferenceAction.MY_DATA_SAVE_PERIOD))) {
                this.mPeriod = i;
            }
        }
        this.mSpDateMethod.setSelection(this.mDateMethod);
        this.mSpTimeMethod.setSelection(this.mTimeMethod);
        this.mSpLanguage.setSelection(this.mLanguage);
        this.mSpPeriod.setSelection(this.mPeriod);
        this.logCat.log(className, "periodMethodArr--", this.mPeriod + "");
    }

    private void init() {
        this.settingLy0 = (LinearLayout) findViewById(C0213R.id.settingLy0);
        this.mBtnPrev = (Button) findViewById(C0213R.id.setting_btn_prev);
        this.mBtnPrev.setVisibility(8);
        this.mBtnComplete = (Button) findViewById(C0213R.id.setting_btn_complete);
        this.mBtnComplete.setOnClickListener(this);
        this.mBtnClear = (Button) findViewById(C0213R.id.setting_btn_clear);
        this.mBtnClear.setOnClickListener(this);
        this.inputProgress = (ProgressBar) findViewById(C0213R.id.inputProgress);
        this.inputProgress.setVisibility(8);
        this.mSpDateMethod = (Spinner) findViewById(C0213R.id.setting_sp_date_method);
        this.mSpTimeMethod = (Spinner) findViewById(C0213R.id.setting_sp_time_method);
        this.mSpLanguage = (Spinner) findViewById(C0213R.id.setting_sp_language);
        this.mSpPeriod = (Spinner) findViewById(C0213R.id.setting_sp_period);
        this.mSpLocation = (Spinner) findViewById(C0213R.id.setting_sp_location);
        this.mSpServer = (Spinner) findViewById(C0213R.id.setting_sp_server);
        this.mSettingLocation = (LinearLayout) findViewById(C0213R.id.setting_location);
        this.mSettingServer = (LinearLayout) findViewById(C0213R.id.setting_server);
        String[] dateMethodArray = getResources().getStringArray(C0213R.array.array_date_method);
        String[] timeMethodArray = getResources().getStringArray(C0213R.array.array_time_method);
        String[] periodArray = getResources().getStringArray(C0213R.array.array_save_period);
        String[] locationArray = getResources().getStringArray(C0213R.array.array_location_select);
        String[] serverArray = getResources().getStringArray(C0213R.array.array_server_select);
        String[] languageArray = getResources().getStringArray(C0213R.array.array_language);
        String[] languageArrayData = getResources().getStringArray(C0213R.array.array_language_data);
        String sysLang = new LanguageChange(this.mContext).getSystemLanguage();
        this.logCat.log(className, "langPromptSelectNum sysLang", sysLang + "");
        int langPromptSelectNum = 0;
        for (int i = 0; i < languageArrayData.length; i++) {
            if (languageArrayData[i].equals(sysLang)) {
                langPromptSelectNum = i;
            }
        }
        this.logCat.log(className, "langPromptSelectNum", langPromptSelectNum + "");
        ArrayAdapter<String> dateMethodAdapter = new ArrayAdapter(this, 17367048, dateMethodArray);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter(this, 17367048, timeMethodArray);
        ArrayAdapter<String> languageAdapter = new ArrayAdapter(this, 17367048, languageArray);
        ArrayAdapter<String> periodAdapter = new ArrayAdapter(this, 17367048, periodArray);
        ArrayAdapter<String> locationAdapter = new ArrayAdapter(this, C0213R.layout.spinner_item, locationArray);
        arrayAdapter = new ArrayAdapter(this, C0213R.layout.spinner_item, serverArray);
        dateMethodAdapter.setDropDownViewResource(17367049);
        arrayAdapter.setDropDownViewResource(17367049);
        languageAdapter.setDropDownViewResource(17367049);
        periodAdapter.setDropDownViewResource(17367049);
        locationAdapter.setDropDownViewResource(17367049);
        arrayAdapter.setDropDownViewResource(17367049);
        this.mSpDateMethod.setAdapter(dateMethodAdapter);
        this.mSpTimeMethod.setAdapter(arrayAdapter);
        this.mSpLanguage.setAdapter(languageAdapter);
        this.mSpLanguage.setSelection(langPromptSelectNum);
        this.mSpPeriod.setAdapter(periodAdapter);
        this.mSpLocation.setAdapter(locationAdapter);
        this.mSpServer.setAdapter(arrayAdapter);
        this.mSpDateMethod.setPrompt(getString(C0213R.string.prompt_date_method));
        this.mSpTimeMethod.setPrompt(getString(C0213R.string.prompt_time_method));
        this.mSpLanguage.setPrompt(getString(C0213R.string.prompt_language));
        this.mSpPeriod.setPrompt(getString(C0213R.string.prompt_period));
        this.mSpLocation.setPrompt(getString(C0213R.string.prompt_location));
        this.mSpServer.setPrompt(getString(C0213R.string.prompt_server));
        this.mSpLocation.setEnabled(false);
        this.mSpServer.setEnabled(false);
        this.mSpLocation.setVisibility(8);
        this.mSpServer.setVisibility(8);
        this.mSettingLocation.setVisibility(8);
        this.mSettingServer.setVisibility(8);
        this.mSpDateMethod.setOnItemSelectedListener(this.dateMethodSelectedListener);
        this.mSpTimeMethod.setOnItemSelectedListener(this.timeMethodSelectedListener);
        this.mSpLanguage.setOnItemSelectedListener(this.languageSelectedListener);
        this.mSpPeriod.setOnItemSelectedListener(this.periodSelectedListener);
        PreferenceAction preferenceAction = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_LOCATION);
        preferenceAction = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_SERVER);
        if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_LOCATION) == 0) {
            this.mSpLocation.setSelection(0);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_LOCATION) == 1) {
            this.mSpLocation.setSelection(1);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_LOCATION) == 2) {
            this.mSpLocation.setSelection(2);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_LOCATION) == 3) {
            this.mSpLocation.setSelection(3);
        } else {
            this.mSpLocation.setSelection(4);
        }
        if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_SERVER) == 0) {
            this.mSpServer.setSelection(0);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_SERVER) == 1) {
            this.mSpServer.setSelection(1);
        } else if (preferenceAction.getInt(PreferenceAction.PREF_SELECT_SERVER) == 2) {
            this.mSpServer.setSelection(2);
        } else {
            this.mSpServer.setSelection(3);
        }
        this.settingLy0.setOnTouchListener(new C04681());
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0213R.id.setting_btn_prev:
                finish();
                return;
            case C0213R.id.setting_btn_complete:
                settingFinish();
                return;
            case C0213R.id.setting_btn_clear:
                this.mDateMethod = 0;
                this.mTimeMethod = 0;
                this.mLanguage = 0;
                this.mPeriod = 0;
                this.mSpDateMethod.setSelection(this.mDateMethod);
                this.mSpTimeMethod.setSelection(this.mTimeMethod);
                this.mSpLanguage.setSelection(this.mLanguage);
                this.mSpPeriod.setSelection(this.mPeriod);
                return;
            default:
                return;
        }
    }

    private void settingFinish() {
        this.inputProgress.setVisibility(0);
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        String dateMethodValue = this.dateMethodArr[this.mDateMethod];
        String timeMethodValue = this.timeMethodArr[this.mTimeMethod];
        String laguageMethodValue = this.languageMethodArr[this.mLanguage];
        String periodMethodValue = Integer.toString(this.periodMethodArr[this.mPeriod]);
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        pref.putString(PreferenceAction.MY_DATE_METHOD, dateMethodValue);
        pref.putString(PreferenceAction.MY_TIME_METHOD, timeMethodValue);
        pref.putString(PreferenceAction.MY_LANGUAGE, laguageMethodValue);
        pref.putString(PreferenceAction.MY_DATA_SAVE_PERIOD, periodMethodValue);
        this.logCat.log(className, PreferenceAction.MY_DATE_METHOD, pref.getString(PreferenceAction.MY_DATE_METHOD));
        this.logCat.log(className, PreferenceAction.MY_TIME_METHOD, pref.getString(PreferenceAction.MY_TIME_METHOD));
        this.logCat.log(className, PreferenceAction.MY_LANGUAGE, pref.getString(PreferenceAction.MY_LANGUAGE));
        this.logCat.log(className, PreferenceAction.MY_DATA_SAVE_PERIOD, pref.getString(PreferenceAction.MY_DATA_SAVE_PERIOD));
        this.logCat.log(className, "langTat", laguageMethodValue);
        Locale locale = new Locale(laguageMethodValue);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        actionDefine(MODIFY_SETTINT);
        Toast.makeText(this.mContext, getString(C0213R.string.setting_restart), 0).show();
    }

    public void onBackPressed() {
        this.logCat.log(className, "onBackPressed", "in");
        finish();
    }

    void pakageRestart() {
        ContainerFragmentActivity.containerFragmentActivity.finish();
        startActivity(new Intent(this, ContainerFragmentActivity.class));
        finish();
    }

    private void actionDefine(int gubun) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                if (gubun == MODIFY_SETTINT) {
                    pakageRestart();
                    return;
                }
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == MODIFY_SETTINT) {
                    pakageRestart();
                    return;
                }
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == MODIFY_SETTINT) {
                    pakageRestart();
                    return;
                }
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == MODIFY_SETTINT) {
                    pakageRestart();
                    return;
                }
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == MODIFY_SETTINT) {
                    pakageRestart();
                    return;
                }
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == MODIFY_SETTINT) {
                    pakageRestart();
                    return;
                }
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == MODIFY_SETTINT) {
                    pakageRestart();
                    return;
                }
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == MODIFY_SETTINT) {
                    pakageRestart();
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == MODIFY_SETTINT) {
                    new ThrModUser(getApplicationContext(), modUserThrDM(), null).start();
                    pakageRestart();
                    return;
                }
                return;
            default:
                return;
        }
    }

    private ModUserThrDM modUserThrDM() {
        PreferenceAction prefProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        PreferenceAction prefSetting = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        ModUserThrDM dm = new ModUserThrDM();
        dm.MY_EMAIL = prefProfile.getString(PreferenceAction.MY_EMAIL);
        dm.MY_SERVER_ID = prefProfile.getString(PreferenceAction.MY_SERVER_ID);
        dm.MY_NAME = prefProfile.getString(PreferenceAction.MY_NAME);
        dm.MY_BIRTH = prefProfile.getString(PreferenceAction.MY_BIRTH);
        dm.MY_GENDER = prefProfile.getString(PreferenceAction.MY_GENDER);
        dm.MY_HEIGHT = prefProfile.getString(PreferenceAction.MY_HEIGHT);
        dm.MY_HEIGHT_UNIT = prefProfile.getString(PreferenceAction.MY_HEIGHT_UNIT);
        dm.MY_WEIGHT = prefProfile.getString(PreferenceAction.MY_WEIGHT);
        dm.MY_WEIGHT_UNIT = prefProfile.getString(PreferenceAction.MY_WEIGHT_UNIT);
        dm.MY_OCCOURDAY = prefProfile.getString(PreferenceAction.MY_OCCOURDAY);
        dm.MY_BLOOD_SUGAR_TYPE = prefProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_TYPE);
        dm.MY_BLOOD_SUGAR_UNIT = prefProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
        dm.MY_HIGH_BLOOD_SUGAR = prefProfile.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR);
        dm.MY_LOW_BLOOD_SUGAR = prefProfile.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR);
        dm.MY_DATE_METHOD = prefSetting.getString(PreferenceAction.MY_DATE_METHOD);
        dm.MY_TIME_METHOD = prefSetting.getString(PreferenceAction.MY_TIME_METHOD);
        dm.MY_LANGUAGE = prefSetting.getString(PreferenceAction.MY_LANGUAGE);
        this.logCat.log(className, "dm.MY_SERVER_ID", dm.MY_SERVER_ID);
        this.logCat.log(className, "dm.MY_EMAIL", dm.MY_EMAIL);
        this.logCat.log(className, "dm.MY_PASSWORD", dm.MY_PASSWORD);
        this.logCat.log(className, "dm.MY_NAME", dm.MY_NAME);
        this.logCat.log(className, "dm.MY_BIRTH", dm.MY_BIRTH);
        this.logCat.log(className, "dm.MY_GENDER", dm.MY_GENDER);
        this.logCat.log(className, "dm.MY_HEIGHT", dm.MY_HEIGHT);
        this.logCat.log(className, "dm.MY_HEIGHT_UNIT", dm.MY_HEIGHT_UNIT);
        this.logCat.log(className, "dm.MY_WEIGHT", dm.MY_WEIGHT);
        this.logCat.log(className, "dm.MY_WEIGHT_UNIT", dm.MY_WEIGHT_UNIT);
        this.logCat.log(className, "dm.MY_OCCOURDAY", dm.MY_OCCOURDAY);
        this.logCat.log(className, "dm.MY_BLOOD_SUGAR_TYPE", dm.MY_BLOOD_SUGAR_TYPE);
        this.logCat.log(className, "dm.MY_BLOOD_SUGAR_UNIT", dm.MY_BLOOD_SUGAR_UNIT);
        this.logCat.log(className, "dm.MY_HIGH_BLOOD_SUGAR", dm.MY_HIGH_BLOOD_SUGAR);
        this.logCat.log(className, "dm.MY_LOW_BLOOD_SUGAR", dm.MY_LOW_BLOOD_SUGAR);
        this.logCat.log(className, "dm.MY_DATE_METHOD", dm.MY_DATE_METHOD);
        this.logCat.log(className, "dm.MY_TIME_METHOD", dm.MY_TIME_METHOD);
        this.logCat.log(className, "dm.MY_LANGUAGE", dm.MY_LANGUAGE);
        return dm;
    }

    public void onModUser(Object obj) {
        this.logCat.log(className, "onModUser", "in");
        ModUserReturnDM dm = (ModUserReturnDM) obj;
        this.logCat.log(className, "onModUser", dm.code);
        this.logCat.log(className, "onModUser", dm.result);
        this.logCat.log(className, "onModUser", dm.statusResult);
        finish();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
