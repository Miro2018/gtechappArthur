package com.accumed.gtech.settings;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.Util;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Profile extends Activity implements OnClickListener, OnCheckedChangeListener, OnFocusChangeListener {
    static final String className = "ProfileActivity";
    private OnDateSetListener birthdayPickerListener = new C04475();
    private OnItemSelectedListener bodyUnitSelectedListener = new C04497();
    private OnItemSelectedListener bsTypeSelectedListener = new C04508();
    private OnItemSelectedListener bsUnitSelectedListener = new C04519();
    private OnTouchListener focusTouchListener = new C04453();
    LogCat logCat;
    private int mBirthDate;
    private String mBirthDay;
    private int mBirthMonth;
    private int mBirthYear;
    private String mBloodSugarHigh;
    private String mBloodSugarLow;
    private String mBloodSugarType;
    private int mBloodSugarUnit;
    private int mBodyUnit;
    private Button mBtnNext;
    Context mContext;
    private EditText mEdit;
    private EditText mEditBloodSugarHigh;
    private EditText mEditBloodSugarLow;
    private EditText mEditHeight;
    private EditText mEditName;
    private EditText mEditWeight;
    private String mGender;
    private String mGenderValue;
    private String mHeight;
    private String mName;
    private int mOccurDate;
    private String mOccurDay;
    private int mOccurMonth;
    private int mOccurYear;
    private RadioButton mRbtnFemale;
    private RadioButton mRbtnMale;
    private Spinner mSpBloodSugarType;
    private Spinner mSpBloodSugarUnit;
    private Spinner mSpBodyUnit;
    private TextView mTvBirthDay;
    private TextView mTvOccurDay;
    private TextView mTvUnit_BloodSugar01;
    private TextView mTvUnit_BloodSugar02;
    private TextView mTvUnit_Height;
    private TextView mTvUnit_Weight;
    private String mWeight;
    private OnDateSetListener occurdayPickerListener = new C04486();
    private LinearLayout profileLy0;
    private Util util;

    class C04431 implements Runnable {
        C04431() {
        }

        public void run() {
            Profile.this.mEditName.requestFocus();
            Profile.this.mEditName.setCursorVisible(true);
        }
    }

    class C04442 implements OnTouchListener {
        C04442() {
        }

        public boolean onTouch(View arg0, MotionEvent arg1) {
            ((InputMethodManager) Profile.this.getSystemService("input_method")).hideSoftInputFromWindow(Profile.this.mEditName.getWindowToken(), 0);
            return false;
        }
    }

    class C04453 implements OnTouchListener {
        C04453() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            if (event.getAction() == 0) {
                ((EditText) v).setCursorVisible(true);
                ((EditText) v).setSelectAllOnFocus(true);
            }
            return false;
        }
    }

    class C04475 implements OnDateSetListener {
        C04475() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            Profile.this.mBirthYear = year;
            Profile.this.mBirthMonth = monthOfYear + 1;
            Profile.this.mBirthDate = dayOfMonth;
            Profile.this.mBirthDay = Profile.this.convertDateValue(Profile.this.mBirthYear) + Profile.this.convertDateValue(Profile.this.mBirthMonth) + Profile.this.convertDateValue(Profile.this.mBirthDate);
            Profile.this.mTvBirthDay.setText(Profile.this.convertDateValue(Profile.this.mBirthYear) + "." + Profile.this.convertDateValue(Profile.this.mBirthMonth) + "." + Profile.this.convertDateValue(Profile.this.mBirthDate));
            Profile.this.setCursorOff();
        }
    }

    class C04486 implements OnDateSetListener {
        C04486() {
        }

        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            Profile.this.mOccurYear = year;
            Profile.this.mOccurMonth = monthOfYear + 1;
            Profile.this.mOccurDate = dayOfMonth;
            Profile.this.mOccurDay = Profile.this.convertDateValue(Profile.this.mOccurYear) + Profile.this.convertDateValue(Profile.this.mOccurMonth) + Profile.this.convertDateValue(Profile.this.mOccurDate);
            Profile.this.mTvOccurDay.setText(Profile.this.convertDateValue(Profile.this.mOccurYear) + "." + Profile.this.convertDateValue(Profile.this.mOccurMonth) + "." + Profile.this.convertDateValue(Profile.this.mOccurDate));
            Profile.this.setCursorOff();
        }
    }

    class C04497 implements OnItemSelectedListener {
        C04497() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            if (Profile.this.mBodyUnit != position) {
                Profile.this.setCalValue2(position);
            }
            if (position == 0) {
                Profile.this.mTvUnit_Weight.setText(Profile.this.getString(C0213R.string.unit_weight_ko));
                Profile.this.mTvUnit_Height.setText(Profile.this.getString(C0213R.string.unit_height_ko));
            } else if (position == 1) {
                Profile.this.mTvUnit_Weight.setText(Profile.this.getString(C0213R.string.unit_weight_en));
                Profile.this.mTvUnit_Height.setText(Profile.this.getString(C0213R.string.unit_height_en));
            }
            Profile.this.setCursorOff();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04508 implements OnItemSelectedListener {
        C04508() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            Profile.this.mBloodSugarType = Profile.this.getResources().getStringArray(C0213R.array.array_bloodsugar_type_data)[position];
            Profile.this.setCursorOff();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    class C04519 implements OnItemSelectedListener {
        C04519() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View v, int position, long id) {
            if (Profile.this.mBloodSugarUnit != position) {
                Profile.this.setCalValue(position, 1);
            }
            Profile.this.setCursorOff();
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
        if (this.mEdit != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEdit.getWindowToken(), 0);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.profile_start);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.util = new Util();
        init();
        new Handler().postDelayed(new C04431(), 1000);
    }

    private void init() {
        this.profileLy0 = (LinearLayout) findViewById(C0213R.id.profileLy0);
        this.mEditName = (EditText) findViewById(C0213R.id.profile_edit_name);
        this.mTvBirthDay = (TextView) findViewById(C0213R.id.profile_tv_birth);
        this.mRbtnMale = (RadioButton) findViewById(C0213R.id.profile_rbtn_male);
        this.mRbtnFemale = (RadioButton) findViewById(C0213R.id.profile_rbtn_female);
        this.mSpBodyUnit = (Spinner) findViewById(C0213R.id.profile_sp_body_unit);
        this.mEditWeight = (EditText) findViewById(C0213R.id.profile_edit_weight);
        this.mEditHeight = (EditText) findViewById(C0213R.id.profile_edit_height);
        this.mTvOccurDay = (TextView) findViewById(C0213R.id.profile_tv_occur);
        this.mSpBloodSugarType = (Spinner) findViewById(C0213R.id.profile_sp_blood_sugar_type);
        this.mSpBloodSugarUnit = (Spinner) findViewById(C0213R.id.profile_sp_blood_sugar_unit);
        this.mEditBloodSugarHigh = (EditText) findViewById(C0213R.id.profile_edit_high_blood_sugar);
        this.mEditBloodSugarLow = (EditText) findViewById(C0213R.id.profile_edit_low_blood_sugar);
        this.mTvUnit_Weight = (TextView) findViewById(C0213R.id.profile_tv_unit_weight);
        this.mTvUnit_Height = (TextView) findViewById(C0213R.id.profile_tv_unit_height);
        this.mTvUnit_BloodSugar01 = (TextView) findViewById(C0213R.id.profile_tv_unit_bloodsugar01);
        this.mTvUnit_BloodSugar02 = (TextView) findViewById(C0213R.id.profile_tv_unit_bloodsugar02);
        this.mTvBirthDay.setOnClickListener(this);
        this.mTvOccurDay.setOnClickListener(this);
        this.mRbtnMale.setOnCheckedChangeListener(this);
        this.mRbtnFemale.setOnCheckedChangeListener(this);
        String[] bodyUnitArray = getResources().getStringArray(C0213R.array.array_body_unit);
        String[] bloodSugarTypeArray = getResources().getStringArray(C0213R.array.array_bloodsugar_type);
        String[] bloodSugarUnitArray = getResources().getStringArray(C0213R.array.array_bloodsugar_unit);
        ArrayAdapter<String> bodyUnitAdapter = new ArrayAdapter(this, C0213R.layout.item_spinner, bodyUnitArray);
        ArrayAdapter<String> bloodSugarTypeAdapter = new ArrayAdapter(this, 17367048, bloodSugarTypeArray);
        ArrayAdapter<String> bloodSugarUnitAdapter = new ArrayAdapter(this, C0213R.layout.item_spinner, bloodSugarUnitArray);
        bodyUnitAdapter.setDropDownViewResource(17367049);
        bloodSugarTypeAdapter.setDropDownViewResource(17367049);
        bloodSugarUnitAdapter.setDropDownViewResource(17367049);
        this.mSpBodyUnit.setAdapter(bodyUnitAdapter);
        this.mSpBloodSugarType.setAdapter(bloodSugarTypeAdapter);
        this.mSpBloodSugarUnit.setAdapter(bloodSugarUnitAdapter);
        this.mSpBodyUnit.setPrompt(getString(C0213R.string.prompt_body_unit));
        this.mSpBloodSugarType.setPrompt(getString(C0213R.string.prompt_bloodsugar_type));
        this.mSpBloodSugarUnit.setPrompt(getString(C0213R.string.prompt_bloodsugar_unit));
        this.mSpBodyUnit.setOnItemSelectedListener(this.bodyUnitSelectedListener);
        this.mSpBloodSugarType.setOnItemSelectedListener(this.bsTypeSelectedListener);
        this.mSpBloodSugarUnit.setOnItemSelectedListener(this.bsUnitSelectedListener);
        this.mEditName.setOnTouchListener(this.focusTouchListener);
        this.mEditWeight.setOnTouchListener(this.focusTouchListener);
        this.mEditHeight.setOnTouchListener(this.focusTouchListener);
        this.mEditBloodSugarHigh.setOnTouchListener(this.focusTouchListener);
        this.mEditBloodSugarLow.setOnTouchListener(this.focusTouchListener);
        setBaseOnEditorAction(this.mEditName);
        setBaseOnEditorAction(this.mEditWeight);
        this.mEditName.setOnFocusChangeListener(this);
        this.mEditWeight.setOnFocusChangeListener(this);
        this.mEditHeight.setOnFocusChangeListener(this);
        this.mEditBloodSugarHigh.setOnFocusChangeListener(this);
        this.mEditBloodSugarLow.setOnFocusChangeListener(this);
        this.mBtnNext = (Button) findViewById(C0213R.id.profile_btn_next);
        this.mBtnNext.setOnClickListener(this);
        this.mBtnNext.setVisibility(0);
        setData();
        this.mEditName.requestFocus();
        this.mEditName.setSelectAllOnFocus(true);
        this.profileLy0.setOnTouchListener(new C04442());
    }

    private void setData() {
        int year = getYear();
        int month = getMonth();
        int day = getDay();
        this.mOccurDay = convertDateValue(year) + convertDateValue(month) + convertDateValue(day);
        this.mTvOccurDay.setText(convertDateValue(year) + "." + convertDateValue(month) + "." + convertDateValue(day));
        this.mBodyUnit = 0;
        this.mWeight = "0";
        this.mHeight = "0";
        String strLanguage = getResources().getConfiguration().locale.getLanguage();
        if (strLanguage == null || !strLanguage.equals("ko")) {
            this.mBloodSugarUnit = 1;
            this.mBloodSugarHigh = Float.toString(ClassConstant.GLUCOSE_mmoll_HIGHT);
            this.mBloodSugarLow = Float.toString(ClassConstant.GLUCOSE_mmoll_LOW);
        } else {
            this.mBloodSugarUnit = 0;
            this.mBloodSugarHigh = Integer.toString(200);
            this.mBloodSugarLow = Integer.toString(70);
        }
        this.mRbtnMale.setChecked(true);
        this.mRbtnFemale.setChecked(false);
        this.mSpBodyUnit.setSelection(this.mBodyUnit);
        this.mSpBloodSugarType.setSelection(0);
        this.mSpBloodSugarUnit.setSelection(this.mBloodSugarUnit);
        this.mEditBloodSugarHigh.setText(this.mBloodSugarHigh);
        this.mEditBloodSugarLow.setText(this.mBloodSugarLow);
    }

    public void setBaseOnEditorAction(final EditText edit) {
        edit.setOnEditorActionListener(new OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId != 6 && (event == null || event.getKeyCode() != 66)) {
                    return false;
                }
                edit.setSelectAllOnFocus(true);
                ((InputMethodManager) Profile.this.getSystemService("input_method")).hideSoftInputFromWindow(edit.getWindowToken(), 0);
                return true;
            }
        });
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0213R.id.profile_btn_next:
                goSetting();
                return;
            case C0213R.id.profile_tv_birth:
                showBirthDayPicker();
                return;
            case C0213R.id.profile_tv_occur:
                showOccurDayPicker();
                return;
            default:
                return;
        }
    }

    private void goSetting() {
        this.mName = this.mEditName.getText().toString();
        if (this.mName != null && !this.mName.trim().equals("") && this.mBirthDay != null && !this.mBirthDay.trim().equals("")) {
            String mBloodSugarUnitValue;
            String mBodyUnitHeightValue;
            String mBodyUnitWeightValue;
            String weight = this.mEditWeight.getText().toString();
            String height = this.mEditHeight.getText().toString();
            String bloodsugarHigh = this.mEditBloodSugarHigh.getText().toString().trim();
            String bloodsugarLow = this.mEditBloodSugarLow.getText().toString().trim();
            if (weight == null || weight.trim().equals("")) {
                this.mWeight = "0";
            } else {
                this.mWeight = weight;
            }
            if (height == null || height.trim().equals("")) {
                this.mHeight = "0";
            } else {
                this.mHeight = height;
            }
            String[] sugarUnitValueArr = getResources().getStringArray(C0213R.array.array_bloodsugar_unit_data);
            if (this.mBloodSugarUnit == 1) {
                setCalValue(0, 0);
                this.mBloodSugarUnit = 1;
                mBloodSugarUnitValue = sugarUnitValueArr[1];
            } else {
                mBloodSugarUnitValue = sugarUnitValueArr[0];
            }
            String[] mBodyUnitHeightValueArr = getResources().getStringArray(C0213R.array.array_body_height_data);
            if (this.mBodyUnit == 0) {
                mBodyUnitHeightValue = mBodyUnitHeightValueArr[0];
            } else {
                mBodyUnitHeightValue = mBodyUnitHeightValueArr[1];
            }
            String[] mBodyUnitWeightValueArr = getResources().getStringArray(C0213R.array.array_body_weight_data);
            if (this.mBodyUnit == 0) {
                mBodyUnitWeightValue = mBodyUnitWeightValueArr[0];
            } else {
                mBodyUnitWeightValue = mBodyUnitWeightValueArr[1];
            }
            if (!mBloodSugarUnitValue.equals("mg/dL") && mBloodSugarUnitValue.equals("mmol/L")) {
                this.logCat.log(className, "bloodsugarHigh", bloodsugarHigh);
                this.logCat.log(className, "bloodsugarLow", bloodsugarLow);
                bloodsugarHigh = this.util.mmolLToMgdl(bloodsugarHigh);
                bloodsugarLow = this.util.mmolLToMgdl(bloodsugarLow);
            }
            PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            pref.putString(PreferenceAction.MY_NAME, this.mName);
            pref.putString(PreferenceAction.MY_BIRTH, changeDateStr(this.mBirthDay));
            pref.putString(PreferenceAction.MY_GENDER, this.mGenderValue);
            pref.putString(PreferenceAction.MY_WEIGHT_UNIT, mBodyUnitWeightValue);
            pref.putString(PreferenceAction.MY_HEIGHT_UNIT, mBodyUnitHeightValue);
            pref.putString(PreferenceAction.MY_WEIGHT, this.mWeight);
            pref.putString(PreferenceAction.MY_HEIGHT, this.mHeight);
            pref.putString(PreferenceAction.MY_OCCOURDAY, changeDateStr(this.mOccurDay));
            pref.putString(PreferenceAction.MY_BLOOD_SUGAR_TYPE, this.mBloodSugarType);
            pref.putString(PreferenceAction.MY_BLOOD_SUGAR_UNIT, mBloodSugarUnitValue);
            pref.putString(PreferenceAction.MY_HIGH_BLOOD_SUGAR, bloodsugarHigh);
            pref.putString(PreferenceAction.MY_LOW_BLOOD_SUGAR, bloodsugarLow);
            pref.putString(PreferenceAction.MY_GCM_STR, new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_GCM).getString(PreferenceAction.GCM_REGISTRED_ID));
            this.logCat.log(className, PreferenceAction.MY_NAME, pref.getString(PreferenceAction.MY_NAME));
            this.logCat.log(className, PreferenceAction.MY_BIRTH, pref.getString(PreferenceAction.MY_BIRTH));
            this.logCat.log(className, PreferenceAction.MY_GENDER, pref.getString(PreferenceAction.MY_GENDER));
            this.logCat.log(className, PreferenceAction.MY_WEIGHT_UNIT, pref.getString(PreferenceAction.MY_WEIGHT_UNIT));
            this.logCat.log(className, PreferenceAction.MY_HEIGHT_UNIT, pref.getString(PreferenceAction.MY_HEIGHT_UNIT));
            this.logCat.log(className, PreferenceAction.MY_WEIGHT, pref.getString(PreferenceAction.MY_WEIGHT));
            this.logCat.log(className, PreferenceAction.MY_HEIGHT, pref.getString(PreferenceAction.MY_HEIGHT));
            this.logCat.log(className, PreferenceAction.MY_OCCOURDAY, pref.getString(PreferenceAction.MY_OCCOURDAY));
            this.logCat.log(className, PreferenceAction.MY_BLOOD_SUGAR_TYPE, pref.getString(PreferenceAction.MY_BLOOD_SUGAR_TYPE));
            this.logCat.log(className, PreferenceAction.MY_BLOOD_SUGAR_UNIT, pref.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT));
            this.logCat.log(className, PreferenceAction.MY_HIGH_BLOOD_SUGAR, pref.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR));
            this.logCat.log(className, PreferenceAction.MY_LOW_BLOOD_SUGAR, pref.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR));
            this.logCat.log(className, PreferenceAction.MY_GCM_STR, pref.getString(PreferenceAction.MY_GCM_STR));
            setResult(10);
            finish();
        }
    }

    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            String[] genderArr = getResources().getStringArray(C0213R.array.array_gender_unit_data);
            if (buttonView.getId() == C0213R.id.profile_rbtn_male) {
                this.mGender = getString(C0213R.string.profile_male);
                this.mGenderValue = genderArr[0];
            } else if (buttonView.getId() == C0213R.id.profile_rbtn_female) {
                this.mGender = getString(C0213R.string.profile_female);
                this.mGenderValue = genderArr[1];
            }
        }
    }

    private void showBirthDayPicker() {
        if (this.mBirthYear == 0) {
            this.mBirthYear = 1980;
        }
        if (this.mBirthMonth == 0) {
            this.mBirthMonth = 1;
        }
        if (this.mBirthDate == 0) {
            this.mBirthDate = 1;
        }
        new DatePickerDialog(this, this.birthdayPickerListener, this.mBirthYear, this.mBirthMonth - 1, this.mBirthDate).show();
    }

    private void showOccurDayPicker() {
        if (this.mOccurYear == 0) {
            this.mOccurYear = getYear();
        }
        if (this.mOccurMonth == 0) {
            this.mOccurMonth = getMonth();
        }
        if (this.mOccurDate == 0) {
            this.mOccurDate = getDay();
        }
        new DatePickerDialog(this, this.occurdayPickerListener, this.mOccurYear, this.mOccurMonth - 1, this.mOccurDate).show();
    }

    private void setCursorOff() {
        this.mEditName.setCursorVisible(false);
        this.mEditWeight.setCursorVisible(false);
        this.mEditHeight.setCursorVisible(false);
        this.mEditBloodSugarHigh.setCursorVisible(false);
        this.mEditBloodSugarLow.setCursorVisible(false);
    }

    public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus) {
            ((EditText) v).setCursorVisible(true);
            ((EditText) v).setSelectAllOnFocus(true);
            this.mEdit = (EditText) v;
        }
    }

    private void setCalValue(int type, int inputType) {
        this.mBloodSugarHigh = this.mEditBloodSugarHigh.getText().toString();
        this.mBloodSugarLow = this.mEditBloodSugarLow.getText().toString();
        if (type == 0) {
            if (this.mBloodSugarHigh == null || this.mBloodSugarHigh.trim().equals("")) {
                this.mBloodSugarHigh = Integer.toString(200);
            }
            if (this.mBloodSugarLow == null || this.mBloodSugarLow.trim().equals("")) {
                this.mBloodSugarHigh = Integer.toString(70);
            }
            String H = this.util.mmolLToMgdl(this.mBloodSugarHigh);
            String L = this.util.mmolLToMgdl(this.mBloodSugarLow);
            this.mBloodSugarHigh = String.valueOf(H);
            this.mBloodSugarLow = String.valueOf(L);
        } else if (type == 1) {
            if (this.mBloodSugarHigh == null || this.mBloodSugarHigh.trim().equals("")) {
                this.mBloodSugarHigh = Float.toString(ClassConstant.GLUCOSE_mmoll_HIGHT);
            }
            if (this.mBloodSugarLow == null || this.mBloodSugarLow.trim().equals("")) {
                this.mBloodSugarLow = Float.toString(ClassConstant.GLUCOSE_mmoll_LOW);
            }
            double val01 = Double.parseDouble(this.mBloodSugarHigh) / 18.010000228881836d;
            double val02 = Double.parseDouble(this.mBloodSugarLow) / 18.010000228881836d;
            DecimalFormat df = new DecimalFormat("###,##0.0");
            this.mBloodSugarHigh = df.format(val01);
            this.mBloodSugarLow = df.format(val02);
        }
        if (type == 0) {
            this.mTvUnit_BloodSugar01.setText(getString(C0213R.string.unit_blood_sugar_ko));
            this.mTvUnit_BloodSugar02.setText(getString(C0213R.string.unit_blood_sugar_ko));
        } else if (type == 1) {
            this.mTvUnit_BloodSugar01.setText(getString(C0213R.string.unit_blood_sugar_en));
            this.mTvUnit_BloodSugar02.setText(getString(C0213R.string.unit_blood_sugar_en));
        }
        this.mBloodSugarUnit = type;
        if (inputType != 0) {
            this.mEditBloodSugarHigh.setText(this.mBloodSugarHigh);
            this.mEditBloodSugarLow.setText(this.mBloodSugarLow);
            if (type == 0) {
                this.mTvUnit_BloodSugar01.setText(getString(C0213R.string.unit_blood_sugar_ko));
                this.mTvUnit_BloodSugar02.setText(getString(C0213R.string.unit_blood_sugar_ko));
            } else if (type == 1) {
                this.mTvUnit_BloodSugar01.setText(getString(C0213R.string.unit_blood_sugar_en));
                this.mTvUnit_BloodSugar02.setText(getString(C0213R.string.unit_blood_sugar_en));
            }
        }
    }

    private void setCalValue2(int type) {
        this.mHeight = this.mEditHeight.getText().toString().trim();
        this.mWeight = this.mEditWeight.getText().toString().trim();
        if (type == 0) {
            if (this.mHeight == null || this.mHeight.trim().equals("") || this.mHeight.trim().equals("0.0")) {
                this.mHeight = "0";
            }
            if (this.mWeight == null || this.mWeight.trim().equals("") || this.mWeight.trim().equals("0.0")) {
                this.mWeight = "0";
            }
            int val02 = (int) roundOff(Double.parseDouble(this.mWeight) * 0.45359d, 0);
            this.mHeight = String.valueOf((int) roundOff(Double.parseDouble(this.mHeight) * 30.48d, 0));
            this.mWeight = String.valueOf(val02);
        } else if (type == 1) {
            if (this.mHeight == null || this.mHeight.trim().equals("")) {
                this.mHeight = "0";
            }
            if (this.mWeight == null || this.mWeight.trim().equals("")) {
                this.mWeight = "0";
            }
            double val01 = roundOff(Double.parseDouble(this.mHeight) / 30.48d, 2);
            double val022 = roundOff(Double.parseDouble(this.mWeight) / 0.45359d, 2);
            String strVal01 = String.valueOf(val01);
            String strVal02 = String.valueOf(val022);
            String[] strArray01 = strVal01.split("\\.");
            String[] strArray02 = strVal02.split("\\.");
            if (strArray01 != null && strArray01.length == 2 && strArray01[1].length() > 2) {
                strVal01 = strArray01[0] + "." + strArray01[1].substring(0, 2);
            }
            if (strArray02 != null && strArray02.length == 2 && strArray02[1].length() > 2) {
                strVal02 = strArray02[0] + "." + strArray02[1].substring(0, 2);
            }
            this.mHeight = strVal01;
            this.mWeight = strVal02;
        }
        if (type == 0) {
            this.mTvUnit_Height.setText(getString(C0213R.string.unit_height_ko));
            this.mTvUnit_Weight.setText(getString(C0213R.string.unit_weight_ko));
        } else if (type == 1) {
            this.mTvUnit_Height.setText(getString(C0213R.string.unit_height_en));
            this.mTvUnit_Weight.setText(getString(C0213R.string.unit_weight_en));
        }
        this.mBodyUnit = type;
        this.mEditHeight.setText(this.mHeight);
        this.mEditWeight.setText(this.mWeight);
    }

    public static double roundOff(double num, int point) {
        return Math.floor((Math.pow(10.0d, (double) point) * num) + 0.5d) / Math.pow(10.0d, (double) point);
    }

    public int getYear() {
        return Integer.parseInt(new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime()));
    }

    public int getMonth() {
        return Integer.parseInt(new SimpleDateFormat("MM").format(Calendar.getInstance().getTime()));
    }

    public int getDay() {
        return Integer.parseInt(new SimpleDateFormat("dd").format(Calendar.getInstance().getTime()));
    }

    public String convertDateValue(int value) {
        if (value > 9) {
            return String.valueOf(value);
        }
        return String.valueOf(addZero(value));
    }

    public String addZero(int value) {
        if (value < 10) {
            return "0" + String.valueOf(value);
        }
        return String.valueOf(value);
    }

    public void onBackPressed() {
        this.logCat.log(className, "onBackPressed", "in");
        new Builder(this).setTitle(getString(C0213R.string.alert_text_title)).setMessage(getString(C0213R.string.alert_text_finish)).setNegativeButton(getString(C0213R.string.alert_text_cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
            }
        }).setPositiveButton(getString(C0213R.string.alert_text_confirm), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Profile.this.setResult(-1);
                Profile.this.finish();
            }
        }).show();
    }

    private String changeDateStr(String str) {
        String y = str.substring(0, 4);
        String m = str.substring(4, 6);
        return y + "-" + m + "-" + str.substring(6, 8) + " 00:00:00.000";
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
