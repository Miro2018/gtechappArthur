package com.accumed.gtech.gcm;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewCompat;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.PopupMessage;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.google.android.gcm.GCMBaseIntentService;
import org.json.JSONException;
import org.json.JSONObject;

public class GCMService extends GCMBaseIntentService {
    static final String className = "GCMService";
    public static final int notificationId = 9998;
    String intentEmail = "";
    String intentName = "";
    LogCat logCat = new LogCat();
    Context mContext;
    String msg;
    Handler toastH = new C02911();

    class C02911 extends Handler {
        C02911() {
        }

        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                GCMService.this.makeToast((NotiDM) msg.obj);
            }
        }
    }

    class LongerToastTask extends CountDownTimer {
        Toast toast;

        LongerToastTask(long millisInFuture, long countDownInterval, Toast toast) {
            super(millisInFuture, countDownInterval);
            this.toast = toast;
        }

        public void onFinish() {
        }

        public void onTick(long millisUntilFinished) {
            this.toast.show();
        }
    }

    class NotiDM {
        String FRIEND_EMAIL = "";
        String FRIEND_NAME = "";
        String GUBUN_NUM = "";
        String PANDING = "";
        String iconResource = "";
        String message = "";

        NotiDM() {
        }
    }

    public GCMService() {
        this.logCat.log(className, className, "in");
    }

    protected void onRegistered(Context context, String regID) {
        this.logCat.log(className, "onRegistered", "in");
    }

    protected void onUnregistered(Context context, String regID) {
        Log.e("onUnregistered", "" + regID);
    }

    protected void onError(Context context, String msg) {
        Log.e("onError", "" + msg);
    }

    protected void onMessage(Context context, Intent intent) {
        this.mContext = context;
        this.logCat.log(className, "onMessage", "in");
        final Context mContext = context;
        final String msg = intent.getStringExtra("message");
        this.logCat.log(className, "onMessage", msg);
        new GetNotiSetting(context).setOnGetNotiSetting(new OnNotiSettingListener() {
            public void onNotiSettingListener(int soundVib) {
                GCMService.this.logCat.log(GCMService.className, "notiSet", Integer.toString(soundVib));
                GCMService.this.notification(mContext, msg, soundVib);
            }
        });
    }

    public String getOsVersion() {
        return VERSION.RELEASE;
    }

    private void notification(Context context, String msg, int soundVib) {
        this.logCat.log(className, "notimsg", msg);
        String gubun = "";
        String gubun_num = "";
        String from_email = "";
        String message = "";
        String name = "";
        String use = "";
        try {
            JSONObject jo = new JSONObject(msg);
            gubun_num = jo.getString("gubun_num");
            int iconResource = C0213R.drawable.ic_launcher;
            PreferenceAction preferenceAction = new PreferenceAction(getApplicationContext(), PreferenceAction.PREF_NAME_MY_PROFILE);
            if (gubun_num.equals(LogDM.GLUCOSE_EAT_NONE)) {
                message = jo.getString("my_name") + " " + jo.getString("message");
                if (!preferenceAction.getString(PreferenceAction.MY_EMAIL).equals(jo.getString("target_email"))) {
                    return;
                }
            } else if (gubun_num.equals(LogDM.GLUCOSE_EAT_FASTING) || gubun_num.equals("2") || gubun_num.equals("1") || gubun_num.equals("0")) {
                gubun = jo.getString("gubun");
                from_email = jo.getString("from_email");
                String target_email = jo.getString("target_email");
                message = jo.getString("message");
                name = jo.getString("name");
                if (gubun_num.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                    if (!preferenceAction.getString(PreferenceAction.MY_EMAIL).equals(from_email)) {
                        this.logCat.log(className, "noti0", "2");
                        return;
                    }
                } else if ((gubun_num.equals("0") || gubun_num.equals("1") || gubun_num.equals("2")) && preferenceAction.getString(PreferenceAction.MY_EMAIL).equals(from_email)) {
                    this.logCat.log(className, "nmnmnm", "0");
                    return;
                }
            } else if (gubun_num.equals("5")) {
                message = jo.getString("message");
            } else {
                return;
            }
            String notimessage = context.getString(C0213R.string.noti_message_01);
            if (gubun_num.equals("0") || gubun_num.equals("1") || gubun_num.equals("2") || gubun_num.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                this.intentEmail = from_email;
                this.intentName = name;
            }
            if (gubun_num.equals("0")) {
                iconResource = C0213R.drawable.ic_input_glucose;
            } else if (gubun_num.equals("1")) {
                iconResource = C0213R.drawable.ic_input_insulin;
            } else if (gubun_num.equals("2")) {
                iconResource = C0213R.drawable.ic_input_note;
            } else if (gubun_num.equals(LogDM.GLUCOSE_EAT_FASTING)) {
                iconResource = C0213R.drawable.ic_write;
            } else if (gubun_num.equals(LogDM.GLUCOSE_EAT_NONE)) {
                iconResource = C0213R.drawable.ic_user;
            } else if (gubun_num.equals("5")) {
                iconResource = C0213R.drawable.ic_launcher;
            }
            if (gubun_num.equals("5")) {
                try {
                    use = jo.getString("use");
                    if (!use.equals("test")) {
                        if (use.equals("service")) {
                            Intent popupIntent = new Intent(context, PopupMessage.class).setFlags(268435456);
                            popupIntent.putExtra(PreferenceAction.FRIEND_EMAIL, this.intentEmail);
                            popupIntent.putExtra("FRIEND_NAME", this.intentName);
                            popupIntent.putExtra("PANDING", "PANDING");
                            popupIntent.putExtra("IMG_RESOURCE", Integer.toString(iconResource));
                            popupIntent.putExtra("GUBUN_NUM", gubun_num);
                            popupIntent.putExtra("MESSAGE", message);
                            context.startActivity(popupIntent);
                            return;
                        }
                        return;
                    }
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    this.logCat.log(className, "use", "in2");
                    return;
                }
            }
            preferenceAction = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_NOTIFICATION_IS_USE);
            if (preferenceAction.getString(PreferenceAction.NOTIFICATION_POPUPMESSAGE_IS_USE) == null || preferenceAction.getString(PreferenceAction.NOTIFICATION_POPUPMESSAGE_IS_USE).equals("")) {
                preferenceAction.putString(PreferenceAction.NOTIFICATION_POPUPMESSAGE_IS_USE, "no");
            } else if (preferenceAction.getString(PreferenceAction.NOTIFICATION_POPUPMESSAGE_IS_USE).equals("yes")) {
                NotiDM dm = new NotiDM();
                dm.message = message;
                dm.FRIEND_EMAIL = this.intentEmail;
                dm.FRIEND_NAME = this.intentName;
                dm.GUBUN_NUM = gubun_num;
                dm.iconResource = Integer.toString(iconResource);
                dm.PANDING = "PANDING";
                Message oMsg = Message.obtain();
                oMsg.what = 0;
                oMsg.obj = dm;
                this.toastH.sendMessage(oMsg);
            }
            Intent intent = new Intent(this.mContext, ContainerFragmentActivity.class);
            intent.setFlags(67108864);
            if (gubun_num.equals(LogDM.GLUCOSE_EAT_NONE)) {
                preferenceAction = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
                intent.putExtra(PreferenceAction.FRIEND_EMAIL, preferenceAction.getString(PreferenceAction.MY_EMAIL));
                intent.putExtra("FRIEND_NAME", preferenceAction.getString(PreferenceAction.MY_NAME));
            } else {
                intent.putExtra(PreferenceAction.FRIEND_EMAIL, this.intentEmail);
                intent.putExtra("FRIEND_NAME", this.intentName);
            }
            intent.putExtra("GUBUN_NUM", gubun_num);
            intent.putExtra("PANDING", "PANDING");
            NotificationManager nm = (NotificationManager) getSystemService("notification");
            PendingIntent pIntent = PendingIntent.getActivity(this, notificationId, intent, 134217728);
            Builder builder = new Builder(context);
            switch (soundVib) {
                case 0:
                    this.logCat.log(className, "notiSet", "sON_vON");
                    builder.setContentIntent(pIntent);
                    builder.setSmallIcon(C0213R.drawable.ic_launcher);
                    builder.setContentTitle(getResources().getString(C0213R.string.noti_message_01));
                    builder.setContentText(message);
                    builder.setAutoCancel(true);
                    builder.setDefaults(-1);
                    builder.setTicker(message);
                    nm.notify(notificationId, builder.build());
                    return;
                case 1:
                    this.logCat.log(className, "notiSet", "sON_vOFF");
                    builder.setDefaults(1);
                    builder.setAutoCancel(true);
                    nm.notify(notificationId, builder.build());
                    return;
                case 2:
                    this.logCat.log(className, "notiSet", "sOFF_vON");
                    builder.setDefaults(2);
                    builder.setAutoCancel(true);
                    nm.notify(notificationId, builder.build());
                    return;
                case 3:
                    this.logCat.log(className, "notiSet", "sOFF_vOFF");
                    builder.setAutoCancel(true);
                    nm.notify(notificationId, builder.build());
                    return;
                case 4:
                    this.logCat.log(className, "notiSet", "sOFF_vOFF_NONE");
                    return;
                default:
                    return;
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
            this.logCat.log(className, "noti failed", "1");
        }
    }

    boolean isRunningApplication() {
        Context context = this.mContext;
        Context context2 = this.mContext;
        for (RunningTaskInfo runningTaskInfo : ((ActivityManager) context.getSystemService("activity")).getRunningTasks(50)) {
            this.logCat.log(className, "task className", runningTaskInfo.baseActivity.getClassName());
            if (runningTaskInfo.baseActivity.getClassName().toString().matches(".*com.sdbio.ContainerFragmentActivity.*")) {
                this.logCat.log(className, "sdbio", "runing");
                return true;
            }
        }
        return false;
    }

    private void makeToast(NotiDM dm) {
        TextView tv = new TextView(getApplicationContext());
        this.logCat.log(className, "makeToast", dm.message);
        tv.setText(dm.message);
        tv.setTextSize(14.0f);
        tv.setTextColor(ViewCompat.MEASURED_STATE_MASK);
        ImageView imgV = new ImageView(getApplication());
        imgV.setLayoutParams(new LayoutParams(45, 45));
        imgV.setPadding(0, 0, 5, 0);
        imgV.setImageResource(Integer.parseInt(dm.iconResource));
        Button closeBt = new Button(getApplication());
        closeBt.setText(C0213R.string.alert_text_cancel);
        closeBt.setVisibility(8);
        LinearLayout lyContainer = new LinearLayout(getApplicationContext());
        lyContainer.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        lyContainer.setOrientation(1);
        lyContainer.setGravity(17);
        lyContainer.setBackgroundResource(C0213R.drawable.pop_round);
        lyContainer.setPadding(15, 30, 15, 30);
        LinearLayout ly0 = new LinearLayout(getApplicationContext());
        ly0.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        ly0.setOrientation(0);
        ly0.setPadding(0, 0, 0, 10);
        ly0.setGravity(48);
        ly0.addView(imgV);
        ly0.addView(tv);
        LinearLayout ly1 = new LinearLayout(getApplicationContext());
        ly1.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        ly1.setGravity(17);
        ly1.addView(closeBt);
        lyContainer.addView(ly0);
        lyContainer.addView(ly1);
        final Toast toast = Toast.makeText(getApplicationContext(), "", 1);
        toast.setView(lyContainer);
        final LongerToastTask longerToastTask = new LongerToastTask((long) 1800, 1000, toast);
        longerToastTask.start();
        lyContainer.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                longerToastTask.cancel();
                toast.cancel();
            }
        });
    }
}
