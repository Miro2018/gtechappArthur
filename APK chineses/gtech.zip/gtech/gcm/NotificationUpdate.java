package com.accumed.gtech.gcm;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.intro.SplashRoute;

public class NotificationUpdate extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.notification);
        Intent intent = new Intent(this, SplashRoute.class);
        intent.setFlags(67108864);
        startActivity(intent);
        finish();
    }
}
