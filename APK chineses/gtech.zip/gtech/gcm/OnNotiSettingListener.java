package com.accumed.gtech.gcm;

public interface OnNotiSettingListener {
    void onNotiSettingListener(int i);
}
