package com.accumed.gtech.gcm;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import com.accumed.gtech.util.LogCat;
import com.google.android.gcm.GCMConstants;
import com.google.android.gcm.GCMRegistrar;

public class GCMManager {
    public static final String PROJECT_ID = "1017211782132";
    public static String registration_id = null;
    final String className = "GCMManager";
    private LogCat logCat;
    private Context mContext;

    public GCMManager(Context c) {
        this.mContext = c;
        this.logCat = new LogCat();
    }

    public void register() {
        this.logCat.log("GCMManager", "register", "in");
        GCMRegistrar.register(this.mContext, PROJECT_ID);
    }

    public void unRegister() {
        GCMRegistrar.unregister(this.mContext);
    }

    public void stopPushService() {
        Intent unregIntent = new Intent(GCMConstants.INTENT_TO_GCM_UNREGISTRATION);
        unregIntent.putExtra(GCMConstants.EXTRA_APPLICATION_PENDING_INTENT, PendingIntent.getBroadcast(this.mContext, 0, new Intent(), 0));
        this.mContext.startService(unregIntent);
    }

    public String getOsVersion() {
        return VERSION.RELEASE;
    }
}
