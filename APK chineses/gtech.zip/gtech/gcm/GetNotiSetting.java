package com.accumed.gtech.gcm;

import android.content.Context;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;

public class GetNotiSetting {
    static final String className = "GetNotiSetting";
    public static final int sOFF_vOFF = 3;
    public static final int sOFF_vOFF_NONE = 4;
    public static final int sOFF_vON = 2;
    public static final int sON_vOFF = 1;
    public static final int sON_vON = 0;
    LogCat logCat = new LogCat();
    OnNotiSettingListener onNotiSettingListener;
    String soundVib;
    int sound_vib;

    public GetNotiSetting(Context context) {
        PreferenceAction pref = new PreferenceAction(context, PreferenceAction.PREF_NAME_NOTIFICATION_IS_USE);
        String notiDefaultSettng = pref.getString(PreferenceAction.NOTIFICATION_IS_DEFAULT_SETTING);
        String useSound = pref.getString(PreferenceAction.NOTIFICATION_IS_USE_SOUND);
        String useVibration = pref.getString(PreferenceAction.NOTIFICATION_IS_USE_VIBRATION);
        String useNone = pref.getString(PreferenceAction.NOTIFICATION_IS_USE_NONE);
        this.logCat.log(className, "sssuseSound + useVibration", useSound + useVibration);
        if (notiDefaultSettng == null || notiDefaultSettng.equals("") || notiDefaultSettng.equals("yes")) {
            if ((useSound == null || useSound.equals("") || useSound.equals("yes")) && (useVibration == null || useVibration.equals("") || useVibration.equals("yes"))) {
                this.sound_vib = 0;
                this.logCat.log(className, "alram", "sON_vON");
            }
            if ((useSound == null || useSound.equals("") || useSound.equals("yes")) && useVibration.equals("no")) {
                this.sound_vib = 1;
                this.logCat.log(className, "alram", "sON_vOFF");
            }
            if (useSound.equals("no") && (useVibration == null || useVibration.equals("") || useVibration.equals("yes"))) {
                this.sound_vib = 2;
                this.logCat.log(className, "alram", "sOFF_vON");
            }
            if (useSound.equals("no") && useVibration.equals("no")) {
                this.sound_vib = 3;
                this.logCat.log(className, "alram", "sOFF_vOFF");
            }
            if (useSound.equals("no") && useVibration.equals("no") && useNone.equals("no")) {
                this.sound_vib = 4;
                this.logCat.log(className, "alram", "sOFF_vOFF_NONE");
                return;
            }
            return;
        }
        this.sound_vib = 0;
    }

    void setOnGetNotiSetting(OnNotiSettingListener onNotiSettingListener) {
        this.logCat.log(className, "sound_vib", Integer.toString(this.sound_vib));
        onNotiSettingListener.onNotiSettingListener(this.sound_vib);
    }
}
