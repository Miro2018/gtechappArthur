package com.accumed.gtech.gcm;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import com.accumed.gtech.util.LogCat;

public class GCMReceiver extends BroadcastReceiver {
    final String className = "GCMReceiver";
    LogCat logCat;

    public final void onReceive(Context context, Intent intent) {
        this.logCat = new LogCat();
        this.logCat.log("GCMReceiver", "onReceive", "in");
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService("connectivity");
        NetworkInfo mobile = manager.getNetworkInfo(0);
        NetworkInfo wifi = manager.getNetworkInfo(1);
        try {
            if ((mobile.isConnected() || wifi.isConnected()) && !getServiceTaskName(context)) {
                this.logCat.log("GCMReceiver", "getServiceTaskName", "false");
                intent.setClassName(context, GCMService.class.getName());
                context.startService(intent);
            }
        } catch (Exception e) {
            intent.setClassName(context, GCMService.class.getName());
            context.startService(intent);
        }
        if (intent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
            NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
            NetworkInfo mobNetInfo = connectivityManager.getNetworkInfo(0);
            try {
                if ((mobile.isConnected() || wifi.isConnected()) && !getServiceTaskName(context)) {
                    intent.setClassName(context, GCMService.class.getName());
                    context.startService(intent);
                }
            } catch (Exception e2) {
                intent.setClassName(context, GCMService.class.getName());
                context.startService(intent);
            }
        }
    }

    private boolean getServiceTaskName(Context context) {
        for (RunningServiceInfo runningTaskInfo : ((ActivityManager) context.getSystemService("activity")).getRunningServices(30)) {
            this.logCat.log("GCMReceiver", "runningTaskInfo.service.getClassName()", runningTaskInfo.service.getClassName());
            if (runningTaskInfo.service.getClassName().equals("com.accumed")) {
                Log.e("getServiceTaskName", "running to service");
                return true;
            }
        }
        return false;
    }
}
