package com.accumed.gtech.datamodel;

import java.io.Serializable;

public class LogDM implements Serializable {
    public static final String GLUCOSE_EAT_AFTER = "0";
    public static final int GLUCOSE_EAT_AFTER_NUM = 0;
    public static final String GLUCOSE_EAT_BEFORE = "1";
    public static final int GLUCOSE_EAT_BEFORE_NUM = 1;
    public static final String GLUCOSE_EAT_CONTROL = "2";
    public static final int GLUCOSE_EAT_CONTROL_NUM = 2;
    public static final String GLUCOSE_EAT_FASTING = "3";
    public static final int GLUCOSE_EAT_FASTING_NUM = 3;
    public static final String GLUCOSE_EAT_NONE = "4";
    public static final int GLUCOSE_EAT_NONE_NUM = 4;
    private static final long serialVersionUID = 1;
    public String _id = "";
    public String blood_sugar_eat = "";
    public String blood_sugar_eat_origin = "";
    public String blood_sugar_type = "";
    public String blood_sugar_value = "";
    public String category = "";
    public String device_id = "";
    public String input_date = "";
    public String insulin_name = "";
    public String insulin_type = "";
    public String insulin_value = "";
    public String note_content = "";
    public String note_picture = "";
    public String note_picture_thumb = "";
    public String note_type = "";
    public String seq = "";
    public String system_date = "";
    public String targetemail = "";
    public String update_flag = "";
    public String user_id = "";
}
