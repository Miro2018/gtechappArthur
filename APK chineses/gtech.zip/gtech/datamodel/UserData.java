package com.accumed.gtech.datamodel;

public class UserData {
    public static String column_agreement = "agreement";
    public static String column_birthday = "birthday";
    public static String column_blood_sugar_type = "blood_sugar_type";
    public static String column_blood_sugar_unit = "blood_sugar_unit";
    public static String column_data_save_period = "data_save_period";
    public static String column_date_method = "date_method";
    public static String column_gender = "gender";
    public static String column_height = "height";
    public static String column_height_unit = "height_unit";
    public static String column_high_blood_sugar = "high_blood_sugar";
    public static String column_language = "language";
    public static String column_low_blood_sugar = "low_blood_sugar";
    public static String column_name = "name";
    public static String column_occurday = "occurday";
    public static String column_seq = "seq";
    public static String column_time_method = "time_method";
    public static String column_user_email = "user_email";
    public static String column_user_id = "user_id";
    public static String column_user_password = "user_password";
    public static String column_viewer_birthday = "viewer_birthday";
    public static String column_viewer_created_at = "viewer_created_at";
    public static String column_viewer_datetype = "viewer_datetype";
    public static String column_viewer_diabetestype = "viewer_diabetestype";
    public static String column_viewer_diabeticsince = "viewer_diabeticsince";
    public static String column_viewer_email = "viewer_email";
    public static String column_viewer_gender = "viewer_gender";
    public static String column_viewer_glucoseunit = "viewer_glucoseunit";
    public static String column_viewer_height = "viewer_height";
    public static String column_viewer_height_unit = "viewer_height_unit";
    public static String column_viewer_hyper = "viewer_hyper";
    public static String column_viewer_hypo = "viewer_hypo";
    public static String column_viewer_id = "viewer_id";
    public static String column_viewer_language = "viewer_language";
    public static String column_viewer_name = "viewer_name";
    public static String column_viewer_photo1 = "viewer_photo1";
    public static String column_viewer_photo2 = "viewer_photo2";
    public static String column_viewer_timetype = "viewer_timetype";
    public static String column_viewer_weight = "viewer_weight";
    public static String column_viewer_weight_unit = "viewer_weight_unit";
    public static String column_weight = "weight";
    public static String column_weight_unit = "weight_unit";
    public static String table_name = "user";
    private int agreement;
    private String birthday;
    private int blood_sugar_type;
    private int blood_sugar_unit;
    private int data_save_period;
    private int date_method;
    private int gender;
    private String height;
    private int height_unit;
    private String high_blood_sugar;
    private int language;
    private String low_blood_sugar;
    private String name;
    private String occurday;
    private int seq;
    private int time_method;
    private String user_email;
    private String user_id;
    private String user_password;
    private String viewer_birthday;
    private String viewer_created_at;
    private int viewer_datetype;
    private int viewer_diabetestype;
    private String viewer_diabeticsince;
    private String viewer_email;
    private int viewer_gender;
    private int viewer_glucoseunit;
    private String viewer_height;
    private int viewer_height_unit;
    private String viewer_hyper;
    private String viewer_hypo;
    private String viewer_id;
    private int viewer_language;
    private String viewer_name;
    private String viewer_photo1;
    private String viewer_photo2;
    private int viewer_timetype;
    private String viewer_weight;
    private int viewer_weight_unit;
    private String weight;
    private int weight_unit;

    public int getSeq() {
        return this.seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public String getUser_email() {
        return this.user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getUser_password() {
        return this.user_password;
    }

    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }

    public String getUser_id() {
        return this.user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public int getAgreement() {
        return this.agreement;
    }

    public void setAgreement(int agreement) {
        this.agreement = agreement;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthday() {
        return this.birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public int getGender() {
        return this.gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getWeight() {
        return this.weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public int getWeight_unit() {
        return this.weight_unit;
    }

    public void setWeight_unit(int weight_unit) {
        this.weight_unit = weight_unit;
    }

    public String getHeight() {
        return this.height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public int getHeight_unit() {
        return this.height_unit;
    }

    public void setHeight_unit(int height_unit) {
        this.height_unit = height_unit;
    }

    public String getOccurday() {
        return this.occurday;
    }

    public void setOccurday(String occurday) {
        this.occurday = occurday;
    }

    public int getBlood_sugar_type() {
        return this.blood_sugar_type;
    }

    public void setBlood_sugar_type(int blood_sugar_type) {
        this.blood_sugar_type = blood_sugar_type;
    }

    public int getBlood_sugar_unit() {
        return this.blood_sugar_unit;
    }

    public void setBlood_sugar_unit(int blood_sugar_unit) {
        this.blood_sugar_unit = blood_sugar_unit;
    }

    public String getHigh_blood_sugar() {
        return this.high_blood_sugar;
    }

    public void setHigh_blood_sugar(String high_blood_sugar) {
        this.high_blood_sugar = high_blood_sugar;
    }

    public String getLow_blood_sugar() {
        return this.low_blood_sugar;
    }

    public void setLow_blood_sugar(String low_blood_sugar) {
        this.low_blood_sugar = low_blood_sugar;
    }

    public int getDate_method() {
        return this.date_method;
    }

    public void setDate_method(int date_method) {
        this.date_method = date_method;
    }

    public int getTime_method() {
        return this.time_method;
    }

    public void setTime_method(int time_method) {
        this.time_method = time_method;
    }

    public int getLanguage() {
        return this.language;
    }

    public void setLanguage(int language) {
        this.language = language;
    }

    public int getData_save_period() {
        return this.data_save_period;
    }

    public void setData_save_period(int data_save_period) {
        this.data_save_period = data_save_period;
    }

    public String getViewer_email() {
        return this.viewer_email;
    }

    public void setViewer_email(String viewer_email) {
        this.viewer_email = viewer_email;
    }

    public String getViewer_id() {
        return this.viewer_id;
    }

    public void setViewer_id(String viewer_id) {
        this.viewer_id = viewer_id;
    }

    public String getViewer_name() {
        return this.viewer_name;
    }

    public void setViewer_name(String viewer_name) {
        this.viewer_name = viewer_name;
    }

    public String getViewer_birthday() {
        return this.viewer_birthday;
    }

    public void setViewer_birthday(String viewer_birthday) {
        this.viewer_birthday = viewer_birthday;
    }

    public int getViewer_gender() {
        return this.viewer_gender;
    }

    public void setViewer_gender(int viewer_gender) {
        this.viewer_gender = viewer_gender;
    }

    public String getViewer_weight() {
        return this.viewer_weight;
    }

    public void setViewer_weight(String viewer_weight) {
        this.viewer_weight = viewer_weight;
    }

    public int getViewer_weight_unit() {
        return this.viewer_weight_unit;
    }

    public void setViewer_weight_unit(int viewer_weight_unit) {
        this.viewer_weight_unit = viewer_weight_unit;
    }

    public String getViewer_height() {
        return this.viewer_height;
    }

    public void setViewer_height(String viewer_height) {
        this.viewer_height = viewer_height;
    }

    public int getViewer_height_unit() {
        return this.viewer_height_unit;
    }

    public void setViewer_height_unit(int viewer_height_unit) {
        this.viewer_height_unit = viewer_height_unit;
    }

    public String getViewer_diabeticsince() {
        return this.viewer_diabeticsince;
    }

    public void setViewer_diabeticsince(String viewer_diabeticsince) {
        this.viewer_diabeticsince = viewer_diabeticsince;
    }

    public int getViewer_diabetestype() {
        return this.viewer_diabetestype;
    }

    public void setViewer_diabetestype(int viewer_diabetestype) {
        this.viewer_diabetestype = viewer_diabetestype;
    }

    public int getViewer_glucoseunit() {
        return this.viewer_glucoseunit;
    }

    public void setViewer_glucoseunit(int viewer_glucoseunit) {
        this.viewer_glucoseunit = viewer_glucoseunit;
    }

    public String getViewer_hypo() {
        return this.viewer_hypo;
    }

    public void setViewer_hypo(String viewer_hypo) {
        this.viewer_hypo = viewer_hypo;
    }

    public String getViewer_hyper() {
        return this.viewer_hyper;
    }

    public void setViewer_hyper(String viewer_hyper) {
        this.viewer_hyper = viewer_hyper;
    }

    public int getViewer_datetype() {
        return this.viewer_datetype;
    }

    public void setViewer_datetype(int viewer_datetype) {
        this.viewer_datetype = viewer_datetype;
    }

    public int getViewer_timetype() {
        return this.viewer_timetype;
    }

    public void setViewer_timetype(int viewer_timetype) {
        this.viewer_timetype = viewer_timetype;
    }

    public int getViewer_language() {
        return this.viewer_language;
    }

    public void setViewer_language(int viewer_language) {
        this.viewer_language = viewer_language;
    }

    public String getViewer_photo1() {
        return this.viewer_photo1;
    }

    public void setViewer_photo1(String viewer_photo1) {
        this.viewer_photo1 = viewer_photo1;
    }

    public String getViewer_photo2() {
        return this.viewer_photo2;
    }

    public void setViewer_photo2(String viewer_photo2) {
        this.viewer_photo2 = viewer_photo2;
    }

    public String getViewer_created_at() {
        return this.viewer_created_at;
    }

    public void setViewer_created_at(String viewer_created_at) {
        this.viewer_created_at = viewer_created_at;
    }

    public static String getCreateQuery() {
        return (((((((((((((((((((((((((((((((((((((((((("" + "create table if not exists " + table_name + " (") + column_seq + " integer primary key autoincrement, ") + column_user_email + " text, ") + column_user_password + " text, ") + column_user_id + " text, ") + column_agreement + " integer, ") + column_name + " text, ") + column_birthday + " text, ") + column_gender + " integer, ") + column_weight + " text, ") + column_weight_unit + " integer, ") + column_height + " text, ") + column_height_unit + " integer, ") + column_occurday + " text, ") + column_blood_sugar_type + " integer, ") + column_blood_sugar_unit + " integer, ") + column_high_blood_sugar + " text, ") + column_low_blood_sugar + " text, ") + column_date_method + " integer, ") + column_time_method + " integer, ") + column_language + " integer, ") + column_data_save_period + " integer, ") + column_viewer_email + " text, ") + column_viewer_id + " text, ") + column_viewer_name + " text, ") + column_viewer_birthday + " text, ") + column_viewer_gender + " text, ") + column_viewer_weight + " text, ") + column_viewer_weight_unit + " text, ") + column_viewer_height + " text, ") + column_viewer_height_unit + " text, ") + column_viewer_diabeticsince + " text, ") + column_viewer_diabetestype + " text, ") + column_viewer_glucoseunit + " text, ") + column_viewer_hypo + " text, ") + column_viewer_hyper + " text, ") + column_viewer_datetype + " text, ") + column_viewer_timetype + " text, ") + column_viewer_language + " text, ") + column_viewer_photo1 + " text, ") + column_viewer_photo2 + " text, ") + column_viewer_created_at + " text") + ");";
    }
}
