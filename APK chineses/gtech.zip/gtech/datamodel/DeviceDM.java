package com.accumed.gtech.datamodel;

public class DeviceDM {
    public String _id = "";
    public String device_id = "";
    public String seq = "";
    public String update_date = "";
}
