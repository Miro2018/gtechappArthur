package com.accumed.gtech.datamodel;

import java.util.ArrayList;

public class InsulinDM {
    public ArrayList<String> nameList = new ArrayList();
    public String type = "";
}
