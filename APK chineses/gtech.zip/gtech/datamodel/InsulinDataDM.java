package com.accumed.gtech.datamodel;

import java.util.ArrayList;

public class InsulinDataDM {
    public ArrayList<String> nameDataList = new ArrayList();
    public String typeData = "";
}
