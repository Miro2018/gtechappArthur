package com.accumed.gtech.datamodel;

import android.content.Context;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;

public class UserProfileSettingData {
    static final String className = "UserProfileSettingData";
    public String USER_BIRTH = "";
    public String USER_BLOOD_SUGAR_TYPE = "";
    public String USER_BLOOD_SUGAR_UNIT = "";
    public String USER_DATA_SAVE_PERIOD = "";
    public String USER_DATE_METHOD = "";
    public String USER_EMAIL = "";
    public String USER_GCM_STR = "";
    public String USER_GENDER = "";
    public String USER_HEIGHT = "";
    public String USER_HEIGHT_UNIT = "";
    public String USER_HIGH_BLOOD_SUGAR = "";
    public String USER_LANGUAGE = "";
    public String USER_LOW_BLOOD_SUGAR = "";
    public String USER_NAME = "";
    public String USER_OCCOURDAY = "";
    public String USER_PASSWORD = "";
    public String USER_TIME_METHOD = "";
    public String USER_WEIGHT = "";
    public String USER_WEIGHT_UNIT = "";
    boolean amI = true;
    LogCat logCat = new LogCat();
    Context mContext;
    PreferenceAction prefMyProfile;
    PreferenceAction prefMySetting;

    public UserProfileSettingData(Context c) {
        this.mContext = c;
        this.prefMyProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        this.prefMySetting = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        changeData();
    }

    public void changeData() {
        if (this.USER_EMAIL == null) {
            this.logCat.log(className, "change Data", "my data0");
            getMyProfileSetting();
        } else if (this.USER_EMAIL.equals(this.prefMyProfile.getString(PreferenceAction.MY_EMAIL)) || this.USER_EMAIL.equals("")) {
            this.logCat.log(className, "change Data", "my data1");
            getMyProfileSetting();
        } else {
            this.logCat.log(className, "changeData", "friend dada");
        }
    }

    private void getMyProfileSetting() {
        init();
        this.USER_EMAIL = this.prefMyProfile.getString(PreferenceAction.MY_EMAIL);
        this.USER_NAME = this.prefMyProfile.getString(PreferenceAction.MY_NAME);
        this.USER_BIRTH = this.prefMyProfile.getString(PreferenceAction.MY_BIRTH);
        this.USER_GENDER = this.prefMyProfile.getString(PreferenceAction.MY_GENDER);
        this.USER_HEIGHT = this.prefMyProfile.getString(PreferenceAction.MY_HEIGHT);
        this.USER_HEIGHT_UNIT = this.prefMyProfile.getString(PreferenceAction.MY_HEIGHT_UNIT);
        this.USER_WEIGHT = this.prefMyProfile.getString(PreferenceAction.MY_WEIGHT);
        this.USER_WEIGHT_UNIT = this.prefMyProfile.getString(PreferenceAction.MY_WEIGHT_UNIT);
        this.USER_OCCOURDAY = this.prefMyProfile.getString(PreferenceAction.MY_OCCOURDAY);
        this.USER_BLOOD_SUGAR_TYPE = this.prefMyProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_TYPE);
        this.USER_BLOOD_SUGAR_UNIT = this.prefMyProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
        this.USER_HIGH_BLOOD_SUGAR = this.prefMyProfile.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR);
        this.logCat.log(className, "USER_HIGH_BLOOD_SUGAR", this.USER_HIGH_BLOOD_SUGAR);
        this.USER_LOW_BLOOD_SUGAR = this.prefMyProfile.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR);
        this.USER_DATE_METHOD = this.prefMySetting.getString(PreferenceAction.MY_DATE_METHOD);
        this.USER_TIME_METHOD = this.prefMySetting.getString(PreferenceAction.MY_TIME_METHOD);
        this.USER_LANGUAGE = this.prefMySetting.getString(PreferenceAction.MY_LANGUAGE);
    }

    public boolean isMe(String userEmail) {
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        if (userEmail == null || userEmail.equals(pref.getString(PreferenceAction.MY_EMAIL)) || userEmail.equals("")) {
            return true;
        }
        return false;
    }

    public void init() {
        this.USER_NAME = "";
        this.USER_BIRTH = "";
        this.USER_GENDER = "";
        this.USER_HEIGHT = "";
        this.USER_HEIGHT_UNIT = "";
        this.USER_WEIGHT = "";
        this.USER_WEIGHT_UNIT = "";
        this.USER_OCCOURDAY = "";
        this.USER_BLOOD_SUGAR_TYPE = "";
        this.USER_BLOOD_SUGAR_UNIT = "";
        this.USER_HIGH_BLOOD_SUGAR = "";
        this.USER_LOW_BLOOD_SUGAR = "";
        this.USER_DATE_METHOD = "";
        this.USER_TIME_METHOD = "";
        this.USER_LANGUAGE = "";
    }
}
