package com.accumed.gtech.datamodel;

public class ChartData {
    private String chart01_color01;
    private String chart01_color02;
    private String chart01_color03;
    private String chart01_color04;
    private String chart01_count01;
    private String chart01_count02;
    private String chart01_count03;
    private String chart01_percent01;
    private String chart01_percent02;
    private String chart01_percent03;
    private String chart02_color01;
    private String chart02_color02;
    private String chart02_color03;
    private String chart02_count01;
    private String chart02_count02;
    private String chart02_count03;
    private String chart02_percent01;
    private String chart02_percent02;
    private String chart02_percent03;
    private String chart03_color01;
    private String chart03_color02;
    private String chart03_color03;
    private String chart03_color04;
    private String chart03_count01;
    private String chart03_count02;
    private String chart03_count03;
    private String chart03_percent01;
    private String chart03_percent02;
    private String chart03_percent03;
    private String chart04_color01;
    private String chart04_color02;
    private String chart04_color03;
    private String chart04_color04;
    private String chart04_count01;
    private String chart04_count02;
    private String chart04_count03;
    private String chart04_percent01;
    private String chart04_percent02;
    private String chart04_percent03;
    private String chart_average_count;
    private String chart_total_count;
    private String info_birth;
    private String info_date01;
    private String info_date02;
    private String info_language;
    private String info_name;
    private String info_preriod;
    private String info_since;
    private String table01_avg01;
    private String table01_avg02;
    private String table01_avg03;
    private String table01_avg04;
    private String table01_max01;
    private String table01_max02;
    private String table01_max03;
    private String table01_max04;
    private String table01_min01;
    private String table01_min02;
    private String table01_min03;
    private String table01_min04;
    private String table01_sd01;
    private String table01_sd02;
    private String table01_sd03;
    private String table01_sd04;
    private String table01_title;
    private String table02_avg01;
    private String table02_avg02;
    private String table02_avg03;
    private String table02_avg04;
    private String table02_avg05;
    private String table02_avg06;
    private String table02_avg07;
    private String table02_max01;
    private String table02_max02;
    private String table02_max03;
    private String table02_max04;
    private String table02_max05;
    private String table02_max06;
    private String table02_max07;
    private String table02_min01;
    private String table02_min02;
    private String table02_min03;
    private String table02_min04;
    private String table02_min05;
    private String table02_min06;
    private String table02_min07;
    private String table02_sd01;
    private String table02_sd02;
    private String table02_sd03;
    private String table02_sd04;
    private String table02_sd05;
    private String table02_sd06;
    private String table02_sd07;
    private String table02_title;

    public String getInfo_preriod() {
        return this.info_preriod;
    }

    public void setInfo_preriod(String info_preriod) {
        this.info_preriod = info_preriod;
    }

    public String getInfo_name() {
        return this.info_name;
    }

    public void setInfo_name(String info_name) {
        this.info_name = info_name;
    }

    public String getInfo_birth() {
        return this.info_birth;
    }

    public void setInfo_birth(String info_birth) {
        this.info_birth = info_birth;
    }

    public String getInfo_since() {
        return this.info_since;
    }

    public void setInfo_since(String info_since) {
        this.info_since = info_since;
    }

    public String getInfo_date01() {
        return this.info_date01;
    }

    public void setInfo_date01(String info_date01) {
        this.info_date01 = info_date01;
    }

    public String getInfo_date02() {
        return this.info_date02;
    }

    public void setInfo_date02(String info_date02) {
        this.info_date02 = info_date02;
    }

    public String getInfo_language() {
        return this.info_language;
    }

    public void setInfo_language(String info_language) {
        this.info_language = info_language;
    }

    public String getChart_total_count() {
        return this.chart_total_count;
    }

    public void setChart_total_count(String chart_total_count) {
        this.chart_total_count = chart_total_count;
    }

    public String getChart_average_count() {
        return this.chart_average_count;
    }

    public void setChart_average_count(String chart_average_count) {
        this.chart_average_count = chart_average_count;
    }

    public String getChart01_color01() {
        return this.chart01_color01;
    }

    public void setChart01_color01(String chart01_color01) {
        this.chart01_color01 = chart01_color01;
    }

    public String getChart01_color02() {
        return this.chart01_color02;
    }

    public void setChart01_color02(String chart01_color02) {
        this.chart01_color02 = chart01_color02;
    }

    public String getChart01_color03() {
        return this.chart01_color03;
    }

    public void setChart01_color03(String chart01_color03) {
        this.chart01_color03 = chart01_color03;
    }

    public String getChart01_color04() {
        return this.chart01_color04;
    }

    public void setChart01_color04(String chart01_color04) {
        this.chart01_color04 = chart01_color04;
    }

    public String getChart02_color01() {
        return this.chart02_color01;
    }

    public void setChart02_color01(String chart02_color01) {
        this.chart02_color01 = chart02_color01;
    }

    public String getChart02_color02() {
        return this.chart02_color02;
    }

    public void setChart02_color02(String chart02_color02) {
        this.chart02_color02 = chart02_color02;
    }

    public String getChart02_color03() {
        return this.chart02_color03;
    }

    public void setChart02_color03(String chart02_color03) {
        this.chart02_color03 = chart02_color03;
    }

    public String getChart03_color01() {
        return this.chart03_color01;
    }

    public void setChart03_color01(String chart03_color01) {
        this.chart03_color01 = chart03_color01;
    }

    public String getChart03_color02() {
        return this.chart03_color02;
    }

    public void setChart03_color02(String chart03_color02) {
        this.chart03_color02 = chart03_color02;
    }

    public String getChart03_color03() {
        return this.chart03_color03;
    }

    public void setChart03_color03(String chart03_color03) {
        this.chart03_color03 = chart03_color03;
    }

    public String getChart03_color04() {
        return this.chart03_color04;
    }

    public void setChart03_color04(String chart03_color04) {
        this.chart03_color04 = chart03_color04;
    }

    public String getChart04_color01() {
        return this.chart04_color01;
    }

    public void setChart04_color01(String chart04_color01) {
        this.chart04_color01 = chart04_color01;
    }

    public String getChart04_color02() {
        return this.chart04_color02;
    }

    public void setChart04_color02(String chart04_color02) {
        this.chart04_color02 = chart04_color02;
    }

    public String getChart04_color03() {
        return this.chart04_color03;
    }

    public void setChart04_color03(String chart04_color03) {
        this.chart04_color03 = chart04_color03;
    }

    public String getChart04_color04() {
        return this.chart04_color04;
    }

    public void setChart04_color04(String chart04_color04) {
        this.chart04_color04 = chart04_color04;
    }

    public String getChart01_count01() {
        return this.chart01_count01;
    }

    public void setChart01_count01(String chart01_count01) {
        this.chart01_count01 = chart01_count01;
    }

    public String getChart01_count02() {
        return this.chart01_count02;
    }

    public void setChart01_count02(String chart01_count02) {
        this.chart01_count02 = chart01_count02;
    }

    public String getChart01_count03() {
        return this.chart01_count03;
    }

    public void setChart01_count03(String chart01_count03) {
        this.chart01_count03 = chart01_count03;
    }

    public String getChart02_count01() {
        return this.chart02_count01;
    }

    public void setChart02_count01(String chart02_count01) {
        this.chart02_count01 = chart02_count01;
    }

    public String getChart02_count02() {
        return this.chart02_count02;
    }

    public void setChart02_count02(String chart02_count02) {
        this.chart02_count02 = chart02_count02;
    }

    public String getChart02_count03() {
        return this.chart02_count03;
    }

    public void setChart02_count03(String chart02_count03) {
        this.chart02_count03 = chart02_count03;
    }

    public String getChart03_count01() {
        return this.chart03_count01;
    }

    public void setChart03_count01(String chart03_count01) {
        this.chart03_count01 = chart03_count01;
    }

    public String getChart03_count02() {
        return this.chart03_count02;
    }

    public void setChart03_count02(String chart03_count02) {
        this.chart03_count02 = chart03_count02;
    }

    public String getChart03_count03() {
        return this.chart03_count03;
    }

    public void setChart03_count03(String chart03_count03) {
        this.chart03_count03 = chart03_count03;
    }

    public String getChart04_count01() {
        return this.chart04_count01;
    }

    public void setChart04_count01(String chart04_count01) {
        this.chart04_count01 = chart04_count01;
    }

    public String getChart04_count02() {
        return this.chart04_count02;
    }

    public void setChart04_count02(String chart04_count02) {
        this.chart04_count02 = chart04_count02;
    }

    public String getChart04_count03() {
        return this.chart04_count03;
    }

    public void setChart04_count03(String chart04_count03) {
        this.chart04_count03 = chart04_count03;
    }

    public String getChart01_percent01() {
        return this.chart01_percent01;
    }

    public void setChart01_percent01(String chart01_percent01) {
        this.chart01_percent01 = chart01_percent01;
    }

    public String getChart01_percent02() {
        return this.chart01_percent02;
    }

    public void setChart01_percent02(String chart01_percent02) {
        this.chart01_percent02 = chart01_percent02;
    }

    public String getChart01_percent03() {
        return this.chart01_percent03;
    }

    public void setChart01_percent03(String chart01_percent03) {
        this.chart01_percent03 = chart01_percent03;
    }

    public String getChart02_percent01() {
        return this.chart02_percent01;
    }

    public void setChart02_percent01(String chart02_percent01) {
        this.chart02_percent01 = chart02_percent01;
    }

    public String getChart02_percent02() {
        return this.chart02_percent02;
    }

    public void setChart02_percent02(String chart02_percent02) {
        this.chart02_percent02 = chart02_percent02;
    }

    public String getChart02_percent03() {
        return this.chart02_percent03;
    }

    public void setChart02_percent03(String chart02_percent03) {
        this.chart02_percent03 = chart02_percent03;
    }

    public String getChart03_percent01() {
        return this.chart03_percent01;
    }

    public void setChart03_percent01(String chart03_percent01) {
        this.chart03_percent01 = chart03_percent01;
    }

    public String getChart03_percent02() {
        return this.chart03_percent02;
    }

    public void setChart03_percent02(String chart03_percent02) {
        this.chart03_percent02 = chart03_percent02;
    }

    public String getChart03_percent03() {
        return this.chart03_percent03;
    }

    public void setChart03_percent03(String chart03_percent03) {
        this.chart03_percent03 = chart03_percent03;
    }

    public String getChart04_percent01() {
        return this.chart04_percent01;
    }

    public void setChart04_percent01(String chart04_percent01) {
        this.chart04_percent01 = chart04_percent01;
    }

    public String getChart04_percent02() {
        return this.chart04_percent02;
    }

    public void setChart04_percent02(String chart04_percent02) {
        this.chart04_percent02 = chart04_percent02;
    }

    public String getChart04_percent03() {
        return this.chart04_percent03;
    }

    public void setChart04_percent03(String chart04_percent03) {
        this.chart04_percent03 = chart04_percent03;
    }

    public String getTable01_title() {
        return this.table01_title;
    }

    public void setTable01_title(String table01_title) {
        this.table01_title = table01_title;
    }

    public String getTable01_avg01() {
        return this.table01_avg01;
    }

    public void setTable01_avg01(String table01_avg01) {
        this.table01_avg01 = table01_avg01;
    }

    public String getTable01_avg02() {
        return this.table01_avg02;
    }

    public void setTable01_avg02(String table01_avg02) {
        this.table01_avg02 = table01_avg02;
    }

    public String getTable01_avg03() {
        return this.table01_avg03;
    }

    public void setTable01_avg03(String table01_avg03) {
        this.table01_avg03 = table01_avg03;
    }

    public String getTable01_avg04() {
        return this.table01_avg04;
    }

    public void setTable01_avg04(String table01_avg04) {
        this.table01_avg04 = table01_avg04;
    }

    public String getTable01_sd01() {
        return this.table01_sd01;
    }

    public void setTable01_sd01(String table01_sd01) {
        this.table01_sd01 = table01_sd01;
    }

    public String getTable01_sd02() {
        return this.table01_sd02;
    }

    public void setTable01_sd02(String table01_sd02) {
        this.table01_sd02 = table01_sd02;
    }

    public String getTable01_sd03() {
        return this.table01_sd03;
    }

    public void setTable01_sd03(String table01_sd03) {
        this.table01_sd03 = table01_sd03;
    }

    public String getTable01_sd04() {
        return this.table01_sd04;
    }

    public void setTable01_sd04(String table01_sd04) {
        this.table01_sd04 = table01_sd04;
    }

    public String getTable01_max01() {
        return this.table01_max01;
    }

    public void setTable01_max01(String table01_max01) {
        this.table01_max01 = table01_max01;
    }

    public String getTable01_max02() {
        return this.table01_max02;
    }

    public void setTable01_max02(String table01_max02) {
        this.table01_max02 = table01_max02;
    }

    public String getTable01_max03() {
        return this.table01_max03;
    }

    public void setTable01_max03(String table01_max03) {
        this.table01_max03 = table01_max03;
    }

    public String getTable01_max04() {
        return this.table01_max04;
    }

    public void setTable01_max04(String table01_max04) {
        this.table01_max04 = table01_max04;
    }

    public String getTable01_min01() {
        return this.table01_min01;
    }

    public void setTable01_min01(String table01_min01) {
        this.table01_min01 = table01_min01;
    }

    public String getTable01_min02() {
        return this.table01_min02;
    }

    public void setTable01_min02(String table01_min02) {
        this.table01_min02 = table01_min02;
    }

    public String getTable01_min03() {
        return this.table01_min03;
    }

    public void setTable01_min03(String table01_min03) {
        this.table01_min03 = table01_min03;
    }

    public String getTable01_min04() {
        return this.table01_min04;
    }

    public void setTable01_min04(String table01_min04) {
        this.table01_min04 = table01_min04;
    }

    public String getTable02_title() {
        return this.table02_title;
    }

    public void setTable02_title(String table02_title) {
        this.table02_title = table02_title;
    }

    public String getTable02_avg01() {
        return this.table02_avg01;
    }

    public void setTable02_avg01(String table02_avg01) {
        this.table02_avg01 = table02_avg01;
    }

    public String getTable02_avg02() {
        return this.table02_avg02;
    }

    public void setTable02_avg02(String table02_avg02) {
        this.table02_avg02 = table02_avg02;
    }

    public String getTable02_avg03() {
        return this.table02_avg03;
    }

    public void setTable02_avg03(String table02_avg03) {
        this.table02_avg03 = table02_avg03;
    }

    public String getTable02_avg04() {
        return this.table02_avg04;
    }

    public void setTable02_avg04(String table02_avg04) {
        this.table02_avg04 = table02_avg04;
    }

    public String getTable02_avg05() {
        return this.table02_avg05;
    }

    public void setTable02_avg05(String table02_avg05) {
        this.table02_avg05 = table02_avg05;
    }

    public String getTable02_avg06() {
        return this.table02_avg06;
    }

    public void setTable02_avg06(String table02_avg06) {
        this.table02_avg06 = table02_avg06;
    }

    public String getTable02_avg07() {
        return this.table02_avg07;
    }

    public void setTable02_avg07(String table02_avg07) {
        this.table02_avg07 = table02_avg07;
    }

    public String getTable02_sd01() {
        return this.table02_sd01;
    }

    public void setTable02_sd01(String table02_sd01) {
        this.table02_sd01 = table02_sd01;
    }

    public String getTable02_sd02() {
        return this.table02_sd02;
    }

    public void setTable02_sd02(String table02_sd02) {
        this.table02_sd02 = table02_sd02;
    }

    public String getTable02_sd03() {
        return this.table02_sd03;
    }

    public void setTable02_sd03(String table02_sd03) {
        this.table02_sd03 = table02_sd03;
    }

    public String getTable02_sd04() {
        return this.table02_sd04;
    }

    public void setTable02_sd04(String table02_sd04) {
        this.table02_sd04 = table02_sd04;
    }

    public String getTable02_sd05() {
        return this.table02_sd05;
    }

    public void setTable02_sd05(String table02_sd05) {
        this.table02_sd05 = table02_sd05;
    }

    public String getTable02_sd06() {
        return this.table02_sd06;
    }

    public void setTable02_sd06(String table02_sd06) {
        this.table02_sd06 = table02_sd06;
    }

    public String getTable02_sd07() {
        return this.table02_sd07;
    }

    public void setTable02_sd07(String table02_sd07) {
        this.table02_sd07 = table02_sd07;
    }

    public String getTable02_max01() {
        return this.table02_max01;
    }

    public void setTable02_max01(String table02_max01) {
        this.table02_max01 = table02_max01;
    }

    public String getTable02_max02() {
        return this.table02_max02;
    }

    public void setTable02_max02(String table02_max02) {
        this.table02_max02 = table02_max02;
    }

    public String getTable02_max03() {
        return this.table02_max03;
    }

    public void setTable02_max03(String table02_max03) {
        this.table02_max03 = table02_max03;
    }

    public String getTable02_max04() {
        return this.table02_max04;
    }

    public void setTable02_max04(String table02_max04) {
        this.table02_max04 = table02_max04;
    }

    public String getTable02_max05() {
        return this.table02_max05;
    }

    public void setTable02_max05(String table02_max05) {
        this.table02_max05 = table02_max05;
    }

    public String getTable02_max06() {
        return this.table02_max06;
    }

    public void setTable02_max06(String table02_max06) {
        this.table02_max06 = table02_max06;
    }

    public String getTable02_max07() {
        return this.table02_max07;
    }

    public void setTable02_max07(String table02_max07) {
        this.table02_max07 = table02_max07;
    }

    public String getTable02_min01() {
        return this.table02_min01;
    }

    public void setTable02_min01(String table02_min01) {
        this.table02_min01 = table02_min01;
    }

    public String getTable02_min02() {
        return this.table02_min02;
    }

    public void setTable02_min02(String table02_min02) {
        this.table02_min02 = table02_min02;
    }

    public String getTable02_min03() {
        return this.table02_min03;
    }

    public void setTable02_min03(String table02_min03) {
        this.table02_min03 = table02_min03;
    }

    public String getTable02_min04() {
        return this.table02_min04;
    }

    public void setTable02_min04(String table02_min04) {
        this.table02_min04 = table02_min04;
    }

    public String getTable02_min05() {
        return this.table02_min05;
    }

    public void setTable02_min05(String table02_min05) {
        this.table02_min05 = table02_min05;
    }

    public String getTable02_min06() {
        return this.table02_min06;
    }

    public void setTable02_min06(String table02_min06) {
        this.table02_min06 = table02_min06;
    }

    public String getTable02_min07() {
        return this.table02_min07;
    }

    public void setTable02_min07(String table02_min07) {
        this.table02_min07 = table02_min07;
    }
}
