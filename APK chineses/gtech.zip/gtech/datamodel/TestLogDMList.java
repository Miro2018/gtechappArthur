package com.accumed.gtech.datamodel;

import java.util.ArrayList;

public class TestLogDMList {
    public ArrayList<LogDM> getLogDMList() {
        ArrayList<LogDM> list = new ArrayList();
        for (int i = 0; i < 5; i++) {
            LogDM dm = new LogDM();
            dm.seq = "0";
            dm._id = "";
            dm.user_id = "";
            dm.update_flag = "";
            dm.device_id = "devid";
            dm.input_date = "20130303";
            dm.system_date = "";
            dm.category = "";
            dm.blood_sugar_type = "";
            dm.blood_sugar_eat = "";
            dm.blood_sugar_value = "";
            dm.insulin_type = "";
            dm.insulin_name = "";
            dm.insulin_value = "";
            dm.note_type = "";
            dm.note_content = "";
            dm.note_picture = "";
            dm.note_picture_thumb = "";
            list.add(dm);
        }
        return list;
    }
}
