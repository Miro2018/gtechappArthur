package com.accumed.gtech.util;

import android.annotation.SuppressLint;
import com.accumed.gtech.ClassConstant;
import java.io.File;

@SuppressLint({"SdCardPath"})
public class MakeSaveImgDir {
    public MakeSaveImgDir() {
        File dir = new File(ClassConstant.DIR_DATA);
        if (!dir.exists()) {
            dir.mkdir();
        }
        dir = new File(ClassConstant.DIR_IMG);
        if (!dir.exists()) {
            dir.mkdir();
        }
        dir = new File(ClassConstant.DIR_IMG_THUMB);
        if (!dir.exists()) {
            dir.mkdir();
        }
    }
}
