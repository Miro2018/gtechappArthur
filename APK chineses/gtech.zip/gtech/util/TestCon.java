package com.accumed.gtech.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import org.apache.http.HttpHeaders;

public class TestCon {
    public String postImage() {
        String resultStr = "";
        StringBuilder sb = null;
        String inputStreamReader;
        try {
            String boundary = "SpecificString";
            URLConnection con = new URL("https://service.sdbiosensor.com/users/joinuser").openConnection();
            con.setDoInput(true);
            con.setDoOutput(true);
            con.setRequestProperty(HttpHeaders.ACCEPT_CHARSET, "UTF-8");
            con.setRequestProperty("Content-Type", "text/plain; boundary=" + boundary);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes("\r\n--" + boundary + "\r\n");
            wr.writeBytes("Content-Disposition: form-data; name=\"email\"\r\n\r\njeunsu1@gmail");
            wr.flush();
            inputStreamReader = new InputStreamReader(con.getInputStream());
            BufferedReader rd = new BufferedReader(inputStreamReader);
            while (true) {
                String line = rd.readLine();
                if (line == null) {
                    break;
                }
                inputStreamReader = line + '\n';
                sb.append(inputStreamReader);
            }
            resultStr = sb.toString();
            return resultStr;
        } catch (Exception e) {
            inputStreamReader = e.toString();
            return inputStreamReader;
        } finally {
        }
    }
}
