package com.accumed.gtech.util;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Handler;
import android.os.Message;

public class ShowAlert {
    public static final int CLICK_CANCLE = 1;
    public static final int CLICK_CONFIRM = 0;
    static final String className = "ShowAlert";
    LogCat logCat = new LogCat();
    Context mContext;
    Handler mHandler;

    class C04861 implements OnClickListener {
        C04861() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
        }
    }

    class C04872 implements OnClickListener {
        C04872() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Message msg = Message.obtain();
            msg.what = 0;
            ShowAlert.this.mHandler.sendMessage(msg);
        }
    }

    class C04883 implements OnClickListener {
        C04883() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Message msg = Message.obtain();
            msg.what = 0;
            ShowAlert.this.mHandler.sendMessage(msg);
        }
    }

    class C04894 implements OnClickListener {
        C04894() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Message msg = Message.obtain();
            msg.what = 1;
            ShowAlert.this.mHandler.sendMessage(msg);
        }
    }

    class C04905 implements OnClickListener {
        C04905() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Message msg = Message.obtain();
            msg.what = 0;
            ShowAlert.this.mHandler.sendMessage(msg);
        }
    }

    class C04916 implements OnClickListener {
        C04916() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Message msg = Message.obtain();
            msg.what = 1;
            ShowAlert.this.mHandler.sendMessage(msg);
        }
    }

    class C04927 implements OnClickListener {
        C04927() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Message msg = Message.obtain();
            msg.what = 0;
            ShowAlert.this.mHandler.sendMessage(msg);
        }
    }

    public ShowAlert(Context c) {
        this.mContext = c;
    }

    public ShowAlert(Context c, Handler h) {
        this.mContext = c;
        this.mHandler = h;
    }

    public void alert0(String title, String message, String btText) {
        new Builder(this.mContext).setTitle(title).setMessage(message).setPositiveButton(btText, new C04861()).show();
    }

    public void alert1(String title, String message, String btText) {
        new Builder(this.mContext).setTitle(title).setMessage(message).setPositiveButton(btText, new C04872()).show();
    }

    public void alert2(String title, String message, String btTextPosi, String btTextNega) {
        this.logCat.log(className, "alert2", "in");
        new Builder(this.mContext).setTitle(title).setMessage(message).setNegativeButton(btTextNega, new C04894()).setPositiveButton(btTextPosi, new C04883()).show();
    }

    public void alert3(int what, String title, String message, String btTextPosi, String btTextNega) {
        new Builder(this.mContext).setTitle(title).setMessage(message).setNegativeButton(btTextNega, new C04916()).setPositiveButton(btTextPosi, new C04905()).show();
    }

    public void alert4(int what, String title, String message, String btTextPosi) {
        new Builder(this.mContext).setTitle(title).setMessage(message).setPositiveButton(btTextPosi, new C04927()).show();
    }

    public void showToast(String message) {
    }
}
