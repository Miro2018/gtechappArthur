package com.accumed.gtech.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class PreferenceUtil {
    Editor editor;
    Context mContext;
    SharedPreferences pref;

    public class ModelName {
        public static final String BGMS_MODEL_GLUCOSE_CODEFREE_BT_NAME = "01GM52";
        public static final String BGMS_MODEL_GLUCOSE_MENTOR_BT_NAME = "01GM27";
    }

    public class PREF_NAME_MY_DEVICE_TABLE {
        public static final String IS_BLUETOOTH_ADDRESS = "IS_BLUETOOTH_ADDRESS";
        public static final String IS_BLUETOOTH_NAME = "IS_BLUETOOTH_NAME";
        public static final String IS_BLUETOOTH_SEQUENCE_NUMBER = "IS_BLUETOOTH_SEQUENCE_NUMBER";
        public static final String IS_DATABASE_SEQUENCE_NUMBER = "IS_DATABASE_SEQUENCE_NUMBER";
        public static final String IS_DEVICE_MODEL = "IS_DEVICE_MODEL";
        public static final String IS_DEVICE_SERIAL_NUMBER = "IS_DEVICE_SERIAL_NUMBER";
        public static final String PREF_NAME = "PREF_NAME_AUTO_CONNECT";
    }

    public PreferenceUtil(Context context, String prefName) {
        this.mContext = context;
        this.pref = this.mContext.getSharedPreferences(prefName, 0);
    }

    public PreferenceUtil(Context context) {
        this.mContext = context;
    }

    public void putString(String key, String value) {
        this.editor = this.pref.edit();
        this.editor.putString(key, value);
        this.editor.commit();
    }

    public void putInt(String key, int value) {
        this.editor = this.pref.edit();
        this.editor.putInt(key, value);
        this.editor.commit();
    }

    public void putBoolean(String key, boolean value) {
        this.editor = this.pref.edit();
        this.editor.putBoolean(key, value);
        this.editor.commit();
    }

    public String getString(String key) {
        return this.pref.getString(key, "");
    }

    public int getInt(String key) {
        return this.pref.getInt(key, 0);
    }

    public boolean getBoolean(String key) {
        return this.pref.getBoolean(key, false);
    }

    public void remove(String key) {
        this.editor = this.pref.edit();
        this.editor.remove(key);
        this.editor.commit();
    }

    public void allRemove() {
        this.editor = this.pref.edit();
        this.editor.clear();
        this.editor.commit();
    }

    public void initDevicePref(Context context) {
        PreferenceUtil devicePref = new PreferenceUtil(context, PREF_NAME_MY_DEVICE_TABLE.PREF_NAME);
        devicePref.remove(PREF_NAME_MY_DEVICE_TABLE.IS_DEVICE_MODEL);
        devicePref.remove(PREF_NAME_MY_DEVICE_TABLE.IS_DEVICE_SERIAL_NUMBER);
        devicePref.remove(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_ADDRESS);
        devicePref.remove(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_NAME);
        devicePref.remove(PREF_NAME_MY_DEVICE_TABLE.IS_BLUETOOTH_SEQUENCE_NUMBER);
    }
}
