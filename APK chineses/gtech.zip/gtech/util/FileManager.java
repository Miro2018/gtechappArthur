package com.accumed.gtech.util;

import android.os.Environment;
import com.handmark.pulltorefresh.library.internal.ViewCompat.VERSION_CODES;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;

public class FileManager {
    static final HostnameVerifier DO_NOT_VERIFY = new C04792();
    final String className = "FileManager";
    LogCat logCat = new LogCat();

    static class C04792 implements HostnameVerifier {
        C04792() {
        }

        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    static class C04803 implements X509TrustManager {
        C04803() {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }

        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }
    }

    public FileManager() {
        MakeSaveImgDir makeSaveImgDir = new MakeSaveImgDir();
    }

    public static boolean isSDCARDMounted() {
        if (Environment.getExternalStorageState().equals("mounted")) {
            return true;
        }
        return false;
    }

    public void imageDown1(String path, String url, String fileName) {
        final String imgUrl = url;
        if (!new File(path + fileName).isFile()) {
            final String path_imgName = path + fileName;
            new Thread(new Runnable() {
                public void run() {
                    FileManager.this.imageDownload(path_imgName, imgUrl);
                }
            }).start();
        }
    }

    public void imageDownload(String path, String image_url) {
        IOException e;
        Throwable th;
        if (isSDCARDMounted()) {
            File file = new File(path);
            if (!file.exists()) {
                InputStream in = null;
                OutputStream out = null;
                byte[] buffer = new byte[1024];
                try {
                    this.logCat.log("FileManager", "img url", image_url);
                    URL url = new URL(image_url);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    if (url.getProtocol().toLowerCase().equals("https")) {
                        HttpURLConnection https = (HttpsURLConnection) url.openConnection();
                        https.setHostnameVerifier(DO_NOT_VERIFY);
                        conn = https;
                    } else {
                        conn = (HttpURLConnection) url.openConnection();
                    }
                    if (conn != null) {
                        conn.setConnectTimeout(VERSION_CODES.CUR_DEVELOPMENT);
                        conn.setUseCaches(false);
                        in = conn.getInputStream();
                        OutputStream out2 = new BufferedOutputStream(new FileOutputStream(file));
                        while (true) {
                            try {
                                int read = in.read(buffer);
                                if (read == -1) {
                                    break;
                                }
                                out2.write(buffer, 0, read);
                            } catch (IOException e2) {
                                e = e2;
                                out = out2;
                            } catch (Throwable th2) {
                                th = th2;
                                out = out2;
                            }
                        }
                        in.close();
                        out2.close();
                        out = out2;
                    }
                    if (in != null) {
                        try {
                            in.close();
                        } catch (IOException e3) {
                            e3.printStackTrace();
                        }
                    }
                    if (out != null) {
                        try {
                            out.close();
                        } catch (IOException e32) {
                            e32.printStackTrace();
                        }
                    }
                } catch (IOException e4) {
                    e32 = e4;
                    try {
                        e32.printStackTrace();
                        this.logCat.log("FileManager", "fileout", e32.toString());
                        if (in != null) {
                            try {
                                in.close();
                            } catch (IOException e322) {
                                e322.printStackTrace();
                            }
                        }
                        if (out != null) {
                            try {
                                out.close();
                            } catch (IOException e3222) {
                                e3222.printStackTrace();
                            }
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        if (in != null) {
                            try {
                                in.close();
                            } catch (IOException e32222) {
                                e32222.printStackTrace();
                            }
                        }
                        if (out != null) {
                            try {
                                out.close();
                            } catch (IOException e322222) {
                                e322222.printStackTrace();
                            }
                        }
                        throw th;
                    }
                }
            }
        }
    }

    private static void trustAllHosts() {
        TrustManager[] trustAllCerts = new TrustManager[]{new C04803()};
        try {
            SSLContext sc = SSLContext.getInstance(SSLConnectionSocketFactory.TLS);
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
