package com.accumed.gtech.util;

import java.io.File;

public class FileRename {
    public Boolean rename(String dir, String name, String reName) {
        File f = new File(dir + name);
        File t = new File(dir + reName);
        if (!f.exists()) {
            return Boolean.valueOf(false);
        }
        f.renameTo(t);
        return Boolean.valueOf(true);
    }
}
