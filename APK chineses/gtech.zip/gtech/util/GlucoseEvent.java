package com.accumed.gtech.util;

public class GlucoseEvent {
    public static int CS_1 = 2;
    public static int DAWN_10 = 1024;
    public static int DEL_9 = 512;
    public static int EVENING_13 = 8192;
    public static int LUNCH_12 = 4096;
    public static int MODIFY_8 = 256;
    public static int MODIFY_CS_17 = 131072;
    public static int MODIFY_POST_MEAL_16 = 65536;
    public static int MODIFY_PRE_MEAL_15 = 32768;
    public static int MORNING_11 = 2048;
    public static int POST_MEAL_5 = 32;
    public static int PRE_MEAL_4 = 16;
    public static int SLEEP_14 = 16384;

    public static int getOriginEvent(int ev) {
        int result = 0;
        int[] originEventArr = new int[]{CS_1, PRE_MEAL_4, POST_MEAL_5, MODIFY_8, DEL_9, DAWN_10, MORNING_11, LUNCH_12, EVENING_13, SLEEP_14, MODIFY_PRE_MEAL_15, MODIFY_POST_MEAL_16, MODIFY_CS_17};
        for (int i = 0; i < originEventArr.length; i++) {
            if ((originEventArr[i] & ev) == originEventArr[i]) {
                result = originEventArr[i];
            }
        }
        return result;
    }
}
