package com.accumed.gtech.util;

import android.util.Log;

public class LogCat {
    public void log(String className, String tag, String msg) {
    }

    public void logF(String className, String tag, float msg) {
        Log.e(tag, "(" + className + ") " + Float.toString(msg));
    }

    public void logL(String className, String tag, long msg) {
        Log.e(tag, "(" + className + ") " + Long.toString(msg));
    }

    public void log_w(String className, String tag, String msg) {
        Log.w(tag, "(" + className + ") " + msg);
    }

    public void log_d(String className, String tag, String msg) {
        Log.d(tag, "(" + className + ") " + msg);
    }

    public void dckimlog(String className, String tag, String msg) {
    }
}
