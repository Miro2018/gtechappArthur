package com.accumed.gtech.util;

import android.content.Context;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;

public class ReadTextFile {
    public static String readText(Context context, String file) {
        try {
            InputStream is = context.getAssets().open(file);
            Log.e("getAssets", is.toString());
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            return new String(buffer);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
