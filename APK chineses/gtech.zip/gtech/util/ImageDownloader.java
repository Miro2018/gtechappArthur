package com.accumed.gtech.util;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.widget.ImageView;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import lecho.lib.hellocharts.model.ColumnChartData;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.HttpGetHC4;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;

public class ImageDownloader {
    private static final int DELAY_BEFORE_PURGE = 10000;
    private static final int HARD_CACHE_CAPACITY = 10;
    public static final int IMG_DOWN = 0;
    private static final String LOG_TAG = "ImageDownloader";
    static final String className = "ImageDownloader";
    private static final ConcurrentHashMap<String, SoftReference<Bitmap>> sSoftBitmapCache = new ConcurrentHashMap(5);
    ImageDownloaderListener imageDownloaderListener;
    private Mode mode;
    private final Handler purgeHandler;
    private final Runnable purger;
    boolean round;
    private final HashMap<String, Bitmap> sHardBitmapCache;

    static class C04811 implements X509TrustManager {
        C04811() {
        }

        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }

        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }

        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        }
    }

    class C04822 implements HostnameVerifier {
        C04822() {
        }

        public boolean verify(String s, SSLSession sslSession) {
            return true;
        }
    }

    class C04844 implements Runnable {
        C04844() {
        }

        public void run() {
            ImageDownloader.this.clearCache();
        }
    }

    class BitmapDownloaderTask extends AsyncTask<String, Void, Bitmap> {
        private final WeakReference<ImageView> imageViewReference;
        private String url;

        public BitmapDownloaderTask(ImageView imageView) {
            this.imageViewReference = new WeakReference(imageView);
        }

        protected Bitmap doInBackground(String... params) {
            this.url = params[0];
            if (ImageDownloader.this.round) {
                return getRoundedBitmap(ImageDownloader.this.downloadBitmap(this.url));
            }
            return ImageDownloader.this.downloadBitmap(this.url);
        }

        public Bitmap getRoundedBitmap(Bitmap bitmap) {
            if (bitmap == null) {
                return null;
            }
            Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888);
            Canvas canvas = new Canvas(output);
            Paint paint = new Paint();
            Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
            RectF rectF = new RectF(rect);
            paint.setAntiAlias(true);
            canvas.drawARGB(0, 0, 0, 0);
            paint.setColor(-12434878);
            canvas.drawRoundRect(rectF, 3.0f, 3.0f, paint);
            paint.setXfermode(new PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN));
            canvas.drawBitmap(bitmap, rect, rect, paint);
            return output;
        }

        protected void onPostExecute(Bitmap bitmap) {
            if (isCancelled()) {
                bitmap = null;
            }
            ImageDownloader.this.addBitmapToCache(this.url, bitmap);
            if (this.imageViewReference != null) {
                ImageView imageView = (ImageView) this.imageViewReference.get();
                if (this == ImageDownloader.getBitmapDownloaderTask(imageView) || ImageDownloader.this.mode != Mode.CORRECT) {
                    imageView.setImageBitmap(bitmap);
                    if (ImageDownloader.this.imageDownloaderListener != null) {
                        ImageDownloader.this.imageDownloaderListener.onImageDown(Integer.valueOf(0));
                    }
                }
            }
        }
    }

    static class DownloadedDrawable extends ColorDrawable {
        private final WeakReference<BitmapDownloaderTask> bitmapDownloaderTaskReference;

        public DownloadedDrawable(BitmapDownloaderTask bitmapDownloaderTask) {
            super(0);
            this.bitmapDownloaderTaskReference = new WeakReference(bitmapDownloaderTask);
        }

        public BitmapDownloaderTask getBitmapDownloaderTask() {
            return (BitmapDownloaderTask) this.bitmapDownloaderTaskReference.get();
        }
    }

    static class FlushedInputStream extends FilterInputStream {
        public FlushedInputStream(InputStream inputStream) {
            super(inputStream);
        }

        public long skip(long n) throws IOException {
            long totalBytesSkipped = 0;
            while (totalBytesSkipped < n) {
                long bytesSkipped = this.in.skip(n - totalBytesSkipped);
                if (bytesSkipped == 0) {
                    if (read() < 0) {
                        break;
                    }
                    bytesSkipped = 1;
                }
                totalBytesSkipped += bytesSkipped;
            }
            return totalBytesSkipped;
        }
    }

    public enum Mode {
        NO_ASYNC_TASK,
        NO_DOWNLOADED_DRAWABLE,
        CORRECT,
        SRC_IN
    }

    public ImageDownloader() {
        this.mode = Mode.CORRECT;
        this.sHardBitmapCache = new LinkedHashMap<String, Bitmap>(5, ColumnChartData.DEFAULT_FILL_RATIO, true) {
            private static final long serialVersionUID = 1;

            protected boolean removeEldestEntry(Entry<String, Bitmap> eldest) {
                if (size() <= 10) {
                    return false;
                }
                ImageDownloader.sSoftBitmapCache.put(eldest.getKey(), new SoftReference(eldest.getValue()));
                return true;
            }
        };
        this.purgeHandler = new Handler();
        this.purger = new C04844();
        this.round = true;
    }

    public ImageDownloader(ImageDownloaderListener l) {
        this.mode = Mode.CORRECT;
        this.sHardBitmapCache = /* anonymous class already generated */;
        this.purgeHandler = new Handler();
        this.purger = new C04844();
        this.imageDownloaderListener = l;
    }

    public void setRound(boolean isRound) {
        this.round = isRound;
    }

    public void download(String url, ImageView imageView) {
        resetPurgeTimer();
        Bitmap bitmap = getBitmapFromCache(url);
        if (bitmap == null) {
            forceDownload(url, imageView);
            return;
        }
        cancelPotentialDownload(url, imageView);
        imageView.setImageBitmap(bitmap);
    }

    private void forceDownload(String url, ImageView imageView) {
        if (url != null && !url.equals("") && cancelPotentialDownload(url, imageView)) {
            switch (this.mode) {
                case NO_ASYNC_TASK:
                    Bitmap bitmap = downloadBitmap(url);
                    addBitmapToCache(url, bitmap);
                    imageView.setImageBitmap(bitmap);
                    return;
                case NO_DOWNLOADED_DRAWABLE:
                    imageView.setMinimumHeight(156);
                    new BitmapDownloaderTask(imageView).execute(new String[]{url});
                    return;
                case CORRECT:
                    BitmapDownloaderTask task = new BitmapDownloaderTask(imageView);
                    imageView.setImageDrawable(new DownloadedDrawable(task));
                    imageView.setMinimumHeight(156);
                    task.execute(new String[]{url});
                    return;
                default:
                    return;
            }
        }
    }

    private static boolean cancelPotentialDownload(String url, ImageView imageView) {
        BitmapDownloaderTask bitmapDownloaderTask = getBitmapDownloaderTask(imageView);
        if (bitmapDownloaderTask == null) {
            return true;
        }
        String bitmapUrl = bitmapDownloaderTask.url;
        if (bitmapUrl != null && bitmapUrl.equals(url)) {
            return false;
        }
        bitmapDownloaderTask.cancel(true);
        return true;
    }

    private static BitmapDownloaderTask getBitmapDownloaderTask(ImageView imageView) {
        if (imageView != null) {
            Drawable drawable = imageView.getDrawable();
            if (drawable instanceof DownloadedDrawable) {
                return ((DownloadedDrawable) drawable).getBitmapDownloaderTask();
            }
        }
        return null;
    }

    private static void trustAllHosts() {
        TrustManager[] trustAllCerts = new TrustManager[]{new C04811()};
        try {
            SSLContext sc = SSLContext.getInstance(SSLConnectionSocketFactory.TLS);
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Bitmap downloadBitmap(String srtUrl) {
        HttpURLConnection connection;
        try {
            URL url = new URL(srtUrl);
            String COOKIES_HEADER = "Set-Cookie";
            trustAllHosts();
            HttpURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
            httpsURLConnection.setHostnameVerifier(new C04822());
            connection = httpsURLConnection;
            connection.setRequestMethod(HttpGetHC4.METHOD_NAME);
            connection.setDoInput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty(HttpHeaders.ACCEPT, "application/json");
            connection.connect();
            if (connection.getResponseCode() == 200) {
                Bitmap btMap = BitmapFactory.decodeStream(new FlushedInputStream(connection.getInputStream()));
                if (connection == null) {
                    return btMap;
                }
                connection.disconnect();
                return btMap;
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (Throwable th) {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return null;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
        clearCache();
    }

    private void addBitmapToCache(String url, Bitmap bitmap) {
        if (bitmap != null) {
            this.sHardBitmapCache.put(url, bitmap);
            synchronized (this.sHardBitmapCache) {
                this.sHardBitmapCache.put(url, bitmap);
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.graphics.Bitmap getBitmapFromCache(java.lang.String r5) {
        /*
        r4 = this;
        r3 = r4.sHardBitmapCache;
        monitor-enter(r3);
        r2 = r4.sHardBitmapCache;	 Catch:{ all -> 0x002f }
        r0 = r2.get(r5);	 Catch:{ all -> 0x002f }
        r0 = (android.graphics.Bitmap) r0;	 Catch:{ all -> 0x002f }
        if (r0 == 0) goto L_0x001a;
    L_0x000d:
        r2 = r4.sHardBitmapCache;	 Catch:{ all -> 0x002f }
        r2.remove(r5);	 Catch:{ all -> 0x002f }
        r2 = r4.sHardBitmapCache;	 Catch:{ all -> 0x002f }
        r2.put(r5, r0);	 Catch:{ all -> 0x002f }
        monitor-exit(r3);	 Catch:{ all -> 0x002f }
        r2 = r0;
    L_0x0019:
        return r2;
    L_0x001a:
        monitor-exit(r3);	 Catch:{ all -> 0x002f }
        r2 = sSoftBitmapCache;
        r1 = r2.get(r5);
        r1 = (java.lang.ref.SoftReference) r1;
        if (r1 == 0) goto L_0x0037;
    L_0x0025:
        r0 = r1.get();
        r0 = (android.graphics.Bitmap) r0;
        if (r0 == 0) goto L_0x0032;
    L_0x002d:
        r2 = r0;
        goto L_0x0019;
    L_0x002f:
        r2 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x002f }
        throw r2;
    L_0x0032:
        r2 = sSoftBitmapCache;
        r2.remove(r5);
    L_0x0037:
        r2 = 0;
        goto L_0x0019;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.accumed.gtech.util.ImageDownloader.getBitmapFromCache(java.lang.String):android.graphics.Bitmap");
    }

    public void clearCache() {
        this.sHardBitmapCache.clear();
        sSoftBitmapCache.clear();
    }

    private void resetPurgeTimer() {
        this.purgeHandler.removeCallbacks(this.purger);
        this.purgeHandler.postDelayed(this.purger, 10000);
    }
}
