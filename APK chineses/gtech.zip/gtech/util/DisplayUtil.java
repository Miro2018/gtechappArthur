package com.accumed.gtech.util;

import android.content.Context;
import android.content.res.Configuration;
import android.view.Display;
import android.view.WindowManager;

public class DisplayUtil {
    private static final float DEFAULT_HDIP_DISPLAY_HEIGHT = 800.0f;
    private static final float DEFAULT_HDIP_DISPLAY_WIDTH = 480.0f;

    public static int DPFromPixelWidth(Context context, int width, float density) {
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int display_width = 0;
        if (context.getResources().getConfiguration().orientation == 1) {
            display_width = defaultDisplay.getWidth();
            if (display_width == 0) {
                display_width = 1;
            }
        } else if (context.getResources().getConfiguration().orientation == 2) {
            display_width = defaultDisplay.getHeight();
            if (display_width == 0) {
                display_width = 1;
            }
        }
        return (int) ((((float) display_width) / DEFAULT_HDIP_DISPLAY_WIDTH) * ((float) width));
    }

    public static int DPFromPixelHeight(Context context, int height, float density) {
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int display_height = 0;
        if (context.getResources().getConfiguration().orientation == 1) {
            display_height = defaultDisplay.getHeight();
            if (display_height == 0) {
                display_height = 1;
            }
        } else if (context.getResources().getConfiguration().orientation == 2) {
            display_height = defaultDisplay.getWidth();
            if (display_height == 0) {
                display_height = 1;
            }
        }
        return (int) ((((float) display_height) / DEFAULT_HDIP_DISPLAY_HEIGHT) * ((float) height));
    }

    public static int DPFromPixelImageWidth(Context context, int res, float density) {
        int width = context.getResources().getDrawable(res).getIntrinsicWidth();
        double count = 0.0d;
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int display_width = 0;
        if (context.getResources().getConfiguration().orientation == 1) {
            display_width = defaultDisplay.getWidth();
            if (isTablet(context)) {
                count = 1.45d;
            } else {
                count = 1.45d;
            }
            if (display_width == 0) {
                display_width = 1;
            }
        } else if (context.getResources().getConfiguration().orientation == 2) {
            display_width = defaultDisplay.getHeight();
            if (isTablet(context)) {
                count = 2.4d;
            } else {
                count = 2.45d;
            }
            if (display_width == 0) {
                display_width = 1;
            }
        }
        return (int) ((((float) display_width) / DEFAULT_HDIP_DISPLAY_WIDTH) * ((float) ((int) (((double) (((float) width) / density)) * count))));
    }

    public static int DPFromPixelImageHeight(Context context, int res, float density) {
        int height = context.getResources().getDrawable(res).getIntrinsicHeight();
        double count = 0.0d;
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int portrait_width_pixel = Math.min(context.getResources().getDisplayMetrics().widthPixels, context.getResources().getDisplayMetrics().heightPixels);
        int display_height = 0;
        if (context.getResources().getConfiguration().orientation == 1) {
            display_height = defaultDisplay.getHeight();
            if (portrait_width_pixel == 768) {
                count = 2.0d;
            } else {
                count = 1.5d;
            }
            if (display_height == 0) {
                display_height = 1;
            }
        } else if (context.getResources().getConfiguration().orientation == 2) {
            display_height = defaultDisplay.getWidth();
            if (portrait_width_pixel == 768) {
                count = 2.0d;
            } else {
                count = 1.5d;
            }
            if (display_height == 0) {
                display_height = 1;
            }
        }
        return (int) ((((float) display_height) / DEFAULT_HDIP_DISPLAY_HEIGHT) * ((float) ((int) (((double) (((float) height) / density)) * count))));
    }

    public static int getScreenWidth(Context context) {
        Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int display_width;
        if (context.getResources().getConfiguration().orientation == 1) {
            display_width = defaultDisplay.getWidth();
            if (display_width == 0) {
                return 1;
            }
            return display_width;
        } else if (context.getResources().getConfiguration().orientation != 2) {
            return 0;
        } else {
            display_width = defaultDisplay.getHeight();
            if (display_width == 0) {
                return 1;
            }
            return display_width;
        }
    }

    public static boolean isTablet(Context context) {
        Configuration config = context.getResources().getConfiguration();
        float virutal_width_inch = (float) (Math.min(context.getResources().getDisplayMetrics().widthPixels, context.getResources().getDisplayMetrics().heightPixels) / context.getResources().getDisplayMetrics().densityDpi);
        return (config.screenLayout & 4) == 4 || (config.screenLayout & 3) == 3;
    }
}
