package com.accumed.gtech.util;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

public class ViewProperty {
    final String className = "ViewProperty";
    LogCat logCat = new LogCat();
    Context mContext;
    View mView;

    public ViewProperty(Context c, View v) {
        this.mContext = c;
        this.mView = v;
    }

    public View resizeView(int listSize, int rowHeight) {
        this.logCat.log("ViewProperty", "listSize", listSize + "");
        LayoutParams params = this.mView.getLayoutParams();
        params.width = -1;
        params.height = dpToPx(rowHeight) * listSize;
        this.mView.setLayoutParams(params);
        return this.mView;
    }

    private int dpToPx(int dp) {
        return Math.round(((float) dp) * (this.mContext.getResources().getDisplayMetrics().xdpi / 160.0f));
    }
}
