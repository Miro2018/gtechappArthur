package com.accumed.gtech.util;

import java.io.FileWriter;

public class Save {
    private static FileWriter objfile = null;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void traceText(java.lang.String r7, java.lang.String r8) {
        /*
        r2 = new java.io.File;
        r4 = "/sdcard/data";
        r2.<init>(r4);
        r4 = r2.exists();
        if (r4 != 0) goto L_0x0010;
    L_0x000d:
        r2.mkdir();
    L_0x0010:
        r2 = new java.io.File;
        r4 = "/sdcard/data/com.gluconavii";
        r2.<init>(r4);
        r4 = r2.exists();
        if (r4 != 0) goto L_0x0020;
    L_0x001d:
        r2.mkdir();
    L_0x0020:
        r2 = new java.io.File;
        r4 = "/sdcard/data/com.gluconavii/file";
        r2.<init>(r4);
        r4 = r2.exists();
        if (r4 != 0) goto L_0x0030;
    L_0x002d:
        r2.mkdir();
    L_0x0030:
        r3 = new java.io.File;
        r4 = new java.lang.StringBuilder;
        r4.<init>();
        r5 = "/sdcard/data/com.gluconavii/file/";
        r4 = r4.append(r5);
        r4 = r4.append(r7);
        r5 = ".html";
        r4 = r4.append(r5);
        r4 = r4.toString();
        r3.<init>(r4);
        r4 = r3.exists();
        if (r4 == 0) goto L_0x0057;
    L_0x0054:
        r3.delete();
    L_0x0057:
        r0 = new java.lang.StringBuffer;
        r0.<init>();
        r4 = "/sdcard/data/com.gluconavii/file/";
        r0.append(r4);
        r0.append(r7);
        r4 = ".html";
        r0.append(r4);
        r1 = new java.lang.StringBuffer;
        r1.<init>();
        r1.append(r8);
        r4 = new java.io.FileWriter;	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        r5 = r0.toString();	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        r6 = 1;
        r4.<init>(r5, r6);	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        objfile = r4;	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        r4 = objfile;	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        r5 = r1.toString();	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        r4.write(r5);	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        r4 = objfile;	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        r5 = "\r\n";
        r4.write(r5);	 Catch:{ IOException -> 0x0093, all -> 0x009c }
        r4 = objfile;	 Catch:{ Exception -> 0x00a5 }
        r4.close();	 Catch:{ Exception -> 0x00a5 }
    L_0x0092:
        return;
    L_0x0093:
        r4 = move-exception;
        r4 = objfile;	 Catch:{ Exception -> 0x009a }
        r4.close();	 Catch:{ Exception -> 0x009a }
        goto L_0x0092;
    L_0x009a:
        r4 = move-exception;
        goto L_0x0092;
    L_0x009c:
        r4 = move-exception;
        r5 = objfile;	 Catch:{ Exception -> 0x00a3 }
        r5.close();	 Catch:{ Exception -> 0x00a3 }
    L_0x00a2:
        throw r4;
    L_0x00a3:
        r5 = move-exception;
        goto L_0x00a2;
    L_0x00a5:
        r4 = move-exception;
        goto L_0x0092;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.accumed.gtech.util.Save.traceText(java.lang.String, java.lang.String):void");
    }
}
