package com.accumed.gtech.util;

import android.content.Context;
import android.net.ConnectivityManager;

public class NetworkWatcher {
    static final String className = "NetworkWatcher";
    Context mContext;

    public NetworkWatcher(Context c) {
        this.mContext = c;
    }

    public boolean isCon() {
        try {
            ConnectivityManager manager = (ConnectivityManager) this.mContext.getSystemService("connectivity");
            boolean isMobile = manager.getNetworkInfo(0).isConnectedOrConnecting();
            boolean isWifi = manager.getNetworkInfo(1).isConnectedOrConnecting();
            if (isMobile || isWifi) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return true;
        }
    }
}
