package com.accumed.gtech.util;

import android.content.Context;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.thread.datamodel.AddDeviceReturnDM;
import com.accumed.gtech.thread.datamodel.AddFriendReturnDM;
import com.accumed.gtech.thread.datamodel.AddG_I_ReturnDM;
import com.accumed.gtech.thread.datamodel.AddGlucoseReturnDM;
import com.accumed.gtech.thread.datamodel.AddInsulinReturnDM;
import com.accumed.gtech.thread.datamodel.AddNoteReturnDM;
import com.accumed.gtech.thread.datamodel.AddOtherrecordReturnDM;
import com.accumed.gtech.thread.datamodel.AddUserReturnDM;
import com.accumed.gtech.thread.datamodel.ChangestatusReturnDM;
import com.accumed.gtech.thread.datamodel.DelDataReturnDM;
import com.accumed.gtech.thread.datamodel.DelOtherrecordReturnDM;
import com.accumed.gtech.thread.datamodel.FindPasswordReturnDM;
import com.accumed.gtech.thread.datamodel.FriendListReturnDM;
import com.accumed.gtech.thread.datamodel.FriendListReturnDMSubDM;
import com.accumed.gtech.thread.datamodel.GetDeviceReturnDM;
import com.accumed.gtech.thread.datamodel.GetDeviceReturnDMSubDM;
import com.accumed.gtech.thread.datamodel.JoinEmailCheckReturnDM;
import com.accumed.gtech.thread.datamodel.LoginReturnDM;
import com.accumed.gtech.thread.datamodel.ModG_I_ReturnDM;
import com.accumed.gtech.thread.datamodel.ModGlucoseReturnDM;
import com.accumed.gtech.thread.datamodel.ModInsulinReturnDM;
import com.accumed.gtech.thread.datamodel.ModNoteReturnDM;
import com.accumed.gtech.thread.datamodel.ModOtherrecordReturnDM;
import com.accumed.gtech.thread.datamodel.ModUserReturnDM;
import com.accumed.gtech.thread.datamodel.TimeLineReturnDM;
import com.accumed.gtech.thread.datamodel.TimeLineReturnDMSubDM;
import com.accumed.gtech.thread.datamodel.UserProfileReturnDM;
import com.accumed.gtech.thread.datamodel.UserRequestReturnDM;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MagicReturnDM {
    static String className = "MagicReturnDM";
    LogCat logCat = new LogCat();
    Context mContext;

    public MagicReturnDM(Context c) {
        this.mContext = c;
    }

    public AddUserReturnDM addUserReturnDM(String jsonStr) {
        AddUserReturnDM addUserReturnDM = new AddUserReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                addUserReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data"));
                addUserReturnDM.result = j1.getString("result");
                addUserReturnDM.id = j1.getString("id");
                addUserReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return addUserReturnDM;
    }

    public GetDeviceReturnDM getDeviceReturnDM(String jsonStr) {
        GetDeviceReturnDM getDeviceReturnDM = new GetDeviceReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                getDeviceReturnDM.code = j0.getString("code");
                JSONArray jarr0 = j0.getJSONArray("data");
                for (int i = 0; i < jarr0.length(); i++) {
                    GetDeviceReturnDMSubDM subDM = new GetDeviceReturnDMSubDM();
                    subDM.id = jarr0.getJSONObject(i).getString("id");
                    subDM.deviceid = jarr0.getJSONObject(i).getString("deviceid");
                    subDM.lastvalue = jarr0.getJSONObject(i).getString("lastvalue");
                    this.logCat.log(className, "subDM.id", subDM.id);
                    this.logCat.log(className, "subDM.deviceid", subDM.deviceid);
                    this.logCat.log(className, "subDM.lastvalue", subDM.lastvalue);
                    getDeviceReturnDM.deviceList.add(subDM);
                }
                getDeviceReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return getDeviceReturnDM;
    }

    public AddDeviceReturnDM addDeviceReturnDM(String jsonStr) {
        AddDeviceReturnDM addDeviceReturnDM = new AddDeviceReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                addDeviceReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data"));
                addDeviceReturnDM.result = j1.getString("result");
                addDeviceReturnDM.id = j1.getString("id");
                addDeviceReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return addDeviceReturnDM;
    }

    public JoinEmailCheckReturnDM joinEmailCheckReturnDM(String jsonStr) {
        JoinEmailCheckReturnDM joinEmailCheckReturnDM = new JoinEmailCheckReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                joinEmailCheckReturnDM.code = j0.getString("code");
                joinEmailCheckReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                joinEmailCheckReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return joinEmailCheckReturnDM;
    }

    public LoginReturnDM loginReturnDM(String jsonStr) {
        LoginReturnDM loginReturnDM = new LoginReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                loginReturnDM.code = j0.getString("code");
                loginReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                loginReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return loginReturnDM;
    }

    public ModUserReturnDM modUserReturnDM(String jsonStr) {
        ModUserReturnDM modUserReturnDM = new ModUserReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                modUserReturnDM.code = j0.getString("code");
                modUserReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                modUserReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return modUserReturnDM;
    }

    public AddGlucoseReturnDM addGlucoseReturnDM(String jsonStr) {
        AddGlucoseReturnDM addGlucoseReturnDM = new AddGlucoseReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                addGlucoseReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data"));
                addGlucoseReturnDM.result = j1.getString("result");
                addGlucoseReturnDM.id = j1.getString("id");
                addGlucoseReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return addGlucoseReturnDM;
    }

    public AddG_I_ReturnDM addG_I_ReturnDM(String jsonStr) {
        this.logCat.log(className, "AddG_I_ReturnDM", "in");
        AddG_I_ReturnDM addG_I_ReturnDM = new AddG_I_ReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                addG_I_ReturnDM.code = j0.getString("code");
                addG_I_ReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                JSONArray j0Arr = j0.getJSONArray("success_client_seq");
                this.logCat.log(className, "success_client_seq size", j0Arr.length() + "");
                for (int i = 0; i < j0Arr.length(); i++) {
                    this.logCat.log(className, "success_client_seq", j0Arr.getString(i));
                    addG_I_ReturnDM.clientSeqList.add(j0Arr.getString(i));
                }
                addG_I_ReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return addG_I_ReturnDM;
    }

    public ModG_I_ReturnDM modG_I_ReturnDM(String jsonStr) {
        this.logCat.log(className, "AddG_I_ReturnDM", "in");
        ModG_I_ReturnDM modG_I_ReturnDM = new ModG_I_ReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                modG_I_ReturnDM.code = j0.getString("code");
                modG_I_ReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                JSONArray j0Arr = j0.getJSONArray("success_client_seq");
                this.logCat.log(className, "success_client_seq size", j0Arr.length() + "");
                for (int i = 0; i < j0Arr.length(); i++) {
                    this.logCat.log(className, "success_client_seq", j0Arr.getString(i));
                    modG_I_ReturnDM.clientSeqList.add(j0Arr.getString(i));
                }
                modG_I_ReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return modG_I_ReturnDM;
    }

    public ModGlucoseReturnDM modGlucoseReturnDM(String jsonStr) {
        ModGlucoseReturnDM modGlucoseReturnDM = new ModGlucoseReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                modGlucoseReturnDM.code = j0.getString("code");
                modGlucoseReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                modGlucoseReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return modGlucoseReturnDM;
    }

    public AddInsulinReturnDM addInsulinReturnDM(String jsonStr) {
        AddInsulinReturnDM addInsulinReturnDM = new AddInsulinReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                addInsulinReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data"));
                addInsulinReturnDM.result = j1.getString("result");
                addInsulinReturnDM.id = j1.getString("id");
                this.logCat.log(className, "addInsulinReturnDM.id", addInsulinReturnDM.id);
                addInsulinReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return addInsulinReturnDM;
    }

    public ModInsulinReturnDM modInsulinReturnDM(String jsonStr) {
        ModInsulinReturnDM modInsulinReturnDM = new ModInsulinReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                modInsulinReturnDM.code = j0.getString("code");
                modInsulinReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                modInsulinReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return modInsulinReturnDM;
    }

    public AddNoteReturnDM addNoteReturnDM(String jsonStr) {
        AddNoteReturnDM addNoteReturnDM = new AddNoteReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                addNoteReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data"));
                addNoteReturnDM.result = j1.getString("result");
                addNoteReturnDM.id = j1.getString("id");
                addNoteReturnDM.filename = j1.getString("filename");
                addNoteReturnDM.thumbnail = j1.getString("thumbnail");
                addNoteReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return addNoteReturnDM;
    }

    public ModNoteReturnDM modNoteReturnDM(String jsonStr) {
        ModNoteReturnDM modNoteReturnDM = new ModNoteReturnDM();
        if (jsonStr != null) {
            try {
                this.logCat.log(className, "modeNote return str", jsonStr);
                JSONObject j0 = new JSONObject(jsonStr);
                modNoteReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data"));
                modNoteReturnDM.result = j1.getString("result");
                modNoteReturnDM.filename = j1.getString("filename");
                modNoteReturnDM.thumbnail = j1.getString("thumbnail");
                modNoteReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return modNoteReturnDM;
    }

    public DelDataReturnDM delDataReturnDM(String jsonStr) {
        DelDataReturnDM delDataReturnDM = new DelDataReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                delDataReturnDM.code = j0.getString("code");
                delDataReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                delDataReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return delDataReturnDM;
    }

    public FindPasswordReturnDM findPasswordReturnDM(String jsonStr) {
        FindPasswordReturnDM findPasswordReturnDM = new FindPasswordReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                findPasswordReturnDM.code = j0.getString("code");
                findPasswordReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                findPasswordReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return findPasswordReturnDM;
    }

    public UserRequestReturnDM userRequestReturnaDM(String jsonStr) {
        UserRequestReturnDM userRequestReturnaDM = new UserRequestReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                userRequestReturnaDM.code = j0.getString("code");
                JSONObject j00 = new JSONObject(new JSONArray(j0.getString("data")).get(0).toString());
                userRequestReturnaDM.id = j00.getString("id");
                userRequestReturnaDM.email = j00.getString("email");
                userRequestReturnaDM.created_at = j00.getString("created_at");
                userRequestReturnaDM.name = j00.getString("name");
                userRequestReturnaDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return userRequestReturnaDM;
    }

    public FriendListReturnDM friendListReturnDM(String jsonStr) {
        FriendListReturnDM friendListReturnDM = new FriendListReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                friendListReturnDM.code = j0.getString("code");
                try {
                    JSONArray ja1 = new JSONArray(j0.getString("data"));
                    ArrayList<FriendListReturnDMSubDM> subDMList = new ArrayList();
                    for (int i = 0; i < ja1.length(); i++) {
                        FriendListReturnDMSubDM friendListReturnDMSubDM = new FriendListReturnDMSubDM();
                        JSONObject j = new JSONObject(ja1.getString(i));
                        friendListReturnDMSubDM.id = j.getString("id");
                        friendListReturnDMSubDM.friend = j.getString("friend");
                        friendListReturnDMSubDM.status = j.getString("status");
                        friendListReturnDMSubDM.eventcount = j.getString("eventcount");
                        friendListReturnDMSubDM.name = j.getString("name");
                        friendListReturnDM.subDMList.add(friendListReturnDMSubDM);
                    }
                    friendListReturnDM.statusResult = "ok";
                } catch (JSONException e) {
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        return friendListReturnDM;
    }

    public HashMap<String, String> friendMapReturn(String jsonStr) {
        HashMap<String, String> fMap = new HashMap();
        if (jsonStr != null) {
            try {
                try {
                    JSONArray ja1 = new JSONArray(new JSONObject(jsonStr).getString("data"));
                    for (int i = 0; i < ja1.length(); i++) {
                        JSONObject j = new JSONObject(ja1.getString(i));
                        fMap.put(j.getString("friend"), j.getString("name"));
                    }
                } catch (JSONException e) {
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }
        return fMap;
    }

    public AddFriendReturnDM addFriendReturnDM(String jsonStr) {
        AddFriendReturnDM addFriendReturnDM = new AddFriendReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                addFriendReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data"));
                addFriendReturnDM.result = j1.getString("result");
                addFriendReturnDM.userid = j1.getString("userid");
                addFriendReturnDM.friendid = j1.getString("friendid");
                addFriendReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return addFriendReturnDM;
    }

    public ChangestatusReturnDM changestatusReturnDM(String jsonStr) {
        ChangestatusReturnDM changestatusReturnDM = new ChangestatusReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                changestatusReturnDM.code = j0.getString("code");
                changestatusReturnDM.result = new JSONObject(j0.getString("data")).getString("result");
                changestatusReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return changestatusReturnDM;
    }

    private String getCategory(String s) {
        if (s.toLowerCase().equals("glucose")) {
            return "0";
        }
        if (s.toLowerCase().equals("insulin")) {
            return "1";
        }
        if (s.toLowerCase().equals("note")) {
            return "2";
        }
        if (s.toLowerCase().equals("comment")) {
            return LogDM.GLUCOSE_EAT_FASTING;
        }
        return null;
    }

    private String getblood_sugar_type(String s) {
        if (s.toLowerCase().equals("no")) {
            return "0";
        }
        if (s.toLowerCase().equals("yes")) {
            return "1";
        }
        return null;
    }

    private String getinsulin_type(String s) {
        if (s.toLowerCase().equals("rapid")) {
            return "0";
        }
        if (s.toLowerCase().equals("short")) {
            return "1";
        }
        if (s.toLowerCase().equals("nph")) {
            return "2";
        }
        if (s.toLowerCase().equals("long")) {
            return LogDM.GLUCOSE_EAT_FASTING;
        }
        if (s.toLowerCase().equals("Mix")) {
            return LogDM.GLUCOSE_EAT_NONE;
        }
        return null;
    }

    private String getNote_type(String s) {
        if (s.toLowerCase().equals("meal")) {
            return "0";
        }
        if (s.toLowerCase().equals("ex")) {
            return "1";
        }
        if (s.toLowerCase().equals("note")) {
            return "2";
        }
        return null;
    }

    private String mobileDateFormat(String dStr) {
        try {
            if (dStr.trim().length() < 23) {
                dStr = dStr + " 00:00:00.000";
            }
            this.logCat.log("className", "dStr", dStr);
            String result = dStr.replaceAll("\\-", "").replaceAll(" ", "").replaceAll("\\:", "").replaceAll("\\.", "");
            this.logCat.log(className, "ssss", result);
            return result;
        } catch (Exception e) {
            return "...";
        }
    }

    public TimeLineReturnDM suport_timeLineReturnDM(String jonStr) {
        this.logCat.log(className, "timeLineReturnDM()", "in");
        TimeLineReturnDM timeLineReturnDM = new TimeLineReturnDM();
        if (jonStr != null) {
            JSONObject j0 = new JSONObject(jonStr);
            timeLineReturnDM.code = j0.getString("code");
            if (timeLineReturnDM.code.equals("200")) {
                JSONArray jr0 = new JSONArray(j0.getString("data"));
                for (int i = 0; i < jr0.length(); i++) {
                    TimeLineReturnDMSubDM timeLineReturnDMSubDM = new TimeLineReturnDMSubDM();
                    LogDM logDM = new LogDM();
                    JSONObject j1 = new JSONObject(jr0.getString(i));
                    timeLineReturnDMSubDM.tkind = j1.getString("tkind");
                    timeLineReturnDMSubDM.tid = j1.getString("tid");
                    timeLineReturnDMSubDM.created_at = j1.getString("created_at");
                    logDM.category = getCategory(j1.getString("tkind"));
                    logDM._id = j1.getString("tid");
                    this.logCat.log(className, "category", logDM.category);
                    JSONObject j2 = new JSONObject(j1.getString("tdatas"));
                    if (timeLineReturnDMSubDM.tkind.equals("glucose")) {
                        timeLineReturnDMSubDM.manualinput = j2.getString("manualinput");
                        timeLineReturnDMSubDM.gvalue = j2.getString("gvalue");
                        timeLineReturnDMSubDM.gdate = j2.getString("gdate");
                        timeLineReturnDMSubDM.gtempeature = j2.getString("gtempeature");
                        timeLineReturnDMSubDM.gevent = j2.getString("gevent");
                        timeLineReturnDMSubDM.deviceid = j2.getString("deviceid");
                        try {
                            timeLineReturnDMSubDM.gmodevent = j2.getString("gmodevent");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        logDM.blood_sugar_type = getblood_sugar_type(j2.getString("manualinput"));
                        logDM.blood_sugar_value = j2.getString("gvalue");
                        logDM.input_date = mobileDateFormat(j2.getString("gdate"));
                        logDM.blood_sugar_eat = j2.getString("gevent");
                        try {
                            logDM.blood_sugar_eat_origin = j2.getString("gmodevent");
                        } catch (Exception e2) {
                            e2.printStackTrace();
                        }
                        logDM.device_id = j2.getString("deviceid");
                    } else if (timeLineReturnDMSubDM.tkind.equals("insulin")) {
                        try {
                            timeLineReturnDMSubDM.email = j2.getString("email");
                        } catch (Exception e3) {
                        }
                        timeLineReturnDMSubDM.idate = j2.getString("idate");
                        timeLineReturnDMSubDM.itype = j2.getString("itype");
                        timeLineReturnDMSubDM.iproduct = j2.getString("iproduct");
                        timeLineReturnDMSubDM.ivalue = j2.getString("ivalue");
                        try {
                            logDM.user_id = j2.getString("email");
                        } catch (Exception e4) {
                        }
                        logDM.input_date = mobileDateFormat(j2.getString("idate"));
                        logDM.insulin_type = Integer.toString(getInsulinTypeNum(j2.getString("itype")));
                        logDM.insulin_name = Integer.toString(getInsulinNameNum(j2.getString("iproduct")));
                        logDM.insulin_value = j2.getString("ivalue");
                    } else if (timeLineReturnDMSubDM.tkind.equals("note")) {
                        timeLineReturnDMSubDM.ndate = j2.getString("ndate");
                        try {
                            timeLineReturnDMSubDM.email = j2.getString("email");
                        } catch (Exception e5) {
                        }
                        timeLineReturnDMSubDM.nvalue = j2.getString("nvalue");
                        timeLineReturnDMSubDM.ntype = j2.getString("ntype");
                        try {
                            timeLineReturnDMSubDM.picture = j2.getString("picture");
                            timeLineReturnDMSubDM.thumbnail = j2.getString("thumbnail");
                        } catch (Exception e6) {
                        }
                        logDM.input_date = mobileDateFormat(j2.getString("ndate"));
                        try {
                            logDM.user_id = j2.getString("email");
                        } catch (Exception e7) {
                        }
                        logDM.note_content = j2.getString("nvalue");
                        logDM.note_type = getNote_type(j2.getString("ntype"));
                        try {
                            logDM.note_picture = j2.getString("picture");
                            logDM.note_picture_thumb = j2.getString("thumbnail");
                        } catch (Exception e8) {
                        }
                    } else if (timeLineReturnDMSubDM.tkind.toLowerCase().equals("comment")) {
                        timeLineReturnDMSubDM.ndate = j2.getString("ndate");
                        try {
                            timeLineReturnDMSubDM.email = j2.getString("email");
                        } catch (Exception e9) {
                        }
                        try {
                            timeLineReturnDMSubDM.nvalue = j2.getString("nvalue");
                            timeLineReturnDMSubDM.targetemail = j2.getString("targetemail");
                            try {
                                timeLineReturnDMSubDM.picture = j2.getString("picture");
                                timeLineReturnDMSubDM.thumbnail = j2.getString("thumbnail");
                            } catch (Exception e10) {
                            }
                            this.logCat.log(className, "comment ", timeLineReturnDMSubDM.targetemail);
                            logDM.input_date = mobileDateFormat(j2.getString("ndate"));
                            logDM.user_id = j2.getString("email");
                            logDM.note_content = j2.getString("nvalue");
                            logDM.targetemail = j2.getString("targetemail");
                            try {
                                logDM.note_picture = j2.getString("picture");
                                logDM.note_picture_thumb = j2.getString("thumbnail");
                            } catch (Exception e11) {
                            }
                        } catch (JSONException e12) {
                            e12.printStackTrace();
                            this.logCat.log(className, "timeLineReturnDM()", e12.toString());
                        }
                    }
                    this.logCat.log(className, "logDM._id", logDM._id);
                    this.logCat.log(className, "logDM.user_id", logDM.user_id);
                    this.logCat.log(className, "logDM.update_flag", logDM.update_flag);
                    this.logCat.log(className, "logDM.device_id", logDM.device_id);
                    this.logCat.log(className, "logDM.input_date", logDM.input_date);
                    this.logCat.log(className, "logDM.system_date", logDM.system_date);
                    this.logCat.log(className, "logDM.blood_sugar_type", logDM.blood_sugar_type);
                    this.logCat.log(className, "logDM.blood_sugar_eat", logDM.blood_sugar_eat);
                    this.logCat.log(className, "logDM.blood_sugar_value", logDM.blood_sugar_value);
                    this.logCat.log(className, "logDM.insulin_type", logDM.insulin_type);
                    this.logCat.log(className, "logDM.insulin_name", logDM.insulin_name);
                    this.logCat.log(className, "logDM.insulin_value", logDM.insulin_value);
                    this.logCat.log(className, "logDM.note_type", logDM.note_type);
                    this.logCat.log(className, "logDM.note_content", logDM.note_content);
                    this.logCat.log(className, "logDM.note_picture", logDM.note_picture);
                    this.logCat.log(className, "logDM.note_picture_thumb", logDM.note_picture_thumb);
                    if (timeLineReturnDMSubDM.gmodevent == null || timeLineReturnDMSubDM.gmodevent.equals("") || timeLineReturnDMSubDM.gmodevent.equals("null")) {
                        timeLineReturnDM.subDMList.add(timeLineReturnDMSubDM);
                    } else if ((Integer.parseInt(timeLineReturnDMSubDM.gmodevent) & GlucoseEvent.DEL_9) == GlucoseEvent.DEL_9) {
                        this.logCat.log(className, "no_input", timeLineReturnDMSubDM.gvalue);
                    } else {
                        timeLineReturnDM.subDMList.add(timeLineReturnDMSubDM);
                    }
                    if (logDM.blood_sugar_eat_origin == null || logDM.blood_sugar_eat_origin.equals("") || timeLineReturnDMSubDM.gmodevent.equals("null")) {
                        timeLineReturnDM.subLogDMList.add(logDM);
                    } else if ((Integer.parseInt(logDM.blood_sugar_eat_origin) & GlucoseEvent.DEL_9) == GlucoseEvent.DEL_9) {
                        this.logCat.log(className, "no_input", logDM.blood_sugar_eat_origin);
                    } else {
                        timeLineReturnDM.subLogDMList.add(logDM);
                    }
                }
                timeLineReturnDM.statusResult = "ok";
            } else {
                timeLineReturnDM.statusResult = "";
            }
        }
        return timeLineReturnDM;
    }

    private int getInsulinTypeNum(String iTypeName) {
        int result = 0;
        String[] insulin_type_arr = this.mContext.getResources().getStringArray(C0213R.array.array_insulin_type_data);
        int i = 0;
        while (i < insulin_type_arr.length) {
            try {
                if (iTypeName.toLowerCase().equals(insulin_type_arr[i].toLowerCase())) {
                    result = i;
                }
                i++;
            } catch (Exception e) {
                this.logCat.log(className, "iTypeName", result + "");
                return 0;
            }
        }
        if (result == 0) {
            String[] insulin_type_arr_ko = this.mContext.getResources().getStringArray(C0213R.array.array_insulin_type_data_ko);
            for (i = 0; i < insulin_type_arr_ko.length; i++) {
                if (iTypeName.toLowerCase().equals(insulin_type_arr_ko[i].toLowerCase())) {
                    result = i;
                }
            }
        }
        this.logCat.log(className, "iTypeName", result + "");
        return result;
    }

    private int getInsulinNameNum(String iName) {
        this.logCat.log(className, "iName", iName);
        int result = 0;
        String[] insulin_name_arr = this.mContext.getResources().getStringArray(C0213R.array.array_insulin_name_data);
        int i = 0;
        while (i < insulin_name_arr.length) {
            try {
                if (iName.toLowerCase().equals(insulin_name_arr[i].toLowerCase())) {
                    result = i;
                }
                i++;
            } catch (Exception e) {
                this.logCat.log(className, "iName", result + "");
                return 0;
            }
        }
        if (result == 0) {
            String[] insulin_name_arr_ko = this.mContext.getResources().getStringArray(C0213R.array.array_insulin_name_data_ko);
            for (i = 0; i < insulin_name_arr_ko.length; i++) {
                if (iName.toLowerCase().equals(insulin_name_arr_ko[i].toLowerCase())) {
                    result = i;
                }
            }
        }
        this.logCat.log(className, "iName", result + "");
        return result;
    }

    public TimeLineReturnDM suport_sync_timeLineReturnDM(String jonStr) {
        this.logCat.log(className, "timeLineReturnDM()", "in");
        Util util = new Util();
        DBAction dbAction = new DBAction(this.mContext);
        TimeLineReturnDM timeLineReturnDM = new TimeLineReturnDM();
        if (jonStr != null) {
            JSONObject j0 = new JSONObject(jonStr);
            timeLineReturnDM.code = j0.getString("code");
            if (timeLineReturnDM.code.equals("200")) {
                JSONArray jr0 = new JSONArray(j0.getString("data"));
                for (int i = 0; i < jr0.length(); i++) {
                    String where_note_picture_str;
                    String where_note_picture_thumb_str;
                    FileManager fileManager;
                    String imgUrl;
                    TimeLineReturnDMSubDM timeLineReturnDMSubDM = new TimeLineReturnDMSubDM();
                    LogDM logDM = new LogDM();
                    JSONObject j1 = new JSONObject(jr0.getString(i));
                    timeLineReturnDMSubDM.tkind = j1.getString("tkind");
                    timeLineReturnDMSubDM.tid = j1.getString("tid");
                    timeLineReturnDMSubDM.created_at = j1.getString("created_at");
                    logDM.category = getCategory(j1.getString("tkind"));
                    logDM._id = j1.getString("tid");
                    this.logCat.log(className, "category", logDM.category);
                    JSONObject j2 = new JSONObject(j1.getString("tdatas"));
                    if (timeLineReturnDMSubDM.tkind.equals("glucose")) {
                        timeLineReturnDMSubDM.manualinput = j2.getString("manualinput");
                        timeLineReturnDMSubDM.gvalue = j2.getString("gvalue");
                        timeLineReturnDMSubDM.gdate = j2.getString("gdate");
                        timeLineReturnDMSubDM.gtempeature = j2.getString("gtempeature");
                        timeLineReturnDMSubDM.gevent = j2.getString("gevent");
                        timeLineReturnDMSubDM.deviceid = j2.getString("deviceid");
                        logDM.blood_sugar_type = getblood_sugar_type(j2.getString("manualinput"));
                        logDM.blood_sugar_value = j2.getString("gvalue");
                        logDM.input_date = mobileDateFormat(j2.getString("gdate"));
                        logDM.blood_sugar_eat = j2.getString("gevent");
                        logDM.device_id = j2.getString("deviceid");
                        try {
                            logDM.blood_sugar_eat_origin = j2.getString("gmodevent");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else if (timeLineReturnDMSubDM.tkind.equals("insulin")) {
                        try {
                            timeLineReturnDMSubDM.email = j2.getString("email");
                        } catch (Exception e2) {
                        }
                        timeLineReturnDMSubDM.idate = j2.getString("idate");
                        timeLineReturnDMSubDM.itype = j2.getString("itype");
                        timeLineReturnDMSubDM.iproduct = j2.getString("iproduct");
                        timeLineReturnDMSubDM.ivalue = j2.getString("ivalue");
                        try {
                            logDM.user_id = j2.getString("email");
                        } catch (Exception e3) {
                        }
                        logDM.input_date = mobileDateFormat(j2.getString("idate"));
                        logDM.insulin_type = Integer.toString(getInsulinTypeNum(j2.getString("itype")));
                        this.logCat.log(className, "iName 0", j2.getString("iproduct"));
                        logDM.insulin_name = Integer.toString(getInsulinNameNum(j2.getString("iproduct")));
                        logDM.insulin_value = j2.getString("ivalue");
                    } else if (timeLineReturnDMSubDM.tkind.equals("note")) {
                        timeLineReturnDMSubDM.ndate = j2.getString("ndate");
                        try {
                            timeLineReturnDMSubDM.email = j2.getString("email");
                        } catch (Exception e4) {
                        }
                        timeLineReturnDMSubDM.nvalue = j2.getString("nvalue");
                        timeLineReturnDMSubDM.ntype = j2.getString("ntype");
                        try {
                            timeLineReturnDMSubDM.picture = j2.getString("picture");
                            timeLineReturnDMSubDM.thumbnail = j2.getString("thumbnail");
                        } catch (Exception e5) {
                        }
                        logDM.input_date = mobileDateFormat(j2.getString("ndate"));
                        try {
                            logDM.user_id = j2.getString("email");
                        } catch (Exception e6) {
                        }
                        logDM.note_content = j2.getString("nvalue");
                        logDM.note_type = getNote_type(j2.getString("ntype"));
                        try {
                            logDM.note_picture = j2.getString("picture");
                            logDM.note_picture_thumb = j2.getString("thumbnail");
                        } catch (Exception e7) {
                        }
                    } else if (timeLineReturnDMSubDM.tkind.toLowerCase().equals("comment")) {
                        timeLineReturnDMSubDM.ndate = j2.getString("ndate");
                        try {
                            timeLineReturnDMSubDM.email = j2.getString("email");
                        } catch (Exception e8) {
                        }
                        timeLineReturnDMSubDM.nvalue = j2.getString("nvalue");
                        timeLineReturnDMSubDM.targetemail = j2.getString("targetemail");
                        try {
                            timeLineReturnDMSubDM.picture = j2.getString("picture");
                            timeLineReturnDMSubDM.thumbnail = j2.getString("thumbnail");
                        } catch (Exception e9) {
                        }
                        this.logCat.log(className, "comment ", timeLineReturnDMSubDM.targetemail);
                        logDM.input_date = mobileDateFormat(j2.getString("ndate"));
                        logDM.user_id = j2.getString("email");
                        logDM.note_content = j2.getString("nvalue");
                        logDM.targetemail = j2.getString("targetemail");
                        try {
                            logDM.note_picture = j2.getString("picture");
                            logDM.note_picture_thumb = j2.getString("thumbnail");
                        } catch (Exception e10) {
                        }
                    }
                    timeLineReturnDM.subDMList.add(timeLineReturnDMSubDM);
                    timeLineReturnDM.subLogDMList.add(logDM);
                    String isLogSql = "";
                    if (timeLineReturnDMSubDM.tkind.equals("glucose")) {
                        if (logDM.blood_sugar_eat_origin == null || logDM.blood_sugar_eat_origin.equals("")) {
                            isLogSql = "select * from log where input_date='" + logDM.input_date + "' and category ='" + logDM.category + "' and blood_sugar_value='" + logDM.blood_sugar_value + "' and blood_sugar_type='" + logDM.blood_sugar_type + "' and blood_sugar_eat_origin ='" + logDM.blood_sugar_eat_origin + "'";
                        } else {
                            try {
                                isLogSql = "select * from log where input_date='" + logDM.input_date + "' and category ='" + logDM.category + "' and blood_sugar_value='" + logDM.blood_sugar_value + "' and blood_sugar_type='" + logDM.blood_sugar_type + "' and blood_sugar_eat='" + logDM.blood_sugar_eat + "'";
                            } catch (JSONException e11) {
                                e11.printStackTrace();
                                this.logCat.log(className, "timeLineReturnDM()", e11.toString());
                            }
                        }
                    }
                    if (timeLineReturnDMSubDM.tkind.equals("insulin")) {
                        isLogSql = "select * from log where input_date='" + logDM.input_date + "' and category ='" + logDM.category + "' and insulin_type='" + logDM.insulin_type + "' and insulin_name='" + logDM.insulin_name + "' and insulin_value='" + logDM.insulin_value + "'";
                    }
                    if (timeLineReturnDMSubDM.tkind.equals("note")) {
                        logDM.note_picture = util.toBlankStr(logDM.note_picture);
                        logDM.note_picture_thumb = util.toBlankStr(logDM.note_picture_thumb);
                        where_note_picture_str = "";
                        if (logDM.note_picture.equals("")) {
                            where_note_picture_str = "and (note_picture=null or note_picture='null' or note_picture='' or note_picture='temp.jpg') ";
                        } else {
                            where_note_picture_str = "and note_picture='" + logDM.note_picture + "'";
                        }
                        where_note_picture_thumb_str = "";
                        if (logDM.note_picture.equals("")) {
                            where_note_picture_thumb_str = "and (note_picture_thumb=null or note_picture_thumb='null' or note_picture_thumb='' or note_picture_thumb='temp.jpg') ";
                        } else {
                            where_note_picture_thumb_str = "and note_picture='" + logDM.note_picture + "' ";
                        }
                        isLogSql = "select * from log where input_date='" + logDM.input_date + "' and category ='" + logDM.category + "' and note_type='" + logDM.note_type + "' and note_content='" + logDM.note_content + "' " + where_note_picture_str + where_note_picture_thumb_str;
                    }
                    if (timeLineReturnDMSubDM.tkind.equals("comment")) {
                        logDM.note_picture = util.toBlankStr(logDM.note_picture);
                        logDM.note_picture_thumb = util.toBlankStr(logDM.note_picture_thumb);
                        where_note_picture_str = "";
                        if (logDM.note_picture.equals("")) {
                            where_note_picture_str = "and (note_picture=null or note_picture='null' or note_picture='' or note_picture='temp.jpg') ";
                        } else {
                            where_note_picture_str = "and note_picture='" + logDM.note_picture + "'";
                        }
                        where_note_picture_thumb_str = "";
                        if (logDM.note_picture.equals("")) {
                            where_note_picture_thumb_str = "and (note_picture_thumb=null or note_picture_thumb='null' or note_picture_thumb='' or note_picture_thumb='temp.jpg') ";
                        } else {
                            where_note_picture_thumb_str = "and note_picture='" + logDM.note_picture + "' ";
                        }
                        isLogSql = "select * from log where input_date='" + logDM.input_date + "' and category ='" + logDM.category + "' and note_type='" + logDM.note_type + "' and note_content='" + logDM.note_content + "' and targetemail='" + logDM.targetemail + "' " + where_note_picture_str + where_note_picture_thumb_str;
                    }
                    if (dbAction.getCount(isLogSql) > 0) {
                        this.logCat.log(className, "log____", "있음");
                    } else {
                        this.logCat.log(className, "log____", "없음");
                        logDM.update_flag = "null";
                        dbAction.insertLog(logDM);
                    }
                    if (!((!timeLineReturnDMSubDM.tkind.equals("comment") && !timeLineReturnDMSubDM.tkind.equals("note")) || logDM.note_picture == null || logDM.note_picture.equals("temp.jpg") || logDM.note_picture.equals("null") || logDM.note_picture.equals(""))) {
                        fileManager = new FileManager();
                        imgUrl = "";
                        if (logDM.note_picture.matches(".*svr_1_.*")) {
                            imgUrl = "https://54.250.126.59/img/" + logDM.note_picture;
                        } else {
                            imgUrl = "https://service.sdbiosensor.com/img/" + logDM.note_picture;
                        }
                        fileManager.imageDown1(ClassConstant.DIR_IMG, imgUrl, logDM.note_picture);
                    }
                    if (!((!timeLineReturnDMSubDM.tkind.equals("comment") && !timeLineReturnDMSubDM.tkind.equals("note")) || logDM.note_picture_thumb == null || logDM.note_picture_thumb.equals("temp.jpg") || logDM.note_picture_thumb.equals("null") || logDM.note_picture_thumb.equals(""))) {
                        fileManager = new FileManager();
                        imgUrl = "";
                        if (logDM.note_picture_thumb.matches(".*svr_1_.*")) {
                            imgUrl = "https://54.250.126.59/img/" + logDM.note_picture_thumb;
                        } else {
                            imgUrl = "https://service.sdbiosensor.com/img/" + logDM.note_picture_thumb;
                        }
                        fileManager.imageDown1(ClassConstant.DIR_IMG_THUMB, imgUrl, logDM.note_picture_thumb);
                    }
                }
                timeLineReturnDM.statusResult = "ok";
            } else {
                timeLineReturnDM.statusResult = "";
            }
        }
        return timeLineReturnDM;
    }

    public UserProfileReturnDM userProfileReturnDM(String jsonStr) {
        UserProfileReturnDM userProfileReturnDM = new UserProfileReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                userProfileReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data"));
                userProfileReturnDM.id = j1.getString("id");
                userProfileReturnDM.email = j1.getString("email");
                userProfileReturnDM.birth = j1.getString("birth");
                userProfileReturnDM.gender = j1.getString("gender");
                userProfileReturnDM.height = j1.getString("height");
                userProfileReturnDM.heightunit = j1.getString("heightunit");
                userProfileReturnDM.weight = j1.getString("weight");
                userProfileReturnDM.weightunit = j1.getString("weightunit");
                userProfileReturnDM.diabeticsince = j1.getString("diabeticsince");
                userProfileReturnDM.diabetestype = j1.getString("diabetestype");
                userProfileReturnDM.glucoseunit = j1.getString("glucoseunit");
                userProfileReturnDM.hypo = j1.getString("hypo");
                userProfileReturnDM.hyper = j1.getString("hyper");
                userProfileReturnDM.datetype = j1.getString("datetype");
                userProfileReturnDM.timetype = j1.getString("timetype");
                userProfileReturnDM.language = j1.getString("language");
                userProfileReturnDM.photo1 = j1.getString("photo1");
                userProfileReturnDM.photo2 = j1.getString("photo2");
                userProfileReturnDM.created_at = j1.getString("created_at");
                userProfileReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return userProfileReturnDM;
    }

    public AddOtherrecordReturnDM otherrecordReturnDM(String jsonStr) {
        AddOtherrecordReturnDM otherrecordReturnDM = new AddOtherrecordReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                otherrecordReturnDM.code = j0.getString("code");
                JSONObject j1 = new JSONObject(j0.getString("data").toString());
                otherrecordReturnDM.result = j1.getString("result");
                otherrecordReturnDM.id = j1.getString("id");
                otherrecordReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return otherrecordReturnDM;
    }

    public ModOtherrecordReturnDM modOtherrecordReturnDM(String jsonStr) {
        ModOtherrecordReturnDM modOtherrecordReturnDM = new ModOtherrecordReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                modOtherrecordReturnDM.code = j0.getString("code");
                modOtherrecordReturnDM.result = new JSONObject(j0.getString("data").toString()).getString("result");
                modOtherrecordReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return modOtherrecordReturnDM;
    }

    public DelOtherrecordReturnDM delOtherrecordReturnDM(String jsonStr) {
        DelOtherrecordReturnDM delOtherrecordReturnDM = new DelOtherrecordReturnDM();
        if (jsonStr != null) {
            try {
                JSONObject j0 = new JSONObject(jsonStr);
                delOtherrecordReturnDM.code = j0.getString("code");
                delOtherrecordReturnDM.result = new JSONObject(j0.getString("data").toString()).getString("result");
                delOtherrecordReturnDM.statusResult = "ok";
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return delOtherrecordReturnDM;
    }
}
