package com.accumed.gtech.util;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.Uri;
import android.util.Log;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.fragments.GraphFragment;
import com.accumed.gtech.structure.UtilStrStructure;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Util implements UtilStrStructure {
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    static final String className = "Util";
    LogCat logCat = new LogCat();
    Context mContext;

    public Util(Context c) {
        this.mContext = c;
    }

    public boolean isNullEmpty(String str) {
        if (str == null || str.length() == 0) {
            return false;
        }
        return true;
    }

    public String inputDateToGoodDate(String dateStr) {
        String goodDate = "";
        int hour = Integer.parseInt(dateStr.substring(8, 10));
        if (hour < 12 || hour >= 24) {
            goodDate = this.mContext.getString(C0213R.string.unit_am) + " " + hour + ":";
        } else {
            goodDate = this.mContext.getString(C0213R.string.unit_pm);
            if (hour == 12) {
                goodDate = goodDate + " 12:";
            } else {
                goodDate = goodDate + " " + (hour - 12) + ":";
            }
        }
        return goodDate + dateStr.substring(10, 12);
    }

    public String logApLineDateFormat(String dateStr) {
        this.logCat.log(className, "dateStr date", dateStr);
        String date = dateStr.substring(0, 8);
        this.logCat.log(className, "inputDateLineToGoodDate date", date);
        String strLanguage = this.mContext.getResources().getConfiguration().locale.getLanguage();
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        Log.e("dckim", "setting MY_DATE_METHOD:::" + pref.getString(PreferenceAction.MY_DATE_METHOD));
        Log.e("dckim", "setting MY_TIME_METHOD:::" + pref.getString(PreferenceAction.MY_TIME_METHOD));
        String location_format = "EEE, dd MMM yyyy";
        Locale location = Locale.ENGLISH;
        if (strLanguage != null && strLanguage.equals("ko")) {
            if (pref.getString(PreferenceAction.MY_DATE_METHOD).equals("yyyy/dd/MM")) {
                location_format = "yyyy.MM.dd EEE";
            } else if (pref.getString(PreferenceAction.MY_DATE_METHOD).equals("MM/dd/yyyy")) {
                location_format = "MM dd yyyy EEE";
            } else if (pref.getString(PreferenceAction.MY_DATE_METHOD).equals("yyyy/dd/MM")) {
                location_format = "yyyy dd MM EEE";
            } else if (pref.getString(PreferenceAction.MY_DATE_METHOD).equals("dd/MM/yyyy")) {
                location_format = "dd MM yyyy EEE";
            } else {
                location_format = "dd MM yyyy EEE";
            }
            location = Locale.KOREAN;
        } else if (pref.getString(PreferenceAction.MY_DATE_METHOD).equals("yyyy/dd/MM")) {
            location_format = "EEE, yyyy dd MM";
            if (strLanguage != null && strLanguage.equals("ch")) {
                location = Locale.CHINA;
            } else if (strLanguage != null && strLanguage.equals("ru")) {
                location = new Locale("ru", "RU");
            } else if (strLanguage != null && strLanguage.equals("ja")) {
                location = Locale.JAPAN;
            } else if (strLanguage == null || !strLanguage.equals("pt")) {
                location = Locale.ENGLISH;
            } else {
                location = new Locale("pt", "BR");
            }
        } else if (pref.getString(PreferenceAction.MY_DATE_METHOD).equals("MM/dd/yyyy")) {
            location_format = "EEE, MM dd yyyy";
            if (strLanguage != null && strLanguage.equals("ch")) {
                location = Locale.CHINA;
            } else if (strLanguage != null && strLanguage.equals("ru")) {
                location = new Locale("ru", "RU");
            } else if (strLanguage != null && strLanguage.equals("ja")) {
                location = Locale.JAPAN;
            } else if (strLanguage == null || !strLanguage.equals("pt")) {
                location = Locale.ENGLISH;
            } else {
                location = new Locale("pt", "BR");
            }
        } else if (pref.getString(PreferenceAction.MY_DATE_METHOD).equals("yyyy/dd/MM")) {
            location_format = "EEE, yyyy dd MM";
            if (strLanguage != null && strLanguage.equals("ch")) {
                location = Locale.CHINA;
            } else if (strLanguage != null && strLanguage.equals("ru")) {
                location = new Locale("ru", "RU");
            } else if (strLanguage != null && strLanguage.equals("ja")) {
                location = Locale.JAPAN;
            } else if (strLanguage == null || !strLanguage.equals("pt")) {
                location = Locale.ENGLISH;
            } else {
                location = new Locale("pt", "BR");
            }
        } else if (pref.getString(PreferenceAction.MY_DATE_METHOD).equals("dd/MM/yyyy")) {
            location_format = "EEE, dd MM yyyy";
            if (strLanguage != null && strLanguage.equals("ch")) {
                location = Locale.CHINA;
            } else if (strLanguage != null && strLanguage.equals("ru")) {
                location = new Locale("ru", "RU");
            } else if (strLanguage != null && strLanguage.equals("ja")) {
                location = Locale.JAPAN;
            } else if (strLanguage == null || !strLanguage.equals("pt")) {
                location = Locale.ENGLISH;
            } else {
                location = new Locale("pt", "BR");
            }
        } else {
            location_format = "EEE, dd MM yyyy";
            if (strLanguage != null && strLanguage.equals("ch")) {
                location = Locale.CHINA;
            } else if (strLanguage != null && strLanguage.equals("ru")) {
                location = new Locale("ru", "RU");
            } else if (strLanguage != null && strLanguage.equals("ja")) {
                location = Locale.JAPAN;
            } else if (strLanguage == null || !strLanguage.equals("pt")) {
                location = Locale.ENGLISH;
            } else {
                location = new Locale("pt", "BR");
            }
        }
        String s = "";
        try {
            s = new SimpleDateFormat(location_format, location).format(new SimpleDateFormat("yyyyMMdd").parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return s;
    }

    public String timeSet(String date) {
        if (date == null) {
            return null;
        }
        String rdate = date.replaceAll("\\-", "").replaceAll("\\.", "").replaceAll("\\:", "").replaceAll("\\p{Space}", "");
        if (rdate == null || rdate.trim().equals("")) {
            return rdate;
        }
        if (rdate.length() == 8) {
            rdate = rdate.substring(0, 4) + "-" + rdate.substring(4, 6) + "-" + rdate.substring(6, 8) + " 00:00:00.000";
        } else if (rdate.length() == 12) {
            rdate = rdate.substring(0, 4) + "-" + rdate.substring(4, 6) + "-" + rdate.substring(6, 8) + " " + rdate.substring(8, 10) + ":" + rdate.substring(10) + ":00.000";
        } else if (rdate.length() == 14) {
            rdate = rdate.substring(0, 4) + "-" + rdate.substring(4, 6) + "-" + rdate.substring(6, 8) + " " + rdate.substring(8, 10) + ":" + rdate.substring(10, 12) + ":" + rdate.substring(12) + ".000";
        } else if (rdate.length() == 17) {
            rdate = rdate.substring(0, 4) + "-" + rdate.substring(4, 6) + "-" + rdate.substring(6, 8) + " " + rdate.substring(8, 10) + ":" + rdate.substring(10, 12) + ":" + rdate.substring(12, 14) + "." + rdate.substring(14);
        }
        return rdate;
    }

    public String blankToZero(String s) {
        if (s.equals("")) {
            return "0";
        }
        return s;
    }

    public String toBlankStr(String s) {
        String result = s;
        if (s == null) {
            return "";
        }
        if (s.equals("null")) {
            return "";
        }
        return result;
    }

    public String vvv(String bloodSugarValue) {
        if (Integer.parseInt(bloodSugarValue) < 100) {
            return "0" + bloodSugarValue;
        }
        return bloodSugarValue;
    }

    public String ee(String bloodSugarEvent) {
        if (Integer.parseInt(bloodSugarEvent) < 10) {
            return "0" + bloodSugarEvent;
        }
        return bloodSugarEvent;
    }

    public String mgdlToMmolL(String bloodValue) {
        try {
            float mmol_L = (float) (((double) Integer.parseInt(bloodValue)) / 18.01d);
            return Float.toString(Float.parseFloat(String.format("%.1f", new Object[]{Float.valueOf(mmol_L)}).replace(",", ".")));
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public String mmolLToMgdl(String bloodValue) {
        float vv = (float) (((double) Float.parseFloat(bloodValue)) * 18.01d);
        return Integer.toString((int) Float.parseFloat(String.format("%.0f", new Object[]{Float.valueOf(vv)})));
    }

    public static String conversionStrDateTimeFormat(String date) {
        if (date == null) {
            return null;
        }
        return date.replaceAll("-", "").replaceAll(":", "").replaceAll("\\.", "").replaceAll("\\p{Space}", "");
    }

    public String getServerDateFormat(String dStr) {
        this.logCat.log(className, "dStr--", dStr);
        String y = dStr.substring(0, 4);
        String m = dStr.substring(4, 6);
        String d = dStr.substring(6, 8);
        String h = dStr.substring(8, 10);
        String result = y + "-" + m + "-" + d + " " + h + ":" + dStr.substring(10, 12) + ":00.000";
        this.logCat.log(className, "dStr-- result", result);
        return result;
    }

    public String getServerNoteType(String s) {
        String result = "";
        if (s == null) {
            return "Note";
        }
        if (s.equals("0")) {
            result = "Meal";
        } else if (s.equals("1")) {
            result = "EX";
        } else if (s.equals("2")) {
            result = "Note";
        } else if (s.equals(LogDM.GLUCOSE_EAT_FASTING)) {
            result = "comment";
        } else {
            result = "Meal";
        }
        return result;
    }

    public String mobileProfileDateFormat(String dStr) {
        return dStr.substring(0, 10).replaceAll("-", ".");
    }

    public String getTomorrow() {
        Date today = new Date();
        Date seldate = new Date();
        SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd");
        seldate.setTime(today.getTime() + GraphFragment.DATE_DAY);
        return simple.format(seldate);
    }

    public String getTomorrowBartype(String dateString) {
        return dateString.substring(0, 4) + "-" + dateString.substring(4, 6) + "-" + dateString.substring(6, 8);
    }

    public int getYear() {
        return Integer.parseInt(new SimpleDateFormat("yyyy").format(Calendar.getInstance().getTime()));
    }

    public int getMonth() {
        return Integer.parseInt(new SimpleDateFormat("MM").format(Calendar.getInstance().getTime()));
    }

    public int getDay() {
        return Integer.parseInt(new SimpleDateFormat("dd").format(Calendar.getInstance().getTime()));
    }

    public String convertDateValue(int value) {
        if (value > 9) {
            return String.valueOf(value);
        }
        return String.valueOf(addZero(value));
    }

    public String addZero(int value) {
        if (value < 10) {
            return "0" + String.valueOf(value);
        }
        return String.valueOf(value);
    }

    public String floatToInt(String s) {
        try {
            return s.split("\\.")[0];
        } catch (Exception e) {
            return s;
        }
    }

    public Bitmap uriToBitmap(Uri uri, int ratio) {
        Options options = new Options();
        options.inSampleSize = ratio;
        return BitmapFactory.decodeFile(uri.getPath().toString(), options);
    }

    public static String parse(BluetoothGattCharacteristic characteristic) {
        return parse(characteristic.getValue());
    }

    public static String parse(BluetoothGattDescriptor descriptor) {
        return parse(descriptor.getValue());
    }

    public static String parse(byte[] data) {
        if (data == null || data.length == 0) {
            return "";
        }
        char[] out = new char[((data.length * 3) - 1)];
        for (int j = 0; j < data.length; j++) {
            int v = data[j] & 255;
            out[j * 3] = HEX_ARRAY[v >>> 4];
            out[(j * 3) + 1] = HEX_ARRAY[v & 15];
            if (j != data.length - 1) {
                out[(j * 3) + 2] = '-';
            }
        }
        return "(0x) " + new String(out);
    }

    public static String byteArrayToHex(byte[] ba) {
        if (ba == null || ba.length == 0) {
            return null;
        }
        StringBuffer sb = new StringBuffer(ba.length * 2);
        for (byte b : ba) {
            String hexNumber = "0" + Integer.toHexString(b & 255);
            sb.append(hexNumber.substring(hexNumber.length() - 2));
        }
        return sb.toString();
    }
}
