package com.accumed.gtech.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.accumed.gtech.DBStructure;
import com.accumed.gtech.datamining.DataMiningProgressListener;
import com.accumed.gtech.datamodel.DeviceDM;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.thread.datamodel.AddDeviceThrDM;
import com.accumed.gtech.thread.datamodel.FriendListReturnDMSubDM;
import com.accumed.gtech.thread.datamodel.OtherrecordThrDM;
import java.text.NumberFormat;
import java.util.ArrayList;

public class DBAction {
    static final boolean IS_CNT_QRY = false;
    static final String className = "DBAction";
    DataMiningProgressListener dataMiningProgressListener;
    SQLiteDatabase db;
    DBStructure dbHelper = new DBStructure(this.mContext, DBStructure.DB_NAME, null, Integer.parseInt("1"));
    LogCat logCat = new LogCat();
    Context mContext;
    ContentValues row;

    public boolean isRegisterDevice(java.lang.String r19) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find immediate dominator for block B:21:? in {4, 6, 9, 12, 13, 18, 20, 22, 23} preds:[]
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.computeDominators(BlockProcessor.java:129)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.processBlocksTree(BlockProcessor.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockProcessor.rerun(BlockProcessor.java:44)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:57)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r18 = this;
        r10 = java.lang.System.nanoTime();
        r0 = r18;
        r9 = r0.logCat;
        r12 = "DBAction";
        r13 = "NDEFTAGTest";
        r14 = new java.lang.StringBuilder;
        r14.<init>();
        r15 = "dbAction.isRegisterDevice query:SELECT count(*) FROM device where device_id='";
        r14 = r14.append(r15);
        r0 = r19;
        r14 = r14.append(r0);
        r15 = "'";
        r14 = r14.append(r15);
        r14 = r14.toString();
        r9.log(r12, r13, r14);
        r8 = 0;
        r2 = 0;
        r0 = r18;
        r9 = r0.dbHelper;
        r9 = r9.getReadableDatabase();
        r0 = r18;
        r0.db = r9;
        r0 = r18;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9 = r0.db;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12.<init>();	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r13 = "SELECT * FROM device where device_id='";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = r12.append(r13);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r0 = r19;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = r12.append(r0);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r13 = "'";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = r12.append(r13);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = r12.toString();	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r13 = 0;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r3 = r9.rawQuery(r12, r13);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r0 = r18;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9 = r0.logCat;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = "DBAction";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r13 = "isRegisterDeviceId";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r14 = "ok";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9.log(r12, r13, r14);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9 = r3.getClass();	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        if (r9 != 0) goto L_0x00d7;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
    L_0x006f:
        r2 = 0;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
    L_0x0070:
        if (r2 != 0) goto L_0x00dc;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
    L_0x0072:
        r8 = 0;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
    L_0x0073:
        r0 = r18;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9 = r0.logCat;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = "DBAction";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r13 = "NDEFTAGTest";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r14 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r14.<init>();	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r15 = "dbAction.isRegisterDevice cnt:";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r14 = r14.append(r15);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r14 = r14.append(r2);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r14 = r14.toString();	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9.log(r12, r13, r14);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r3.close();	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r0 = r18;
        r9 = r0.db;
        r9.close();
    L_0x009b:
        r6 = java.lang.System.nanoTime();
        r5 = java.text.NumberFormat.getNumberInstance();
        r0 = r18;
        r9 = r0.logCat;
        r12 = "DBAction";
        r13 = "NDEFTAGTest";
        r14 = new java.lang.StringBuilder;
        r14.<init>();
        r15 = "dbAction.isRegisterDevice DBcount gap:";
        r14 = r14.append(r15);
        r16 = r6 - r10;
        r0 = r16;
        r15 = r5.format(r0);
        r14 = r14.append(r15);
        r14 = r14.toString();
        r9.log(r12, r13, r14);
        r0 = r18;
        r9 = r0.logCat;
        r12 = "DBAction";
        r13 = "NDEFTAGTest";
        r14 = "dbAction-----------------------------------------------------------------------------------------------------------------------";
        r9.log(r12, r13, r14);
        return r8;
    L_0x00d7:
        r2 = r3.getCount();	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        goto L_0x0070;
    L_0x00dc:
        r8 = 1;
        goto L_0x0073;
    L_0x00de:
        r4 = move-exception;
        r0 = r18;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9 = r0.logCat;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = "DBAction";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r13 = "isRegisterDeviceId";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r14 = "failed";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9.log(r12, r13, r14);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r0 = r18;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9 = r0.logCat;	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r12 = "DBAction";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r13 = "isRegisterDeviceId";	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r14 = r4.toString();	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r9.log(r12, r13, r14);	 Catch:{ Exception -> 0x00de, all -> 0x0104 }
        r8 = 0;
        r0 = r18;
        r9 = r0.db;
        r9.close();
        goto L_0x009b;
    L_0x0104:
        r9 = move-exception;
        r0 = r18;
        r12 = r0.db;
        r12.close();
        throw r9;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.accumed.gtech.util.DBAction.isRegisterDevice(java.lang.String):boolean");
    }

    public DBAction(Context c) {
        this.mContext = c;
        dbUpdate();
    }

    public DBAction(Context c, DataMiningProgressListener l) {
        this.mContext = c;
        this.dataMiningProgressListener = l;
        dbUpdate();
    }

    private void dbUpdate() {
        try {
            this.db = this.dbHelper.getWritableDatabase();
            this.dbHelper.onUpgrade(this.db, 0, 0);
            this.db.close();
        } catch (Exception e) {
        }
    }

    public void viewSchema() {
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        String q = "SELECT * FROM sqlite_master";
        this.dbHelper.onUpgrade(this.db, 0, 0);
        try {
            Cursor cursor = this.db.rawQuery(q, null);
            this.logCat.log("sqlite_master()", "sqlite_master()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                this.logCat.log("sqlite_master()", "sqlite_master()", cursor.getString(4));
            }
            this.logCat.log("sqlite_master()", "sqlite_master()", "-----------------------------------------");
            cursor.close();
            this.db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
    }

    public boolean executeQuery(String q) {
        boolean result = false;
        this.logCat.log(className, "update executeQuery() in", "q");
        this.db = null;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            this.db.execSQL(q);
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean updateDateDevice(String deviceId, String date) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            this.db.execSQL("UPDATE device set update_date='" + date + "' where device_id='" + deviceId + "'");
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "updateDateDevice", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean update_IdDevice(String deviceId, String _Id) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            this.db.execSQL("UPDATE device set _id='" + _Id + "' where device_id='" + deviceId + "'");
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "update_IdDevice", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean insertDevice(DeviceDM dm) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            this.row = new ContentValues();
            this.row.put("device_id", dm.device_id);
            this.row.put("_id", dm._id);
            this.row.put("update_date", dm.update_date);
            this.db.insert(DBStructure.DB_TABLE_NAME_DEVICE, null, this.row);
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "insertDevice", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean isDevice() {
        long startTime = System.nanoTime();
        String q = "SELECT count(*) FROM device";
        this.logCat.log(className, "NDEFTAGTest", "dbAction.isDevice query:" + q);
        boolean result = false;
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery(q, null);
            int total = cursor.getCount();
            if (total > 0) {
                result = true;
            } else {
                result = false;
            }
            this.logCat.log(className, "NDEFTAGTest", "dbAction.isDevice cnt:" + total);
            cursor.close();
        } catch (Exception e) {
            result = false;
        } finally {
            this.db.close();
        }
        long endTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.isDevice DBcount gap:" + NumberFormat.getNumberInstance().format(endTime - startTime));
        this.logCat.log(className, "NDEFTAGTest", "dbAction-----------------------------------------------------------------------------------------------------------------------");
        return result;
    }

    public ArrayList<AddDeviceThrDM> getAddDeviceThrDMList() {
        ArrayList<AddDeviceThrDM> addDeviceThrDMList = new ArrayList();
        ArrayList<DeviceDM> deviceDMList = selectDevice();
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        for (int a = 0; a < deviceDMList.size(); a++) {
            AddDeviceThrDM addDeviceThrDM = new AddDeviceThrDM();
            addDeviceThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
            addDeviceThrDM.deviceid = ((DeviceDM) deviceDMList.get(a)).device_id;
            addDeviceThrDM.lastvalue = makeDeviceLastValue(((DeviceDM) deviceDMList.get(a)).device_id);
            addDeviceThrDMList.add(addDeviceThrDM);
        }
        return addDeviceThrDMList;
    }

    public ArrayList<DeviceDM> selectDevice() {
        ArrayList<DeviceDM> list = new ArrayList();
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM device where _id=''", null);
            this.logCat.log(className, "selectDevice()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                DeviceDM dm = new DeviceDM();
                dm.seq = cursor.getString(0);
                dm.device_id = cursor.getString(1);
                dm._id = cursor.getString(2);
                dm.update_date = cursor.getString(3);
                list.add(dm);
            }
            this.logCat.log(className, "selectDevice()", "-----------------------------------------");
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        return list;
    }

    private String makeDeviceLastValue(String deviceId) {
        String lastValueStr = "";
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM log where category='0' and device_id='" + deviceId + "' order by input_date DESC, seq DESC", null);
            this.logCat.log(className, "makeDeviceLastValue()", "-----------------------------------------");
            int p = 0;
            while (cursor.moveToNext() && p < 5) {
                String date = cursor.getString(5).substring(0, 12);
                String value = cursor.getString(10);
                if (value.length() == 1) {
                    value = "00" + value;
                } else if (cursor.getString(10).length() == 2) {
                    value = "0" + value;
                }
                String event = cursor.getString(9);
                if (event.length() == 1) {
                    event = "0" + event;
                }
                lastValueStr = lastValueStr + date + value + event + ",";
                p++;
            }
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        if (lastValueStr.length() != 0 && lastValueStr.substring(lastValueStr.length() - 1, lastValueStr.length()).equals(",")) {
            lastValueStr = lastValueStr.substring(0, lastValueStr.length() - 1);
        }
        this.logCat.log(className, "makeDeviceLastValue() lastValueStr ", lastValueStr);
        return lastValueStr;
    }

    public int getCount(String q) {
        long startTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.getCount query:" + q);
        int total = 0;
        try {
            this.db = this.dbHelper.getReadableDatabase();
            Cursor cursor = this.db.rawQuery(q, null);
            total = cursor.getCount();
            this.logCat.log(className, "total", total + "");
            this.logCat.log(className, "NDEFTAGTest", "dbAction.getCount cnt:" + total);
            cursor.close();
            this.db.close();
        } catch (Exception e) {
            total = 0;
            this.db.close();
        } catch (Exception e2) {
        } catch (Throwable th) {
            this.db.close();
        }
        long endTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.getCount DBcount gap:" + NumberFormat.getNumberInstance().format(endTime - startTime));
        this.logCat.log(className, "NDEFTAGTest", "dbAction-----------------------------------------------------------------------------------------------------------------------");
        return total;
    }

    public int getCountForUpdate(String q) {
        long startTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.getCountForUpdate query:" + q);
        int total = 0;
        try {
            this.db = this.dbHelper.getReadableDatabase();
            Cursor cursor = this.db.rawQuery(q, null);
            if (cursor.moveToNext()) {
                total = cursor.getInt(0);
                this.logCat.log(className, "NDEFTAGTest", "dbAction.getCountForUpdate cnt:" + cursor.getInt(0));
            }
            cursor.close();
            this.db.close();
        } catch (Exception e) {
            total = 0;
            this.db.close();
        } catch (Exception e2) {
        } catch (Throwable th) {
            this.db.close();
        }
        long endTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.getCountForUpdate DBcount gap:" + NumberFormat.getNumberInstance().format(endTime - startTime));
        this.logCat.log(className, "NDEFTAGTest", "dbAction-----------------------------------------------------------------------------------------------------------------------");
        return total;
    }

    public int getCountByTransaction(String q, SQLiteDatabase db) {
        long startTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.getCountByTransaction query:" + q);
        Cursor cursor = db.rawQuery(q, null);
        int total = cursor.getCount();
        this.logCat.log(className, "total", total + "");
        this.logCat.log(className, "NDEFTAGTest", "dbAction.getCountByTransaction cnt:" + total);
        cursor.close();
        long endTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.getCountByTransaction DBcount gap:" + NumberFormat.getNumberInstance().format(endTime - startTime));
        this.logCat.log(className, "NDEFTAGTest", "dbAction-----------------------------------------------------------------------------------------------------------------------");
        return total;
    }

    public boolean isLogRecord(String q) {
        long startTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.isLogRecord query:" + q);
        boolean result = false;
        this.logCat.log(className, "isLogRecord() q", q);
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery(q, null);
            int total = cursor.getCount();
            cursor.close();
            this.logCat.log(className, "total", total + "");
            if (total > 0) {
                result = true;
            } else {
                result = false;
            }
            this.logCat.log(className, "NDEFTAGTest", "dbAction.isLogRecord cnt:" + total);
        } catch (Exception e) {
            result = false;
        } finally {
            this.db.close();
        }
        long endTime = System.nanoTime();
        this.logCat.log(className, "NDEFTAGTest", "dbAction.isLogRecord DBcount gap:" + NumberFormat.getNumberInstance().format(endTime - startTime));
        this.logCat.log(className, "NDEFTAGTest", "dbAction-----------------------------------------------------------------------------------------------------------------------");
        return result;
    }

    public boolean insertLog(LogDM dm) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            this.db.execSQL("insert or ignore into log(_id, user_id, update_flag, device_id, input_date, system_date, category, blood_sugar_type, blood_sugar_eat, blood_sugar_value, insulin_type, insulin_name, insulin_value, note_type, note_content, note_picture, note_picture_thumb, blood_sugar_eat_origin, targetemail) values('" + dm._id + "', '" + dm.user_id + "', '" + dm.update_flag + "', '" + dm.device_id + "', '" + dm.input_date + "', '" + dm.system_date + "', '" + dm.category + "', '" + dm.blood_sugar_type + "', '" + dm.blood_sugar_eat + "', '" + dm.blood_sugar_value + "', '" + dm.insulin_type + "', '" + dm.insulin_name + "', '" + dm.insulin_value + "', '" + dm.note_type + "', '" + dm.note_content + "', '" + dm.note_picture + "', '" + dm.note_picture_thumb + "', '" + dm.blood_sugar_eat_origin + "', '" + dm.targetemail + "')");
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean insertLogList(ArrayList<LogDM> dmList) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        int i = 0;
        while (i < dmList.size()) {
            try {
                String sql = "insert into log(_id, user_id, update_flag, device_id, input_date, system_date, category, blood_sugar_type, blood_sugar_eat, blood_sugar_value, insulin_type, insulin_name, insulin_value, note_type, note_content, note_picture, note_picture_thumb, blood_sugar_eat_origin, targetemail) values('" + ((LogDM) dmList.get(i))._id + "', '" + ((LogDM) dmList.get(i)).user_id + "', '" + ((LogDM) dmList.get(i)).update_flag + "', '" + ((LogDM) dmList.get(i)).device_id + "', '" + ((LogDM) dmList.get(i)).input_date + "', '" + ((LogDM) dmList.get(i)).system_date + "', '" + ((LogDM) dmList.get(i)).category + "', '" + ((LogDM) dmList.get(i)).blood_sugar_type + "', '" + ((LogDM) dmList.get(i)).blood_sugar_eat + "', '" + ((LogDM) dmList.get(i)).blood_sugar_value + "', '" + ((LogDM) dmList.get(i)).insulin_type + "', '" + ((LogDM) dmList.get(i)).insulin_name + "', '" + ((LogDM) dmList.get(i)).insulin_value + "', '" + ((LogDM) dmList.get(i)).note_type + "', '" + ((LogDM) dmList.get(i)).note_content + "', '" + ((LogDM) dmList.get(i)).note_picture + "', '" + ((LogDM) dmList.get(i)).note_picture_thumb + "', '" + ((LogDM) dmList.get(i)).blood_sugar_eat_origin + "', '" + ((LogDM) dmList.get(i)).targetemail + "')";
                this.logCat.log(className, "insertLogList() i", i + "");
                this.logCat.log(className, "insertLogList() sql", sql);
                try {
                    this.db.execSQL(sql);
                    this.logCat.log(className, "device_data_input", "ok :" + ((LogDM) dmList.get(i)).blood_sugar_value + "/" + ((LogDM) dmList.get(i)).input_date);
                } catch (Exception e) {
                    this.logCat.log(className, "device_data_input", "failed :" + ((LogDM) dmList.get(i)).blood_sugar_value + "/" + ((LogDM) dmList.get(i)).input_date);
                }
                i++;
            } catch (Exception e2) {
                this.logCat.log(className, "insertLogList()", "log input failed");
                this.logCat.log(className, "insertLogList()", e2.toString());
                result = false;
            } finally {
                this.db.endTransaction();
                this.db.close();
            }
        }
        this.db.setTransactionSuccessful();
        result = true;
        return result;
    }

    public ArrayList<LogDM> selectLogList(String query) {
        this.db = this.dbHelper.getReadableDatabase();
        ArrayList<LogDM> list = new ArrayList();
        try {
            Cursor cursor = this.db.rawQuery(query, null);
            this.logCat.log(className, "query", query);
            this.logCat.log(className, "testLogSelect()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                LogDM logDM = new LogDM();
                logDM.seq = cursor.getString(0);
                logDM._id = cursor.getString(1);
                logDM.user_id = cursor.getString(2);
                logDM.update_flag = cursor.getString(3);
                logDM.device_id = cursor.getString(4);
                logDM.input_date = cursor.getString(5);
                logDM.system_date = cursor.getString(6);
                logDM.category = cursor.getString(7);
                logDM.blood_sugar_type = cursor.getString(8);
                logDM.blood_sugar_eat = cursor.getString(9);
                logDM.blood_sugar_value = cursor.getString(10);
                logDM.insulin_type = cursor.getString(11);
                logDM.insulin_name = cursor.getString(12);
                logDM.insulin_value = cursor.getString(13);
                logDM.note_type = cursor.getString(14);
                logDM.note_content = cursor.getString(15);
                logDM.note_picture = cursor.getString(16);
                logDM.note_picture_thumb = cursor.getString(17);
                logDM.targetemail = cursor.getString(18);
                logDM.blood_sugar_eat_origin = cursor.getString(19);
                list.add(logDM);
            }
            this.logCat.log(className, "selectLogList()", "-----------------------------------------");
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        this.logCat.log(className, "list size", list.size() + "");
        return list;
    }

    public boolean updateLog(LogDM logDM) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            String q = "update log set _id = '" + logDM._id + "', user_id = '" + logDM.user_id + "', update_flag = '" + logDM.update_flag + "', device_id = '" + logDM.device_id + "', input_date = '" + logDM.input_date + "', system_date = '" + logDM.system_date + "', category = '" + logDM.category + "', blood_sugar_type = '" + logDM.blood_sugar_type + "', blood_sugar_eat = '" + logDM.blood_sugar_eat + "', blood_sugar_value = '" + logDM.blood_sugar_value + "', insulin_type = '" + logDM.insulin_type + "', insulin_name = '" + logDM.insulin_name + "', insulin_value = '" + logDM.insulin_value + "', note_type = '" + logDM.note_type + "', note_content = '" + logDM.note_content + "', note_picture = '" + logDM.note_picture + "', note_picture_thumb = '" + logDM.note_picture_thumb + "', blood_sugar_eat_origin = '" + logDM.blood_sugar_eat_origin + "', targetemail = '" + logDM.targetemail + "' where seq = '" + logDM.seq + "'";
            this.logCat.log(className, "updatelogSql", q);
            this.db.execSQL(q);
            this.db.setTransactionSuccessful();
            result = true;
            this.logCat.log(className, "updateLog", "true");
        } catch (Exception e) {
            this.logCat.log(className, "updateLog", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean delLog(String seq) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            this.db.execSQL("delete from log where seq='" + seq + "'");
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "del log", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public String getOneDeviceId() {
        String result = "";
        this.db = this.dbHelper.getReadableDatabase();
        String q = "SELECT device_id FROM device LIMIT 1";
        try {
            Cursor cursor = this.db.rawQuery(q, null);
            this.logCat.log(className, "getOneDeviceId()", "cursor = db.rawQuery(q, null);");
            if (cursor.moveToFirst()) {
                result = cursor.getString(0);
                this.logCat.log(className, "getOneDeviceId()", "device_id:" + result + ",query:" + q);
            }
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        return result;
    }

    public int getLastSeq(String tableName, String updateFlag) {
        int result = 0;
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT MAX(seq) FROM " + tableName + " where update_flag='" + updateFlag + "'", null);
            cursor.moveToFirst();
            result = cursor.getInt(0);
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        return result;
    }

    public int getSeq(String tableName, String systemDate) {
        int result = 0;
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT seq FROM " + tableName + " where system_date ='" + systemDate + "'", null);
            cursor.moveToFirst();
            result = cursor.getInt(0);
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        return result;
    }

    public boolean insertOtherrecord(OtherrecordThrDM dm) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            this.row = new ContentValues();
            this.row.put("email", dm.email);
            this.row.put("odate", dm.odate);
            this.row.put("weight", dm.weight);
            this.row.put("bmi", dm.bmi);
            this.row.put("waist", dm.waist);
            this.row.put("waistunit", dm.waistunit);
            this.row.put("hba1c", dm.hba1c);
            this.row.put("hba1cunit", dm.hba1cunit);
            this.row.put("bloodpressure", dm.bloodpressure);
            this.row.put("tc", dm.tc);
            this.row.put("tg", dm.tg);
            this.row.put("hdl", dm.hdl);
            this.row.put("ldl", dm.ldl);
            this.row.put("_id", dm._id);
            this.row.put("update_flag", dm.update_flag);
            this.row.put("input_date", dm.input_date);
            this.row.put("system_date", dm.system_date);
            this.db.insert(DBStructure.DB_TABLE_NAME_OTHERRECORD, null, this.row);
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "insertOtherrecord", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public ArrayList<OtherrecordThrDM> otherrecordSelect() {
        ArrayList<OtherrecordThrDM> list = new ArrayList();
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM otherrecord order by odate desc, system_date desc", null);
            this.logCat.log(className, "otherrecordSelect()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                OtherrecordThrDM dm = new OtherrecordThrDM();
                dm.seq = cursor.getString(0);
                dm.email = cursor.getString(1);
                dm.odate = cursor.getString(2);
                dm.weight = cursor.getString(3);
                dm.bmi = cursor.getString(4);
                dm.waist = cursor.getString(5);
                dm.waistunit = cursor.getString(6);
                dm.hba1c = cursor.getString(7);
                dm.hba1cunit = cursor.getString(8);
                dm.bloodpressure = cursor.getString(9);
                dm.tc = cursor.getString(10);
                dm.tg = cursor.getString(11);
                dm.hdl = cursor.getString(12);
                dm.ldl = cursor.getString(13);
                dm._id = cursor.getString(14);
                dm.update_flag = cursor.getString(15);
                dm.input_date = cursor.getString(16);
                dm.system_date = cursor.getString(17);
                list.add(dm);
            }
            this.logCat.log(className, "testOtherrecordSelect()", "-----------------------------------------");
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        return list;
    }

    public boolean delOtherrecord(String seq) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        try {
            this.db.execSQL("delete from otherrecord where seq='" + seq + "'");
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "del Otherrecord", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean updateOtherrecord(OtherrecordThrDM dm) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        String sqlStr = "UPDATE otherrecord set email ='" + dm.email + "', odate ='" + dm.odate + "', weight ='" + dm.weight + "', bmi ='" + dm.bmi + "', waist ='" + dm.waist + "', waistunit ='" + dm.waistunit + "', hba1c ='" + dm.hba1c + "', hba1cunit ='" + dm.hba1cunit + "', bloodpressure ='" + dm.bloodpressure + "', tc ='" + dm.tc + "', tg ='" + dm.tg + "', hdl ='" + dm.hdl + "', ldl ='" + dm.ldl + "', _id ='" + dm._id + "', update_flag ='" + dm.update_flag + "' where seq='" + dm.seq + "'";
        this.logCat.log(className, "sqlStr", sqlStr);
        try {
            this.db.execSQL(sqlStr);
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "updateOtherrecord", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean updateOtherrecord_updateFlag_id(String seq, String _id) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        String sqlStr = "UPDATE otherrecord set _id ='" + _id + "', update_flag = null where seq = '" + seq + "'";
        this.logCat.log(className, "sqlStr", sqlStr);
        try {
            this.db.execSQL(sqlStr);
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "updateOtherrecord", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public boolean updateOtherrecord_updateFlag(String seq) {
        boolean result = false;
        this.db = this.dbHelper.getWritableDatabase();
        this.db.beginTransaction();
        String sqlStr = "UPDATE otherrecord set update_flag = null where seq = '" + seq + "'";
        this.logCat.log(className, "sqlStr", sqlStr);
        try {
            this.db.execSQL(sqlStr);
            this.db.setTransactionSuccessful();
            result = true;
        } catch (Exception e) {
            this.logCat.log(className, "updateOtherrecord", "failed");
            result = false;
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        return result;
    }

    public OtherrecordThrDM otherrecordOneSelect(String seq) {
        Exception e;
        OtherrecordThrDM otherrecordThrDM = new OtherrecordThrDM();
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM otherrecord where seq='" + seq + "'", null);
            this.logCat.log(className, "otherrecordOneSelect()", "-----------------------------------------");
            OtherrecordThrDM dm = otherrecordThrDM;
            while (cursor.moveToNext()) {
                try {
                    otherrecordThrDM = new OtherrecordThrDM();
                    otherrecordThrDM.seq = cursor.getString(0);
                    otherrecordThrDM.email = cursor.getString(1);
                    otherrecordThrDM.odate = cursor.getString(2);
                    otherrecordThrDM.weight = cursor.getString(3);
                    otherrecordThrDM.bmi = cursor.getString(4);
                    otherrecordThrDM.waist = cursor.getString(5);
                    otherrecordThrDM.waistunit = cursor.getString(6);
                    otherrecordThrDM.hba1c = cursor.getString(7);
                    otherrecordThrDM.hba1cunit = cursor.getString(8);
                    otherrecordThrDM.bloodpressure = cursor.getString(9);
                    otherrecordThrDM.tc = cursor.getString(10);
                    otherrecordThrDM.tg = cursor.getString(11);
                    otherrecordThrDM.hdl = cursor.getString(12);
                    otherrecordThrDM.ldl = cursor.getString(13);
                    otherrecordThrDM._id = cursor.getString(14);
                    otherrecordThrDM.update_flag = cursor.getString(15);
                    otherrecordThrDM.input_date = cursor.getString(16);
                    otherrecordThrDM.system_date = cursor.getString(17);
                    dm = otherrecordThrDM;
                } catch (Exception e2) {
                    e = e2;
                    otherrecordThrDM = dm;
                } catch (Throwable th) {
                    Throwable th2 = th;
                    otherrecordThrDM = dm;
                }
            }
            this.logCat.log(className, "testOtherrecordSelect()", "-----------------------------------------");
            cursor.close();
            this.db.close();
            return dm;
        } catch (Exception e3) {
            e = e3;
        }
        try {
            this.logCat.log(className, "", e.toString());
            this.db.close();
            return otherrecordThrDM;
        } catch (Throwable th3) {
            th2 = th3;
            this.db.close();
            throw th2;
        }
    }

    public String getColumn_Id(String columnSeq) {
        String result = "";
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT _id FROM log where seq='" + columnSeq + "'", null);
            this.logCat.log(className, "getColumn_Id()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                result = cursor.getString(0);
                this.logCat.log(className, "getColumn_Id() _id", cursor.getString(0));
            }
            this.logCat.log(className, "getColumn_Id()", "-----------------------------------------");
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        return result;
    }

    public String getColumn_userId(String columnSeq) {
        String result = "";
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT user_id FROM log where seq='" + columnSeq + "'", null);
            this.logCat.log(className, "getColumn_userId()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                result = cursor.getString(0);
                this.logCat.log(className, "getColumn_userId() _id", cursor.getString(0));
            }
            this.logCat.log(className, "getColumn_userId()", "-----------------------------------------");
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        return result;
    }

    public int getFriendEventCount(String email) {
        int eventCount = 0;
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM friend_eventcount where email='" + email + "'", null);
            while (cursor.moveToNext()) {
                eventCount = Integer.parseInt(cursor.getString(2));
            }
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.close();
        }
        return eventCount;
    }

    public void insertFriendEventCount(FriendListReturnDMSubDM dm) {
        if (getCount("select count(*) from friend_eventcount where email='" + dm.friend + "'") == 0) {
            String inq = "insert into friend_eventcount (email, name) values('" + dm.friend + "', '" + dm.name + "')";
            this.logCat.log(className, "inq", inq);
            executeQuery(inq);
        }
    }

    public ArrayList<FriendListReturnDMSubDM> getFriendList() {
        ArrayList<FriendListReturnDMSubDM> list = new ArrayList();
        this.db = this.dbHelper.getReadableDatabase();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM friend_eventcount", null);
            this.logCat.log(className, "getFriendList()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                FriendListReturnDMSubDM dm = new FriendListReturnDMSubDM();
                dm.id = cursor.getString(0);
                dm.friend = cursor.getString(1);
                dm.name = cursor.getString(2);
                this.logCat.log(className, "getFriendList() seq", cursor.getString(0));
                this.logCat.log(className, "getFriendList() email", cursor.getString(1));
                this.logCat.log(className, "getFriendList() name", cursor.getString(2));
                this.logCat.log(className, "getFriendList() eventcount", cursor.getString(3));
            }
            this.logCat.log(className, "getFriendList()", "-----------------------------------------");
            cursor.close();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.endTransaction();
        }
        return list;
    }

    public boolean isOriginEvent(String seq) {
        String getE = "";
        this.db = this.dbHelper.getReadableDatabase();
        this.db.beginTransaction();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM log where seq='" + seq + "'", null);
            while (cursor.moveToNext()) {
                getE = cursor.getString(19);
                this.logCat.log(className, "blood_sugar_eat_origin", cursor.getString(19));
            }
            cursor.close();
            this.db.setTransactionSuccessful();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
        if (getE == null || getE.trim().equals("")) {
            return false;
        }
        return true;
    }

    public void testFriend_eventcount() {
        this.db = this.dbHelper.getReadableDatabase();
        this.db.beginTransaction();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM friend_eventcount", null);
            this.logCat.log(className, "testFriend_eventcount()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                this.logCat.log(className, "testFriend_eventcount() seq", cursor.getString(0));
                this.logCat.log(className, "testFriend_eventcount() email", cursor.getString(1));
                this.logCat.log(className, "testFriend_eventcount() name", cursor.getString(2));
                this.logCat.log(className, "testFriend_eventcount() eventcount", cursor.getString(3));
            }
            this.logCat.log(className, "testFriend_eventcount()", "-----------------------------------------");
            cursor.close();
            this.db.setTransactionSuccessful();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
    }

    public void testDeviceSelect() {
        this.db = this.dbHelper.getReadableDatabase();
        this.db.beginTransaction();
        try {
            Cursor cursor = this.db.rawQuery("SELECT * FROM device", null);
            this.logCat.log(className, "testDeviceSelect()", "-----------------------------------------");
            while (cursor.moveToNext()) {
                this.logCat.log(className, "testDeviceSelect() seq", cursor.getString(0));
                this.logCat.log(className, "testDeviceSelect() device_id", cursor.getString(1));
                this.logCat.log(className, "testDeviceSelect() _id", cursor.getString(2));
                this.logCat.log(className, "testDeviceSelect() update_date", cursor.getString(3));
            }
            this.logCat.log(className, "testDeviceSelect()", "-----------------------------------------");
            cursor.close();
            this.db.setTransactionSuccessful();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
    }

    public void testSelectLog(String query) {
        this.db = this.dbHelper.getReadableDatabase();
        this.db.beginTransaction();
        try {
            Cursor cursor = this.db.rawQuery(query, null);
            this.logCat.log(className, "query", query);
            this.logCat.log(className, "testLogSelect()", "-----------------------------------------");
            while (true) {
                if (!cursor.moveToNext()) {
                    break;
                }
            }
            this.logCat.log(className, "testLogSelect()", "-----------------------------------------");
            cursor.close();
            this.db.setTransactionSuccessful();
        } catch (Exception e) {
            this.logCat.log(className, "", e.toString());
        } finally {
            this.db.endTransaction();
            this.db.close();
        }
    }

    public String getCompareLastNewGlucose(ArrayList<LogDM> arrayList) {
        return "";
    }
}
