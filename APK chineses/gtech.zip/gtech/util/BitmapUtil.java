package com.accumed.gtech.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Matrix;
import com.handmark.pulltorefresh.library.PullToRefreshBase;

public class BitmapUtil {
    public static Bitmap getImageRotate(String path) {
        if (path == null || path.trim().equals("")) {
            return null;
        }
        try {
            Options options = new Options();
            options.inSampleSize = 2;
            return resizeBitmapImage(BitmapFactory.decodeFile(path, options), 480);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static int exifOrientationToDegrees(int exifOrientation) {
        if (exifOrientation == 6) {
            return 90;
        }
        if (exifOrientation == 3) {
            return 180;
        }
        if (exifOrientation == 8) {
            return 270;
        }
        return 0;
    }

    public static Bitmap rotate(Bitmap bitmap, int degrees) {
        if (degrees == 0 || bitmap == null) {
            return bitmap;
        }
        Matrix m = new Matrix();
        m.setRotate((float) degrees, ((float) bitmap.getWidth()) / PullToRefreshBase.DEFAULT_FRICTION, ((float) bitmap.getHeight()) / PullToRefreshBase.DEFAULT_FRICTION);
        try {
            Bitmap converted = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true);
            if (bitmap == converted) {
                return bitmap;
            }
            bitmap.recycle();
            return converted;
        } catch (OutOfMemoryError e) {
            return bitmap;
        }
    }

    public static Bitmap resizeBitmapImage(Bitmap source, int maxResolution) {
        int width = source.getWidth();
        int height = source.getHeight();
        int newWidth = width;
        int newHeight = height;
        if (width > height) {
            if (maxResolution < width) {
                newHeight = (int) (((float) height) * (((float) maxResolution) / ((float) width)));
                newWidth = maxResolution;
            }
        } else if (maxResolution < height) {
            newWidth = (int) (((float) width) * (((float) maxResolution) / ((float) height)));
            newHeight = maxResolution;
        }
        return Bitmap.createScaledBitmap(source, newWidth, newHeight, true);
    }
}
