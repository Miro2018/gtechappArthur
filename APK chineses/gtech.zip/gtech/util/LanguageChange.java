package com.accumed.gtech.util;

import android.content.Context;
import android.content.res.Configuration;
import java.util.Locale;

public class LanguageChange {
    static final String className = "LanguageChange";
    LogCat logCat = new LogCat();
    Context mContext;

    public LanguageChange(Context c) {
        this.mContext = c;
    }

    public String getSystemLanguage() {
        String systemLanguage = this.mContext.getResources().getConfiguration().locale.getLanguage();
        this.logCat.log(className, "language system", systemLanguage);
        return systemLanguage;
    }

    public String getPrefLanguage() {
        String perfLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING).getString(PreferenceAction.MY_LANGUAGE).trim();
        this.logCat.log(className, "language pref", perfLang);
        return perfLang;
    }

    public void putLanguage(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        this.mContext.getResources().updateConfiguration(config, this.mContext.getResources().getDisplayMetrics());
    }
}
