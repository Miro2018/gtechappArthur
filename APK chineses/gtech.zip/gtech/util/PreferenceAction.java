package com.accumed.gtech.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class PreferenceAction {
    public static final String FRIEND_EMAIL = "FRIEND_EMAIL";
    public static final String GCM_REGISTRED_ID = "GCM_REGISTRED_ID";
    public static final String INTRO_PAGE_STATE = "INTRO_PAGE_STATE";
    public static final String IS_AGREEMENT = "IS_AGREEMENT";
    public static final String IS_LOGIN = "IS_LOGIN";
    public static final String MY_BIRTH = "MY_BIRTH";
    public static final String MY_BLOOD_SUGAR_TYPE = "MY_BLOOD_SUGAR_TYPE";
    public static final String MY_BLOOD_SUGAR_UNIT = "MY_BLOOD_SUGAR_UNIT";
    public static final String MY_DATA_SAVE_PERIOD = "MY_DATA_SAVE_PERIOD";
    public static final String MY_DATE_METHOD = "MY_DATE_METHOD";
    public static final String MY_EMAIL = "MY_EMAIL";
    public static final String MY_GCM_STR = "MY_GCM_STR";
    public static final String MY_GENDER = "MY_GENDER";
    public static final String MY_HEIGHT = "MY_HEIGHT";
    public static final String MY_HEIGHT_UNIT = "MY_HEIGHT_UNIT";
    public static final String MY_HIGH_BLOOD_SUGAR = "MY_HIGH_BLOOD_SUGAR";
    public static final String MY_LANGUAGE = "MY_LANGUAGE";
    public static final String MY_LOW_BLOOD_SUGAR = "MY_LOW_BLOOD_SUGAR";
    public static final String MY_NAME = "MY_NAME";
    public static final String MY_OCCOURDAY = "MY_OCCOURDAY";
    public static final String MY_PASSWORD = "MY_PASSWORD";
    public static final String MY_SERVER_CREATE_AT = "MY_SERVER_CREATE_AT";
    public static final String MY_SERVER_ID = "MY_SERVER_ID";
    public static final String MY_TIME_METHOD = "MY_TIME_METHOD";
    public static final String MY_WEIGHT = "MY_WEIGHT";
    public static final String MY_WEIGHT_UNIT = "MY_WEIGHT_UNIT";
    public static final String NFC_IS_USE = "NFC_IS_USE";
    public static final String NFC_ONE_SHOW = "NFC_ONE_SHOW";
    public static final String NOTIFICATION_IS_DEFAULT_SETTING = "NOTIFICATION_IS_DEFAULT_SETTING";
    public static final String NOTIFICATION_IS_USE_NONE = "NOTIFICATION_IS_USE_NONE";
    public static final String NOTIFICATION_IS_USE_SOUND = "NOTIFICATION_IS_USE_SOUND";
    public static final String NOTIFICATION_IS_USE_VIBRATION = "NOTIFICATION_IS_USE_VIBRATION";
    public static final String NOTIFICATION_POPUPMESSAGE_IS_USE = "NOTIFICATION_POPUPMESSAGE_IS_USE";
    public static final String PREF_DATA_POPUP_CHECK = "PREF_DATA_POPUP_CHECK";
    public static final String PREF_DATA_POPUP_FIRST = "PREF_DATA_POPUP_FIRST";
    public static final String PREF_EVENT_END = "PREF_EVENT_END";
    public static final String PREF_EVENT_START = "PREF_EVENT_START";
    public static final String PREF_INSULIN_NAME = "PREF_INSULIN_NAME";
    public static final String PREF_INSULIN_TYPE = "PREF_INSULIN_TYPE";
    public static final String PREF_NAME_AGREEMENT = "PREF_NAME_AGREEMENT";
    public static final String PREF_NAME_FRIEND_PROFILE = "PREF_NAME_FRIEND_PROFILE";
    public static final String PREF_NAME_GCM = "SDBIO";
    public static final String PREF_NAME_IS_LOGIN = "PREF_NAME_IS_LOGIN";
    public static final String PREF_NAME_MY_PROFILE = "PREF_NAME_MY_PROFILE";
    public static final String PREF_NAME_MY_SETTING = "PREF_NAME_MY_SETTING";
    public static final String PREF_NAME_NFC_IS_USE = "PREF_NAME_NFC_IS_USE";
    public static final String PREF_NAME_NOTIFICATION_IS_USE = "PREF_NAME_NOTIFICATION_IS_USE";
    public static final String PREF_NAME_ONE_SHOW = "PREF_NAME_ONE_SHOW";
    public static final String PREF_NAME_SYNC_SWITCH = "PREF_NAME_SYNC_SWITCH";
    public static final String PREF_NAME_TEST_LIMIT = "PREF_NAME_TEST_LIMIT";
    public static final String PREF_NAME_VERSION_UPDATE = "PREF_NAME_VERSION_UPDATE";
    public static final String PREF_SELECT_LOCATION = "PREF_SELECT_LOCATION";
    public static final String PREF_SELECT_SERVER = "PREF_SELECT_SERVER";
    public static final String SYNC_SWITCH = "SYNC_SWITCH";
    public static final String TEST_LIMIT = "TEST_LIMIT";
    public static final String VERSION_UPADTE = "VERSION_UPADTE";
    public static final String VERSION_UPDATE_ONE_SHOW = "VERSION_UPDATE_ONE_SHOW";
    Context context;
    Editor editor = this.pref.edit();
    SharedPreferences pref;

    public PreferenceAction(Context context, String prefName) {
        this.context = context;
        this.pref = this.context.getSharedPreferences(prefName, 0);
    }

    public void putString(String key, String value) {
        this.editor.putString(key, value);
        this.editor.commit();
    }

    public void putInt(String key, int value) {
        this.editor.putInt(key, value);
        this.editor.commit();
    }

    public void putBoolean(String key, boolean value) {
        this.editor.putBoolean(key, value);
        this.editor.commit();
    }

    public String getString(String key) {
        return this.pref.getString(key, "");
    }

    public int getInt(String key) {
        return this.pref.getInt(key, 0);
    }

    public int getIntDefaultNum(String key) {
        return this.pref.getInt(key, 3);
    }

    public boolean getBoolean(String key) {
        return this.pref.getBoolean(key, false);
    }

    public void remove(String key) {
        this.editor.remove(key);
        this.editor.commit();
    }

    public void allRemove() {
        this.editor.clear();
        this.editor.commit();
    }
}
