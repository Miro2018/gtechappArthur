package com.accumed.gtech.util;

public interface ImageDownloaderListener {
    void onImageDown(Object obj);
}
