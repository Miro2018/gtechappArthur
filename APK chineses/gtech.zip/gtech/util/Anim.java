package com.accumed.gtech.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.drawable.BitmapDrawable;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.view.ViewCompat;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.ListView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import lecho.lib.hellocharts.model.BubbleChartData;

public class Anim {
    public static String IN = "in";
    public static String OUT = "out";
    Context context;

    public Anim(Context context) {
        this.context = context;
    }

    public void startAnim(View v, String inOut) {
        Animation anim;
        if (inOut.equals("in")) {
            anim = AnimationUtils.loadAnimation(this.context, C0213R.anim.fadein);
            v.setVisibility(0);
        } else {
            anim = AnimationUtils.loadAnimation(this.context, C0213R.anim.fadeout);
            v.setVisibility(8);
        }
        v.startAnimation(anim);
    }

    public void startAnimSlow(View v, String inOut) {
        Animation anim;
        if (inOut.equals("in")) {
            anim = AnimationUtils.loadAnimation(this.context, C0213R.anim.fadein_slow);
            v.setVisibility(0);
        } else {
            anim = AnimationUtils.loadAnimation(this.context, C0213R.anim.fadeout_slow);
            v.setVisibility(8);
        }
        v.startAnimation(anim);
    }

    public void listAnim(ListView listView) {
        AnimationSet set = new AnimationSet(true);
        Animation animation = new AlphaAnimation(0.0f, BubbleChartData.DEFAULT_BUBBLE_SCALE);
        animation.setDuration(200);
        set.addAnimation(animation);
        animation = new TranslateAnimation(1, 0.0f, 1, 0.0f, 1, -1.0f, 1, 0.0f);
        animation.setDuration(100);
        set.addAnimation(animation);
        listView.setLayoutAnimation(new LayoutAnimationController(set, ClassConstant.INPUT_GLUCOSE_MMOL_MIN));
    }

    public void newChatCountBt(ImageView iv, int d, int count) {
        Bitmap bitmap = ((BitmapDrawable) this.context.getResources().getDrawable(d)).getBitmap().copy(Config.ARGB_8888, true);
        int cirMarginLeft = 0;
        int cirMarginTop = 0;
        int cirRadius = 0;
        int textMarginLeft = 0;
        int textMarginTop = 0;
        if (count > 0 && count < 10) {
            cirMarginLeft = 35;
            cirMarginTop = 10;
            cirRadius = 10;
            textMarginLeft = 35;
            textMarginTop = 14;
        } else if (count > 9 && count < 100) {
            cirMarginLeft = 35 - 1;
            cirMarginTop = 12;
            cirRadius = 11;
            textMarginLeft = 36 - 1;
            textMarginTop = 15;
        } else if (count > 99 && count < 1000) {
            cirMarginLeft = 35 - 3;
            cirMarginTop = 14;
            cirRadius = 12;
            textMarginLeft = 35 - 3;
            textMarginTop = 17;
        } else if (count == 0) {
        }
        Canvas cv = new Canvas(bitmap);
        Paint Pnt = new Paint();
        Pnt.setAntiAlias(true);
        Pnt.setColor(SupportMenu.CATEGORY_MASK);
        Pnt.setStrokeWidth(PullToRefreshBase.DEFAULT_FRICTION);
        Pnt.setShadowLayer(BubbleChartData.DEFAULT_BUBBLE_SCALE, 0.0f, 0.0f, ViewCompat.MEASURED_STATE_MASK);
        cv.drawCircle((float) cirMarginLeft, (float) cirMarginTop, (float) cirRadius, Pnt);
        Paint Pnt_font = new Paint();
        Pnt_font.setColor(-1);
        Pnt.setAntiAlias(true);
        Pnt_font.setTextSize(12.0f);
        Pnt_font.setAntiAlias(true);
        Pnt_font.setTextAlign(Align.CENTER);
        cv.drawText(Integer.toString(count), (float) textMarginLeft, (float) textMarginTop, Pnt_font);
        cv.setBitmap(bitmap);
        iv.setImageBitmap(bitmap);
    }

    public void newAlramCountBt(ImageView iv, int d, int count) {
        Bitmap bitmap = ((BitmapDrawable) this.context.getResources().getDrawable(d)).getBitmap().copy(Config.ARGB_8888, true);
        int cirMarginLeft = 0;
        int cirMarginTop = 0;
        int cirRadius = 0;
        int textMarginLeft = 0;
        int textMarginTop = 0;
        if (count > 0 && count < 10) {
            cirMarginLeft = 35;
            cirMarginTop = 10;
            cirRadius = 10;
            textMarginLeft = 35;
            textMarginTop = 14;
        } else if (count > 9 && count < 100) {
            cirMarginLeft = 35 - 1;
            cirMarginTop = 12;
            cirRadius = 11;
            textMarginLeft = 36 - 1;
            textMarginTop = 15;
        } else if (count > 99 && count < 1000) {
            cirMarginLeft = 35 - 3;
            cirMarginTop = 14;
            cirRadius = 12;
            textMarginLeft = 35 - 3;
            textMarginTop = 17;
        } else if (count == 0) {
        }
        Canvas cv = new Canvas(bitmap);
        Paint Pnt = new Paint();
        Pnt.setAntiAlias(true);
        Pnt.setColor(SupportMenu.CATEGORY_MASK);
        Pnt.setStrokeWidth(PullToRefreshBase.DEFAULT_FRICTION);
        Pnt.setShadowLayer(BubbleChartData.DEFAULT_BUBBLE_SCALE, 0.0f, 0.0f, ViewCompat.MEASURED_STATE_MASK);
        cv.drawCircle((float) cirMarginLeft, (float) cirMarginTop, (float) cirRadius, Pnt);
        Paint Pnt_font = new Paint();
        Pnt_font.setColor(-1);
        Pnt.setAntiAlias(true);
        Pnt_font.setTextSize(12.0f);
        Pnt_font.setAntiAlias(true);
        Pnt_font.setTextAlign(Align.CENTER);
        cv.drawText(Integer.toString(count), (float) textMarginLeft, (float) textMarginTop, Pnt_font);
        cv.setBitmap(bitmap);
        iv.setImageBitmap(bitmap);
    }

    public void rotateAnim(View v) {
        Animation animation = new RotateAnimation(0.0f, 350.0f, 1, ClassConstant.INPUT_GLUCOSE_MMOL_MIN, 1, ClassConstant.INPUT_GLUCOSE_MMOL_MIN);
        animation.setDuration(3000);
        animation.setRepeatCount(-1);
        animation.initialize(50, 0, 0, 0);
        v.setAnimation(animation);
    }
}
