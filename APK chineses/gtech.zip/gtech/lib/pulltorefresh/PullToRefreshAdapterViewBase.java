package com.accumed.gtech.lib.pulltorefresh;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.FrameLayout;
import android.widget.LinearLayout.LayoutParams;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.lib.pulltorefresh.PullToRefreshBase.Mode;
import com.accumed.gtech.lib.pulltorefresh.PullToRefreshBase.OnLastItemVisibleListener;
import com.accumed.gtech.lib.pulltorefresh.internal.EmptyViewMethodAccessor;
import com.accumed.gtech.lib.pulltorefresh.internal.IndicatorLayout;
import lecho.lib.hellocharts.model.BubbleChartData;

public abstract class PullToRefreshAdapterViewBase<T extends AbsListView> extends PullToRefreshBase<T> implements OnScrollListener {
    static final boolean DEFAULT_SHOW_INDICATOR = true;
    private View mEmptyView;
    private IndicatorLayout mIndicatorIvBottom;
    private IndicatorLayout mIndicatorIvTop;
    private OnLastItemVisibleListener mOnLastItemVisibleListener;
    private OnScrollListener mOnScrollListener;
    private FrameLayout mRefreshableViewHolder;
    private int mSavedLastVisibleIndex = -1;
    private boolean mShowIndicator;

    public abstract ContextMenuInfo getContextMenuInfo();

    public PullToRefreshAdapterViewBase(Context context) {
        super(context);
        ((AbsListView) this.mRefreshableView).setOnScrollListener(this);
    }

    public PullToRefreshAdapterViewBase(Context context, AttributeSet attrs) {
        super(context, attrs);
        ((AbsListView) this.mRefreshableView).setOnScrollListener(this);
    }

    public PullToRefreshAdapterViewBase(Context context, Mode mode) {
        super(context, mode);
        ((AbsListView) this.mRefreshableView).setOnScrollListener(this);
    }

    public boolean getShowIndicator() {
        return this.mShowIndicator;
    }

    public final void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (this.mOnLastItemVisibleListener != null) {
            int lastVisibleItemIndex = firstVisibleItem + visibleItemCount;
            if (visibleItemCount > 0 && lastVisibleItemIndex + 1 == totalItemCount && lastVisibleItemIndex != this.mSavedLastVisibleIndex) {
                this.mSavedLastVisibleIndex = lastVisibleItemIndex;
                this.mOnLastItemVisibleListener.onLastItemVisible();
            }
        }
        if (getShowIndicatorInternal()) {
            updateIndicatorViewsVisibility();
        }
        if (this.mOnScrollListener != null) {
            this.mOnScrollListener.onScroll(view, firstVisibleItem, visibleItemCount, totalItemCount);
        }
    }

    public final void onScrollStateChanged(AbsListView view, int scrollState) {
        if (this.mOnScrollListener != null) {
            this.mOnScrollListener.onScrollStateChanged(view, scrollState);
        }
    }

    public final void setEmptyView(View newEmptyView) {
        if (this.mEmptyView != null) {
            this.mRefreshableViewHolder.removeView(this.mEmptyView);
        }
        if (newEmptyView != null) {
            newEmptyView.setClickable(DEFAULT_SHOW_INDICATOR);
            ViewParent newEmptyViewParent = newEmptyView.getParent();
            if (newEmptyViewParent != null && (newEmptyViewParent instanceof ViewGroup)) {
                ((ViewGroup) newEmptyViewParent).removeView(newEmptyView);
            }
            this.mRefreshableViewHolder.addView(newEmptyView, -1, -1);
            if (this.mRefreshableView instanceof EmptyViewMethodAccessor) {
                ((EmptyViewMethodAccessor) this.mRefreshableView).setEmptyViewInternal(newEmptyView);
            } else {
                ((AbsListView) this.mRefreshableView).setEmptyView(newEmptyView);
            }
        }
    }

    public final void setOnLastItemVisibleListener(OnLastItemVisibleListener listener) {
        this.mOnLastItemVisibleListener = listener;
    }

    public final void setOnScrollListener(OnScrollListener listener) {
        this.mOnScrollListener = listener;
    }

    public void setShowIndicator(boolean showIndicator) {
        this.mShowIndicator = showIndicator;
        if (getShowIndicatorInternal()) {
            addIndicatorViews();
        } else {
            removeIndicatorViews();
        }
    }

    protected void addRefreshableView(Context context, T refreshableView) {
        this.mRefreshableViewHolder = new FrameLayout(context);
        this.mRefreshableViewHolder.addView(refreshableView, -1, -1);
        addView(this.mRefreshableViewHolder, new LayoutParams(-1, 0, BubbleChartData.DEFAULT_BUBBLE_SCALE));
    }

    protected int getNumberInternalFooterViews() {
        return 0;
    }

    protected int getNumberInternalHeaderViews() {
        return 0;
    }

    protected int getNumberInternalViews() {
        return getNumberInternalHeaderViews() + getNumberInternalFooterViews();
    }

    protected void handleStyledAttributes(TypedArray a) {
        this.mShowIndicator = a.getBoolean(5, DEFAULT_SHOW_INDICATOR);
    }

    protected boolean isReadyForPullDown() {
        return isFirstItemVisible();
    }

    protected boolean isReadyForPullUp() {
        return isLastItemVisible();
    }

    protected void onPullToRefresh() {
        super.onPullToRefresh();
        if (getShowIndicatorInternal()) {
            switch (getCurrentMode()) {
                case PULL_UP_TO_REFRESH:
                    this.mIndicatorIvBottom.pullToRefresh();
                    return;
                case PULL_DOWN_TO_REFRESH:
                    this.mIndicatorIvTop.pullToRefresh();
                    return;
                default:
                    return;
            }
        }
    }

    protected void onReleaseToRefresh() {
        super.onReleaseToRefresh();
        if (getShowIndicatorInternal()) {
            switch (getCurrentMode()) {
                case PULL_UP_TO_REFRESH:
                    this.mIndicatorIvBottom.releaseToRefresh();
                    return;
                case PULL_DOWN_TO_REFRESH:
                    this.mIndicatorIvTop.releaseToRefresh();
                    return;
                default:
                    return;
            }
        }
    }

    protected void resetHeader() {
        super.resetHeader();
        if (getShowIndicatorInternal()) {
            updateIndicatorViewsVisibility();
        }
    }

    protected void setRefreshingInternal(boolean doScroll) {
        super.setRefreshingInternal(doScroll);
        if (getShowIndicatorInternal()) {
            updateIndicatorViewsVisibility();
        }
    }

    protected void updateUIForMode() {
        super.updateUIForMode();
        if (getShowIndicatorInternal()) {
            addIndicatorViews();
        }
    }

    private void addIndicatorViews() {
        Mode mode = getMode();
        if (mode.canPullDown() && this.mIndicatorIvTop == null) {
            this.mIndicatorIvTop = new IndicatorLayout(getContext(), Mode.PULL_DOWN_TO_REFRESH);
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(-2, -2);
            params.rightMargin = getResources().getDimensionPixelSize(C0213R.dimen.indicator_right_padding);
            params.gravity = 53;
            this.mRefreshableViewHolder.addView(this.mIndicatorIvTop, params);
        } else if (!(mode.canPullDown() || this.mIndicatorIvTop == null)) {
            this.mRefreshableViewHolder.removeView(this.mIndicatorIvTop);
            this.mIndicatorIvTop = null;
        }
        if (mode.canPullUp() && this.mIndicatorIvBottom == null) {
            this.mIndicatorIvBottom = new IndicatorLayout(getContext(), Mode.PULL_UP_TO_REFRESH);
            params = new FrameLayout.LayoutParams(-2, -2);
            params.rightMargin = getResources().getDimensionPixelSize(C0213R.dimen.indicator_right_padding);
            params.gravity = 85;
            this.mRefreshableViewHolder.addView(this.mIndicatorIvBottom, params);
        } else if (!mode.canPullUp() && this.mIndicatorIvBottom != null) {
            this.mRefreshableViewHolder.removeView(this.mIndicatorIvBottom);
            this.mIndicatorIvBottom = null;
        }
    }

    private boolean getShowIndicatorInternal() {
        return (this.mShowIndicator && isPullToRefreshEnabled()) ? DEFAULT_SHOW_INDICATOR : false;
    }

    private boolean isFirstItemVisible() {
        if (((AbsListView) this.mRefreshableView).getCount() <= getNumberInternalViews()) {
            return DEFAULT_SHOW_INDICATOR;
        }
        if (((AbsListView) this.mRefreshableView).getFirstVisiblePosition() == 0) {
            View firstVisibleChild = ((AbsListView) this.mRefreshableView).getChildAt(0);
            if (firstVisibleChild != null) {
                return firstVisibleChild.getTop() >= ((AbsListView) this.mRefreshableView).getTop() ? DEFAULT_SHOW_INDICATOR : false;
            }
        }
        return false;
    }

    private boolean isLastItemVisible() {
        int count = ((AbsListView) this.mRefreshableView).getCount();
        int lastVisiblePosition = ((AbsListView) this.mRefreshableView).getLastVisiblePosition();
        if (count <= getNumberInternalViews()) {
            return DEFAULT_SHOW_INDICATOR;
        }
        if (lastVisiblePosition == count - 1) {
            View lastVisibleChild = ((AbsListView) this.mRefreshableView).getChildAt(lastVisiblePosition - ((AbsListView) this.mRefreshableView).getFirstVisiblePosition());
            if (lastVisibleChild != null) {
                return lastVisibleChild.getBottom() <= ((AbsListView) this.mRefreshableView).getBottom() ? DEFAULT_SHOW_INDICATOR : false;
            }
        }
        return false;
    }

    private void removeIndicatorViews() {
        if (this.mIndicatorIvTop != null) {
            this.mRefreshableViewHolder.removeView(this.mIndicatorIvTop);
            this.mIndicatorIvTop = null;
        }
        if (this.mIndicatorIvBottom != null) {
            this.mRefreshableViewHolder.removeView(this.mIndicatorIvBottom);
            this.mIndicatorIvBottom = null;
        }
    }

    private void updateIndicatorViewsVisibility() {
        if (this.mIndicatorIvTop != null) {
            if (isRefreshing() || !isReadyForPullDown()) {
                if (this.mIndicatorIvTop.isVisible()) {
                    this.mIndicatorIvTop.hide();
                }
            } else if (!this.mIndicatorIvTop.isVisible()) {
                this.mIndicatorIvTop.show();
            }
        }
        if (this.mIndicatorIvBottom == null) {
            return;
        }
        if (isRefreshing() || !isReadyForPullUp()) {
            if (this.mIndicatorIvBottom.isVisible()) {
                this.mIndicatorIvBottom.hide();
            }
        } else if (!this.mIndicatorIvBottom.isVisible()) {
            this.mIndicatorIvBottom.show();
        }
    }
}
