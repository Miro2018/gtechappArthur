package com.accumed.gtech.lib.pulltorefresh;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.lib.pulltorefresh.internal.LoadingLayout;
import lecho.lib.hellocharts.model.BubbleChartData;

public abstract class PullToRefreshBase<T extends View> extends LinearLayout {
    static final boolean DEBUG = false;
    static final Mode DEFAULT_MODE = Mode.PULL_DOWN_TO_REFRESH;
    static final float FRICTION = 2.0f;
    static final String LOG_TAG = "PullToRefresh";
    static final int MANUAL_REFRESHING = 3;
    static final int PULL_TO_REFRESH = 0;
    static final int REFRESHING = 2;
    static final int RELEASE_TO_REFRESH = 1;
    static final String STATE_CURRENT_MODE = "ptr_current_mode";
    static final String STATE_DISABLE_SCROLLING_REFRESHING = "ptr_disable_scrolling";
    static final String STATE_MODE = "ptr_mode";
    static final String STATE_SHOW_REFRESHING_VIEW = "ptr_show_refreshing_view";
    static final String STATE_STATE = "ptr_state";
    static final String STATE_SUPER = "ptr_super";
    private Mode mCurrentMode;
    private SmoothScrollRunnable mCurrentSmoothScrollRunnable;
    private boolean mDisableScrollingWhileRefreshing = true;
    private boolean mFilterTouchEvents = true;
    private LoadingLayout mFooterLayout;
    private final Handler mHandler = new Handler();
    private int mHeaderHeight;
    private LoadingLayout mHeaderLayout;
    private float mInitialMotionY;
    private boolean mIsBeingDragged = false;
    private float mLastMotionX;
    private float mLastMotionY;
    private Mode mMode = DEFAULT_MODE;
    private OnRefreshListener mOnRefreshListener;
    private OnRefreshListener2 mOnRefreshListener2;
    private boolean mPullToRefreshEnabled = true;
    T mRefreshableView;
    private boolean mShowViewWhileRefreshing = true;
    private int mState = 0;
    private int mTouchSlop;

    public interface OnRefreshListener {
        void onRefresh();
    }

    public enum Mode {
        PULL_DOWN_TO_REFRESH(1),
        PULL_UP_TO_REFRESH(2),
        BOTH(3);
        
        private int mIntValue;

        public static Mode mapIntToMode(int modeInt) {
            switch (modeInt) {
                case 2:
                    return PULL_UP_TO_REFRESH;
                case 3:
                    return BOTH;
                default:
                    return PULL_DOWN_TO_REFRESH;
            }
        }

        private Mode(int modeInt) {
            this.mIntValue = modeInt;
        }

        boolean canPullDown() {
            return this == PULL_DOWN_TO_REFRESH || this == BOTH;
        }

        boolean canPullUp() {
            return this == PULL_UP_TO_REFRESH || this == BOTH;
        }

        int getIntValue() {
            return this.mIntValue;
        }
    }

    public interface OnLastItemVisibleListener {
        void onLastItemVisible();
    }

    public interface OnRefreshListener2 {
        void onPullDownToRefresh();

        void onPullUpToRefresh();
    }

    final class SmoothScrollRunnable implements Runnable {
        static final int ANIMATION_DURATION_MS = 190;
        static final int ANIMATION_FPS = 16;
        private boolean mContinueRunning = true;
        private int mCurrentY = -1;
        private final Handler mHandler;
        private final Interpolator mInterpolator;
        private final int mScrollFromY;
        private final int mScrollToY;
        private long mStartTime = -1;

        public SmoothScrollRunnable(Handler handler, int fromY, int toY) {
            this.mHandler = handler;
            this.mScrollFromY = fromY;
            this.mScrollToY = toY;
            this.mInterpolator = new AccelerateDecelerateInterpolator();
        }

        public void run() {
            if (this.mStartTime == -1) {
                this.mStartTime = System.currentTimeMillis();
            } else {
                this.mCurrentY = this.mScrollFromY - Math.round(((float) (this.mScrollFromY - this.mScrollToY)) * this.mInterpolator.getInterpolation(((float) Math.max(Math.min(((System.currentTimeMillis() - this.mStartTime) * 1000) / 190, 1000), 0)) / 1000.0f));
                PullToRefreshBase.this.setHeaderScroll(this.mCurrentY);
            }
            if (this.mContinueRunning && this.mScrollToY != this.mCurrentY) {
                this.mHandler.postDelayed(this, 16);
            }
        }

        public void stop() {
            this.mContinueRunning = false;
            this.mHandler.removeCallbacks(this);
        }
    }

    protected abstract T createRefreshableView(Context context, AttributeSet attributeSet);

    protected abstract boolean isReadyForPullDown();

    protected abstract boolean isReadyForPullUp();

    public PullToRefreshBase(Context context) {
        super(context);
        init(context, null);
    }

    public PullToRefreshBase(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public PullToRefreshBase(Context context, Mode mode) {
        super(context);
        this.mMode = mode;
        init(context, null);
    }

    public final Mode getCurrentMode() {
        return this.mCurrentMode;
    }

    public final boolean getFilterTouchEvents() {
        return this.mFilterTouchEvents;
    }

    public final Mode getMode() {
        return this.mMode;
    }

    public final T getRefreshableView() {
        return this.mRefreshableView;
    }

    public final boolean getShowViewWhileRefreshing() {
        return this.mShowViewWhileRefreshing;
    }

    public final boolean hasPullFromTop() {
        return this.mCurrentMode == Mode.PULL_DOWN_TO_REFRESH;
    }

    public final boolean isDisableScrollingWhileRefreshing() {
        return this.mDisableScrollingWhileRefreshing;
    }

    public final boolean isPullToRefreshEnabled() {
        return this.mPullToRefreshEnabled;
    }

    public final boolean isRefreshing() {
        return this.mState == 2 || this.mState == 3;
    }

    public final boolean onInterceptTouchEvent(MotionEvent event) {
        if (!this.mPullToRefreshEnabled) {
            return false;
        }
        if (isRefreshing() && this.mDisableScrollingWhileRefreshing) {
            return true;
        }
        int action = event.getAction();
        if (action == 3 || action == 1) {
            this.mIsBeingDragged = false;
            return false;
        } else if (action != 0 && this.mIsBeingDragged) {
            return true;
        } else {
            switch (action) {
                case 0:
                    if (isReadyForPull()) {
                        float y = event.getY();
                        this.mInitialMotionY = y;
                        this.mLastMotionY = y;
                        this.mLastMotionX = event.getX();
                        this.mIsBeingDragged = false;
                        break;
                    }
                    break;
                case 2:
                    if (isReadyForPull()) {
                        float y2 = event.getY();
                        float dy = y2 - this.mLastMotionY;
                        float yDiff = Math.abs(dy);
                        float xDiff = Math.abs(event.getX() - this.mLastMotionX);
                        if (yDiff > ((float) this.mTouchSlop) && (!this.mFilterTouchEvents || yDiff > xDiff)) {
                            if (!this.mMode.canPullDown() || dy < BubbleChartData.DEFAULT_BUBBLE_SCALE || !isReadyForPullDown()) {
                                if (this.mMode.canPullUp() && dy <= -1.0f && isReadyForPullUp()) {
                                    this.mLastMotionY = y2;
                                    this.mIsBeingDragged = true;
                                    if (this.mMode == Mode.BOTH) {
                                        this.mCurrentMode = Mode.PULL_UP_TO_REFRESH;
                                        break;
                                    }
                                }
                            }
                            this.mLastMotionY = y2;
                            this.mIsBeingDragged = true;
                            if (this.mMode == Mode.BOTH) {
                                this.mCurrentMode = Mode.PULL_DOWN_TO_REFRESH;
                                break;
                            }
                        }
                    }
                    break;
            }
            return this.mIsBeingDragged;
        }
    }

    public final void onRefreshComplete() {
        if (this.mState != 0) {
            resetHeader();
        }
    }

    public final boolean onTouchEvent(MotionEvent event) {
        if (!this.mPullToRefreshEnabled) {
            return false;
        }
        if (isRefreshing() && this.mDisableScrollingWhileRefreshing) {
            return true;
        }
        if (event.getAction() == 0 && event.getEdgeFlags() != 0) {
            return false;
        }
        switch (event.getAction()) {
            case 0:
                if (!isReadyForPull()) {
                    return false;
                }
                float y = event.getY();
                this.mInitialMotionY = y;
                this.mLastMotionY = y;
                return true;
            case 1:
            case 3:
                if (!this.mIsBeingDragged) {
                    return false;
                }
                this.mIsBeingDragged = false;
                if (this.mState != 1) {
                    smoothScrollTo(0);
                    return true;
                } else if (this.mOnRefreshListener != null) {
                    setRefreshingInternal(true);
                    this.mOnRefreshListener.onRefresh();
                    return true;
                } else if (this.mOnRefreshListener2 == null) {
                    return true;
                } else {
                    setRefreshingInternal(true);
                    if (this.mCurrentMode == Mode.PULL_DOWN_TO_REFRESH) {
                        this.mOnRefreshListener2.onPullDownToRefresh();
                    } else if (this.mCurrentMode == Mode.PULL_UP_TO_REFRESH) {
                        this.mOnRefreshListener2.onPullUpToRefresh();
                    }
                    return true;
                }
            case 2:
                if (!this.mIsBeingDragged) {
                    return false;
                }
                this.mLastMotionY = event.getY();
                pullEvent();
                return true;
            default:
                return false;
        }
    }

    public final void setDisableScrollingWhileRefreshing(boolean disableScrollingWhileRefreshing) {
        this.mDisableScrollingWhileRefreshing = disableScrollingWhileRefreshing;
    }

    public final void setFilterTouchEvents(boolean filterEvents) {
        this.mFilterTouchEvents = filterEvents;
    }

    public void setLastUpdatedLabel(CharSequence label) {
        if (this.mHeaderLayout != null) {
            this.mHeaderLayout.setSubHeaderText(label);
        }
        if (this.mFooterLayout != null) {
            this.mFooterLayout.setSubHeaderText(label);
        }
        refreshLoadingViewsHeight();
    }

    public void setLoadingDrawable(Drawable drawable) {
        setLoadingDrawable(drawable, Mode.BOTH);
    }

    public void setLoadingDrawable(Drawable drawable, Mode mode) {
        if (this.mHeaderLayout != null && mode.canPullDown()) {
            this.mHeaderLayout.setLoadingDrawable(drawable);
        }
        if (this.mFooterLayout != null && mode.canPullUp()) {
            this.mFooterLayout.setLoadingDrawable(drawable);
        }
        refreshLoadingViewsHeight();
    }

    public void setLongClickable(boolean longClickable) {
        getRefreshableView().setLongClickable(longClickable);
    }

    public final void setMode(Mode mode) {
        if (mode != this.mMode) {
            this.mMode = mode;
            updateUIForMode();
        }
    }

    public final void setOnRefreshListener(OnRefreshListener listener) {
        this.mOnRefreshListener = listener;
    }

    public final void setOnRefreshListener(OnRefreshListener2 listener) {
        this.mOnRefreshListener2 = listener;
    }

    public void setPullLabel(String pullLabel) {
        setPullLabel(pullLabel, Mode.BOTH);
    }

    public void setPullLabel(String pullLabel, Mode mode) {
        if (this.mHeaderLayout != null && mode.canPullDown()) {
            this.mHeaderLayout.setPullLabel(pullLabel);
        }
        if (this.mFooterLayout != null && mode.canPullUp()) {
            this.mFooterLayout.setPullLabel(pullLabel);
        }
    }

    public final void setPullToRefreshEnabled(boolean enable) {
        this.mPullToRefreshEnabled = enable;
    }

    public final void setRefreshing() {
        setRefreshing(true);
    }

    public final void setRefreshing(boolean doScroll) {
        if (!isRefreshing()) {
            setRefreshingInternal(doScroll);
            this.mState = 3;
        }
    }

    public void setRefreshingLabel(String refreshingLabel) {
        setRefreshingLabel(refreshingLabel, Mode.BOTH);
    }

    public void setRefreshingLabel(String refreshingLabel, Mode mode) {
        if (this.mHeaderLayout != null && mode.canPullDown()) {
            this.mHeaderLayout.setRefreshingLabel(refreshingLabel);
        }
        if (this.mFooterLayout != null && mode.canPullUp()) {
            this.mFooterLayout.setRefreshingLabel(refreshingLabel);
        }
    }

    public void setReleaseLabel(String releaseLabel) {
        setReleaseLabel(releaseLabel, Mode.BOTH);
    }

    public void setReleaseLabel(String releaseLabel, Mode mode) {
        if (this.mHeaderLayout != null && mode.canPullDown()) {
            this.mHeaderLayout.setReleaseLabel(releaseLabel);
        }
        if (this.mFooterLayout != null && mode.canPullUp()) {
            this.mFooterLayout.setReleaseLabel(releaseLabel);
        }
    }

    public final void setShowViewWhileRefreshing(boolean showView) {
        this.mShowViewWhileRefreshing = showView;
    }

    protected void addRefreshableView(Context context, T refreshableView) {
        addView(refreshableView, new LayoutParams(-1, 0, BubbleChartData.DEFAULT_BUBBLE_SCALE));
    }

    protected final LoadingLayout getFooterLayout() {
        return this.mFooterLayout;
    }

    protected final int getHeaderHeight() {
        return this.mHeaderHeight;
    }

    protected final LoadingLayout getHeaderLayout() {
        return this.mHeaderLayout;
    }

    protected final int getState() {
        return this.mState;
    }

    protected void handleStyledAttributes(TypedArray a) {
    }

    protected void onPullToRefresh() {
        switch (this.mCurrentMode) {
            case PULL_UP_TO_REFRESH:
                this.mFooterLayout.pullToRefresh();
                return;
            case PULL_DOWN_TO_REFRESH:
                this.mHeaderLayout.pullToRefresh();
                return;
            default:
                return;
        }
    }

    protected void onReleaseToRefresh() {
        switch (this.mCurrentMode) {
            case PULL_UP_TO_REFRESH:
                this.mFooterLayout.releaseToRefresh();
                return;
            case PULL_DOWN_TO_REFRESH:
                this.mHeaderLayout.releaseToRefresh();
                return;
            default:
                return;
        }
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof Bundle) {
            Bundle bundle = (Bundle) state;
            this.mMode = Mode.mapIntToMode(bundle.getInt(STATE_MODE, 0));
            this.mCurrentMode = Mode.mapIntToMode(bundle.getInt(STATE_CURRENT_MODE, 0));
            this.mDisableScrollingWhileRefreshing = bundle.getBoolean(STATE_DISABLE_SCROLLING_REFRESHING, true);
            this.mShowViewWhileRefreshing = bundle.getBoolean(STATE_SHOW_REFRESHING_VIEW, true);
            super.onRestoreInstanceState(bundle.getParcelable(STATE_SUPER));
            int viewState = bundle.getInt(STATE_STATE, 0);
            if (viewState == 2) {
                setRefreshingInternal(true);
                this.mState = viewState;
                return;
            }
            return;
        }
        super.onRestoreInstanceState(state);
    }

    protected Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putInt(STATE_STATE, this.mState);
        bundle.putInt(STATE_MODE, this.mMode.getIntValue());
        bundle.putInt(STATE_CURRENT_MODE, this.mCurrentMode.getIntValue());
        bundle.putBoolean(STATE_DISABLE_SCROLLING_REFRESHING, this.mDisableScrollingWhileRefreshing);
        bundle.putBoolean(STATE_SHOW_REFRESHING_VIEW, this.mShowViewWhileRefreshing);
        bundle.putParcelable(STATE_SUPER, super.onSaveInstanceState());
        return bundle;
    }

    protected void resetHeader() {
        this.mState = 0;
        this.mIsBeingDragged = false;
        if (this.mMode.canPullDown()) {
            this.mHeaderLayout.reset();
        }
        if (this.mMode.canPullUp()) {
            this.mFooterLayout.reset();
        }
        smoothScrollTo(0);
    }

    protected final void setHeaderScroll(int y) {
        scrollTo(0, y);
    }

    protected void setRefreshingInternal(boolean doScroll) {
        this.mState = 2;
        if (this.mMode.canPullDown()) {
            this.mHeaderLayout.refreshing();
        }
        if (this.mMode.canPullUp()) {
            this.mFooterLayout.refreshing();
        }
        if (!doScroll) {
            return;
        }
        if (this.mShowViewWhileRefreshing) {
            smoothScrollTo(this.mCurrentMode == Mode.PULL_DOWN_TO_REFRESH ? -this.mHeaderHeight : this.mHeaderHeight);
        } else {
            smoothScrollTo(0);
        }
    }

    protected final void smoothScrollTo(int y) {
        if (this.mCurrentSmoothScrollRunnable != null) {
            this.mCurrentSmoothScrollRunnable.stop();
        }
        if (getScrollY() != y) {
            this.mCurrentSmoothScrollRunnable = new SmoothScrollRunnable(this.mHandler, getScrollY(), y);
            this.mHandler.post(this.mCurrentSmoothScrollRunnable);
        }
    }

    protected void updateUIForMode() {
        if (this == this.mHeaderLayout.getParent()) {
            removeView(this.mHeaderLayout);
        }
        if (this.mMode.canPullDown()) {
            addView(this.mHeaderLayout, 0, new LayoutParams(-1, -2));
        }
        if (this == this.mFooterLayout.getParent()) {
            removeView(this.mFooterLayout);
        }
        if (this.mMode.canPullUp()) {
            addView(this.mFooterLayout, new LayoutParams(-1, -2));
        }
        refreshLoadingViewsHeight();
        this.mCurrentMode = this.mMode != Mode.BOTH ? this.mMode : Mode.PULL_DOWN_TO_REFRESH;
    }

    private void init(Context context, AttributeSet attrs) {
        Drawable background;
        setOrientation(1);
        this.mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        TypedArray a = context.obtainStyledAttributes(attrs, C0213R.styleable.PullToRefresh);
        handleStyledAttributes(a);
        if (a.hasValue(4)) {
            this.mMode = Mode.mapIntToMode(a.getInteger(4, 0));
        }
        this.mRefreshableView = createRefreshableView(context, attrs);
        addRefreshableView(context, this.mRefreshableView);
        this.mHeaderLayout = new LoadingLayout(context, Mode.PULL_DOWN_TO_REFRESH, a);
        this.mFooterLayout = new LoadingLayout(context, Mode.PULL_UP_TO_REFRESH, a);
        updateUIForMode();
        if (a.hasValue(1)) {
            background = a.getDrawable(1);
            if (background != null) {
                setBackgroundDrawable(background);
            }
        }
        if (a.hasValue(34)) {
            background = a.getDrawable(34);
            if (background != null) {
                this.mRefreshableView.setBackgroundDrawable(background);
            }
        }
        a.recycle();
    }

    private boolean isReadyForPull() {
        switch (this.mMode) {
            case PULL_UP_TO_REFRESH:
                return isReadyForPullUp();
            case PULL_DOWN_TO_REFRESH:
                return isReadyForPullDown();
            case BOTH:
                return isReadyForPullUp() || isReadyForPullDown();
            default:
                return false;
        }
    }

    private void measureView(View child) {
        int childHeightSpec;
        ViewGroup.LayoutParams p = child.getLayoutParams();
        if (p == null) {
            p = new ViewGroup.LayoutParams(-1, -2);
        }
        int childWidthSpec = ViewGroup.getChildMeasureSpec(0, 0, p.width);
        int lpHeight = p.height;
        if (lpHeight > 0) {
            childHeightSpec = MeasureSpec.makeMeasureSpec(lpHeight, 1073741824);
        } else {
            childHeightSpec = MeasureSpec.makeMeasureSpec(0, 0);
        }
        child.measure(childWidthSpec, childHeightSpec);
    }

    private boolean pullEvent() {
        int newHeight;
        int oldHeight = getScrollY();
        switch (this.mCurrentMode) {
            case PULL_UP_TO_REFRESH:
                newHeight = Math.round(Math.max(this.mInitialMotionY - this.mLastMotionY, 0.0f) / 2.0f);
                break;
            default:
                newHeight = Math.round(Math.min(this.mInitialMotionY - this.mLastMotionY, 0.0f) / 2.0f);
                break;
        }
        setHeaderScroll(newHeight);
        if (newHeight != 0) {
            float scale = ((float) Math.abs(newHeight)) / ((float) this.mHeaderHeight);
            switch (this.mCurrentMode) {
                case PULL_UP_TO_REFRESH:
                    this.mFooterLayout.onPullY(scale);
                    break;
                case PULL_DOWN_TO_REFRESH:
                    this.mHeaderLayout.onPullY(scale);
                    break;
            }
            if (this.mState == 0 && this.mHeaderHeight < Math.abs(newHeight)) {
                this.mState = 1;
                onReleaseToRefresh();
                return true;
            } else if (this.mState == 1 && this.mHeaderHeight >= Math.abs(newHeight)) {
                this.mState = 0;
                onPullToRefresh();
                return true;
            }
        }
        if (oldHeight == newHeight) {
            return false;
        }
        return true;
    }

    private void refreshLoadingViewsHeight() {
        if (this.mMode.canPullDown()) {
            measureView(this.mHeaderLayout);
            this.mHeaderHeight = this.mHeaderLayout.getMeasuredHeight();
        } else if (this.mMode.canPullUp()) {
            measureView(this.mFooterLayout);
            this.mHeaderHeight = this.mFooterLayout.getMeasuredHeight();
        }
        switch (this.mMode) {
            case PULL_UP_TO_REFRESH:
                setPadding(0, 0, 0, -this.mHeaderHeight);
                return;
            case BOTH:
                setPadding(0, -this.mHeaderHeight, 0, -this.mHeaderHeight);
                return;
            default:
                setPadding(0, -this.mHeaderHeight, 0, 0);
                return;
        }
    }
}
