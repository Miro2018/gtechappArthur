package com.accumed.gtech.lib.pulltorefresh.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.support.v4.view.ViewCompat;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.lib.pulltorefresh.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshBase;

public class LoadingLayout extends FrameLayout {
    static final int DEFAULT_ROTATION_ANIMATION_DURATION = 600;
    private final ImageView mHeaderImage;
    private final Matrix mHeaderImageMatrix = new Matrix();
    private final TextView mHeaderText;
    private String mPullLabel;
    private String mRefreshingLabel;
    private String mReleaseLabel;
    private final Animation mRotateAnimation;
    private float mRotationPivotX;
    private float mRotationPivotY;
    private final TextView mSubHeaderText;

    public LoadingLayout(Context context, Mode mode, TypedArray attrs) {
        ColorStateList colors;
        super(context);
        ViewGroup header = (ViewGroup) LayoutInflater.from(context).inflate(C0213R.layout.pull_to_refresh_header_vertical, this);
        this.mHeaderText = (TextView) header.findViewById(C0213R.id.pull_to_refresh_text);
        this.mSubHeaderText = (TextView) header.findViewById(C0213R.id.pull_to_refresh_sub_text);
        this.mHeaderImage = (ImageView) header.findViewById(C0213R.id.pull_to_refresh_image);
        this.mHeaderImage.setScaleType(ScaleType.MATRIX);
        this.mHeaderImage.setImageMatrix(this.mHeaderImageMatrix);
        Interpolator interpolator = new LinearInterpolator();
        this.mRotateAnimation = new RotateAnimation(0.0f, 360.0f, 1, ClassConstant.INPUT_GLUCOSE_MMOL_MIN, 1, ClassConstant.INPUT_GLUCOSE_MMOL_MIN);
        this.mRotateAnimation.setInterpolator(interpolator);
        this.mRotateAnimation.setDuration(600);
        this.mRotateAnimation.setRepeatCount(-1);
        this.mRotateAnimation.setRepeatMode(1);
        switch (mode) {
            case PULL_UP_TO_REFRESH:
                this.mPullLabel = context.getString(C0213R.string.pull_to_refresh_from_bottom_pull_label);
                this.mRefreshingLabel = context.getString(C0213R.string.pull_to_refresh_from_bottom_refreshing_label);
                this.mReleaseLabel = context.getString(C0213R.string.pull_to_refresh_from_bottom_release_label);
                break;
            default:
                this.mPullLabel = context.getString(C0213R.string.pull_to_refresh_pull_label);
                this.mRefreshingLabel = context.getString(C0213R.string.pull_to_refresh_refreshing_label);
                this.mReleaseLabel = context.getString(C0213R.string.pull_to_refresh_release_label);
                break;
        }
        if (attrs.hasValue(2)) {
            colors = attrs.getColorStateList(2);
            if (colors == null) {
                colors = ColorStateList.valueOf(ViewCompat.MEASURED_STATE_MASK);
            }
            setTextColor(colors);
        }
        if (attrs.hasValue(3)) {
            colors = attrs.getColorStateList(3);
            if (colors == null) {
                colors = ColorStateList.valueOf(ViewCompat.MEASURED_STATE_MASK);
            }
            setSubTextColor(colors);
        }
        if (attrs.hasValue(1)) {
            Drawable background = attrs.getDrawable(1);
            if (background != null) {
                setBackgroundDrawable(background);
            }
        }
        Drawable imageDrawable = null;
        if (attrs.hasValue(6)) {
            imageDrawable = attrs.getDrawable(6);
        }
        if (imageDrawable == null) {
            imageDrawable = context.getResources().getDrawable(C0213R.drawable.default_ptr_drawable);
        }
        setLoadingDrawable(imageDrawable);
        reset();
    }

    public void reset() {
        this.mHeaderText.setText(Html.fromHtml(this.mPullLabel));
        this.mHeaderImage.setVisibility(0);
        this.mHeaderImage.clearAnimation();
        resetImageRotation();
        try {
            if (TextUtils.isEmpty(this.mSubHeaderText.getText())) {
                this.mSubHeaderText.setVisibility(8);
            } else {
                this.mSubHeaderText.setVisibility(0);
            }
        } catch (Exception e) {
        }
    }

    public void releaseToRefresh() {
        this.mHeaderText.setText(Html.fromHtml(this.mReleaseLabel));
    }

    public void setPullLabel(String pullLabel) {
        this.mPullLabel = pullLabel;
    }

    public void refreshing() {
        this.mHeaderText.setText(Html.fromHtml(this.mRefreshingLabel));
        this.mHeaderImage.startAnimation(this.mRotateAnimation);
        this.mSubHeaderText.setVisibility(8);
    }

    public void setRefreshingLabel(String refreshingLabel) {
        this.mRefreshingLabel = refreshingLabel;
    }

    public void setReleaseLabel(String releaseLabel) {
        this.mReleaseLabel = releaseLabel;
    }

    public void pullToRefresh() {
        this.mHeaderText.setText(Html.fromHtml(this.mPullLabel));
        this.mHeaderText.setTextColor(ViewCompat.MEASURED_STATE_MASK);
    }

    public void setTextColor(ColorStateList color) {
        this.mHeaderText.setTextColor(color);
        this.mSubHeaderText.setTextColor(color);
    }

    public void setSubTextColor(ColorStateList color) {
        this.mSubHeaderText.setTextColor(color);
    }

    public void setTextColor(int color) {
        setTextColor(ColorStateList.valueOf(color));
    }

    public void setLoadingDrawable(Drawable imageDrawable) {
        this.mHeaderImage.setImageDrawable(imageDrawable);
        this.mRotationPivotX = ((float) imageDrawable.getIntrinsicWidth()) / PullToRefreshBase.DEFAULT_FRICTION;
        this.mRotationPivotY = ((float) imageDrawable.getIntrinsicHeight()) / PullToRefreshBase.DEFAULT_FRICTION;
    }

    public void setSubTextColor(int color) {
        setSubTextColor(ColorStateList.valueOf(color));
    }

    public void setSubHeaderText(CharSequence label) {
        if (TextUtils.isEmpty(label)) {
            this.mSubHeaderText.setVisibility(8);
            return;
        }
        this.mSubHeaderText.setText(label);
        this.mSubHeaderText.setVisibility(0);
    }

    public void onPullY(float scaleOfHeight) {
        this.mHeaderImageMatrix.setRotate(90.0f * scaleOfHeight, this.mRotationPivotX, this.mRotationPivotY);
        this.mHeaderImage.setImageMatrix(this.mHeaderImageMatrix);
    }

    private void resetImageRotation() {
        this.mHeaderImageMatrix.reset();
        this.mHeaderImage.setImageMatrix(this.mHeaderImageMatrix);
    }
}
