package com.accumed.gtech.lib.pulltorefresh.internal;

import android.view.View;

public interface EmptyViewMethodAccessor {
    void setEmptyView(View view);

    void setEmptyViewInternal(View view);
}
