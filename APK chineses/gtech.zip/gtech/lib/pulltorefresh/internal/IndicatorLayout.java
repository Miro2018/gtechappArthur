package com.accumed.gtech.lib.pulltorefresh.internal;

import android.content.Context;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.lib.pulltorefresh.PullToRefreshBase.Mode;

public class IndicatorLayout extends FrameLayout implements AnimationListener {
    static final int DEFAULT_ROTATION_ANIMATION_DURATION = 150;
    private ImageView mArrowImageView;
    private Animation mInAnim;
    private Animation mOutAnim;
    private final Animation mResetRotateAnimation;
    private final Animation mRotateAnimation;

    public IndicatorLayout(Context context, Mode mode) {
        int inAnimResId;
        int outAnimResId;
        super(context);
        this.mArrowImageView = new ImageView(context);
        LayoutParams lp = new LayoutParams(-2, -2, 17);
        int dimensionPixelSize = getResources().getDimensionPixelSize(C0213R.dimen.indicator_internal_padding);
        lp.rightMargin = dimensionPixelSize;
        lp.leftMargin = dimensionPixelSize;
        lp.bottomMargin = dimensionPixelSize;
        lp.topMargin = dimensionPixelSize;
        addView(this.mArrowImageView, lp);
        switch (mode) {
            case PULL_UP_TO_REFRESH:
                inAnimResId = C0213R.anim.slide_in_from_bottom;
                outAnimResId = C0213R.anim.slide_out_to_bottom;
                setBackgroundResource(C0213R.drawable.indicator_bg_bottom);
                this.mArrowImageView.setImageResource(C0213R.drawable.arrow_up);
                break;
            default:
                inAnimResId = C0213R.anim.slide_in_from_top;
                outAnimResId = C0213R.anim.slide_out_to_top;
                setBackgroundResource(C0213R.drawable.indicator_bg_top);
                this.mArrowImageView.setImageResource(C0213R.drawable.arrow_down);
                break;
        }
        this.mInAnim = AnimationUtils.loadAnimation(context, inAnimResId);
        this.mInAnim.setAnimationListener(this);
        this.mOutAnim = AnimationUtils.loadAnimation(context, outAnimResId);
        this.mOutAnim.setAnimationListener(this);
        Interpolator interpolator = new LinearInterpolator();
        this.mRotateAnimation = new RotateAnimation(0.0f, -180.0f, 1, ClassConstant.INPUT_GLUCOSE_MMOL_MIN, 1, ClassConstant.INPUT_GLUCOSE_MMOL_MIN);
        this.mRotateAnimation.setInterpolator(interpolator);
        this.mRotateAnimation.setDuration(150);
        this.mRotateAnimation.setFillAfter(true);
        this.mResetRotateAnimation = new RotateAnimation(-180.0f, 0.0f, 1, ClassConstant.INPUT_GLUCOSE_MMOL_MIN, 1, ClassConstant.INPUT_GLUCOSE_MMOL_MIN);
        this.mResetRotateAnimation.setInterpolator(interpolator);
        this.mResetRotateAnimation.setDuration(150);
        this.mResetRotateAnimation.setFillAfter(true);
    }

    public final boolean isVisible() {
        Animation currentAnim = getAnimation();
        if (currentAnim != null) {
            if (this.mInAnim == currentAnim) {
                return true;
            }
            return false;
        } else if (getVisibility() != 0) {
            return false;
        } else {
            return true;
        }
    }

    public void hide() {
        startAnimation(this.mOutAnim);
    }

    public void show() {
        startAnimation(this.mInAnim);
    }

    public void onAnimationEnd(Animation animation) {
        if (animation == this.mOutAnim) {
            this.mArrowImageView.clearAnimation();
            setVisibility(8);
        } else if (animation == this.mInAnim) {
            setVisibility(0);
        }
        clearAnimation();
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
        setVisibility(0);
    }

    public void releaseToRefresh() {
        this.mArrowImageView.startAnimation(this.mRotateAnimation);
    }

    public void pullToRefresh() {
        this.mArrowImageView.startAnimation(this.mResetRotateAnimation);
    }
}
