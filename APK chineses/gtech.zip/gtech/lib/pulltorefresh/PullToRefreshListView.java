package com.accumed.gtech.lib.pulltorefresh;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.lib.pulltorefresh.PullToRefreshBase.Mode;
import com.accumed.gtech.lib.pulltorefresh.internal.EmptyViewMethodAccessor;
import com.accumed.gtech.lib.pulltorefresh.internal.LoadingLayout;

public class PullToRefreshListView extends PullToRefreshAdapterViewBase<ListView> {
    private LoadingLayout mFooterLoadingView;
    private LoadingLayout mHeaderLoadingView;
    private FrameLayout mLvFooterLoadingFrame;

    class InternalListView extends ListView implements EmptyViewMethodAccessor {
        private boolean mAddedLvFooter = false;

        public InternalListView(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        public void draw(Canvas canvas) {
            try {
                super.draw(canvas);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public ContextMenuInfo getContextMenuInfo() {
            return super.getContextMenuInfo();
        }

        public void setAdapter(ListAdapter adapter) {
            if (!this.mAddedLvFooter) {
                addFooterView(PullToRefreshListView.this.mLvFooterLoadingFrame, null, false);
                this.mAddedLvFooter = true;
            }
            super.setAdapter(adapter);
        }

        public void setEmptyView(View emptyView) {
            PullToRefreshListView.this.setEmptyView(emptyView);
        }

        public void setEmptyViewInternal(View emptyView) {
            super.setEmptyView(emptyView);
        }
    }

    public PullToRefreshListView(Context context) {
        super(context);
        setDisableScrollingWhileRefreshing(false);
    }

    public PullToRefreshListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setDisableScrollingWhileRefreshing(false);
    }

    public PullToRefreshListView(Context context, Mode mode) {
        super(context, mode);
        setDisableScrollingWhileRefreshing(false);
    }

    public ContextMenuInfo getContextMenuInfo() {
        return ((InternalListView) getRefreshableView()).getContextMenuInfo();
    }

    public void setPullLabel(String pullLabel, Mode mode) {
        super.setPullLabel(pullLabel, mode);
        if (this.mHeaderLoadingView != null && mode.canPullDown()) {
            this.mHeaderLoadingView.setPullLabel(pullLabel);
        }
        if (this.mFooterLoadingView != null && mode.canPullUp()) {
            this.mFooterLoadingView.setPullLabel(pullLabel);
        }
    }

    public void setRefreshingLabel(String refreshingLabel, Mode mode) {
        super.setRefreshingLabel(refreshingLabel, mode);
        if (this.mHeaderLoadingView != null && mode.canPullDown()) {
            this.mHeaderLoadingView.setRefreshingLabel(refreshingLabel);
        }
        if (this.mFooterLoadingView != null && mode.canPullUp()) {
            this.mFooterLoadingView.setRefreshingLabel(refreshingLabel);
        }
    }

    public void setReleaseLabel(String releaseLabel, Mode mode) {
        super.setReleaseLabel(releaseLabel, mode);
        if (this.mHeaderLoadingView != null && mode.canPullDown()) {
            this.mHeaderLoadingView.setReleaseLabel(releaseLabel);
        }
        if (this.mFooterLoadingView != null && mode.canPullUp()) {
            this.mFooterLoadingView.setReleaseLabel(releaseLabel);
        }
    }

    protected final ListView createRefreshableView(Context context, AttributeSet attrs) {
        ListView lv = new InternalListView(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, C0213R.styleable.PullToRefresh);
        FrameLayout frame = new FrameLayout(context);
        this.mHeaderLoadingView = new LoadingLayout(context, Mode.PULL_DOWN_TO_REFRESH, a);
        frame.addView(this.mHeaderLoadingView, -1, -2);
        this.mHeaderLoadingView.setVisibility(8);
        lv.addHeaderView(frame, null, false);
        this.mLvFooterLoadingFrame = new FrameLayout(context);
        this.mFooterLoadingView = new LoadingLayout(context, Mode.PULL_UP_TO_REFRESH, a);
        this.mLvFooterLoadingFrame.addView(this.mFooterLoadingView, -1, -2);
        this.mFooterLoadingView.setVisibility(8);
        a.recycle();
        lv.setId(16908298);
        return lv;
    }

    protected int getNumberInternalFooterViews() {
        return this.mFooterLoadingView != null ? 1 : 0;
    }

    protected int getNumberInternalHeaderViews() {
        return this.mHeaderLoadingView != null ? 1 : 0;
    }

    protected void resetHeader() {
        boolean scroll = true;
        ListAdapter adapter = ((ListView) this.mRefreshableView).getAdapter();
        if (!getShowViewWhileRefreshing() || adapter == null || adapter.isEmpty()) {
            super.resetHeader();
            return;
        }
        LoadingLayout originalLoadingLayout;
        LoadingLayout listViewLoadingLayout;
        int selection;
        int scrollToHeight = getHeaderHeight();
        switch (getCurrentMode()) {
            case PULL_UP_TO_REFRESH:
                originalLoadingLayout = getFooterLayout();
                listViewLoadingLayout = this.mFooterLoadingView;
                selection = ((ListView) this.mRefreshableView).getCount() - 1;
                if (((ListView) this.mRefreshableView).getLastVisiblePosition() != selection) {
                    scroll = false;
                }
                break;
            default:
                originalLoadingLayout = getHeaderLayout();
                listViewLoadingLayout = this.mHeaderLoadingView;
                scrollToHeight *= -1;
                selection = 0;
                if (((ListView) this.mRefreshableView).getFirstVisiblePosition() != 0) {
                    scroll = false;
                    break;
                }
                break;
        }
        originalLoadingLayout.setVisibility(0);
        if (scroll && getState() != 3) {
            ((ListView) this.mRefreshableView).setSelection(selection);
            setHeaderScroll(scrollToHeight);
        }
        listViewLoadingLayout.setVisibility(8);
        super.resetHeader();
    }

    protected void setRefreshingInternal(boolean doScroll) {
        ListAdapter adapter = ((ListView) this.mRefreshableView).getAdapter();
        if (!getShowViewWhileRefreshing() || adapter == null || adapter.isEmpty()) {
            super.setRefreshingInternal(doScroll);
            return;
        }
        LoadingLayout originalLoadingLayout;
        LoadingLayout listViewLoadingLayout;
        int selection;
        int scrollToY;
        super.setRefreshingInternal(false);
        switch (getCurrentMode()) {
            case PULL_UP_TO_REFRESH:
                originalLoadingLayout = getFooterLayout();
                listViewLoadingLayout = this.mFooterLoadingView;
                selection = ((ListView) this.mRefreshableView).getCount() - 1;
                scrollToY = getScrollY() - getHeaderHeight();
                break;
            default:
                originalLoadingLayout = getHeaderLayout();
                listViewLoadingLayout = this.mHeaderLoadingView;
                selection = 0;
                scrollToY = getScrollY() + getHeaderHeight();
                break;
        }
        if (doScroll) {
            setHeaderScroll(scrollToY);
        }
        originalLoadingLayout.setVisibility(4);
        listViewLoadingLayout.setVisibility(0);
        listViewLoadingLayout.refreshing();
        if (doScroll) {
            ((ListView) this.mRefreshableView).setSelection(selection);
            smoothScrollTo(0);
        }
    }
}
