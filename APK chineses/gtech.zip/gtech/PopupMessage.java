package com.accumed.gtech;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;

public class PopupMessage extends Activity {
    String FRIEND_EMAIL;
    String FRIEND_NAME;
    String GUBUN_NUM;
    int IMG_RESOURCE;
    String MESSAGE;
    String PANDING;
    final String className = "PopupMessage";
    LogCat logCat = new LogCat();
    Context mContext;
    ImageView popGubunImg;
    Button popInBt;
    LinearLayout popLy0;
    TextView popMessage;
    Button popNoBt;

    class C02121 implements OnClickListener {
        C02121() {
        }

        public void onClick(View arg0) {
            PopupMessage.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0213R.layout.popup_message);
        this.mContext = this;
        getWindow().addFlags(6815744);
        this.popMessage = (TextView) findViewById(C0213R.id.popMessage);
        this.popInBt = (Button) findViewById(C0213R.id.popInBt);
        this.popNoBt = (Button) findViewById(C0213R.id.popNoBt);
        this.popGubunImg = (ImageView) findViewById(C0213R.id.popGubunImg);
        this.popLy0 = (LinearLayout) findViewById(C0213R.id.popLy0);
        this.popLy0.setBackgroundResource(C0213R.drawable.pop_round);
        this.FRIEND_EMAIL = getIntent().getStringExtra(PreferenceAction.FRIEND_EMAIL);
        this.FRIEND_NAME = getIntent().getStringExtra("FRIEND_NAME");
        this.PANDING = getIntent().getStringExtra("PANDING");
        this.GUBUN_NUM = getIntent().getStringExtra("GUBUN_NUM");
        this.MESSAGE = getIntent().getStringExtra("MESSAGE");
        this.IMG_RESOURCE = Integer.parseInt(getIntent().getStringExtra("IMG_RESOURCE"));
        this.logCat.log("PopupMessage", "PopupMessage FRIEND_EMAIL", this.FRIEND_EMAIL);
        this.logCat.log("PopupMessage", "PopupMessage FRIEND_NAME", this.FRIEND_NAME);
        this.logCat.log("PopupMessage", "PopupMessage PANDING", this.PANDING);
        this.logCat.log("PopupMessage", "PopupMessage MESSAGE", this.MESSAGE);
        this.logCat.log("PopupMessage", "PopupMessage GUBUN_NUM", this.GUBUN_NUM);
        this.logCat.log("PopupMessage", "PopupMessage IMG_RESOURCE", Integer.toString(this.IMG_RESOURCE));
        this.popGubunImg.setImageResource(this.IMG_RESOURCE);
        this.popMessage.setText(this.MESSAGE);
        if (this.GUBUN_NUM.equals(LogDM.GLUCOSE_EAT_NONE)) {
            this.popNoBt.setVisibility(8);
            this.popInBt.setText(C0213R.string.alert_text_confirm);
        }
        this.popNoBt.setVisibility(8);
        this.popInBt.setOnClickListener(new C02121());
    }
}
