package com.accumed.gtech.chart;

import android.content.Context;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.datamodel.ChartData;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.util.ReadTextFile;
import com.accumed.gtech.util.Save;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class StatsChart {
    static String className = "StatsChart";
    private ChartData data;
    Context mContext;
    UserProfileSettingData userProfileSettingData;

    public StatsChart(Context c, ChartData cdata, UserProfileSettingData d) {
        this.mContext = c;
        this.data = cdata;
        this.userProfileSettingData = d;
    }

    public void saveStats() {
        SimpleDateFormat f;
        String text = getStatsTextFile();
        String date1 = this.data.getInfo_date01();
        String date2 = this.data.getInfo_date02();
        String period = this.data.getInfo_preriod();
        String name = this.data.getInfo_name();
        String birth = this.data.getInfo_birth();
        String since = this.data.getInfo_since();
        if (this.userProfileSettingData == null || !this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            f = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.ENGLISH);
        } else {
            f = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN);
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.000");
        String str = "";
        String str2 = "";
        String date03 = "";
        String strPeriod = this.mContext.getString(C0213R.string.html_period);
        try {
            str = strPeriod + ": " + f.format(format.parse(date1.substring(0, 8))) + " ~ " + f.format(format.parse(date2.substring(0, 8))) + " (" + (Integer.valueOf(period).intValue() + 1) + this.mContext.getString(C0213R.string.html_days) + ")";
            str2 = f.format(format2.parse(birth));
            date03 = f.format(format2.parse(since));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        text = ((((((((((((text.replace("u_value00", this.mContext.getString(C0213R.string.html_title_stats)).replace("u_value01", str).replace("u_value02", this.mContext.getString(C0213R.string.html_name)).replace("u_value03", name).replace("u_value04", this.mContext.getString(C0213R.string.html_birth)).replace("u_value05", str2).replace("u_value06", this.mContext.getString(C0213R.string.html_occur)).replace("u_value07", date03).replace("i_value01", this.data.getChart_total_count()).replace("i_value02", this.data.getChart_average_count()).replace("i_value03", this.data.getChart02_count02()).replace("i_value04", this.data.getChart02_count01()).replace("chart01_text_value01", this.data.getChart01_count01()) + " (" + this.data.getChart01_percent01() + "%)").replace("chart01_text_value02", this.data.getChart01_count02()) + " (" + this.data.getChart01_percent02() + "%)").replace("chart01_text_value03", this.data.getChart01_count03()) + " (" + this.data.getChart01_percent03() + "%)").replace("chart01_value01", this.data.getChart01_percent01()).replace("chart01_value02", this.data.getChart01_percent02()).replace("chart01_value03", this.data.getChart01_percent03()).replace("chart01_color01", this.data.getChart01_color01()).replace("chart01_color02", this.data.getChart01_color02()).replace("chart01_color03", this.data.getChart01_color03()).replace("chart02_text_value01", this.data.getChart02_count01()) + " (" + this.data.getChart02_percent01() + "%)").replace("chart02_text_value02", this.data.getChart02_count02()) + " (" + this.data.getChart02_percent02() + "%)").replace("chart02_text_value03", this.data.getChart02_count03()) + " (" + this.data.getChart02_percent03() + "%)").replace("chart02_value01", this.data.getChart02_percent01()).replace("chart02_value02", this.data.getChart02_percent02()).replace("chart02_value03", this.data.getChart02_percent03()).replace("chart02_color01", this.data.getChart02_color01()).replace("chart02_color02", this.data.getChart02_color02()).replace("chart02_color03", this.data.getChart02_color03()).replace("chart03_text_value01", this.data.getChart03_count01()) + " (" + this.data.getChart03_percent01() + "%)").replace("chart03_text_value02", this.data.getChart03_count02()) + " (" + this.data.getChart03_percent02() + "%)").replace("chart03_text_value03", this.data.getChart03_count03()) + " (" + this.data.getChart03_percent03() + "%)").replace("chart03_value01", this.data.getChart03_percent01()).replace("chart03_value02", this.data.getChart03_percent02()).replace("chart03_value03", this.data.getChart03_percent03()).replace("chart03_color01", this.data.getChart03_color01()).replace("chart03_color02", this.data.getChart03_color02()).replace("chart03_color03", this.data.getChart03_color03()).replace("chart04_text_value01", this.data.getChart04_count01()) + " (" + this.data.getChart04_percent01() + "%)").replace("chart04_text_value02", this.data.getChart04_count02()) + " (" + this.data.getChart04_percent02() + "%)").replace("chart04_text_value03", this.data.getChart04_count03()) + " (" + this.data.getChart04_percent03() + "%)").replace("chart04_value01", this.data.getChart04_percent01()).replace("chart04_value02", this.data.getChart04_percent02()).replace("chart04_value03", this.data.getChart04_percent03()).replace("chart04_color01", this.data.getChart04_color01()).replace("chart04_color02", this.data.getChart04_color02()).replace("chart04_color03", this.data.getChart04_color03()).replace("a_value01", this.data.getTable01_avg01()).replace("a_value02", this.data.getTable01_avg02()).replace("a_value03", this.data.getTable01_avg03()).replace("a_value04", this.data.getTable01_sd01()).replace("a_value05", this.data.getTable01_sd02()).replace("a_value06", this.data.getTable01_sd03()).replace("a_value07", this.data.getTable01_max01()).replace("a_value08", this.data.getTable01_max02()).replace("a_value09", this.data.getTable01_max03()).replace("a_value10", this.data.getTable01_min01()).replace("a_value11", this.data.getTable01_min02()).replace("a_value12", this.data.getTable01_min03()).replace("b_value01", this.data.getTable02_avg01()).replace("b_value02", this.data.getTable02_avg02()).replace("b_value03", this.data.getTable02_avg03()).replace("b_value04", this.data.getTable02_avg04()).replace("b_value05", this.data.getTable02_avg05()).replace("b_value06", this.data.getTable02_avg06()).replace("b_value07", this.data.getTable02_avg07()).replace("b_value08", this.data.getTable02_sd01()).replace("b_value09", this.data.getTable02_sd02()).replace("b_value10", this.data.getTable02_sd03()).replace("b_value11", this.data.getTable02_sd04()).replace("b_value12", this.data.getTable02_sd05()).replace("b_value13", this.data.getTable02_sd06()).replace("b_value14", this.data.getTable02_sd07()).replace("b_value15", this.data.getTable02_max01()).replace("b_value16", this.data.getTable02_max02()).replace("b_value17", this.data.getTable02_max03()).replace("b_value18", this.data.getTable02_max04()).replace("b_value19", this.data.getTable02_max05()).replace("b_value20", this.data.getTable02_max06()).replace("b_value21", this.data.getTable02_max07()).replace("b_value22", this.data.getTable02_min01()).replace("b_value23", this.data.getTable02_min02()).replace("b_value24", this.data.getTable02_min03()).replace("b_value25", this.data.getTable02_min04()).replace("b_value26", this.data.getTable02_min05()).replace("b_value27", this.data.getTable02_min06()).replace("b_value28", this.data.getTable02_min07()).replace("z_value01", this.data.getTable01_title()).replace("z_value02", this.data.getTable02_title());
        Save.traceText("chart", text.substring(0, text.lastIndexOf("</html>") + 7));
    }

    public String getStatsTextFile() {
        if (this.data.getInfo_language().equals("ko")) {
            return ReadTextFile.readText(this.mContext, "ko/chart.html");
        }
        return ReadTextFile.readText(this.mContext, "en/chart.html");
    }
}
