package com.accumed.gtech.chart;

import android.content.Context;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.datamining.DataMiningSelectLog;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.fragments.GraphFragment;
import com.accumed.gtech.util.GlucoseEvent;
import com.accumed.gtech.util.ReadTextFile;
import com.accumed.gtech.util.Save;
import com.accumed.gtech.util.Util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class StatsBloodSugar {
    static final String className = "StatsBloodSugar";
    Context mContext;
    UserProfileSettingData userProfileSettingData;
    Util util;

    public StatsBloodSugar(Context c, UserProfileSettingData d) {
        this.mContext = c;
        this.userProfileSettingData = d;
    }

    public void saveBloodSugar(String date1, String date2) {
        SimpleDateFormat simpleDateFormat;
        int i;
        int page;
        date1 = date1 + "000000";
        date2 = date2 + "235959";
        int diffDay = getDayDifference(date1, date2);
        String name = this.userProfileSettingData.USER_NAME;
        String birthDay = this.userProfileSettingData.USER_BIRTH;
        String occurDay = this.userProfileSettingData.USER_OCCOURDAY;
        String strDiffDay = String.valueOf(diffDay);
        if (this.userProfileSettingData == null || !this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.ENGLISH);
        } else {
            simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN);
        }
        simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        String str = "";
        String str2 = "";
        String date03 = "";
        try {
            str = this.mContext.getString(C0213R.string.html_period) + ": " + f.format(simpleDateFormat.parse(date1.substring(0, 8))) + " ~ " + f.format(simpleDateFormat.parse(date2.substring(0, 8))) + " (" + strDiffDay + ")";
            str2 = f.format(simpleDateFormat.parse(birthDay));
            date03 = f.format(simpleDateFormat.parse(occurDay));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String title = this.mContext.getString(C0213R.string.html_title_bloodsugar);
        String strDays = this.mContext.getString(C0213R.string.html_days);
        DataMiningSelectLog dataMiningSelectLog = new DataMiningSelectLog(this.mContext);
        ArrayList<String> contentsArr = new ArrayList();
        String contents = "";
        for (i = 0; i <= diffDay; i++) {
            String date = nextDate(date1, i);
            String d1 = date + "000000";
            String d2 = date + "235959";
            ArrayList<LogDM> arr = new ArrayList();
            String MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
            String DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
            arr = dataMiningSelectLog.getLogList("select * from log where category = '0' and input_date between '" + d1 + "' and '" + d2 + "' and blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE);
            if (arr.size() > 0) {
                contents = (((((((((((((((((((("" + "<tr>") + "<td rowspan='2' width='10%' align='center' height='40px'>date01</td>") + "<td width='10%' align='center' height='20px'>time01</td>") + "<td width='10%' align='center'>time02</td>") + "<td width='10%' align='center'>time03</td>") + "<td width='10%' align='center'>time04</td>") + "<td width='10%' align='center'>time05</td>") + "<td width='10%' align='center'>time06</td>") + "<td width='10%' align='center'>time07</td>") + "<td width='10%' align='center'>time08</td>") + "</tr>") + "<tr>") + "<td align='center' height='20px'>value01</td>") + "<td align='center'>value02</td>") + "<td align='center'>value03</td>") + "<td align='center'>value04</td>") + "<td align='center'>value05</td>") + "<td align='center'>value06</td>") + "<td align='center'>value07</td>") + "<td align='center'>value08</td>") + "</tr>";
                int j = 0;
                while (j < 8) {
                    if (j == 0) {
                        String strMonth = ((LogDM) arr.get(j)).input_date.substring(4, 6);
                        String strDay = ((LogDM) arr.get(j)).input_date.substring(6, 8);
                        String strDate = getStrDay(((LogDM) arr.get(j)).input_date.substring(0, 8));
                        String time = ((LogDM) arr.get(j)).input_date.substring(8, 10) + ":" + ((LogDM) arr.get(j)).input_date.substring(10, 12);
                        String value = ((LogDM) arr.get(j)).blood_sugar_value;
                        contents = contents.replace("date01", strMonth + "/" + strDay + "<br/>(" + strDate + ")").replace("time01", time);
                        int valueInt = Integer.parseInt(value);
                        String valueStr = Integer.toString(valueInt);
                        if (this.userProfileSettingData != null && this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mmol/L")) {
                            float value_mmol = Float.parseFloat(this.util.mgdlToMmolL(valueStr));
                            contents = (this.userProfileSettingData.USER_LOW_BLOOD_SUGAR == null || this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR == null) ? (value_mmol <= Float.parseFloat(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR) || value_mmol >= Float.parseFloat(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR)) ? contents.replace("value01", "<font color='#ff0000'>" + String.valueOf(value_mmol) + "</font>") : contents.replace("value01", String.valueOf(value_mmol)) : (value_mmol <= Float.parseFloat(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR) || value_mmol >= Float.parseFloat(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR)) ? contents.replace("value01", "<font color='#ff0000'>" + String.valueOf(value_mmol) + "</font>") : contents.replace("value01", String.valueOf(value_mmol));
                        } else if (this.userProfileSettingData != null && this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mg/dL")) {
                            contents = (this.userProfileSettingData.USER_LOW_BLOOD_SUGAR == null || this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR == null) ? (valueInt <= Integer.parseInt(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR) || valueInt >= Integer.parseInt(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR)) ? contents.replace("value01", "<font color='#ff0000'>" + valueStr + "</font>") : contents.replace("value01", valueStr) : (valueInt <= Integer.parseInt(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR) || valueInt >= Integer.parseInt(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR)) ? contents.replace("value01", "<font color='#ff0000'>" + valueStr + "</font>") : contents.replace("value01", valueStr);
                        }
                    } else if (j == 7) {
                        if (arr.size() > j) {
                            contents = setContents(j, contents, (LogDM) arr.get(j));
                        } else {
                            contents = setNullContents(j, contents);
                        }
                        contentsArr.add(contents);
                    } else {
                        contents = arr.size() > j ? setContents(j, contents, (LogDM) arr.get(j)) : setNullContents(j, contents);
                    }
                    j++;
                }
            }
        }
        String table = "";
        String tableContents = "";
        int page_count = 1;
        if (contentsArr.size() > 13) {
            page = contentsArr.size() / 13;
            if (contentsArr.size() % 13 != 0) {
                page++;
            }
        } else {
            page = 1;
        }
        if (contentsArr.size() > 0) {
            i = 0;
            while (i < contentsArr.size()) {
                tableContents = tableContents + ((String) contentsArr.get(i));
                if (i != 0 && i % 13 == 0) {
                    Save.traceText("bloodsugar_logbook(" + page_count + ")", getBloodsugarTextFile().replace("u_value00", title).replace("u_value01", str).replace("u_value02", "(" + diffDay + strDays + "  " + page_count + " / " + page + ")").replace("u_value03", this.mContext.getString(C0213R.string.html_name)).replace("u_value04", name).replace("u_value05", this.mContext.getString(C0213R.string.html_birth)).replace("u_value06", str2).replace("u_value07", this.mContext.getString(C0213R.string.html_occur)).replace("u_value08", date03).replace("#l#o#g#b#o#o#k#", tableContents));
                    page_count++;
                    tableContents = "";
                }
                if (i == contentsArr.size() - 1) {
                    Save.traceText("bloodsugar_logbook(" + page_count + ")", getBloodsugarTextFile().replace("u_value00", title).replace("u_value01", str).replace("u_value02", "(" + diffDay + strDays + "  " + page_count + " / " + page + ")").replace("u_value03", this.mContext.getString(C0213R.string.html_name)).replace("u_value04", name).replace("u_value05", this.mContext.getString(C0213R.string.html_birth)).replace("u_value06", str2).replace("u_value07", this.mContext.getString(C0213R.string.html_occur)).replace("u_value08", date03).replace("#l#o#g#b#o#o#k#", tableContents));
                }
                i++;
            }
        }
    }

    public String setNullContents(int j, String contents) {
        j++;
        return contents.replace("time0" + j, "&nbsp;").replace("value0" + j, "&nbsp;");
    }

    public String setContents(int j, String contents, LogDM data) {
        j++;
        String date = data.input_date;
        String value = data.blood_sugar_value;
        String time = date.substring(8, 10) + ":" + date.substring(10, 12);
        int i_value = Integer.parseInt(value);
        contents = contents.replace("time0" + j, time);
        if (this.userProfileSettingData.USER_LOW_BLOOD_SUGAR == null || this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR == null) {
            if (((float) i_value) <= Float.parseFloat(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR) || ((float) i_value) >= Float.parseFloat(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR)) {
                return contents.replace("value0" + j, "<font color='#ff0000'>" + value + "</font>");
            }
            return contents.replace("value0" + j, value);
        } else if (((float) i_value) <= Float.parseFloat(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR) || ((float) i_value) >= Float.parseFloat(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR)) {
            return contents.replace("value0" + j, "<font color='#ff0000'>" + value + "</font>");
        } else {
            return contents.replace("value0" + j, value);
        }
    }

    public String nextDate(String date, int i) {
        int year = Integer.parseInt(date.substring(0, 4));
        int month = Integer.parseInt(date.substring(4, 6));
        int day = Integer.parseInt(date.substring(6, 8));
        Calendar cal = new GregorianCalendar();
        cal.set(year, month - 1, day);
        cal.add(5, i);
        return addZero(cal.get(1)) + addZero(cal.get(2) + 1) + addZero(cal.get(5));
    }

    public String getBloodsugarTextFile() {
        if (this.userProfileSettingData == null || !this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            return ReadTextFile.readText(this.mContext, "en/bloodsugar.html");
        }
        return ReadTextFile.readText(this.mContext, "ko/bloodsugar.html");
    }

    private float getBsValue(int value) {
        String strValue = String.valueOf(((double) value) / 18.01d);
        String[] strArray = strValue.split("\\.");
        if (strArray.length == 2 && strArray[1].length() > 1) {
            strValue = strArray[0] + "." + strArray[1].substring(0, 1);
        }
        return Float.parseFloat(strValue);
    }

    private String getBsValue(String value) {
        String strValue = String.valueOf(Double.parseDouble(value) / 18.01d);
        String[] strArray = strValue.split("\\.");
        if (strArray.length != 2 || strArray[1].length() <= 1) {
            return strValue;
        }
        return strArray[0] + "." + strArray[1].substring(0, 1);
    }

    public String addZero(int value) {
        if (value < 10) {
            return "0" + String.valueOf(value);
        }
        return String.valueOf(value);
    }

    private int getDayDifference(String startDate, String endDate) {
        try {
            Date endDay = new SimpleDateFormat("yyyyMMddHHmmss").parse(endDate);
            Calendar endDayCal = new GregorianCalendar();
            endDayCal.setTime(endDay);
            Date startDay = new SimpleDateFormat("yyyyMMddHHmmss").parse(startDate);
            Calendar startDayCal = new GregorianCalendar();
            startDayCal.setTime(startDay);
            return (int) ((endDayCal.getTimeInMillis() - startDayCal.getTimeInMillis()) / GraphFragment.DATE_DAY);
        } catch (ParseException e) {
            e.printStackTrace(System.out);
            return 0;
        }
    }

    private String getStrDay(String strDate) {
        Calendar cal = Calendar.getInstance();
        int year = Integer.parseInt(strDate.substring(0, 4));
        int month = Integer.parseInt(strDate.substring(4, 6));
        int date = Integer.parseInt(strDate.substring(6));
        cal.set(1, year);
        cal.set(2, month - 1);
        cal.set(5, date);
        switch (cal.get(7)) {
            case 1:
                return this.mContext.getString(C0213R.string.html_sunday);
            case 2:
                return this.mContext.getString(C0213R.string.html_monday);
            case 3:
                return this.mContext.getString(C0213R.string.html_tuesday);
            case 4:
                return this.mContext.getString(C0213R.string.html_wednesday);
            case 5:
                return this.mContext.getString(C0213R.string.html_thursday);
            case 6:
                return this.mContext.getString(C0213R.string.html_friday);
            case 7:
                return this.mContext.getString(C0213R.string.html_saturday);
            default:
                return null;
        }
    }
}
