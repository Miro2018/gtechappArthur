package com.accumed.gtech.chart;

import android.content.Context;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.datamining.DataMiningSelectLog;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.util.GlucoseEvent;
import com.accumed.gtech.util.LogCat;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class StatsCsv {
    static final String className = "StatsCsv";
    LogCat logCat = new LogCat();
    Context mContext;
    UserProfileSettingData userProfileSettingData;

    public StatsCsv(Context c, UserProfileSettingData data) {
        this.mContext = c;
        this.userProfileSettingData = data;
    }

    public void saveCsv() {
        System.out.println(new OutputStreamWriter(System.out).getEncoding());
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("/sdcard/data/com.gluconavii/file/csv.csv"), "MS949"));
            getProfileData(writer);
            writer.write("\n");
            getBsData(writer);
            writer.write("\n");
            getInsulinData(writer);
            writer.write("\n");
            getNoteData(writer);
            writer.write("\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getProfileData(BufferedWriter writer) throws IOException {
        String title = "";
        if (this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            title = "프로필";
        } else {
            title = "Profile";
        }
        String name = this.userProfileSettingData.USER_NAME;
        String birthDay = this.userProfileSettingData.USER_BIRTH.substring(0, 8);
        String gender = "";
        if (this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            if (this.userProfileSettingData.USER_GENDER.equals("male")) {
                gender = "남자";
            } else {
                gender = "여자";
            }
        } else if (this.userProfileSettingData.USER_GENDER.equals("male")) {
            gender = "male";
        } else {
            gender = "female";
        }
        String occurDay = this.userProfileSettingData.USER_OCCOURDAY.substring(0, 8);
        String strBsUnit = this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT;
        writer.write(title);
        writer.write("\n");
        writer.write("'" + name + "','" + birthDay + "','" + gender + "','" + occurDay + "','" + strBsUnit + "'");
    }

    public void getBsData(BufferedWriter writer) throws IOException {
        DataMiningSelectLog miningSelectLog = new DataMiningSelectLog(this.mContext);
        ArrayList<LogDM> arr = new ArrayList();
        String MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
        String DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
        arr = miningSelectLog.getLogList("select * from log where category = '0' and  blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE + " ORDER BY seq DESC, input_date DESC");
        String title = "";
        if (this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            title = "혈당";
        } else {
            title = "BloodSugar";
        }
        writer.write(title);
        writer.write("\n");
        for (int i = 0; i < arr.size(); i++) {
            String inputDateStr = ((LogDM) arr.get(i)).input_date;
            String date = yyyy_mm_(inputDateStr);
            String time = dd_tt_mm_ss(inputDateStr);
            String value = "";
            this.logCat.log(className, "inputDateStr", inputDateStr);
            this.logCat.log(className, "inputDateStr date", date);
            this.logCat.log(className, "inputDateStr time", time);
            if (this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mg/dL")) {
                value = ((LogDM) arr.get(i)).blood_sugar_value;
            } else {
                value = getBsValue(((LogDM) arr.get(i)).blood_sugar_value);
            }
            BufferedWriter bufferedWriter = writer;
            bufferedWriter.write("'" + date + "','" + time + "','" + value + "','" + getEatType(((LogDM) arr.get(i)).blood_sugar_eat) + "'");
        }
    }

    private String yyyy_mm_(String dateStr) {
        String y_m = dateStr.substring(0, 6);
        String y = y_m.substring(0, 4);
        return y + "-" + y_m.substring(4, 6) + "-";
    }

    private String dd_tt_mm_ss(String dateStr) {
        String d_t_s = dateStr.substring(6);
        String d = d_t_s.substring(0, 2);
        String t = d_t_s.substring(2, 4);
        String m = d_t_s.substring(4, 6);
        return d + " " + t + ":" + m + ":" + (d_t_s.substring(6, 8) + "." + d_t_s.substring(8));
    }

    public void getInsulinData(BufferedWriter writer) throws IOException {
        DataMiningSelectLog miningSelectLog = new DataMiningSelectLog(this.mContext);
        ArrayList<LogDM> arr = new ArrayList();
        String MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
        String DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
        arr = miningSelectLog.getLogList("select * from log where category = '1' and  blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE + " ORDER BY seq DESC, input_date DESC");
        String title = "";
        if (this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            title = "인슐린";
        } else {
            title = "Insulin";
        }
        writer.write(title);
        writer.write("\n");
        for (int i = 0; i < arr.size(); i++) {
            String inputDateStr = ((LogDM) arr.get(i)).input_date;
            String date = inputDateStr.substring(0, 6);
            String time = inputDateStr.substring(6);
            String type = getInsulinType(((LogDM) arr.get(i)).insulin_type);
            String name = getInsulinName(((LogDM) arr.get(i)).insulin_name);
            BufferedWriter bufferedWriter = writer;
            bufferedWriter.write("'" + date + "','" + time + "','" + type + "','" + name + "''" + ((LogDM) arr.get(i)).insulin_value + "'");
        }
    }

    public void getNoteData(BufferedWriter writer) throws IOException {
        DataMiningSelectLog miningSelectLog = new DataMiningSelectLog(this.mContext);
        ArrayList<LogDM> arr = new ArrayList();
        String MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
        String DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
        arr = miningSelectLog.getLogList("select * from log where category = '2' and  blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE + " ORDER BY seq DESC, input_date DESC");
        String title = "";
        if (this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            title = "노트";
        } else {
            title = "Note";
        }
        writer.write(title);
        writer.write("\n");
        for (int i = 0; i < arr.size(); i++) {
            String inputDateStr = ((LogDM) arr.get(i)).input_date;
            String date = inputDateStr.substring(0, 6);
            String time = inputDateStr.substring(6);
            String type = ((LogDM) arr.get(i)).note_type;
            String note = ((LogDM) arr.get(i)).note_content;
            if (Integer.parseInt(type) == 0) {
                if (this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
                    title = "식사";
                } else {
                    title = "Eat";
                }
            } else if (Integer.parseInt(type) == 1) {
                if (this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
                    title = "운동";
                } else {
                    title = "Sports";
                }
            } else if (this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
                title = "노트";
            } else {
                title = "Note";
            }
            writer.write("'" + date + "','" + time + "','" + type + "','" + note + "'");
        }
    }

    private String getBsValue(String value) {
        String strValue = String.valueOf(Double.parseDouble(value) / 18.01d);
        String[] strArray = strValue.split("\\.");
        if (strArray.length != 2 || strArray[1].length() <= 1) {
            return strValue;
        }
        return strArray[0] + "." + strArray[1].substring(0, 1);
    }

    public String getEatType(String no) {
        if (no.toLowerCase().equals("before")) {
            no = "1";
        }
        if (no.toLowerCase().equals("after")) {
            no = "0";
        }
        if (no.toLowerCase().equals("control solution")) {
            no = "2";
        }
        if (no.toLowerCase().equals("none")) {
            no = LogDM.GLUCOSE_EAT_NONE;
        }
        switch (Integer.parseInt(no)) {
            case 0:
                return this.mContext.getString(C0213R.string.blood_sugar_eat_before);
            case 1:
                return this.mContext.getString(C0213R.string.blood_sugar_eat_after);
            case 2:
                return this.mContext.getString(C0213R.string.blood_sugar_eat_cs);
            default:
                return null;
        }
    }

    public String getInputType(String no) {
        switch (Integer.parseInt(no)) {
            case 0:
                return this.mContext.getString(C0213R.string.blood_sugar_type_machine);
            case 1:
                return this.mContext.getString(C0213R.string.blood_sugar_type_user);
            default:
                return null;
        }
    }

    public String getInsulinType(String no) {
        switch (Integer.parseInt(no)) {
            case 0:
                return this.mContext.getString(C0213R.string.insulin_type_rapid);
            case 1:
                return this.mContext.getString(C0213R.string.insulin_type_short);
            case 2:
                return this.mContext.getString(C0213R.string.insulin_type_nph);
            case 3:
                return this.mContext.getString(C0213R.string.insulin_type_long);
            case 4:
                return this.mContext.getString(C0213R.string.insulin_type_mix);
            default:
                return null;
        }
    }

    private String getInsulinName(String no) {
        switch (Integer.parseInt(no)) {
            case 0:
                return this.mContext.getString(C0213R.string.insulin_name_novorapid);
            case 1:
                return this.mContext.getString(C0213R.string.insulin_name_apidra);
            case 2:
                return this.mContext.getString(C0213R.string.insulin_name_humalog);
            case 3:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_r);
            case 4:
                return this.mContext.getString(C0213R.string.insulin_name_novorin_r);
            case 5:
                return this.mContext.getString(C0213R.string.insulin_name_insulatard);
            case 6:
                return this.mContext.getString(C0213R.string.insulin_name_lantus);
            case 7:
                return this.mContext.getString(C0213R.string.insulin_name_levemir);
            case 8:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_30);
            case 9:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_50);
            case 10:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_70);
            case 11:
                return this.mContext.getString(C0213R.string.insulin_name_mixtard);
            case 12:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_30);
            case 13:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_70);
            case 14:
                return this.mContext.getString(C0213R.string.insulin_name_humalogmix_25);
            case 15:
                return this.mContext.getString(C0213R.string.insulin_name_humalogmix_50);
            default:
                return null;
        }
    }
}
