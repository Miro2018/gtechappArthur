package com.accumed.gtech.chart;

import android.content.Context;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.datamining.DataMiningSelectLog;
import com.accumed.gtech.datamodel.LogDM;
import com.accumed.gtech.datamodel.UserProfileSettingData;
import com.accumed.gtech.fragments.GraphFragment;
import com.accumed.gtech.util.GlucoseEvent;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.ReadTextFile;
import com.accumed.gtech.util.Save;
import com.accumed.gtech.util.Util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class StatsInsulin {
    static final String className = "StatsInsulin";
    LogCat logCat;
    Context mContext;
    UserProfileSettingData userProfileSettingData;
    Util util = new Util();

    public StatsInsulin(Context c, UserProfileSettingData d) {
        this.mContext = c;
        this.userProfileSettingData = d;
        this.logCat = new LogCat();
    }

    public void saveInsulin(String date1, String date2) {
        SimpleDateFormat simpleDateFormat;
        int i;
        date1 = date1 + "000000";
        date2 = date2 + "235959";
        int diffDay = getDayDifference(date1, date2);
        String name = this.userProfileSettingData.USER_NAME;
        String birthDay = this.userProfileSettingData.USER_BIRTH;
        String occurDay = this.userProfileSettingData.USER_OCCOURDAY;
        String strDiffDay = String.valueOf(diffDay);
        if (this.userProfileSettingData == null || !this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.ENGLISH);
        } else {
            simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREAN);
        }
        simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.000");
        String str = "";
        String str2 = "";
        String date03 = "";
        try {
            str = this.mContext.getString(C0213R.string.html_period) + ": " + f.format(simpleDateFormat.parse(date1.substring(0, 8))) + " ~ " + f.format(simpleDateFormat.parse(date2.substring(0, 8))) + " (" + strDiffDay + ")";
            str2 = f.format(simpleDateFormat.parse(birthDay));
            date03 = f.format(simpleDateFormat.parse(occurDay));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        String title = this.mContext.getString(C0213R.string.html_title_insulin);
        String strDays = this.mContext.getString(C0213R.string.html_days);
        DataMiningSelectLog dataMiningSelectLog = new DataMiningSelectLog(this.mContext);
        ArrayList<String> contentsArr = new ArrayList();
        ArrayList<Integer> maxCountArr = new ArrayList();
        for (i = 0; i <= diffDay; i++) {
            int j;
            String d1;
            String d2;
            String MODIFY_VALUE;
            String DELETE_VALUE;
            boolean bsDatacheck;
            boolean isDataCheck;
            String date = nextDate(date1, i);
            ArrayList<ArrayList<LogDM>> bsArr = new ArrayList();
            ArrayList<LogDM> isArr = new ArrayList();
            for (j = 0; j < 17; j++) {
                String q;
                ArrayList<LogDM> arr;
                if (j == 0) {
                    d1 = date + "000000";
                    d2 = date + "075959";
                    MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
                    DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
                    q = "select * from log where category = '0' and input_date between '" + d1 + "' and '" + d2 + "' and blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE;
                    arr = dataMiningSelectLog.getLogList(q);
                } else {
                    String strStartTime = addZero(7 + j);
                    d1 = date + strStartTime + "0000";
                    d2 = date + strStartTime + "5959";
                    MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
                    DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
                    q = "select * from log where category = '0' and input_date between '" + d1 + "' and '" + d2 + "' and blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE;
                    arr = dataMiningSelectLog.getLogList(q);
                }
                this.logCat.log(className, "arr query", q);
                this.logCat.log(className, "arr size", arr.size() + "");
                bsArr.add(arr);
            }
            d1 = date + "000000";
            d2 = date + "235959";
            MODIFY_VALUE = String.valueOf(GlucoseEvent.MODIFY_8);
            DELETE_VALUE = String.valueOf(GlucoseEvent.DEL_9);
            isArr = dataMiningSelectLog.getLogList("select * from log where category = '1' and input_date between '" + d1 + "' and '" + d2 + "' and blood_sugar_eat_origin & " + MODIFY_VALUE + " != " + MODIFY_VALUE + " and blood_sugar_eat_origin & " + DELETE_VALUE + " != " + DELETE_VALUE);
            int max_row_count = 0;
            for (j = 0; j < bsArr.size(); j++) {
                int arr_count = ((ArrayList) bsArr.get(j)).size();
                if (arr_count > max_row_count) {
                    max_row_count = arr_count;
                }
            }
            if (max_row_count > 0) {
                bsDatacheck = true;
            } else {
                bsDatacheck = false;
            }
            if (isArr.size() > 0) {
                max_row_count++;
                isDataCheck = true;
            } else {
                isDataCheck = false;
            }
            int k = 0;
            String contents = "";
            for (int n = 0; n < max_row_count; n++) {
                String strMonth;
                String strDay;
                LogDM logDM;
                String valueStr;
                int valueInt;
                float value_mmol;
                if (n == max_row_count - 1) {
                    if (isDataCheck) {
                        for (j = 0; j < bsArr.size(); j++) {
                            if (j == 0) {
                                if (contents.equals("")) {
                                    strMonth = date.substring(4, 6);
                                    strDay = date.substring(6);
                                    contents = (contents + "<tr>\n") + "<td rowspan='" + max_row_count + "' width='5.4%' align='center'>" + strMonth + "/" + strDay + "<br/>(" + getStrDay(date) + ")</td>\n";
                                } else {
                                    contents = contents + "<tr>\n";
                                }
                            }
                            if (isArr.size() > j) {
                                logDM = (LogDM) isArr.get(j);
                                if (logDM == null || logDM.insulin_value == null || logDM.insulin_value.trim().equals("")) {
                                    contents = contents + "<td width='5.4%' align='center' height='30'>&nbsp;</td>";
                                } else {
                                    String isHour = logDM.input_date.substring(8, 10);
                                    String isMinute = logDM.input_date.substring(10, 12);
                                    String isname = getInsulinName(logDM.insulin_name);
                                    contents = (contents + "<td width='5.4%' align='center' height='30'>" + isHour + ":" + isMinute + "</td>\n") + "<td width='10.8%' colspan='2' align='center'>" + isname + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + logDM.insulin_value + "</td>\n";
                                }
                            } else {
                                contents = contents + "<td width='5.4%' align='center' height='30'>&nbsp;</td>\n";
                            }
                            if (j == (bsArr.size() - 1) - (isArr.size() * 2)) {
                                contents = contents + "</tr>\n";
                                break;
                            }
                        }
                    } else if (bsDatacheck) {
                        for (j = 0; j < bsArr.size(); j++) {
                            if (j == 0) {
                                if (contents.equals("")) {
                                    strMonth = date.substring(4, 6);
                                    strDay = date.substring(6);
                                    contents = (contents + "<tr>\n") + "<td rowspan='" + max_row_count + "' width='5.4%' align='center'>" + strMonth + "/" + strDay + "<br/>(" + getStrDay(date) + ")</td>\n";
                                } else {
                                    contents = contents + "<tr>\n";
                                }
                            }
                            logDM = null;
                            if (((ArrayList) bsArr.get(j)).size() > k) {
                                logDM = (LogDM) ((ArrayList) bsArr.get(j)).get(k);
                            }
                            if (logDM == null || logDM.blood_sugar_value == null || logDM.blood_sugar_value.trim().equals("")) {
                                contents = contents + "<td width='5.4%' align='center' height='30'>&nbsp;</td>\n";
                            } else {
                                valueStr = logDM.blood_sugar_value;
                                valueInt = Integer.parseInt(valueStr);
                                if (this.userProfileSettingData != null && this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mmol/L")) {
                                    value_mmol = Float.parseFloat(this.util.mgdlToMmolL(valueStr));
                                    if (!(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR == null || this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR == null)) {
                                        if (value_mmol > Float.parseFloat(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR)) {
                                            if (value_mmol < Float.parseFloat(getBsValue(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR))) {
                                                valueStr = String.valueOf(value_mmol);
                                            }
                                        }
                                        valueStr = "<font color='#ff0000'>" + String.valueOf(value_mmol) + "</font>";
                                    }
                                } else if (!(this.userProfileSettingData == null || !this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mg/dL") || this.userProfileSettingData.USER_LOW_BLOOD_SUGAR == null || this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR == null || (valueInt > Integer.parseInt(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR) && valueInt < Integer.parseInt(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR)))) {
                                    valueStr = "<font color='#ff0000'>" + valueStr + "</font>";
                                }
                                contents = contents + "<td width='5.4%' align='center' height='30'>" + valueStr + "</td>\n";
                            }
                            if (j == bsArr.size() - 1) {
                                contents = contents + "</tr>\n";
                                k++;
                            }
                        }
                    }
                } else if (bsDatacheck) {
                    for (j = 0; j < bsArr.size(); j++) {
                        if (j == 0) {
                            if (contents.equals("")) {
                                strMonth = date.substring(4, 6);
                                strDay = date.substring(6);
                                contents = (contents + "<tr>\n") + "<td rowspan='" + max_row_count + "' width='5.4%' align='center'>" + strMonth + "/" + strDay + "<br/>(" + getStrDay(date) + ")</td>\n";
                            } else {
                                contents = contents + "<tr>\n";
                            }
                        }
                        logDM = null;
                        if (((ArrayList) bsArr.get(j)).size() > k) {
                            logDM = (LogDM) ((ArrayList) bsArr.get(j)).get(k);
                        }
                        if (logDM == null || logDM.blood_sugar_value == null || logDM.blood_sugar_value.trim().equals("")) {
                            contents = contents + "<td width='5.4%' align='center' height='30'>&nbsp;</td>\n";
                        } else {
                            valueStr = logDM.blood_sugar_value;
                            valueInt = Integer.parseInt(valueStr);
                            if (this.userProfileSettingData != null && this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mmol/L")) {
                                value_mmol = Float.parseFloat(this.util.mgdlToMmolL(valueStr));
                                if (!(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR == null || this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR == null)) {
                                    if (value_mmol > Float.parseFloat(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR)) {
                                        if (value_mmol < Float.parseFloat(getBsValue(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR))) {
                                            valueStr = String.valueOf(value_mmol);
                                        }
                                    }
                                    valueStr = "<font color='#ff0000'>" + String.valueOf(value_mmol) + "</font>";
                                }
                            } else if (!(this.userProfileSettingData == null || !this.userProfileSettingData.USER_BLOOD_SUGAR_UNIT.equals("mg/dL") || this.userProfileSettingData.USER_LOW_BLOOD_SUGAR == null || this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR == null || (valueInt > Integer.parseInt(this.userProfileSettingData.USER_LOW_BLOOD_SUGAR) && valueInt < Integer.parseInt(this.userProfileSettingData.USER_HIGH_BLOOD_SUGAR)))) {
                                valueStr = "<font color='#ff0000'>" + valueStr + "</font>";
                            }
                            contents = contents + "<td width='5.4%' align='center' height='30'>" + valueStr + "</td>\n";
                        }
                        if (j == bsArr.size() - 1) {
                            contents = contents + "</tr>\n";
                            k++;
                        }
                    }
                }
            }
            if (!(contents == null || contents.trim().equals(""))) {
                contentsArr.add(contents);
                maxCountArr.add(Integer.valueOf(max_row_count));
            }
        }
        String table = "";
        String tableContents = "";
        int page = 0;
        int page_count = 1;
        int column_count = 0;
        if (contentsArr.size() > 0) {
            i = 0;
            while (i < contentsArr.size()) {
                if (!(((Integer) maxCountArr.get(i)).intValue() + column_count <= 15 || tableContents == null || tableContents.trim().equals(""))) {
                    page++;
                    tableContents = "";
                    column_count = 0;
                }
                column_count += ((Integer) maxCountArr.get(i)).intValue();
                tableContents = tableContents + ((String) contentsArr.get(i));
                if (i == 0 && i == contentsArr.size() - 1) {
                    if (!(tableContents == null || tableContents.trim().equals(""))) {
                        page++;
                    }
                } else if (!(i != contentsArr.size() - 1 || tableContents == null || tableContents.trim().equals(""))) {
                    page++;
                }
                i++;
            }
        }
        column_count = 0;
        tableContents = "";
        if (contentsArr.size() > 0) {
            for (i = 0; i < contentsArr.size(); i++) {
                if (((Integer) maxCountArr.get(i)).intValue() + column_count > 15) {
                    Save.traceText("insulin_logbook(" + page_count + ")", getInsulinTextFile().replace("u_value00", title).replace("u_value01", str).replace("u_value02", "(" + diffDay + strDays + "  " + page_count + " / " + page + ")").replace("u_value03", this.mContext.getString(C0213R.string.html_name)).replace("u_value04", name).replace("u_value05", this.mContext.getString(C0213R.string.html_birth)).replace("u_value06", str2).replace("u_value07", this.mContext.getString(C0213R.string.html_occur)).replace("u_value08", date03).replace("#l#o#g#b#o#o#k#", tableContents));
                    page_count++;
                    column_count = 0;
                    tableContents = "";
                }
                column_count += ((Integer) maxCountArr.get(i)).intValue();
                tableContents = tableContents + ((String) contentsArr.get(i));
                if (i == contentsArr.size() - 1) {
                    Save.traceText("insulin_logbook(" + page_count + ")", getInsulinTextFile().replace("u_value00", title).replace("u_value01", str).replace("u_value02", "(" + diffDay + strDays + "  " + page_count + " / " + page + ")").replace("u_value03", this.mContext.getString(C0213R.string.html_name)).replace("u_value04", name).replace("u_value05", this.mContext.getString(C0213R.string.html_birth)).replace("u_value06", str2).replace("u_value07", this.mContext.getString(C0213R.string.html_occur)).replace("u_value08", date03).replace("#l#o#g#b#o#o#k#", tableContents));
                }
            }
        }
    }

    public String nextDate(String date, int i) {
        int year = Integer.parseInt(date.substring(0, 4));
        int month = Integer.parseInt(date.substring(4, 6));
        int day = Integer.parseInt(date.substring(6, 8));
        Calendar cal = new GregorianCalendar();
        cal.set(year, month - 1, day);
        cal.add(5, i);
        return addZero(cal.get(1)) + addZero(cal.get(2) + 1) + addZero(cal.get(5));
    }

    public String getInsulinTextFile() {
        String result;
        if (this.userProfileSettingData == null || !this.userProfileSettingData.USER_LANGUAGE.equals("ko")) {
            result = ReadTextFile.readText(this.mContext, "en/insulin.html");
        } else {
            result = ReadTextFile.readText(this.mContext, "ko/insulin.html");
        }
        this.logCat.log(className, "result", result);
        return result;
    }

    private String getBsValue(String value) {
        this.logCat.log(className, "getBsValue value", value);
        String strValue = String.valueOf(Double.parseDouble(value) / 18.01d);
        String[] strArray = strValue.split("\\.");
        if (strArray.length != 2 || strArray[1].length() <= 1) {
            return strValue;
        }
        return strArray[0] + "." + strArray[1].substring(0, 1);
    }

    private String getInsulinName(String no) {
        if (no == null || no.trim().equals("")) {
            return "&nbsp;";
        }
        switch (Integer.parseInt(no)) {
            case 0:
                return this.mContext.getString(C0213R.string.insulin_name_novorapid);
            case 1:
                return this.mContext.getString(C0213R.string.insulin_name_apidra);
            case 2:
                return this.mContext.getString(C0213R.string.insulin_name_humalog);
            case 3:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_r);
            case 4:
                return this.mContext.getString(C0213R.string.insulin_name_novorin_r);
            case 5:
                return this.mContext.getString(C0213R.string.insulin_name_insulatard);
            case 6:
                return this.mContext.getString(C0213R.string.insulin_name_lantus);
            case 7:
                return this.mContext.getString(C0213R.string.insulin_name_levemir);
            case 8:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_30);
            case 9:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_50);
            case 10:
                return this.mContext.getString(C0213R.string.insulin_name_novomix_70);
            case 11:
                return this.mContext.getString(C0213R.string.insulin_name_mixtard);
            case 12:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_30);
            case 13:
                return this.mContext.getString(C0213R.string.insulin_name_humulin_70);
            case 14:
                return this.mContext.getString(C0213R.string.insulin_name_humalogmix_25);
            case 15:
                return this.mContext.getString(C0213R.string.insulin_name_humalogmix_50);
            default:
                return null;
        }
    }

    public String addZero(int value) {
        if (value < 10) {
            return "0" + String.valueOf(value);
        }
        return String.valueOf(value);
    }

    public String getStrDay(String strDate) {
        Calendar cal = Calendar.getInstance();
        int year = Integer.parseInt(strDate.substring(0, 4));
        int month = Integer.parseInt(strDate.substring(4, 6));
        int date = Integer.parseInt(strDate.substring(6));
        cal.set(1, year);
        cal.set(2, month - 1);
        cal.set(5, date);
        switch (cal.get(7)) {
            case 1:
                return this.mContext.getString(C0213R.string.html_sunday);
            case 2:
                return this.mContext.getString(C0213R.string.html_monday);
            case 3:
                return this.mContext.getString(C0213R.string.html_tuesday);
            case 4:
                return this.mContext.getString(C0213R.string.html_wednesday);
            case 5:
                return this.mContext.getString(C0213R.string.html_thursday);
            case 6:
                return this.mContext.getString(C0213R.string.html_friday);
            case 7:
                return this.mContext.getString(C0213R.string.html_saturday);
            default:
                return null;
        }
    }

    private int getDayDifference(String startDate, String endDate) {
        try {
            Date endDay = new SimpleDateFormat("yyyyMMddHHmmss").parse(endDate);
            Calendar endDayCal = new GregorianCalendar();
            endDayCal.setTime(endDay);
            Date startDay = new SimpleDateFormat("yyyyMMddHHmmss").parse(startDate);
            Calendar startDayCal = new GregorianCalendar();
            startDayCal.setTime(startDay);
            return (int) ((endDayCal.getTimeInMillis() - startDayCal.getTimeInMillis()) / GraphFragment.DATE_DAY);
        } catch (ParseException e) {
            e.printStackTrace(System.out);
            return 0;
        }
    }
}
