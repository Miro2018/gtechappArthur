package com.accumed.gtech;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

public class PagerAdapter extends FragmentPagerAdapter implements PageIndicator {
    static final String className = "AdapterMyPageGroup";
    List<Fragment> fragments;
    ArrayList<String> titles;

    public PagerAdapter(FragmentManager fm, List<Fragment> fragments, ArrayList<String> titles) {
        super(fm);
        this.fragments = fragments;
        this.titles = titles;
    }

    public CharSequence getPageTitle(int position) {
        return (CharSequence) this.titles.get(position);
    }

    public Fragment getItem(int pos) {
        return (Fragment) this.fragments.get(pos);
    }

    public int getCount() {
        return this.fragments.size();
    }

    public void destroyItem(ViewGroup container, int position, Object object) {
        super.destroyItem(container, position, object);
    }

    public void setTitle(ArrayList<String> titles) {
        this.titles = titles;
    }

    public void setFragments(List<Fragment> fList) {
        this.fragments = fList;
    }

    public void removeMyPageFragments() {
        this.fragments.remove(0);
    }

    public void onPageScrollStateChanged(int arg0) {
    }

    public void onPageScrolled(int arg0, float arg1, int arg2) {
    }

    public void onPageSelected(int arg0) {
    }

    public void setViewPager(ViewPager view) {
    }

    public void setViewPager(ViewPager view, int initialPosition) {
    }

    public void setCurrentItem(int item) {
    }

    public void setOnPageChangeListener(OnPageChangeListener listener) {
    }

    public int getItemPosition(Object object) {
        return -2;
    }
}
