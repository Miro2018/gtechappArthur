package com.accumed.gtech.intro;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.accumed.gtech.C0213R;

public class AuthActivity extends Activity {

    class C03851 implements OnClickListener {
        C03851() {
        }

        public void onClick(View v) {
            AuthActivity.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0213R.layout.activity_auth);
        ((Button) findViewById(C0213R.id.btn_auth_confirm)).setOnClickListener(new C03851());
    }
}
