package com.accumed.gtech.intro;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.router.AppStatusRouterListener;
import com.accumed.gtech.thread.OnAddUserListener;
import com.accumed.gtech.thread.OnJoinEmailCheckListener;
import com.accumed.gtech.thread.ThrAddUser;
import com.accumed.gtech.thread.ThrJoinEmailCheck;
import com.accumed.gtech.thread.datamodel.AddUserReturnDM;
import com.accumed.gtech.thread.datamodel.AddUserThrDM;
import com.accumed.gtech.thread.datamodel.JoinEmailCheckReturnDM;
import com.accumed.gtech.thread.datamodel.JoinEmailCheckThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import java.util.Locale;

public class Join extends Activity implements OnClickListener, OnJoinEmailCheckListener, OnAddUserListener {
    boolean FLAG_ADD_USER = false;
    final String className = "Join";
    String email;
    ProgressBar joinProgressBar;
    LogCat logCat;
    int mAppStatus;
    private Button mBtnOk;
    Context mContext;
    private EditText mEditPassword;
    String password;

    class C03991 implements AppStatusRouterListener {
        C03991() {
        }

        public void onAppStatus(int appStatus) {
            Join.this.logCat.log("Join", "appStatus on", appStatus + "");
            Join.this.mAppStatus = appStatus;
        }
    }

    class C04002 implements Runnable {
        C04002() {
        }

        public void run() {
            Join.this.joinProgressBar.setVisibility(0);
        }
    }

    class C04013 implements Runnable {
        C04013() {
        }

        public void run() {
            new ShowAlert(Join.this).alert0("Action", "No action define ^__^", "confirm");
        }
    }

    class C04024 implements Runnable {
        C04024() {
        }

        public void run() {
            new ShowAlert(Join.this).alert0(Join.this.getString(C0213R.string.alert_text_title), Join.this.getString(C0213R.string.alert_join_response_exist), Join.this.getString(C0213R.string.alert_text_confirm));
        }
    }

    class C04035 implements Runnable {
        C04035() {
        }

        public void run() {
            new ShowAlert(Join.this).alert0(Join.this.getString(C0213R.string.alert_text_title), Join.this.getString(C0213R.string.message_text42), Join.this.getString(C0213R.string.alert_text_confirm));
        }
    }

    class C04046 implements Runnable {
        C04046() {
        }

        public void run() {
            new ShowAlert(Join.this).alert0(Join.this.getString(C0213R.string.alert_text_title), Join.this.getString(C0213R.string.message_text41), Join.this.getString(C0213R.string.alert_text_confirm));
        }
    }

    class C04057 implements Runnable {
        C04057() {
        }

        public void run() {
            Join.this.joinProgressBar.setVisibility(8);
        }
    }

    class C04078 implements Runnable {

        class C04061 implements DialogInterface.OnClickListener {
            C04061() {
            }

            public void onClick(DialogInterface arg0, int arg1) {
                Join.this.setResult(-1);
                Join.this.finish();
            }
        }

        C04078() {
        }

        public void run() {
            new Builder(Join.this).setTitle(Join.this.getString(C0213R.string.alert_text_title)).setMessage(Join.this.getString(C0213R.string.alert_join_response_success)).setPositiveButton(Join.this.getString(C0213R.string.alert_text_confirm), new C04061()).show();
        }
    }

    class C04089 implements Runnable {
        C04089() {
        }

        public void run() {
            new ShowAlert(Join.this).alert0(Join.this.getString(C0213R.string.alert_text_title), Join.this.getString(C0213R.string.alert_join_response_failed), Join.this.getString(C0213R.string.alert_text_confirm));
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.join);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        init();
    }

    private void init() {
        this.mBtnOk = (Button) findViewById(C0213R.id.join_btn_ok);
        this.mBtnOk.setOnClickListener(this);
        this.mEditPassword = (EditText) findViewById(C0213R.id.join_edit_password);
        this.joinProgressBar = (ProgressBar) findViewById(C0213R.id.joinProgressBar);
        this.joinProgressBar.setVisibility(8);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0213R.id.join_btn_ok:
                if (this.mEditPassword != null) {
                    ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.mEditPassword.getWindowToken(), 0);
                }
                this.email = getIntent().getStringExtra("email");
                this.password = getIntent().getStringExtra("password");
                if (validationCheck(this.email, this.password, this.mEditPassword.getText().toString().trim())) {
                    new AppStatusRouter(this.mContext).setOnStatusListener(new C03991());
                    actionDefine();
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void actionDefine() {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_x");
                emailCheck();
                return;
            case 1:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                emailCheck();
                return;
            case 5:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                emailCheck();
                return;
            case 10:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                emailCheck();
                return;
            case 14:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                emailCheck();
                return;
            case 17:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                emailCheck();
                return;
            case 21:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                emailCheck();
                return;
            case 26:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                emailCheck();
                return;
            case 30:
                this.logCat.log("Join", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                emailCheck();
                return;
            default:
                return;
        }
    }

    private void emailCheck() {
        JoinEmailCheckThrDM joinEmailCheckThrDM = new JoinEmailCheckThrDM();
        joinEmailCheckThrDM.email = this.email;
        new ThrJoinEmailCheck(getApplicationContext(), joinEmailCheckThrDM, this).start();
    }

    private void addUser() {
        if (!this.FLAG_ADD_USER) {
            this.FLAG_ADD_USER = true;
            this.joinProgressBar.post(new C04002());
            PreferenceAction prefProfile = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            PreferenceAction prefSetting = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
            AddUserThrDM dm = new AddUserThrDM();
            dm.MY_EMAIL = this.email;
            dm.MY_PASSWORD = this.password;
            dm.MY_NAME = prefProfile.getString(PreferenceAction.MY_NAME);
            dm.MY_BIRTH = prefProfile.getString(PreferenceAction.MY_BIRTH);
            dm.MY_GENDER = prefProfile.getString(PreferenceAction.MY_GENDER);
            dm.MY_HEIGHT = prefProfile.getString(PreferenceAction.MY_HEIGHT);
            dm.MY_HEIGHT_UNIT = prefProfile.getString(PreferenceAction.MY_HEIGHT_UNIT);
            dm.MY_WEIGHT = prefProfile.getString(PreferenceAction.MY_WEIGHT);
            dm.MY_WEIGHT_UNIT = prefProfile.getString(PreferenceAction.MY_WEIGHT_UNIT);
            dm.MY_OCCOURDAY = prefProfile.getString(PreferenceAction.MY_OCCOURDAY);
            dm.MY_BLOOD_SUGAR_TYPE = prefProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_TYPE);
            dm.MY_BLOOD_SUGAR_UNIT = prefProfile.getString(PreferenceAction.MY_BLOOD_SUGAR_UNIT);
            dm.MY_HIGH_BLOOD_SUGAR = prefProfile.getString(PreferenceAction.MY_HIGH_BLOOD_SUGAR);
            dm.MY_LOW_BLOOD_SUGAR = prefProfile.getString(PreferenceAction.MY_LOW_BLOOD_SUGAR);
            dm.MY_DATE_METHOD = prefSetting.getString(PreferenceAction.MY_DATE_METHOD);
            dm.MY_TIME_METHOD = prefSetting.getString(PreferenceAction.MY_TIME_METHOD);
            dm.MY_LANGUAGE = prefSetting.getString(PreferenceAction.MY_LANGUAGE);
            dm.MY_DATA_SAVE_PERIOD = prefSetting.getString(PreferenceAction.MY_DATA_SAVE_PERIOD);
            new ThrAddUser(getApplicationContext(), dm, this).start();
        }
    }

    private boolean validationCheck(String email, String password, String password_confirm) {
        if (email == null || email.trim().equals("")) {
            passwordAlert();
            return false;
        } else if (password == null || password.trim().equals("")) {
            passwordAlert();
            return false;
        } else if (password_confirm == null || password_confirm.trim().equals("")) {
            passwordAlert();
            return false;
        } else if (password.equals(password_confirm)) {
            return true;
        } else {
            passwordAlert();
            return false;
        }
    }

    private void passwordAlert() {
        new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.message_text38), getString(C0213R.string.alert_text_confirm));
    }

    private void actionAlert() {
        runOnUiThread(new C04013());
    }

    public void onJoinEmailCheckListener(Object obj) {
        this.logCat.log("Join", "onResult", "in");
        JoinEmailCheckReturnDM dm = (JoinEmailCheckReturnDM) obj;
        this.logCat.log("Join", "code", dm.statusResult);
        this.logCat.log("Join", "code", dm.code);
        this.logCat.log("Join", "code", dm.result);
        if (!dm.statusResult.equals("ok")) {
            runOnUiThread(new C04046());
        } else if (!dm.code.equals("200")) {
            runOnUiThread(new C04035());
        } else if (dm.result.equals("0")) {
            addUser();
        } else {
            runOnUiThread(new C04024());
        }
    }

    public void onAddUser(Object obj) {
        this.logCat.log("Join", "onAddUser", "in");
        this.joinProgressBar.post(new C04057());
        AddUserReturnDM dm = (AddUserReturnDM) obj;
        this.logCat.log("Join", "dm.statusResult", dm.statusResult);
        this.logCat.log("Join", "dm.code", dm.code);
        this.logCat.log("Join", "dm.result", dm.result);
        this.logCat.log("Join", "id", dm.id);
        if (!dm.statusResult.equals("ok")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(Join.this).alert0(Join.this.getString(C0213R.string.alert_text_title), Join.this.getString(C0213R.string.message_text41), Join.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        } else if (!dm.code.equals("200")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(Join.this).alert0(Join.this.getString(C0213R.string.alert_text_title), Join.this.getString(C0213R.string.message_text42), Join.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        } else if (dm.result.equals("0")) {
            PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            pref.putString(PreferenceAction.MY_EMAIL, this.email);
            pref.putString(PreferenceAction.MY_PASSWORD, this.password);
            pref.putString(PreferenceAction.MY_SERVER_ID, dm.id);
            runOnUiThread(new C04078());
        } else {
            runOnUiThread(new C04089());
        }
        this.FLAG_ADD_USER = false;
        this.logCat.log("Join", "onAddUser", this.FLAG_ADD_USER + "");
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
