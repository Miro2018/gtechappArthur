package com.accumed.gtech.intro;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.thread.OnChangePasswordListener;
import com.accumed.gtech.thread.ThrChangePassword;
import com.accumed.gtech.thread.datamodel.ChangePasswordThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;

public class ChangePassword extends Activity implements OnChangePasswordListener {
    ProgressBar changePasswordProgressBar;
    Button change_password_btn_ok;
    EditText change_password_edit0;
    EditText change_password_edit1;
    final String className = "ChangePassword";
    LogCat logCat = new LogCat();
    Context mContext;

    class C03891 implements OnClickListener {

        class C03861 implements Runnable {
            C03861() {
            }

            public void run() {
                ChangePassword.this.changePasswordProgressBar.setVisibility(0);
            }
        }

        class C03872 implements Runnable {
            C03872() {
            }

            public void run() {
                ChangePassword.this.changePasswordProgressBar.setVisibility(8);
            }
        }

        class C03883 implements Runnable {
            C03883() {
            }

            public void run() {
                ChangePassword.this.changePasswordProgressBar.setVisibility(8);
            }
        }

        C03891() {
        }

        public void onClick(View v) {
            ChangePassword.this.runOnUiThread(new C03861());
            if (ChangePassword.this.change_password_edit0.getText().toString().trim().equals("") || ChangePassword.this.change_password_edit1.getText().toString().trim().equals("")) {
                new ShowAlert(ChangePassword.this).alert0(ChangePassword.this.getString(C0213R.string.alert_text_title), ChangePassword.this.getString(C0213R.string.alert_login_empty_password), ChangePassword.this.getString(C0213R.string.alert_text_confirm));
                ChangePassword.this.runOnUiThread(new C03872());
                ChangePassword.this.change_password_edit0.setText(null);
                ChangePassword.this.change_password_edit1.setText(null);
                ChangePassword.this.hidePad();
                return;
            }
            PreferenceAction pref = new PreferenceAction(ChangePassword.this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            if (ChangePassword.this.change_password_edit0.getText().toString().trim().equals(pref.getString(PreferenceAction.MY_PASSWORD))) {
                ChangePassword.this.hidePad();
                ChangePasswordThrDM dm = new ChangePasswordThrDM();
                dm.email = pref.getString(PreferenceAction.MY_EMAIL);
                dm.password = ChangePassword.this.change_password_edit0.getText().toString().trim();
                dm.newpassword = ChangePassword.this.change_password_edit1.getText().toString().trim();
                new ThrChangePassword(ChangePassword.this.mContext, dm, ChangePassword.this).start();
                return;
            }
            new ShowAlert(ChangePassword.this).alert0(ChangePassword.this.getString(C0213R.string.alert_text_title), ChangePassword.this.getString(C0213R.string.message_text12), ChangePassword.this.getString(C0213R.string.alert_text_confirm));
            ChangePassword.this.runOnUiThread(new C03883());
            ChangePassword.this.change_password_edit0.setText(null);
            ChangePassword.this.change_password_edit1.setText(null);
            ChangePassword.this.hidePad();
        }
    }

    class C03902 implements Runnable {
        C03902() {
        }

        public void run() {
            ChangePassword.this.changePasswordProgressBar.setVisibility(8);
        }
    }

    class C03913 implements Runnable {
        C03913() {
        }

        public void run() {
            Toast toast = new Toast(ChangePassword.this);
            Toast.makeText(ChangePassword.this, ChangePassword.this.getString(C0213R.string.message_text14), 0).show();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.change_password);
        this.mContext = getApplicationContext();
        this.change_password_edit0 = (EditText) findViewById(C0213R.id.change_password_edit0);
        this.change_password_edit1 = (EditText) findViewById(C0213R.id.change_password_edit1);
        this.change_password_btn_ok = (Button) findViewById(C0213R.id.change_password_btn_ok);
        this.changePasswordProgressBar = (ProgressBar) findViewById(C0213R.id.changePasswordProgressBar);
        this.change_password_btn_ok.setOnClickListener(new C03891());
    }

    void hidePad() {
        ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(this.change_password_edit0.getWindowToken(), 0);
    }

    public void OnChangePassword(Object obj) {
        if (obj == null) {
            runOnUiThread(new C03902());
            runOnUiThread(new C03913());
            new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE).putString(PreferenceAction.MY_PASSWORD, this.change_password_edit1.getText().toString().trim());
            finish();
        }
    }
}
