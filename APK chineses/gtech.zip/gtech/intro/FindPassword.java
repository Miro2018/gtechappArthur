package com.accumed.gtech.intro;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.thread.OnFindPasswordListener;
import com.accumed.gtech.thread.ThrFindPassword;
import com.accumed.gtech.thread.datamodel.FindPasswordReturnDM;
import com.accumed.gtech.thread.datamodel.FindPasswordThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.ShowAlert;

public class FindPassword extends Activity implements OnFindPasswordListener {
    final String className = "FindPassword";
    ProgressBar findPasswordProgressBar;
    Button find_password_btn_ok;
    EditText find_password_edit_password;
    LogCat logCat = new LogCat();
    Context mContext;

    class C03931 implements OnClickListener {

        class C03921 implements Runnable {
            C03921() {
            }

            public void run() {
                new ShowAlert(FindPassword.this).alert0(FindPassword.this.getString(C0213R.string.alert_text_title), FindPassword.this.getString(C0213R.string.message_text04), FindPassword.this.getString(C0213R.string.alert_text_confirm));
            }
        }

        C03931() {
        }

        public void onClick(View v) {
            if (FindPassword.this.find_password_edit_password.getText().toString().trim().equals("")) {
                FindPassword.this.runOnUiThread(new C03921());
                return;
            }
            FindPasswordThrDM dm = new FindPasswordThrDM();
            dm.email = FindPassword.this.find_password_edit_password.getText().toString().trim();
            new ThrFindPassword(FindPassword.this.mContext, dm, FindPassword.this, ClassConstant.SUBDIR_FIND_PASSWORD).start();
            FindPassword.this.findPasswordProgressBar.setVisibility(0);
        }
    }

    class C03962 implements Runnable {

        class C03951 implements Runnable {

            class C03941 implements DialogInterface.OnClickListener {
                C03941() {
                }

                public void onClick(DialogInterface arg0, int arg1) {
                    FindPassword.this.finish();
                }
            }

            C03951() {
            }

            public void run() {
                new Builder(FindPassword.this).setTitle(FindPassword.this.getString(C0213R.string.alert_text_title)).setMessage(FindPassword.this.getString(C0213R.string.send_password_sended_text)).setPositiveButton(FindPassword.this.getString(C0213R.string.alert_text_confirm), new C03941()).show();
            }
        }

        C03962() {
        }

        public void run() {
            FindPassword.this.runOnUiThread(new C03951());
        }
    }

    class C03973 implements Runnable {
        C03973() {
        }

        public void run() {
            new ShowAlert(FindPassword.this).alert0(FindPassword.this.getString(C0213R.string.alert_text_title), FindPassword.this.getString(C0213R.string.send_password_sended_failed_text), FindPassword.this.getString(C0213R.string.alert_text_confirm));
        }
    }

    class C03984 implements Runnable {
        C03984() {
        }

        public void run() {
            FindPassword.this.findPasswordProgressBar.setVisibility(8);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.find_passwod);
        this.mContext = getApplicationContext();
        this.find_password_edit_password = (EditText) findViewById(C0213R.id.change_password_edit0);
        this.find_password_btn_ok = (Button) findViewById(C0213R.id.change_password_btn_ok);
        this.findPasswordProgressBar = (ProgressBar) findViewById(C0213R.id.changePasswordProgressBar);
        this.find_password_btn_ok.setOnClickListener(new C03931());
    }

    public void onFindPassword(Object obj) {
        FindPasswordReturnDM dm = (FindPasswordReturnDM) obj;
        if (!dm.statusResult.equals("ok")) {
            runOnUiThread(new C03973());
        } else if (!dm.code.equals("200")) {
            new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.send_password_sended_failed_text), getString(C0213R.string.alert_text_confirm));
        } else if (dm.result.equals("0")) {
            runOnUiThread(new C03962());
        } else {
            new ShowAlert(this).alert0(getString(C0213R.string.alert_text_title), getString(C0213R.string.send_password_sended_failed_text), getString(C0213R.string.alert_text_confirm));
        }
        runOnUiThread(new C03984());
    }
}
