package com.accumed.gtech.intro;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.ClassConstant;
import com.accumed.gtech.ContainerFragmentActivity;
import com.accumed.gtech.gcm.GCMManager;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.OnLoginListener;
import com.accumed.gtech.thread.SyncProfileDevice;
import com.accumed.gtech.thread.ThrLogin;
import com.accumed.gtech.thread.datamodel.LoginReturnDM;
import com.accumed.gtech.thread.datamodel.LoginThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.google.android.gcm.GCMRegistrar;
import java.util.Locale;

public class SplashRoute extends Activity implements OnLoginListener {
    private static final String className = "SplashRoute";
    int GCM_REGISTER = 0;
    int SPLASH_STAY = 900;
    ContainerFragmentActivity containerFragmentActivity;
    Thread delayT = new C04232();
    Handler finishH = new C04221();
    LogCat logCat;
    private int mAppStatus;
    Context mContext;
    private PreferenceAction prefFirstDialog;
    private PreferenceAction prefLocationCheck;
    private PreferenceAction prefServerCheck;
    String regId = "";

    class C04221 extends Handler {
        C04221() {
        }

        public void handleMessage(Message msg) {
            if (msg.what == 0) {
                SplashRoute.this.finish();
            }
        }
    }

    class C04232 extends Thread {
        C04232() {
        }

        public void run() {
            try {
                Thread.sleep((long) SplashRoute.this.SPLASH_STAY);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message msg = Message.obtain();
            msg.what = 0;
            SplashRoute.this.finishH.sendMessage(msg);
        }
    }

    class C04243 implements OnCancelListener {
        C04243() {
        }

        public void onCancel(DialogInterface dialog) {
            SplashRoute.this.prefServerCheck.putInt(PreferenceAction.PREF_SELECT_SERVER, 3);
            SplashRoute.this.setResult(-1);
            SplashRoute.this.finish();
            dialog.cancel();
        }
    }

    class C04254 implements OnClickListener {
        C04254() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            SplashRoute.this.prefServerCheck.putInt(PreferenceAction.PREF_SELECT_SERVER, 3);
            SplashRoute.this.setResult(-1);
            SplashRoute.this.finish();
            dialog.cancel();
        }
    }

    class C04265 implements OnClickListener {
        C04265() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            SplashRoute.this.SelectServerDialog(SplashRoute.this.prefLocationCheck.getInt(PreferenceAction.PREF_SELECT_LOCATION), SplashRoute.this.prefServerCheck.getInt(PreferenceAction.PREF_SELECT_SERVER));
        }
    }

    class C04276 implements OnClickListener {
        C04276() {
        }

        public void onClick(DialogInterface dialog, int whichButton) {
            SplashRoute.this.prefLocationCheck.putInt(PreferenceAction.PREF_SELECT_LOCATION, whichButton);
            if (whichButton == 1 || whichButton == 2) {
                SplashRoute.this.prefServerCheck.putInt(PreferenceAction.PREF_SELECT_SERVER, 0);
            } else if (whichButton == 0 || whichButton == 3) {
                SplashRoute.this.prefServerCheck.putInt(PreferenceAction.PREF_SELECT_SERVER, 1);
            } else {
                SplashRoute.this.prefServerCheck.putInt(PreferenceAction.PREF_SELECT_SERVER, 2);
            }
        }
    }

    class C04287 implements OnCancelListener {
        C04287() {
        }

        public void onCancel(DialogInterface dialog) {
            SplashRoute.this.prefServerCheck.putInt(PreferenceAction.PREF_SELECT_SERVER, 3);
            SplashRoute.this.setResult(-1);
            SplashRoute.this.setResult(-1);
            SplashRoute.this.finish();
            dialog.cancel();
        }
    }

    class C04298 implements OnClickListener {
        C04298() {
        }

        public void onClick(DialogInterface dialog, int id) {
            SplashRoute.this.prefServerCheck.putInt(PreferenceAction.PREF_SELECT_SERVER, 3);
            SplashRoute.this.setResult(-1);
            SplashRoute.this.setResult(-1);
            SplashRoute.this.finish();
            dialog.cancel();
        }
    }

    class C04309 implements OnClickListener {
        C04309() {
        }

        public void onClick(DialogInterface dialog, int id) {
            SplashRoute.this.prefServerCheck = new PreferenceAction(SplashRoute.this.mContext, PreferenceAction.PREF_SELECT_SERVER);
            SplashRoute.this.prefServerCheck.putInt(PreferenceAction.PREF_SELECT_SERVER, 3);
            SplashRoute.this.DialogSelectOption();
        }
    }

    public void onResume() {
        super.onResume();
        this.logCat.log(className, "SplashRoute onResume", "in");
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.splash);
        this.mContext = getApplicationContext();
        localeEvent();
        this.logCat = new LogCat();
        this.logCat.log(className, "SplashRoute onCreate", "in");
        this.prefFirstDialog = new PreferenceAction(this.mContext, PreferenceAction.PREF_DATA_POPUP_FIRST);
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
        UseNetworkDialog();
    }

    private void DialogSelectOption() {
        this.prefLocationCheck = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_LOCATION);
        this.prefServerCheck = new PreferenceAction(this.mContext, PreferenceAction.PREF_SELECT_SERVER);
        if (this.prefServerCheck.getIntDefaultNum(PreferenceAction.PREF_SELECT_SERVER) == 3) {
            Builder ab = new Builder(this);
            ab.setTitle(C0213R.string.select_location);
            ab.setSingleChoiceItems(getResources().getStringArray(C0213R.array.array_location_select), -1, new C04276()).setPositiveButton(C0213R.string.btn_ok, new C04265()).setNegativeButton(C0213R.string.btn_cancel, new C04254()).setOnCancelListener(new C04243());
            ab.show();
            return;
        }
        UseNetworkDialog();
    }

    private void SelectServerDialog(int location, int server) {
        View selectServerLayout = LayoutInflater.from(this).inflate(C0213R.layout.select_server_dialog, null);
        TextView warnning = (TextView) selectServerLayout.findViewById(C0213R.id.tv_select_server);
        int firstString = getResources().getString(C0213R.string.select_server_body1).length() + 1;
        int secondString = ((getResources().getString(C0213R.string.select_server_body1).length() + getResources().getStringArray(C0213R.array.array_location_select)[location].length()) + getResources().getString(C0213R.string.select_server_body2).length()) + 3;
        SpannableStringBuilder mSpannableStringBuilder = new SpannableStringBuilder(getResources().getString(C0213R.string.select_server_body1) + " " + getResources().getStringArray(C0213R.array.array_location_select)[location] + " " + getResources().getString(C0213R.string.select_server_body2) + " " + getResources().getStringArray(C0213R.array.array_server_select)[server] + "" + getResources().getString(C0213R.string.select_server_body3));
        mSpannableStringBuilder.setSpan(new ForegroundColorSpan(-16711681), firstString, getResources().getStringArray(C0213R.array.array_location_select)[location].length() + firstString, 33);
        mSpannableStringBuilder.setSpan(new ForegroundColorSpan(-16711681), secondString, getResources().getStringArray(C0213R.array.array_server_select)[server].length() + secondString, 33);
        warnning.append(mSpannableStringBuilder);
        Builder alt_bld = new Builder(this);
        alt_bld.setView(selectServerLayout).setPositiveButton(C0213R.string.btn_ok, new OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                SplashRoute.this.UseNetworkDialog();
            }
        }).setNeutralButton(C0213R.string.btn_reslect, new C04309()).setNegativeButton(C0213R.string.btn_cancel, new C04298()).setOnCancelListener(new C04287());
        AlertDialog alert = alt_bld.create();
        alert.setTitle(C0213R.string.use_network_title);
        alert.setIcon(C0213R.drawable.ic_launcher);
        alert.show();
    }

    private void UseNetworkDialog() {
        View notshowagainLayout = LayoutInflater.from(this).inflate(C0213R.layout.use_network_dialog, null);
        final CheckBox dontShowAgain = (CheckBox) notshowagainLayout.findViewById(C0213R.id.skip);
        PreferenceAction prefCheck = new PreferenceAction(this.mContext, PreferenceAction.PREF_DATA_POPUP_CHECK);
        dontShowAgain.setPadding(dontShowAgain.getPaddingLeft() + ((int) ((10.0f * getResources().getDisplayMetrics().density) + ClassConstant.INPUT_GLUCOSE_MMOL_MIN)), dontShowAgain.getPaddingTop(), dontShowAgain.getPaddingRight(), dontShowAgain.getPaddingBottom());
        dontShowAgain.setChecked(prefCheck.getBoolean(PreferenceAction.PREF_DATA_POPUP_CHECK));
        prefCheck.putBoolean(PreferenceAction.PREF_DATA_POPUP_CHECK, dontShowAgain.isChecked());
        if (prefCheck.getBoolean(PreferenceAction.PREF_DATA_POPUP_CHECK) || this.prefFirstDialog.getBoolean(PreferenceAction.PREF_DATA_POPUP_FIRST)) {
            this.prefFirstDialog.putBoolean(PreferenceAction.PREF_DATA_POPUP_FIRST, false);
            this.delayT.start();
            actionDefine(this.GCM_REGISTER);
            return;
        }
        Builder alt_bld = new Builder(this);
        alt_bld.setView(notshowagainLayout).setPositiveButton(C0213R.string.btn_yes, new OnClickListener() {

            class C04211 extends Thread {
                C04211() {
                }

                public void run() {
                    try {
                        Thread.sleep((long) SplashRoute.this.SPLASH_STAY);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Message msg = Message.obtain();
                    msg.what = 0;
                    SplashRoute.this.finishH.sendMessage(msg);
                }
            }

            public void onClick(DialogInterface dialog, int id) {
                new PreferenceAction(SplashRoute.this.mContext, PreferenceAction.PREF_DATA_POPUP_CHECK).putBoolean(PreferenceAction.PREF_DATA_POPUP_CHECK, dontShowAgain.isChecked());
                new PreferenceAction(SplashRoute.this.mContext, PreferenceAction.PREF_NAME_SYNC_SWITCH).putString(PreferenceAction.SYNC_SWITCH, "yes");
                try {
                    SplashRoute.this.delayT.start();
                } catch (Exception e) {
                    SplashRoute.this.delayT = null;
                    new C04211().start();
                }
                SplashRoute.this.actionDefine(SplashRoute.this.GCM_REGISTER);
            }
        }).setNegativeButton(C0213R.string.btn_no, new OnClickListener() {

            class C04201 extends Thread {
                C04201() {
                }

                public void run() {
                    try {
                        Thread.sleep((long) SplashRoute.this.SPLASH_STAY);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Message msg = Message.obtain();
                    msg.what = 0;
                    SplashRoute.this.finishH.sendMessage(msg);
                }
            }

            public void onClick(DialogInterface dialog, int id) {
                new PreferenceAction(SplashRoute.this.mContext, PreferenceAction.PREF_NAME_SYNC_SWITCH).putString(PreferenceAction.SYNC_SWITCH, "no");
                try {
                    SplashRoute.this.delayT.start();
                } catch (Exception e) {
                    SplashRoute.this.delayT = null;
                    new C04201().start();
                }
                SplashRoute.this.actionDefine(SplashRoute.this.GCM_REGISTER);
            }
        }).setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialog) {
                SplashRoute.this.prefFirstDialog.putBoolean(PreferenceAction.PREF_DATA_POPUP_FIRST, false);
                SplashRoute.this.setResult(-1);
                SplashRoute.this.finish();
                dialog.cancel();
            }
        });
        AlertDialog alert = alt_bld.create();
        alert.setTitle(C0213R.string.use_network_title);
        alert.setIcon(C0213R.drawable.ic_launcher);
        alert.show();
    }

    void registerGCM() {
        try {
            GCMRegistrar.checkDevice(this);
            GCMRegistrar.checkManifest(this);
            this.regId = "";
            this.regId = GCMRegistrar.getRegistrationId(this);
            this.logCat.log(className, "regId", this.regId);
            if ("".equals(this.regId)) {
                GCMRegistrar.register(this, GCMManager.PROJECT_ID);
                return;
            }
            this.logCat.log(className, "==============", this.regId);
            new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_GCM).putString(PreferenceAction.GCM_REGISTRED_ID, this.regId);
        } catch (Exception e) {
        }
    }

    void delay() {
        try {
            Thread.sleep((long) this.SPLASH_STAY);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void login() {
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        LoginThrDM loginThrDM = new LoginThrDM();
        loginThrDM.email = pref.getString(PreferenceAction.MY_EMAIL);
        loginThrDM.password = pref.getString(PreferenceAction.MY_PASSWORD);
        loginThrDM.registration_id = this.regId;
        loginThrDM.registration_device = "android";
        new ThrLogin(getApplicationContext(), loginThrDM, this).start();
    }

    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
    }

    private void actionDefine(int gubun) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                }
                setResult(7);
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                    return;
                }
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                }
                try {
                    this.delayT.start();
                    return;
                } catch (Exception e) {
                    this.delayT = null;
                    new Thread() {
                        public void run() {
                            try {
                                Thread.sleep((long) SplashRoute.this.SPLASH_STAY);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            Message msg = Message.obtain();
                            msg.what = 0;
                            SplashRoute.this.finishH.sendMessage(msg);
                        }
                    }.start();
                    return;
                }
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                    return;
                }
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                    return;
                }
                return;
            case 17:
                this.logCat.log(className, "actionDefine()---", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                    login();
                }
                if (!new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_SYNC_SWITCH).getString(PreferenceAction.SYNC_SWITCH).equals("no")) {
                    setResult(9);
                    return;
                }
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                    login();
                }
                startActivity(new Intent(this, Login.class));
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                    login();
                    return;
                }
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == this.GCM_REGISTER) {
                    registerGCM();
                    login();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public boolean onKeyDown(int KeyCode, KeyEvent event) {
        if (event.getAction() != 0 || KeyCode != 4) {
            return super.onKeyDown(KeyCode, event);
        }
        setResult(-1);
        return false;
    }

    public void onLogin(Object obj) {
        LoginReturnDM loginReturnDM = (LoginReturnDM) obj;
        if (loginReturnDM.statusResult.equals("ok") && loginReturnDM.code.equals("200") && loginReturnDM.result.equals("0")) {
            new SyncProfileDevice(this.mContext, null).start();
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
