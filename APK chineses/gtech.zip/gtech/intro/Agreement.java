package com.accumed.gtech.intro;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.router.AppStatusRouterListener;
import com.accumed.gtech.util.LanguageChange;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ReadTextFile;
import java.util.Locale;

public class Agreement extends Activity {
    static final String className = "Agreement";
    Button agreeBtn;
    LogCat logCat = new LogCat();
    int mAppStatus;
    Context mContext;
    TextView provisionTv;

    class C03771 implements OnClickListener {
        C03771() {
        }

        public void onClick(View arg0) {
            AppStatusRouter appStatusRouter = new AppStatusRouter(Agreement.this.mContext);
            Agreement.this.mAppStatus = appStatusRouter.getAppStatus();
            Agreement.this.actionDefine();
            new PreferenceAction(Agreement.this.mContext, PreferenceAction.PREF_DATA_POPUP_FIRST).putBoolean(PreferenceAction.PREF_DATA_POPUP_FIRST, true);
        }
    }

    class C03792 implements DialogInterface.OnClickListener {

        class C03781 implements AppStatusRouterListener {
            C03781() {
            }

            public void onAppStatus(int appStatus) {
                Agreement.this.logCat.log(Agreement.className, "appStatus on", appStatus + "");
                Agreement.this.mAppStatus = appStatus;
            }
        }

        C03792() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            new AppStatusRouter(Agreement.this.mContext).setOnStatusListener(new C03781());
            Agreement.this.actionDefine();
        }
    }

    class C03803 implements DialogInterface.OnClickListener {
        C03803() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Intent intent = new Intent();
            intent.setData(Uri.parse("market://details?id=com.sdbio"));
            Agreement.this.startActivity(intent);
        }
    }

    class C03814 implements DialogInterface.OnClickListener {
        C03814() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
        }
    }

    class C03825 implements DialogInterface.OnClickListener {
        C03825() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Intent intent = new Intent();
            intent.setData(Uri.parse("market://details?id=com.sdbio"));
            Agreement.this.startActivity(intent);
        }
    }

    class C03836 implements DialogInterface.OnClickListener {
        C03836() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
            Agreement.this.setResult(-1);
            Agreement.this.finish();
        }
    }

    class C03847 implements DialogInterface.OnClickListener {
        C03847() {
        }

        public void onClick(DialogInterface arg0, int arg1) {
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0213R.layout.agreement);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.provisionTv = (TextView) findViewById(C0213R.id.provision_tv_content);
        this.agreeBtn = (Button) findViewById(C0213R.id.provision_btn_agree);
        LanguageChange langChange = new LanguageChange(this.mContext);
        String prefLang = langChange.getPrefLanguage();
        String systemLang = langChange.getSystemLanguage();
        if (prefLang.equals("") || prefLang == null) {
            startActivity(new Intent(this, AuthActivity.class));
        } else {
            langChange.putLanguage(systemLang);
            new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING).putString(PreferenceAction.MY_LANGUAGE, systemLang);
        }
        this.logCat.log(className, "systemLang", systemLang);
        if (systemLang.endsWith("ko")) {
            this.provisionTv.setText(Html.fromHtml(ReadTextFile.readText(this.mContext, "ko/agreement")));
        } else if (systemLang.endsWith("zh")) {
            this.provisionTv.setText(Html.fromHtml(ReadTextFile.readText(this.mContext, "zh/agreement")));
        } else {
            this.provisionTv.setText(Html.fromHtml(ReadTextFile.readText(this.mContext, "en/agreement")));
        }
        this.agreeBtn.setOnClickListener(new C03771());
    }

    private void sorry() {
        new Builder(this).setTitle(getString(C0213R.string.sorry_reinstall_title)).setMessage(getString(C0213R.string.sorry_reinstall_content)).setNegativeButton(getString(C0213R.string.sorry_reinstall_btn_del), new C03803()).setPositiveButton(getString(C0213R.string.sorry_reinstall_btn_ing), new C03792()).show();
    }

    private void sorry1() {
        new Builder(this).setTitle(getString(C0213R.string.sorry_reinstall_title)).setMessage(getString(C0213R.string.sorry_reinstall_content)).setNegativeButton(getString(C0213R.string.sorry_reinstall_btn_del), new C03825()).setPositiveButton(getString(C0213R.string.sorry_reinstall_btn_ing), new C03814()).show();
    }

    private void actionDefine() {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_AGREEMENT).putString(PreferenceAction.IS_AGREEMENT, "yes");
                setResult(8);
                finish();
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                return;
            default:
                return;
        }
    }

    private void actionAlert() {
    }

    public void onBackPressed() {
        this.logCat.log(className, "onBackPressed", "in");
        new Builder(this).setTitle(getString(C0213R.string.alert_text_title)).setMessage(getString(C0213R.string.alert_text_finish)).setNegativeButton(getString(C0213R.string.alert_text_cancel), new C03847()).setPositiveButton(getString(C0213R.string.alert_text_confirm), new C03836()).show();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
