package com.accumed.gtech.intro;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import com.accumed.gtech.C0213R;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.router.AppStatusRouterListener;
import com.accumed.gtech.thread.OnLoginListener;
import com.accumed.gtech.thread.SyncProfileDevice;
import com.accumed.gtech.thread.ThrLogin;
import com.accumed.gtech.thread.datamodel.LoginReturnDM;
import com.accumed.gtech.thread.datamodel.LoginThrDM;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import com.accumed.gtech.util.ShowAlert;
import com.google.android.gcm.GCMConstants;
import java.util.Locale;

public class Login extends Activity implements OnLoginListener {
    public static final int CON_FAILED = 5;
    public static final int GUBUN_JOINBTN = 0;
    public static final int GUBUN_LATERBTN = 2;
    public static final int GUBUN_LOGINBTN = 1;
    public static final int JOIN = 6;
    public static final int JSON_FAILED = 4;
    public static final int LOGIN_FAILED = 3;
    static final String className = "Login";
    String email;
    Button joinBtn;
    LogCat logCat;
    Button loginBtnLater;
    LinearLayout loginLy0;
    ProgressBar loginProgressBar;
    Button login_btn_find_password;
    Button login_btn_login;
    Button login_btn_prev;
    EditText login_edit_id;
    EditText login_edit_password;
    int mAppStatus;
    Context mContext;
    String password;
    String registration_id;

    class C04091 implements OnClickListener {
        C04091() {
        }

        public void onClick(View arg0) {
            Login.this.finish();
        }
    }

    class C04102 implements OnTouchListener {
        C04102() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            ((InputMethodManager) Login.this.getSystemService("input_method")).hideSoftInputFromWindow(Login.this.login_edit_id.getWindowToken(), 0);
            return false;
        }
    }

    class C04123 implements OnClickListener {

        class C04111 implements AppStatusRouterListener {
            C04111() {
            }

            public void onAppStatus(int appStatus) {
                Login.this.logCat.log(Login.className, "appStatus login", appStatus + "");
                Login.this.mAppStatus = appStatus;
                PreferenceAction pref = new PreferenceAction(Login.this.mContext, PreferenceAction.PREF_NAME_GCM);
                Login.this.registration_id = pref.getString(PreferenceAction.GCM_REGISTRED_ID);
                Login.this.email = Login.this.login_edit_id.getText().toString();
                Login.this.password = Login.this.login_edit_password.getText().toString();
                Login.this.logCat.log(Login.className, GCMConstants.EXTRA_REGISTRATION_ID, Login.this.registration_id);
                Login.this.actionDefine(1);
            }
        }

        C04123() {
        }

        public void onClick(View arg0) {
            if (Login.this.vaildationCheck()) {
                new AppStatusRouter(Login.this.mContext).setOnStatusListener(new C04111());
            }
        }
    }

    class C04134 implements OnClickListener {
        C04134() {
        }

        public void onClick(View v) {
            if (Login.this.vaildationCheck()) {
                Intent intent = new Intent(Login.this.mContext, Join.class);
                intent.putExtra("password", Login.this.password);
                intent.putExtra("email", Login.this.email);
                Login.this.startActivityForResult(intent, 6);
            }
        }
    }

    class C04155 implements OnClickListener {

        class C04141 implements AppStatusRouterListener {
            C04141() {
            }

            public void onAppStatus(int appStatus) {
                Login.this.logCat.log(Login.className, "appStatus on", appStatus + "");
                Login.this.mAppStatus = appStatus;
                Login.this.actionDefine(2);
            }
        }

        C04155() {
        }

        public void onClick(View arg0) {
            new AppStatusRouter(Login.this.mContext).setOnStatusListener(new C04141());
        }
    }

    class C04166 implements OnClickListener {
        C04166() {
        }

        public void onClick(View v) {
            Login.this.startActivity(new Intent(Login.this.mContext, FindPassword.class));
        }
    }

    class C04177 implements Runnable {
        C04177() {
        }

        public void run() {
            Login.this.loginProgressBar.setVisibility(8);
        }
    }

    class C04188 implements Runnable {
        C04188() {
        }

        public void run() {
            new ShowAlert(Login.this).alert0(Login.this.getString(C0213R.string.alert_text_title), Login.this.getString(C0213R.string.message_text36), Login.this.getString(C0213R.string.alert_text_confirm));
        }
    }

    class C04199 implements Runnable {
        C04199() {
        }

        public void run() {
            new ShowAlert(Login.this).alert0(Login.this.getString(C0213R.string.alert_text_title), Login.this.getString(C0213R.string.message_text42), Login.this.getString(C0213R.string.alert_text_confirm));
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == 6 && resultCode == -1) {
            setResult(11);
            actionDefine(1);
            finish();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.login_back);
        this.mContext = getApplicationContext();
        this.logCat = new LogCat();
        this.loginLy0 = (LinearLayout) findViewById(C0213R.id.loginLy0);
        this.joinBtn = (Button) findViewById(C0213R.id.login_btn_join);
        this.loginBtnLater = (Button) findViewById(C0213R.id.login_btn_later);
        this.login_btn_login = (Button) findViewById(C0213R.id.login_btn_login);
        this.login_btn_prev = (Button) findViewById(C0213R.id.login_btn_prev);
        this.login_edit_id = (EditText) findViewById(C0213R.id.login_edit_id);
        this.login_edit_password = (EditText) findViewById(C0213R.id.login_edit_password);
        this.loginProgressBar = (ProgressBar) findViewById(C0213R.id.loginProgressBar);
        this.loginProgressBar.setVisibility(8);
        this.login_btn_find_password = (Button) findViewById(C0213R.id.login_btn_find_password);
        this.login_btn_prev.setOnClickListener(new C04091());
        this.loginLy0.setOnTouchListener(new C04102());
        this.login_btn_login.setOnClickListener(new C04123());
        this.joinBtn.setOnClickListener(new C04134());
        this.loginBtnLater.setOnClickListener(new C04155());
        this.login_btn_find_password.setOnClickListener(new C04166());
        PreferenceAction pref = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
        if (pref.getString(PreferenceAction.MY_EMAIL) != null && !pref.getString(PreferenceAction.MY_EMAIL).equals("")) {
            this.login_edit_id.setText(pref.getString(PreferenceAction.MY_EMAIL));
            this.login_edit_id.setKeyListener(null);
            this.login_edit_id.setTextColor(-7829368);
        }
    }

    private void actionDefine(int gubun) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_x");
                action(gubun);
                return;
            case 1:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                action(gubun);
                return;
            case 5:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                action(gubun);
                return;
            case 10:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                action(gubun);
                return;
            case 14:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                action(gubun);
                return;
            case 17:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                action(gubun);
                return;
            case 21:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                action(gubun);
                return;
            case 26:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                action(gubun);
                return;
            case 30:
                this.logCat.log(className, "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                action(gubun);
                return;
            default:
                return;
        }
    }

    private void action(int gubun) {
        if (gubun == 2) {
            finish();
        }
        if (gubun == 1) {
            this.logCat.log(className, "GUBUN_LOGINBTN", "in");
            login();
        }
        if (gubun == 0) {
            finish();
        }
    }

    private void login() {
        this.loginProgressBar.setVisibility(0);
        LoginThrDM loginThrDM = new LoginThrDM();
        loginThrDM.email = this.email;
        loginThrDM.password = this.password;
        loginThrDM.registration_id = this.registration_id;
        loginThrDM.registration_device = "android";
        new ThrLogin(getApplicationContext(), loginThrDM, this).start();
    }

    private boolean vaildationCheck() {
        ShowAlert showAlert = new ShowAlert(this);
        this.email = this.login_edit_id.getText().toString();
        this.password = this.login_edit_password.getText().toString();
        if (this.email == null || this.email.trim().equals("")) {
            showAlert.alert0(getString(C0213R.string.alert_title), getString(C0213R.string.message_text04), getString(C0213R.string.alert_text_confirm));
            return false;
        } else if (this.email != null && this.email.trim().indexOf("@") == -1) {
            showAlert.alert0(getString(C0213R.string.alert_title), getString(C0213R.string.message_text37), getString(C0213R.string.alert_text_confirm));
            return false;
        } else if (this.password != null && !this.password.trim().equals("")) {
            return true;
        } else {
            showAlert.alert0(getString(C0213R.string.alert_title), getString(C0213R.string.message_text39), getString(C0213R.string.alert_text_confirm));
            return false;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void onLogin(Object obj) {
        this.logCat.log(className, "onLogin", "in");
        this.loginProgressBar.post(new C04177());
        LoginReturnDM dm = (LoginReturnDM) obj;
        this.logCat.log(className, "loginReturnDM", dm.code);
        this.logCat.log(className, "loginReturnDM", dm.result);
        this.logCat.log(className, "loginReturnDM", dm.statusResult);
        if (!dm.statusResult.equals("ok")) {
            runOnUiThread(new Runnable() {
                public void run() {
                    new ShowAlert(Login.this).alert0(Login.this.getString(C0213R.string.alert_text_title), Login.this.getString(C0213R.string.message_text41), Login.this.getString(C0213R.string.alert_text_confirm));
                }
            });
        } else if (!dm.code.equals("200")) {
            runOnUiThread(new C04199());
        } else if (dm.result.equals("0")) {
            new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_IS_LOGIN).putString(PreferenceAction.IS_LOGIN, "yes");
            PreferenceAction pref1 = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_PROFILE);
            pref1.putString(PreferenceAction.MY_EMAIL, this.email);
            pref1.putString(PreferenceAction.MY_PASSWORD, this.password);
            new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_GCM).putString(PreferenceAction.GCM_REGISTRED_ID, this.registration_id);
            this.logCat.log(className, "-----email", this.email);
            new SyncProfileDevice(this.mContext, null).start();
            finish();
        } else {
            runOnUiThread(new C04188());
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
