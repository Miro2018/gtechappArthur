package com.accumed.gtech;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.accumed.gtech.customview.CustomViewPager;
import com.accumed.gtech.fragments.OtherrecordFragment;
import com.accumed.gtech.fragments.OtherrecordFragment.OnOtherrecordListener;
import com.accumed.gtech.router.AppStatusRouter;
import com.accumed.gtech.thread.datamodel.AddOtherrecordReturnDM;
import com.accumed.gtech.thread.datamodel.ModOtherrecordReturnDM;
import com.accumed.gtech.thread.datamodel.OtherrecordThrDM;
import com.accumed.gtech.util.DBAction;
import com.accumed.gtech.util.LogCat;
import com.accumed.gtech.util.PreferenceAction;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Vector;

public class OtherrecordFragmentActivity extends FragmentActivity implements OnOtherrecordListener {
    private ArrayAdapter<String> Adapter;
    int DELETE = 102;
    int INPUT = 100;
    int PAGE_NUM;
    int UPDATE = ContainerFragmentActivity.USER_BTN;
    final String className = "OtherrecordFragmentActivity";
    List<Fragment> fragments;
    LogCat logCat = new LogCat();
    int mAppStatus;
    Context mContext;
    PagerAdapter otherrecordPagerAp;
    Button otherrecord_btn_cancel;
    Button otherrecord_btn_complete;
    Button otherrecord_btn_del;
    TextView otherrecord_tv_unit_02;
    TextView otherrecord_tv_unit_03;
    CustomViewPager pager;
    ArrayList<OtherrecordThrDM> recordDMList;
    private ListView recordList;
    ArrayList<String> titles = new ArrayList();

    class C02021 implements OnClickListener {
        C02021() {
        }

        public void onClick(View arg0) {
            OtherrecordFragmentActivity.this.finish();
        }
    }

    class C02032 implements OnClickListener {
        C02032() {
        }

        public void onClick(View arg0) {
            if (OtherrecordFragmentActivity.this.PAGE_NUM == 0) {
                OtherrecordFragment f = (OtherrecordFragment) OtherrecordFragmentActivity.this.fragments.get(OtherrecordFragmentActivity.this.PAGE_NUM);
                f.setPageNum(OtherrecordFragmentActivity.this.PAGE_NUM);
                f.actionDefine(OtherrecordFragment.INPUT);
                return;
            }
            f = (OtherrecordFragment) OtherrecordFragmentActivity.this.fragments.get(OtherrecordFragmentActivity.this.PAGE_NUM);
            f.setPageNum(OtherrecordFragmentActivity.this.PAGE_NUM);
            f.actionDefine(OtherrecordFragment.UPDATE);
        }
    }

    class C02063 implements OnClickListener {

        class C02041 implements DialogInterface.OnClickListener {
            C02041() {
            }

            public void onClick(DialogInterface arg0, int arg1) {
            }
        }

        class C02052 implements DialogInterface.OnClickListener {
            C02052() {
            }

            public void onClick(DialogInterface arg0, int arg1) {
                ((OtherrecordFragment) OtherrecordFragmentActivity.this.fragments.get(OtherrecordFragmentActivity.this.PAGE_NUM)).actionDefine(OtherrecordFragment.DELETE);
            }
        }

        C02063() {
        }

        public void onClick(View arg0) {
            if (OtherrecordFragmentActivity.this.PAGE_NUM != 0) {
                new Builder(OtherrecordFragmentActivity.this).setTitle(OtherrecordFragmentActivity.this.getString(C0213R.string.alert_title)).setMessage(OtherrecordFragmentActivity.this.getString(C0213R.string.alert_type21)).setPositiveButton(OtherrecordFragmentActivity.this.getString(C0213R.string.btn_ok), new C02052()).setNegativeButton(OtherrecordFragmentActivity.this.getString(C0213R.string.btn_cancel), new C02041()).show();
            }
        }
    }

    class C02094 implements OnItemClickListener {

        class C02071 implements Runnable {
            C02071() {
            }

            public void run() {
                OtherrecordFragmentActivity.this.otherrecord_btn_del.setVisibility(8);
                OtherrecordFragmentActivity.this.otherrecord_btn_complete.setVisibility(0);
                OtherrecordFragmentActivity.this.otherrecord_btn_complete.setText(OtherrecordFragmentActivity.this.getString(C0213R.string.btn_save));
            }
        }

        class C02082 implements Runnable {
            C02082() {
            }

            public void run() {
                OtherrecordFragmentActivity.this.otherrecord_btn_del.setVisibility(0);
                OtherrecordFragmentActivity.this.otherrecord_btn_complete.setVisibility(0);
                OtherrecordFragmentActivity.this.otherrecord_btn_complete.setText(OtherrecordFragmentActivity.this.getString(C0213R.string.btn_modify));
            }
        }

        C02094() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            OtherrecordFragmentActivity.this.recordList.setVisibility(8);
            OtherrecordFragmentActivity.this.otherrecordPagerAp = new PagerAdapter(OtherrecordFragmentActivity.this.getSupportFragmentManager(), OtherrecordFragmentActivity.this.fragments, null);
            OtherrecordFragmentActivity.this.pager = (CustomViewPager) OtherrecordFragmentActivity.this.findViewById(C0213R.id.viewPager);
            OtherrecordFragmentActivity.this.pager.setAdapter(OtherrecordFragmentActivity.this.otherrecordPagerAp);
            OtherrecordFragmentActivity.this.pager.setCurrentItem(position);
            OtherrecordFragmentActivity.this.pager.setPagingDisabled();
            OtherrecordFragmentActivity.this.PAGE_NUM = position;
            ((OtherrecordFragment) OtherrecordFragmentActivity.this.fragments.get(OtherrecordFragmentActivity.this.PAGE_NUM)).setPageNum(OtherrecordFragmentActivity.this.PAGE_NUM);
            if (position == 0) {
                OtherrecordFragmentActivity.this.runOnUiThread(new C02071());
            } else {
                OtherrecordFragmentActivity.this.runOnUiThread(new C02082());
            }
        }
    }

    class C02115 implements Runnable {

        class C02101 implements Runnable {
            C02101() {
            }

            public void run() {
                if (OtherrecordFragmentActivity.this.Adapter != null) {
                    OtherrecordFragmentActivity.this.Adapter.notifyDataSetChanged();
                }
            }
        }

        C02115() {
        }

        public void run() {
            OtherrecordFragmentActivity.this.runOnUiThread(new C02101());
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(C0213R.layout.otherrecord);
        this.mContext = getApplicationContext();
        this.recordDMList = new ArrayList();
        try {
            this.PAGE_NUM = getIntent().getIntExtra("PAGE_NUM", 0);
        } catch (Exception e) {
        }
        this.otherrecord_btn_cancel = (Button) findViewById(C0213R.id.otherrecord_btn_cancel);
        this.otherrecord_btn_complete = (Button) findViewById(C0213R.id.otherrecord_btn_complete);
        this.otherrecord_btn_del = (Button) findViewById(C0213R.id.otherrecord_btn_del);
        this.otherrecord_btn_del.setVisibility(8);
        this.otherrecord_btn_complete.setVisibility(8);
        this.otherrecord_btn_del.setVisibility(4);
        this.otherrecord_btn_cancel.setOnClickListener(new C02021());
        this.otherrecord_btn_complete.setOnClickListener(new C02032());
        this.otherrecord_btn_del.setOnClickListener(new C02063());
        init();
    }

    private void init() {
        ArrayList<String> titles = new ArrayList();
        titles.add(getString(C0213R.string.otherrecord_new));
        OtherrecordFragment fr0 = (OtherrecordFragment) Fragment.instantiate(this, OtherrecordFragment.class.getName());
        fr0.setPageNum(0);
        this.fragments = new Vector();
        this.fragments.add(fr0);
        this.recordDMList = new DBAction(this.mContext).otherrecordSelect();
        for (int i = 0; i < this.recordDMList.size(); i++) {
            OtherrecordFragment frs = (OtherrecordFragment) Fragment.instantiate(this, OtherrecordFragment.class.getName());
            frs.setPageNum(i);
            frs.setSeq(((OtherrecordThrDM) this.recordDMList.get(i)).seq);
            this.fragments.add(frs);
            titles.add(((OtherrecordThrDM) this.recordDMList.get(i)).odate);
        }
        this.Adapter = new ArrayAdapter(this, C0213R.layout.otherrecord_list, titles);
        this.recordList = (ListView) findViewById(C0213R.id.list);
        this.recordList.setAdapter(this.Adapter);
        this.recordList.setOnItemClickListener(new C02094());
        this.Adapter.notifyDataSetChanged();
    }

    private void restartAfterInput() {
        refreshAdapter();
        Intent intent = new Intent(this, OtherrecordFragmentActivity.class);
        intent.putExtra("PAGE_NUM", 1);
        startActivity(intent);
        finish();
    }

    private void restartAfterDelete() {
        refreshAdapter();
        Intent intent = new Intent(this, OtherrecordFragmentActivity.class);
        intent.putExtra("PAGE_NUM", 0);
        startActivity(intent);
        finish();
    }

    private void restartAfterUpdate() {
        refreshAdapter();
        Intent intent = new Intent(this, OtherrecordFragmentActivity.class);
        intent.putExtra("PAGE_NUM", this.PAGE_NUM);
        startActivity(intent);
        finish();
    }

    private void refreshAdapter() {
        new Thread(new C02115()).start();
    }

    private void actionDefine(int gubun) {
        switch (this.mAppStatus) {
            case 0:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_x");
                return;
            case 1:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_x");
                if (gubun == this.INPUT) {
                    restartAfterInput();
                    return;
                } else if (gubun == this.UPDATE) {
                    restartAfterUpdate();
                    return;
                } else if (gubun == this.DELETE) {
                    restartAfterDelete();
                    return;
                } else {
                    return;
                }
            case 5:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_x");
                if (gubun == this.INPUT) {
                    restartAfterInput();
                    return;
                } else if (gubun == this.UPDATE) {
                    restartAfterUpdate();
                    return;
                } else if (gubun == this.DELETE) {
                    restartAfterDelete();
                    return;
                } else {
                    return;
                }
            case 10:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_x");
                if (gubun == this.INPUT) {
                    restartAfterInput();
                    return;
                } else if (gubun == this.UPDATE) {
                    restartAfterUpdate();
                    return;
                } else if (gubun == this.DELETE) {
                    restartAfterDelete();
                    return;
                } else {
                    return;
                }
            case 14:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_x");
                if (gubun == this.INPUT) {
                    restartAfterInput();
                    return;
                } else if (gubun == this.UPDATE) {
                    restartAfterUpdate();
                    return;
                } else if (gubun == this.DELETE) {
                    restartAfterDelete();
                    return;
                } else {
                    return;
                }
            case 17:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_x_NETWORK_o");
                if (gubun == this.INPUT) {
                    restartAfterInput();
                    return;
                } else if (gubun == this.UPDATE) {
                    restartAfterUpdate();
                    return;
                } else if (gubun == this.DELETE) {
                    restartAfterDelete();
                    return;
                } else {
                    return;
                }
            case 21:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_x_NETWORK_o");
                if (gubun == this.INPUT) {
                    restartAfterInput();
                    return;
                } else if (gubun == this.UPDATE) {
                    restartAfterUpdate();
                    return;
                } else if (gubun == this.DELETE) {
                    restartAfterDelete();
                    return;
                } else {
                    return;
                }
            case 26:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_o_DEVICE_x_LOGIN_o_NETWORK_o");
                if (gubun == this.INPUT) {
                    restartAfterInput();
                    return;
                } else if (gubun == this.UPDATE) {
                    restartAfterUpdate();
                    return;
                } else if (gubun == this.DELETE) {
                    restartAfterDelete();
                    return;
                } else {
                    return;
                }
            case 30:
                this.logCat.log("OtherrecordFragmentActivity", "actionDefine()", "FIRSTUSE_o_DEVICE_o_LOGIN_o_NETWORK_o");
                if (gubun == this.INPUT) {
                    ((OtherrecordFragment) this.fragments.get(this.PAGE_NUM)).actionDefine(OtherrecordFragment.INPUT);
                    return;
                } else if (gubun == this.UPDATE) {
                    ((OtherrecordFragment) this.fragments.get(this.PAGE_NUM)).actionDefine(OtherrecordFragment.UPDATE);
                    return;
                } else if (gubun != this.DELETE) {
                    return;
                } else {
                    return;
                }
            default:
                return;
        }
    }

    private void checkAppStatus() {
        this.mAppStatus = new AppStatusRouter(this.mContext).getAppStatus();
    }

    public void onAddData() {
        this.logCat.log("OtherrecordFragmentActivity", "onAddData()", "in");
        checkAppStatus();
    }

    public void onAddDataSend(Object resultObj, OtherrecordThrDM dm) {
        this.logCat.log("OtherrecordFragmentActivity", "onAddDataSend()", "in");
        AddOtherrecordReturnDM addOtherrecordReturnDM = (AddOtherrecordReturnDM) resultObj;
        if (addOtherrecordReturnDM.code.equals("200")) {
            new DBAction(this.mContext).updateOtherrecord_updateFlag_id(dm.seq, addOtherrecordReturnDM.id);
        }
        restartAfterInput();
    }

    public void onUpdateData() {
        this.logCat.log("OtherrecordFragmentActivity", "onUpdateData()", "in");
        checkAppStatus();
    }

    public void onUpdateDataSend(Object resultObj, OtherrecordThrDM dm) {
        this.logCat.log("OtherrecordFragmentActivity", "onUpdateDataSend()", "in");
        if (((ModOtherrecordReturnDM) resultObj).code.equals("200")) {
            new DBAction(this.mContext).updateOtherrecord_updateFlag(dm.seq);
        }
        restartAfterUpdate();
    }

    public void onDelData() {
        this.logCat.log("OtherrecordFragmentActivity", "onDelData()", "in");
        checkAppStatus();
    }

    public void onDelDataSend(Object resultObj, OtherrecordThrDM dm) {
        this.logCat.log("OtherrecordFragmentActivity", "onDelDataSend()", "in");
        restartAfterDelete();
    }

    public void onRestartAfterInput() {
        restartAfterInput();
    }

    public void onRestartAfterUpdate() {
        restartAfterUpdate();
    }

    public void onRestartAfterDelete() {
        onRestartAfterDelete();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }

    public void onBackPressed() {
        if (this.recordList.getVisibility() != 0) {
            this.recordList.setVisibility(0);
            this.otherrecord_btn_complete.setVisibility(8);
            this.otherrecord_btn_del.setVisibility(4);
            return;
        }
        super.onBackPressed();
    }
}
