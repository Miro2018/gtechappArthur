package com.accumed.gtech;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.accumed.gtech.pinchzoom.GestureImageView;
import com.accumed.gtech.util.PreferenceAction;
import java.util.Locale;

public class IndiaPurchase extends Activity {
    Button mBtnCall;
    Button mBtnPrev;
    Context mContext;
    GestureImageView view;
    GestureImageView view2;

    class C01991 implements OnClickListener {
        C01991() {
        }

        public void onClick(View v) {
            IndiaPurchase.this.finish();
        }
    }

    class C02012 implements OnClickListener {

        class C02001 implements DialogInterface.OnClickListener {
            C02001() {
            }

            public void onClick(DialogInterface dialog, int index) {
                if (index == 0) {
                    IndiaPurchase.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:1800-10-23105")));
                } else {
                    IndiaPurchase.this.startActivity(new Intent("android.intent.action.DIAL", Uri.parse("tel:+91-124-4540908")));
                }
            }
        }

        C02012() {
        }

        public void onClick(View v) {
            CharSequence[] items = new CharSequence[]{"1800-10-23105", "+91-124-4540908"};
            Builder builder = new Builder(IndiaPurchase.this);
            builder.setTitle(C0213R.string.select_num).setItems(items, new C02001());
            builder.create().show();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0213R.layout.india_purchase);
        this.mContext = getApplicationContext();
        this.mBtnPrev = (Button) findViewById(C0213R.id.india_btn_prev);
        this.mBtnPrev.setOnClickListener(new C01991());
        this.mBtnCall = (Button) findViewById(C0213R.id.india_btn_call);
        this.mBtnCall.setOnClickListener(new C02012());
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        localeEvent();
    }

    private void localeEvent() {
        PreferenceAction prefLang = new PreferenceAction(this.mContext, PreferenceAction.PREF_NAME_MY_SETTING);
        if (!prefLang.getString(PreferenceAction.MY_LANGUAGE).equals("") && prefLang.getString(PreferenceAction.MY_LANGUAGE) != null) {
            Locale locale = new Locale(prefLang.getString(PreferenceAction.MY_LANGUAGE));
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
